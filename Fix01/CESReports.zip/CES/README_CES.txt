CES (ASP.NET Core 8) - Front-end skeleton
-----------------------------------------

What this project contains:
- Controllers/ReportsController.cs : simple controller with Index and View actions
- Views/Reports/View.cshtml : iframe that loads report from ReportHost
- appsettings.json : configure ReportHost:BaseUrl (default http://localhost:5005)

How to use:
1) Edit CES/appsettings.json "ReportHost:BaseUrl" to point to your Report Host (http://localhost:5005 by default).
2) Run your CES ASP.NET Core app (dotnet run) and navigate to /Reports to see links.
3) Click a report link to load the report in an iframe. The iframe points to the ReportHost API:
   {ReportHostBase}/api/reports/pdf?name=Invoice&param1=123

Note:
- The CES project assumes the ReportHost is running and accessible.
- If you host the ReportHost on HTTPS or different port, change the BaseUrl in appsettings.json.