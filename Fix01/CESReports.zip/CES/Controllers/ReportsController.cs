using Microsoft.AspNetCore.Mvc;

namespace CES.Controllers
{
    public class ReportsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        // /Reports/View?name=Invoice&param1=123
        public IActionResult View(string name, string param1)
        {
            ViewData["ReportName"] = name;
            ViewData["Param1"] = param1;
            return View();
        }
    }
}