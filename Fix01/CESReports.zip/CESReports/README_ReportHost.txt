CESReports (Report Host) - .NET Framework 4.8 Web API skeleton
-------------------------------------------------------------

What this project contains:
- /Controllers/ReportsController.cs : API endpoint to render / export .rpt -> PDF
- /Reports : put your .rpt files here
- Web.config : appSettings has DbServer/DbName/DbUser/DbPassword and ReportHostPort

Important steps before running:
1) Install SAP Crystal Reports .NET Runtime (CRRuntime_64bit_13_0_xxx.msi) on the machine.
   The runtime provides CrystalDecisions.* assemblies. Without it the project will fail to load reports.

2) In Visual Studio, open CESReports.csproj (TargetFramework net48). Add References to the following DLLs:
   - CrystalDecisions.CrystalReports.Engine.dll
   - CrystalDecisions.Shared.dll
   - CrystalDecisions.ReportSource.dll
   - CrystalDecisions.ReportAppServer.ClientDoc.dll
   These DLLs are located (after runtime install) under:
   C:\\Program Files (x86)\\SAP BusinessObjects\\Crystal Reports for .NET Framework 4.0\\assemblies\\v4.0\\

3) Copy your .rpt files into the /Reports folder. Example: Reports\\Invoice.rpt

4) Edit Web.config appSettings to set your SQL Server connection and (optionally) ReportHostPort.

5) Run the project in IIS or IIS Express. The API endpoint:
   http://localhost:{ReportHostPort}/api/reports/pdf?name=Invoice&param1=123

Security note:
- This skeleton does not include authentication. In production secure the API (Windows Auth, JWT, client certs, etc).