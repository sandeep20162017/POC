using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CESReports.Controllers
{
    [RoutePrefix("api/reports")]
    public class ReportsController : ApiController
    {
        // GET api/reports/pdf?name=Invoice&param1=123
        [HttpGet, Route("pdf")]
        public HttpResponseMessage GetPdf(string name, string param1 = null)
        {
            var reportPath = System.Web.Hosting.HostingEnvironment.MapPath($"~/Reports/{name}.rpt");
            if (!System.IO.File.Exists(reportPath))
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "Report not found: " + name);
            }

            var report = new ReportDocument();
            try
            {
                report.Load(reportPath);

                // --- Configure SQL Server connection (edit appSettings/Web.config or hardcode here)
                var connInfo = new ConnectionInfo
                {
                    ServerName = System.Configuration.ConfigurationManager.AppSettings["DbServer"],
                    DatabaseName = System.Configuration.ConfigurationManager.AppSettings["DbName"],
                    UserID = System.Configuration.ConfigurationManager.AppSettings["DbUser"],
                    Password = System.Configuration.ConfigurationManager.AppSettings["DbPassword"]
                };

                foreach (CrystalDecisions.CrystalReports.Engine.Table table in report.Database.Tables)
                {
                    var logOn = table.LogOnInfo;
                    logOn.ConnectionInfo = connInfo;
                    table.ApplyLogOnInfo(logOn);
                }

                // Subreports
                foreach (ReportDocument sub in report.Subreports)
                {
                    foreach (CrystalDecisions.CrystalReports.Engine.Table t in sub.Database.Tables)
                    {
                        var logOn = t.LogOnInfo;
                        logOn.ConnectionInfo = connInfo;
                        t.ApplyLogOnInfo(logOn);
                    }
                }

                // Parameters (example)
                if (!string.IsNullOrEmpty(param1))
                {
                    try { report.SetParameterValue("param1", param1); } catch { /* ignore if parameter not present */ }
                }

                var stream = report.ExportToStream(ExportFormatType.PortableDocFormat);
                stream.Position = 0;

                var response = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StreamContent(stream)
                };
                response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
                response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("inline")
                {
                    FileName = name + ".pdf"
                };
                return response;
            }
            finally
            {
                report.Close();
                report.Dispose();
            }
        }
    }
}