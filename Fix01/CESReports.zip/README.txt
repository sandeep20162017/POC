CES + CESReports - ZIP skeleton

Structure:
- CES/     -> ASP.NET Core 8 UI (skeleton)
- CESReports/ -> ASP.NET Framework 4.8 Report Host (skeleton)

Before you run:
1) Install SAP Crystal Reports .NET Runtime on the Report Host machine.
2) Add references (in Visual Studio) to CrystalDecisions.* assemblies in the CESReports project.
3) Copy your .rpt files into CESReports/Reports.
4) Edit CESReports/Web.config appSettings to set DbServer/DbName/DbUser/DbPassword.
5) Run CESReports in IIS/IIS Express on port configured in Web.config (default 5005).
6) Update CES/appsettings.json ReportHost:BaseUrl if the ReportHost is not at http://localhost:5005.

Security:
- This is a minimal skeleton and does not include authentication. Protect the report endpoints in production.