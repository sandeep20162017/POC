-- =============================================================
-- 001_UserLoginTracking_Rollback.sql
-- Removes the user tracking tables and indexes.
-- WARNING: this permanently deletes all tracked data.
-- =============================================================

DROP INDEX IF EXISTS [IX_UserActivityLog_VisitDateTime]            ON [SBCES].[UserActivityLog]
GO
DROP INDEX IF EXISTS [IX_UserActivityLog_UserID_VisitDateTime]     ON [SBCES].[UserActivityLog]
GO
DROP INDEX IF EXISTS [IX_UserLoginHistory_LoginDateTime]           ON [SBCES].[UserLoginHistory]
GO
DROP INDEX IF EXISTS [IX_UserLoginHistory_UserID_LoginDateTime]    ON [SBCES].[UserLoginHistory]
GO

DROP TABLE IF EXISTS [SBCES].[UserActivityLog]
GO
DROP TABLE IF EXISTS [SBCES].[UserLoginHistory]
GO
