-- =============================================================
-- 001_UserLoginTracking.sql
-- Creates tables to track user logins and page/link visits.
-- Run once per environment (Dev -> QA -> Prod).
-- =============================================================

-- Login events
CREATE TABLE [SBCES].[UserLoginHistory](
    [LoginHistoryId] [int] IDENTITY(1,1) NOT NULL,
    [UserID]         [int] NOT NULL,
    [LoginDateTime]  [datetime] NOT NULL,
    [IPAddress]      [varchar](45) NULL,
    [UserAgent]      [varchar](500) NULL,
    CONSTRAINT [PK_UserLoginHistory] PRIMARY KEY CLUSTERED ([LoginHistoryId] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF,
              ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
    CONSTRAINT [FK_UserLoginHistory_Users] FOREIGN KEY ([UserID])
        REFERENCES [SBCES].[Users] ([UserID])
) ON [PRIMARY]
GO

-- Page / link visits
CREATE TABLE [SBCES].[UserActivityLog](
    [ActivityLogId]  [int] IDENTITY(1,1) NOT NULL,
    [UserID]         [int] NOT NULL,
    [VisitDateTime]  [datetime] NOT NULL,
    [RequestUrl]     [varchar](2000) NOT NULL,
    [HttpMethod]     [varchar](10) NULL,
    [ControllerName] [varchar](100) NULL,
    [ActionName]     [varchar](100) NULL,
    [IPAddress]      [varchar](45) NULL,
    CONSTRAINT [PK_UserActivityLog] PRIMARY KEY CLUSTERED ([ActivityLogId] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF,
              ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
    CONSTRAINT [FK_UserActivityLog_Users] FOREIGN KEY ([UserID])
        REFERENCES [SBCES].[Users] ([UserID])
) ON [PRIMARY]
GO

-- Indexes for the report queries
CREATE NONCLUSTERED INDEX [IX_UserLoginHistory_UserID_LoginDateTime]
    ON [SBCES].[UserLoginHistory] ([UserID], [LoginDateTime] DESC)
GO
CREATE NONCLUSTERED INDEX [IX_UserLoginHistory_LoginDateTime]
    ON [SBCES].[UserLoginHistory] ([LoginDateTime] DESC)
GO
CREATE NONCLUSTERED INDEX [IX_UserActivityLog_UserID_VisitDateTime]
    ON [SBCES].[UserActivityLog] ([UserID], [VisitDateTime] DESC)
GO
CREATE NONCLUSTERED INDEX [IX_UserActivityLog_VisitDateTime]
    ON [SBCES].[UserActivityLog] ([VisitDateTime] DESC)
GO
