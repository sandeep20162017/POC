# CES – User Login & Page Visit Tracking

Records every user login and every page/link visit (with date and time) in the CES database,
and adds an admin report to view it. Target: ASP.NET Core 10.0, Dapper, Telerik/Kendo UI for ASP.NET Core.

## What gets tracked

| Table | One row per | Columns |
|---|---|---|
| `SBCES.UserLoginHistory` | login (new browser session) | UserID, LoginDateTime, IPAddress, UserAgent |
| `SBCES.UserActivityLog` | page/link visit | UserID, VisitDateTime, RequestUrl, HttpMethod, ControllerName, ActionName, IPAddress |

## Files in this package

```
Database/
  001_UserLoginTracking.sql             create tables + indexes
  001_UserLoginTracking_Rollback.sql    drop them again
Models/Admin/
  UserActivityReportModels.cs           grid row + drop-down models        (NEW)
Controllers/Admin/
  UserActivityReportController.cs       report page, lookups, grid data     (NEW)
Controllers/Base/
  BaseController_Changes.txt            3 edits to the existing BaseController
Views/Admin/
  UserActivityReport.cshtml             report view, all JS inline          (NEW)
Views/Shared/
  _Layout_Changes.txt                   1 edit: Administration menu item
```

## Install steps

1. **Database** – run `Database/001_UserLoginTracking.sql` against the CES database (Dev first).
2. **Model** – copy `Models/Admin/UserActivityReportModels.cs` into your project's `Models/Admin` folder.
3. **Controller** – copy `Controllers/Admin/UserActivityReportController.cs` into `Controllers/Admin`.
4. **View** – copy `Views/Admin/UserActivityReport.cshtml` into `Views/Admin`.
5. **BaseController** – apply the 3 edits in `Controllers/Base/BaseController_Changes.txt`.
6. **Menu** – apply the edit in `Views/Shared/_Layout_Changes.txt`.
7. Build and run. Browse a few pages, then open **Administration → User Activity Report**.

## Things to adjust to your project

* **Namespaces** – controller uses `BCES.Controller.Admin`, models use `BCES.Models.Admin`.
  The view's first line (`@using BCES.Models.Admin`) must match the model namespace.
* **Controller constructor** – `UserActivityReportController` passes `IDbConnection` and
  `IHttpContextAccessor` to `BaseController`. Match the constructor of your other controllers.
  It assumes `_dbConnection` and `_httpContextAccessor` are `protected` in `BaseController`.
* **Role check** – the report is limited to `RoleId` 1, 2 and 3 (same as the Administration menu). This assumes
  `SBCES.Users` has a `RoleId` column; edit `IsReportAdmin()` if the role lives elsewhere.
* **Views location** – the view is in `Views/Admin`, but the controller is `UserActivityReportController`,
  so `Index()` returns the view by full path (`~/Views/Admin/UserActivityReport.cshtml`).
* **Kendo setup** – needs `Kendo.Mvc` services, the Kendo scripts/styles and `@addTagHelper *, Kendo.Mvc`
  already in your project (they are, since the rest of CES uses Kendo).

## Behaviour notes

* **Login** is recorded once per browser session (session key `UserLoginTracked`). After a session timeout,
  the next request records a new login.
* **Page visits** are recorded for normal page requests. AJAX calls (grid reads, lookups) and the report
  itself are skipped so the log does not fill up with noise. To also log AJAX calls, remove the
  `X-Requested-With` check in `TrackPageVisit`.
* Tracking never blocks a request: any failure is written to `SBCES.ErrorLog` and the user continues.
* Paging, sorting and filtering for both grids happen in SQL (`OFFSET/FETCH`), so large logs stay fast.
  Sorting columns are whitelisted; no client text is concatenated into SQL.
* The grid JSON is serialized with PascalCase names regardless of your global JSON settings.
* Excel export was intentionally left out.

## Data retention

`UserActivityLog` grows with every page view. Consider a scheduled job to purge old rows, for example:

```sql
DELETE FROM [SBCES].[UserActivityLog] WHERE [VisitDateTime] < DATEADD(month, -12, GETDATE());
```

## Rollback

Run `Database/001_UserLoginTracking_Rollback.sql` (deletes the tables and all tracked data), then revert the
BaseController, `_Layout.cshtml` edits and delete the new files.
