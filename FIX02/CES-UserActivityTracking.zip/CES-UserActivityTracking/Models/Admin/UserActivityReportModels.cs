using System;

// NOTE: adjust the namespace to match your project's root namespace (e.g. BCES.Models.Admin).
namespace BCES.Models.Admin
{
    /// <summary>One row in the "Login History" grid.</summary>
    public class LoginHistoryRowModel
    {
        public int LoginHistoryId { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public DateTime LoginDateTime { get; set; }
        public string IPAddress { get; set; }
        public string UserAgent { get; set; }
    }

    /// <summary>One row in the "Page Visit Activity" grid.</summary>
    public class ActivityLogRowModel
    {
        public int ActivityLogId { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public DateTime VisitDateTime { get; set; }
        public string ControllerName { get; set; }
        public string ActionName { get; set; }
        public string HttpMethod { get; set; }
        public string RequestUrl { get; set; }
        public string IPAddress { get; set; }
    }

    /// <summary>Item for the "User" drop-downs.</summary>
    public class UserLookupItem
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
    }

    /// <summary>Item for the "Controller" drop-down.</summary>
    public class ControllerLookupItem
    {
        public string ControllerName { get; set; }
    }

    /// <summary>Item for the "Action" drop-down.</summary>
    public class ActionLookupItem
    {
        public string ActionName { get; set; }
    }
}
