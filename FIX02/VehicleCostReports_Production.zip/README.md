# Vehicle Cost Reports - Production Package

## Files

- `Views/TotalCost/_VehicleTotalCost.cshtml`
  - Drop-in Razor partial replacing the existing `_VehicleTotalCost.cshtml`.
  - Provides the three-dots report menu with all 8 requested actions.
  - No PNG action is included.

- `wwwroot/css/vehicle-cost-reports.css`
  - Shared report styling.
  - UI preserves the supplied visual design language.
  - PDF/print styling is intentionally monochrome for black-and-white printers.

- `wwwroot/js/vehicle-cost-reports.js`
  - Data loading, report population, four report variants, clipboard HTML copy and Kendo PDF export.
  - Uses the existing endpoint:
    `TotalCost/GetTotalCostInEstimates?id={PartNum}&gridType={GridType}`

## Report variants

1. Vehicle Estimate Report
   - Header
   - Vehicle Details
   - Material Cost Summary
   - Material/Labour cost summary
   - Totals and Grand Total
   - Modified By / Modified Date
   - Footer

2. Labour Details Report
   - Header
   - Labour Hours Summary
   - Labour Task Summary
   - Labour Cost
   - Modified By / Modified Date
   - Footer

3. Materials Estimate Report
   - Header
   - Material Cost Summary
   - Material line detail
   - Material Cost
   - Modified By / Modified Date
   - Footer

4. Full Vehicle Estimate Report
   - Existing complete report: all sections.

Each report has both:
- Copy to Clipboard
- Save as PDF

## Required dependencies

The page must already load:
- jQuery
- Telerik/Kendo UI for ASP.NET Core JavaScript
- Kendo drawing/PDF export support
- `kendo.saveAs`

The existing application layout normally supplies jQuery/Kendo. The partial only references the two new static files.

## Important implementation notes

- PNG export has been completely removed.
- Clipboard copy writes `text/html` plus `text/plain` when the browser supports `ClipboardItem`, allowing the report to paste into Outlook, Word and similar applications as formatted content.
- A browser fallback uses `document.execCommand("copy")`.
- PDF export renders a real, measurable export host rather than a `display:none` or collapsed element. This specifically avoids the blank/zero-dimension Kendo drawDOM failure mode seen with hidden clones.
- The export host is off-screen but remains layout-visible (`visibility:visible`, non-zero width/height).
- The PDF is Letter landscape with multi-page support.
- The PDF/print representation uses monochrome styling so it remains readable on black-and-white printers.
- HTML escaping is applied to dynamic table data before it is inserted into the DOM.

## Installation

1. Back up the current `_VehicleTotalCost.cshtml`.
2. Copy the supplied CSS to:
   `wwwroot/css/vehicle-cost-reports.css`
3. Copy the supplied JS to:
   `wwwroot/js/vehicle-cost-reports.js`
4. Replace the existing partial with:
   `Views/TotalCost/_VehicleTotalCost.cshtml`
5. Clear browser cache/rebuild the application.
6. Open the Vehicle Cost Estimate tab and click the three-dots button.

## Expected API contract

The existing endpoint is expected to return the same shape used by the supplied page:

```json
{
  "Data": [
    {
      "VehicleSeries": "...",
      "VehicleDescription": "...",
      "Make": "...",
      "Model": "...",
      "Year": 2023,
      "NumOfVehicles": 10,
      "Engine": "...",
      "Transmission": "...",
      "Differential": "...",
      "ModifiedLastBy": "...",
      "ModifiedLastDate": "...",
      "TotalStockPartsCount": 1,
      "TotalNonStockPartsCount": 1,
      "TotalRebuiltPartsCount": 0,
      "SCPartsMaterialCost": 442.40,
      "NSCSCPartsMaterialCost": 90.00,
      "RBPartsMaterialCost": 0,
      "MaterialTotalCostNoTax": 532.40,
      "MaterialTotalTaxAmount": 6.02,
      "MaterialTotalWithTax": 538.42,
      "LabourFringe": 552.50,
      "LabourBenefits": 654.33,
      "BlendedFringeBenefitCost": 1206.83,
      "LabourOverhead": 790.83,
      "FinalLabourCost": 3081.00,
      "TotalLabourHours": 0,
      "TotalEffectiveHours": 0,
      "TotalAdjustedHours": 0,
      "MaterialLines": [],
      "LabourTasks": []
    }
  ]
}
```

The actual endpoint and field names were preserved from the supplied source; no controller/database changes are required by this package.
