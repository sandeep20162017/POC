(function ($, kendo) {
    "use strict";

    window.VehicleCostReports = {
        init: init
    };

    function init(options) {
        options = options || {};
        var root = document.getElementById(options.rootId || "vehicleCostReports");
        if (!root) return;

        var partNum = String(options.partNum || root.getAttribute("data-part-num") || "");
        var gridType = String(options.gridType || root.getAttribute("data-grid-type") || "");
        var dataUrl = String(options.dataUrl || root.getAttribute("data-data-url") || "");

        var state = {
            partNum: partNum,
            gridType: gridType,
            dataUrl: dataUrl,
            costData: null,
            generated: root.getAttribute("data-generated") || new Date().toLocaleString()
        };

        bindMenu(root, state);
        bindRetry(root, state);
        fetchData(root, state);
    }

    function bindMenu(root, state) {
        var menu = $("#" + root.id + "Menu");
        var button = $("#" + root.id + "Actions");

        if (!menu.length || !button.length || !$.fn.kendoContextMenu) {
            console.error("VehicleCostReports: Kendo ContextMenu is unavailable.");
            return;
        }

        menu.kendoContextMenu({
            target: "#" + root.id + "Actions",
            showOn: "click",
            alignToAnchor: true,
            select: function (e) {
                var action = $(e.item).attr("data-report-action");
                if (!action) return;

                if (action.indexOf("copy-") === 0) {
                    copyReport(root, state, action.substring(5));
                } else if (action.indexOf("pdf-") === 0) {
                    savePdf(root, state, action.substring(4));
                }
            }
        });

        button.attr("aria-label", "Vehicle estimate report actions");
    }

    function bindRetry(root, state) {
        $("#" + root.id + "Retry").on("click", function () {
            showLoading(root);
            fetchData(root, state);
        });
    }

    function fetchData(root, state) {
        if (!state.dataUrl) {
            showError(root, "The Total Cost data URL was not supplied.");
            return;
        }

        console.log("VehicleCostReports: fetching", state.dataUrl);

        $.ajax({
            url: state.dataUrl,
            type: "GET",
            dataType: "json",
            timeout: 30000
        }).done(function (response) {
            if (response && Array.isArray(response.Data) && response.Data.length) {
                state.costData = response.Data[0];
                populate(root, state);
                $("#" + root.id + "Loading").hide();
                $("#" + root.id + "Content").show();
                $("#" + root.id + "NoData").hide();
            } else {
                showError(root, "No cost data found for Estimate ID: " + state.partNum);
            }
        }).fail(function (xhr, status, error) {
            console.error("VehicleCostReports data error:", status, error, xhr);
            showError(root, "Unable to load cost data for Estimate ID: " + state.partNum);
        });
    }

    function populate(root, state) {
        var d = state.costData;
        text(root, "vehicleDescription", d.VehicleDescription);
        text(root, "vehicleSeries", d.VehicleSeries);
        text(root, "vehicleMake", d.Make);
        text(root, "vehicleModel", d.Model);
        text(root, "vehicleYear", integerOrDash(d.Year));
        text(root, "numberOfVehicles", integerOrDash(d.NumOfVehicles));
        text(root, "vehicleEngine", d.Engine);
        text(root, "vehicleTransmission", d.Transmission);
        text(root, "vehicleDifferential", d.Differential);
        text(root, "modifiedLastBy", d.ModifiedLastBy);
        text(root, "modifiedLastDate", dateTime(d.ModifiedLastDate));

        var stockCount = num(d.TotalStockPartsCount);
        var nonStockCount = num(d.TotalNonStockPartsCount);
        var rebuiltCount = num(d.TotalRebuiltPartsCount);

        text(root, "materialCountBadge", (stockCount + nonStockCount + rebuiltCount) + " parts");
        number(root, "stockPartsCount", stockCount);
        number(root, "nonStockPartsCount", nonStockCount);
        number(root, "rebuiltPartsCount", rebuiltCount);

        moneyText(root, "stockCost", d.SCPartsMaterialCost);
        moneyText(root, "totalNonStockCost", d.NSCSCPartsMaterialCost);
        moneyText(root, "totalRebuiltCost", d.RBPartsMaterialCost);

        populateMaterialLines(root, d.MaterialLines || []);
        number2(root, "totalHours", d.TotalLabourHours);
        number2(root, "totalEffectiveHours", d.TotalEffectiveHours);
        number2(root, "totalAdjustedHours", d.TotalAdjustedHours);
        populateLabourTasks(root, d.LabourTasks || []);

        var materialWithTax = num(d.MaterialTotalWithTax);
        var totalLabour = num(d.FinalLabourCost);
        var totalWithTax = materialWithTax + totalLabour;

        moneyText(root, "scPartsDisplay", d.SCPartsMaterialCost);
        moneyText(root, "nscPartsDisplay", d.NSCSCPartsMaterialCost);
        moneyText(root, "rbCostDisplay", d.RBPartsMaterialCost);
        moneyText(root, "partsTotalDisplay", d.MaterialTotalCostNoTax);
        moneyText(root, "materialTaxDisplay", d.MaterialTotalTaxAmount);
        moneyText(root, "materialWithTaxDisplay", materialWithTax);

        moneyText(root, "labourFringeDisplay", d.LabourFringe);
        moneyText(root, "labourBenefitsDisplay", d.LabourBenefits);
        moneyText(root, "blendedFringeCostDisplay", d.BlendedFringeBenefitCost);
        moneyText(root, "labourOverheadDisplay", d.LabourOverhead);
        moneyText(root, "totalLabourCostDisplay", totalLabour);

        moneyText(root, "totalMaterialBoxDisplay", materialWithTax);
        moneyText(root, "totalLabourBoxDisplay", totalLabour);
        moneyText(root, "totalWithTaxDisplay", totalWithTax);
    }

    function populateMaterialLines(root, lines) {
        var tbody = $("#" + root.id + "MaterialLinesBody");
        var badge = $("#" + root.id + "MaterialLinesBadge");
        badge.text(lines.length + " items");

        if (!lines.length) {
            tbody.html('<tr><td colspan="8" style="text-align:center;color:#6c757d;padding:20px;">No material items found</td></tr>');
            return;
        }

        var totals = { "Stock": 0, "Rebuilt": 0, "Non-Stock": 0 };
        var grand = 0;
        var html = "";

        lines.forEach(function (item) {
            var type = item.Type || "Stock";
            var cls = type.toLowerCase().replace("-", "");
            var cost = num(item.TotalCost);

            if (Object.prototype.hasOwnProperty.call(totals, type)) totals[type] += cost;
            grand += cost;

            html += "<tr>" +
                '<td><span class="vcr-type-badge vcr-type-' + escapeHtml(cls) + '">' + escapeHtml(type) + "</span></td>" +
                "<td>" + escapeHtml(item.StockCode || "-") + "</td>" +
                "<td>" + escapeHtml(item.CC || "-") + "</td>" +
                "<td>" + escapeHtml(item.Description || "N/A") + "</td>" +
                '<td class="text-right">' + num(item.Quantity).toFixed(2) + "</td>" +
                '<td class="text-right">' + money(num(item.UnitCost)) + "</td>" +
                '<td class="text-right">' + num(item.PercentUsage).toFixed(1) + "%</td>" +
                '<td class="text-right"><strong>' + money(cost) + "</strong></td>" +
                "</tr>";
        });

        ["Stock", "Rebuilt", "Non-Stock"].forEach(function (type) {
            if (totals[type] > 0) {
                html += '<tr class="subtotal-row">' +
                    '<td colspan="7" class="text-right">Subtotal - ' + escapeHtml(type) + "</td>" +
                    '<td class="text-right">' + money(totals[type]) + "</td></tr>";
            }
        });

        html += '<tr class="total-row">' +
            '<td colspan="7" class="text-right">GRAND TOTAL</td>' +
            '<td class="text-right">' + money(grand) + "</td></tr>";

        tbody.html(html);
    }

    function populateLabourTasks(root, tasks) {
        var tbody = $("#" + root.id + "TaskSummaryBody");
        $("#" + root.id + "TaskCountBadge").text(tasks.length + " tasks");

        if (!tasks.length) {
            tbody.html('<tr><td colspan="9" style="text-align:center;color:#6c757d;padding:20px;">No labour tasks found</td></tr>');
            return;
        }

        var h = 0, e = 0, a = 0, c = 0, html = "";

        tasks.forEach(function (task) {
            var hours = num(task.Hours);
            var effective = num(task.EffectiveHours);
            var adjusted = num(task.AdjustedHours);
            var cost = num(task.TotalCost);

            h += hours; e += effective; a += adjusted; c += cost;

            html += "<tr>" +
                "<td>" + escapeHtml(task.Task || "Unnamed") + "</td>" +
                "<td>" + escapeHtml(task.LabourDefinition || "N/A") + "</td>" +
                "<td>" + escapeHtml(task.CC || "-") + "</td>" +
                '<td class="text-right">' + hours.toFixed(2) + "</td>" +
                '<td class="text-right">' + effective.toFixed(2) + "</td>" +
                '<td class="text-right">' + adjusted.toFixed(2) + "</td>" +
                '<td class="text-right">' + money(num(task.RatePerHour)) + "</td>" +
                '<td class="text-right"><strong>' + money(cost) + "</strong></td>" +
                '<td class="text-center">' + num(task.Count) + "</td>" +
                "</tr>";
        });

        html += '<tr class="total-row">' +
            "<td colspan=\"3\"><strong>TOTAL</strong></td>" +
            '<td class="text-right"><strong>' + h.toFixed(2) + "</strong></td>" +
            '<td class="text-right"><strong>' + e.toFixed(2) + "</strong></td>" +
            '<td class="text-right"><strong>' + a.toFixed(2) + "</strong></td>" +
            "<td></td>" +
            '<td class="text-right"><strong>' + money(c) + "</strong></td>" +
            '<td class="text-center"><strong>' + tasks.length + "</strong></td>" +
            "</tr>";

        tbody.html(html);
    }

    function copyReport(root, state, type) {
        if (!state.costData) {
            alertUser("Please wait until the report has finished loading.");
            return;
        }

        var html = buildExportHtml(root, state, type);
        var title = reportTitle(type);

        if (navigator.clipboard && window.ClipboardItem) {
            var item = new ClipboardItem({
                "text/html": new Blob([html], { type: "text/html" }),
                "text/plain": new Blob([stripHtml(html)], { type: "text/plain" })
            });

            navigator.clipboard.write([item]).then(function () {
                alertUser(title + " copied to clipboard.");
            }).catch(function (err) {
                console.error("Clipboard HTML write failed:", err);
                fallbackCopy(html, title);
            });
        } else {
            fallbackCopy(html, title);
        }
    }

    function fallbackCopy(html, title) {
        var host = document.createElement("div");
        host.contentEditable = "true";
        host.style.position = "fixed";
        host.style.left = "-10000px";
        host.style.top = "0";
        host.innerHTML = html;
        document.body.appendChild(host);

        var range = document.createRange();
        range.selectNodeContents(host);
        var selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);

        try {
            document.execCommand("copy");
            alertUser(title + " copied to clipboard.");
        } catch (e) {
            console.error("Clipboard fallback failed:", e);
            alertUser("Clipboard copy is not available in this browser.");
        }

        selection.removeAllRanges();
        document.body.removeChild(host);
    }

    function savePdf(root, state, type) {
        if (!state.costData) {
            alertUser("Please wait until the report has finished loading.");
            return;
        }

        if (!kendo || !kendo.drawing || !kendo.drawing.drawDOM ||
            !kendo.drawing.exportPDF || !kendo.saveAs) {
            alertUser("Kendo PDF export is not available on this page.");
            return;
        }

        var host = document.createElement("div");
        host.className = "vcr-export-host";
        host.innerHTML = buildExportHtml(root, state, type);
        document.body.appendChild(host);

        var report = host.querySelector(".vcr-container");
        if (!report || report.offsetWidth <= 0 || report.offsetHeight <= 0) {
            host.remove();
            alertUser("Unable to prepare the report for PDF export.");
            return;
        }

        var action = root.querySelector("#" + root.id + "Actions");
        if (action) action.disabled = true;

        console.log("PDF export target:", {
            type: type,
            width: report.offsetWidth,
            height: report.offsetHeight
        });

        var request;
        try {
            request = kendo.drawing.drawDOM(report, {
                paperSize: "Letter",
                landscape: true,
                margin: { top: "0.35in", bottom: "0.35in", left: "0.35in", right: "0.35in" },
                scale: 0.78,
                multiPage: true,
                avoidLinks: true,
                keepTogether: ".vcr-audit-row, .vcr-summary-card, .vcr-cost-section"
            });
        } catch (err) {
            cleanup();
            console.error("Kendo drawDOM setup error:", err);
            alertUser("Error preparing PDF: " + safeError(err));
            return;
        }

        request.done(function (group) {
            if (!group) {
                cleanup();
                alertUser("Kendo did not return printable report content.");
                return;
            }

            var pdfRequest;
            try {
                pdfRequest = kendo.drawing.exportPDF(group, {
                    paperSize: "Letter",
                    landscape: true,
                    margin: { top: "0.35in", bottom: "0.35in", left: "0.35in", right: "0.35in" }
                });
            } catch (err) {
                cleanup();
                alertUser("Error generating PDF: " + safeError(err));
                return;
            }

            pdfRequest.done(function (dataUri) {
                cleanup();
                if (!dataUri || dataUri.length < 100) {
                    alertUser("Kendo returned an empty PDF.");
                    return;
                }

                var safeNumber = state.partNum.replace(/[^a-z0-9_.-]/gi, "_") || "Estimate";
                var filename = filePrefix(type) + "_" + safeNumber + ".pdf";

                kendo.saveAs({ dataURI: dataUri, fileName: filename });
                console.log("PDF created successfully:", filename);
            });

            pdfRequest.fail(function (err) {
                cleanup();
                console.error("Kendo exportPDF error:", err);
                alertUser("Error generating PDF: " + safeError(err));
            });
        });

        request.fail(function (err) {
            cleanup();
            console.error("Kendo drawDOM error:", err);
            alertUser("Error preparing PDF: " + safeError(err));
        });

        function cleanup() {
            if (host && host.parentNode) host.parentNode.removeChild(host);
            if (action) action.disabled = false;
        }
    }

    function buildExportHtml(root, state, type) {
        var original = root.querySelector(".vcr-container");
        if (!original) return "";

        var clone = original.cloneNode(true);
        clone.querySelectorAll(".vcr-no-print, .vcr-toolbar, .vcr-loading, .vcr-no-data").forEach(function (el) {
            el.remove();
        });

        clone.classList.add("vcr-print-root");
        clone.setAttribute("data-report-type", type);

        var sections = clone.querySelectorAll("[data-report-section]");
        sections.forEach(function (section) {
            var allowed = isSectionAllowed(type, section.getAttribute("data-report-section"));
            if (!allowed) section.remove();
        });

        var footer = clone.querySelector(".vcr-footer");
        if (footer) footer.textContent = "Estimate Generated On: " + state.generated;

        return '<div class="vcr-page">' + clone.outerHTML + "</div>";
    }

    function isSectionAllowed(type, section) {
        if (type === "vehicle") return ["header", "vehicle", "material-summary", "cost-summary", "audit", "footer"].indexOf(section) >= 0;
        if (type === "labour") return ["header", "labour-hours", "labour-tasks", "labour-cost", "audit", "footer"].indexOf(section) >= 0;
        if (type === "materials") return ["header", "material-summary", "material-lines", "material-cost", "audit", "footer"].indexOf(section) >= 0;
        return true; // full
    }

    function reportTitle(type) {
        if (type === "vehicle") return "Vehicle Estimate Report";
        if (type === "labour") return "Labour Details Report";
        if (type === "materials") return "Materials Estimate Report";
        return "Full Vehicle Estimate Report";
    }

    function filePrefix(type) {
        if (type === "vehicle") return "Vehicle_Estimate_Report";
        if (type === "labour") return "Labour_Details_Report";
        if (type === "materials") return "Materials_Estimate_Report";
        return "Full_Vehicle_Estimate_Report";
    }

    function showLoading(root) {
        $("#" + root.id + "Loading").show();
        $("#" + root.id + "Content").hide();
        $("#" + root.id + "NoData").hide();
    }

    function showError(root, message) {
        $("#" + root.id + "Loading").hide();
        $("#" + root.id + "Content").hide();
        $("#" + root.id + "NoDataText").text(message);
        $("#" + root.id + "NoData").show();
    }

    function text(root, id, value) {
        $("#" + root.id + capitalize(id)).text(value == null || value === "" ? "-" : value);
    }
    function moneyText(root, id, value) { text(root, id, money(num(value))); }
    function number(root, id, value) { text(root, id, num(value).toLocaleString(undefined, { maximumFractionDigits: 0 })); }
    function number2(root, id, value) { text(root, id, num(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })); }

    function num(v) {
        if (v === null || v === undefined || v === "") return 0;
        var n = parseFloat(v);
        return isNaN(n) ? 0 : n;
    }
    function money(v) {
        return "$" + num(v).toLocaleString(undefined, { minimumFractionDigits:2, maximumFractionDigits:2 });
    }
    function integerOrDash(v) {
        if (v === null || v === undefined || v === "") return "-";
        var n = parseInt(v, 10);
        return isNaN(n) ? "-" : n.toLocaleString();
    }
    function dateTime(v) {
        if (!v) return "-";
        var d = new Date(v);
        if (isNaN(d.getTime())) return String(v);
        return d.toLocaleString(undefined, {
            year:"numeric", month:"2-digit", day:"2-digit",
            hour:"2-digit", minute:"2-digit"
        });
    }
    function escapeHtml(v) {
        return String(v).replace(/[&<>"']/g, function (c) {
            return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c];
        });
    }
    function stripHtml(html) {
        var d = document.createElement("div");
        d.innerHTML = html;
        return d.innerText || d.textContent || "";
    }
    function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
    function safeError(e) { return e && e.message ? e.message : "Unknown error"; }
    function alertUser(message) {
        if (kendo && kendo.alert) kendo.alert(message);
        else window.alert(message);
    }
})(jQuery, window.kendo);
