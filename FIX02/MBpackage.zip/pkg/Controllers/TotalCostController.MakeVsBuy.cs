// ============================================================================
// TotalCostController: MAKE VS BUY CHANGES (copy & paste)
//
//  A) REPLACE  ViewReport(...)                                   (full method)
//  B) ADD      GetMakeVsBuyReportViewName(...)                   (new)
//  C) ADD      MapMakeVsBuyDataToViewBag(...)                    (new)
//  D) REPLACE  GetTotalCostInMakeVsBuyEstimatesWithDetails(...)  (full method)
//
//  NOT changed: GetTotalCostInEstimates (already routes "MakeVsBuyGrid"),
//               GetReportViewName, MapDataToViewBag, all Vehicle methods.
//
//  Needs: using System.Linq; using Dapper; using System.Collections.Generic;
// ============================================================================

// ----------------------------------------------------------------------------
// A) ViewReport: REPLACES your existing ViewReport
//    - accepts "MakeVsBuyGrid" (what the tab sends) and "MAKEVSBUY" (your old value)
//    - Vehicle path is exactly as before
// ----------------------------------------------------------------------------
[HttpGet]
public async Task<IActionResult> ViewReport(string reportType, string id, [FromQuery] string gridType)
{
    try
    {
        IEnumerable<TotalCostInEstimates> data;

        var isMakeVsBuy =
            string.Equals(gridType, "MakeVsBuyGrid", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(gridType, "MAKEVSBUY", StringComparison.OrdinalIgnoreCase);

        if (gridType == "VehicleGrid")
        {
            data = await GetTotalCostInVehicleEstimatesWithDetails(id, gridType);
        }
        else if (isMakeVsBuy)
        {
            data = await GetTotalCostInMakeVsBuyEstimatesWithDetails(id, gridType);
        }
        else
        {
            return Content("Invalid grid type");
        }

        var costData = data?.FirstOrDefault();
        if (costData == null)
        {
            return Content("No data found for the specified estimate.");
        }

        if (isMakeVsBuy)
        {
            MapMakeVsBuyDataToViewBag(costData, id);
            return View(GetMakeVsBuyReportViewName(reportType));
        }

        // Vehicle (unchanged)
        MapDataToViewBag(costData, id, gridType);
        string viewName = GetReportViewName(reportType);
        return View(viewName);
    }
    catch (Exception ex)
    {
        return Content($"Error loading report: {ex.Message}");
    }
}

// ----------------------------------------------------------------------------
// B) Report view selection for Make vs Buy.
//    The tab menu sends 'labourdetails' / 'materialsestimate' / 'fullreport',
//    so this matches on keywords and also accepts 'labour' / 'materials' / 'full'.
// ----------------------------------------------------------------------------
private string GetMakeVsBuyReportViewName(string reportType)
{
    var rt = (reportType ?? string.Empty).ToLowerInvariant();

    if (rt.Contains("labour"))
        return "~/Views/Shared/_MakeVsBuy_LabourDetails.cshtml";

    if (rt.Contains("material"))
        return "~/Views/Shared/_MakeVsBuy_MaterialsEstimateReport.cshtml";

    return "~/Views/Shared/_MakeVsBuy_FullEstimateReport.cshtml";
}

// ----------------------------------------------------------------------------
// C) ViewBag mapping for the two server-rendered Make vs Buy report views
// ----------------------------------------------------------------------------
private void MapMakeVsBuyDataToViewBag(TotalCostInEstimates c, string id)
{
    ViewBag.PartNum = id;
    ViewBag.GridType = "MakeVsBuyGrid";

    // Make vs Buy header
    ViewBag.MbDescription = c.Description;
    ViewBag.MbNumber = c.MbNumber;
    ViewBag.VendorPartNum = c.VendorPartNum;
    ViewBag.BuyCode = c.BuyCode;
    ViewBag.RebuildCode = c.RebuildCode;
    ViewBag.AnnualUsage = c.AnnualUsage;
    ViewBag.Recommendation = c.Recommendation;
    ViewBag.InternalCost = c.InternalCost;
    ViewBag.RemanCost = c.RemanCost;
    ViewBag.ExternalCost = c.ExternalCost;
    ViewBag.BuyNewCost = c.BuyNewCost;
    ViewBag.JobNumber = c.JobNumber;
    ViewBag.DateOpened = c.DateOpened.HasValue ? c.DateOpened.Value.ToString("yyyy-MM-dd HH:mm") : "-";

    // Vehicle series: one or many (views expect List<string>)
    ViewBag.VehicleSeriesList = c.VehicleSeriesList ?? new List<string>();

    // Material
    ViewBag.TotalStockPartsCount = c.TotalStockPartsCount;
    ViewBag.TotalNonStockPartsCount = c.TotalNonStockPartsCount;
    ViewBag.TotalRebuiltPartsCount = c.TotalRebuiltPartsCount;
    ViewBag.TotalParts = c.TotalStockPartsCount + c.TotalNonStockPartsCount + c.TotalRebuiltPartsCount;
    ViewBag.SCPartsMaterialCost = c.SCPartsMaterialCost;
    ViewBag.NSCSCPartsMaterialCost = c.NSCSCPartsMaterialCost;
    ViewBag.RBPartsMaterialCost = c.RBPartsMaterialCost;
    ViewBag.MaterialLines = c.MaterialLines;
    ViewBag.MaterialLinesCount = c.MaterialLines?.Count ?? 0;
    ViewBag.MaterialTotalWithTax = c.MaterialTotalWithTax;

    // Labour
    ViewBag.TotalLabourHours = c.TotalLabourHours;
    ViewBag.TotalEffectiveHours = c.TotalEffectiveHours;
    ViewBag.TotalAdjustedHours = c.TotalAdjustedHours;
    ViewBag.LabourTasks = c.LabourTasks;
    ViewBag.LabourTasksCount = c.LabourTasks?.Count ?? 0;
    ViewBag.FinalLabourCost = c.FinalLabourCost;
}

// ----------------------------------------------------------------------------
// D) GetTotalCostInMakeVsBuyEstimatesWithDetails: REPLACES your existing method
//    Fixes vs. the old version:
//      - header query selected NumBusComp twice and used ISNULL(...,'N/A') on
//        possibly numeric columns (conversion errors); now selects raw columns
//      - Keyword/BusType/CoreCode/BenchNumber/SampleProvided/JobNumber/MbPrefix/
//        Readmanualnewprice were read but never selected (always "N/A")
//      - vehicle series (one or many) now loaded from MbListOfBuses/ListOfBuses
//      - all header fields are converted to string safely (no dynamic -> typed errors)
// ----------------------------------------------------------------------------
private static string MbText(object value)
{
    if (value == null || value is DBNull) return "N/A";
    var s = Convert.ToString(value);
    return string.IsNullOrWhiteSpace(s) ? "N/A" : s;
}

private static void AddMaterialLines(List<MaterialLineItem> target, IEnumerable<dynamic> rows)
{
    foreach (var p in rows)
    {
        target.Add(new MaterialLineItem
        {
            Type = p.Type,
            StockCode = p.StockCode,
            CC = p.CC,
            Description = p.Description,
            Quantity = Convert.ToDecimal(p.Quantity ?? 0),
            UnitCost = Convert.ToDecimal(p.UnitCost ?? 0),
            PercentUsage = Convert.ToDecimal(p.PercentUsage ?? 0),
            TotalCost = Convert.ToDecimal(p.TotalCost ?? 0),
            Supplier = p.Supplier
        });
    }
}

private async Task<IEnumerable<TotalCostInEstimates>> GetTotalCostInMakeVsBuyEstimatesWithDetails(string id, string gridType)
{
    try
    {
        var result = new List<TotalCostInEstimates>();

        // STEP 1: Make vs Buy header
        var mb = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
            @"SELECT
                mb.MbPrefix,
                mb.MbNumber,
                mb.Keyword,
                mb.Description,
                mb.BusType,
                mb.NumBusComp,
                mb.VendorPartNum,
                mb.BuyCode,
                mb.RebuildCode,
                mb.CoreCode,
                mb.AnnualUsage,
                mb.BenchNumber,
                mb.SampleProvided,
                mb.Recommendation,
                mb.RemanCost,
                mb.ExternalCost,
                mb.BuyNewCost,
                mb.InternalCost,
                mb.CoreCost,
                mb.SopNumber,
                mb.JobNumber,
                mb.DateOpened,
                mb.Readmanualnewprice
              FROM SBCES.MbList mb
              WHERE mb.MbNumber = @Id",
            new { Id = id });

        // STEP 1b: Buses / vehicle series (zero, one or many)
        var seriesList = (await _dbConnection.QueryAsync<string>(
            @"SELECT lb.Description
              FROM SBCES.MbListOfBuses mblb
              INNER JOIN SBCES.ListOfBuses lb ON lb.ListId = mblb.ListId
              WHERE mblb.MbNumber = @Id AND lb.Description IS NOT NULL
              ORDER BY lb.Description",
            new { Id = id })).ToList();

        // STEP 2: Material costs
        var materialCosts = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
            @"
    WITH MaterialCosts AS (
        SELECT 
            TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SCP.MmsNewCost, 0), 0) AS DECIMAL(18,2)) AS Cost,
            'SC' AS Type
        FROM SBCES.ScPartsUsed SUS
        LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
        WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'MB' AND SUS.RebuiltPart = 'N'
        UNION ALL
        SELECT 
            TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SUS.MmsCost, 0), 0) AS DECIMAL(18,2)) AS Cost,
            'RB' AS Type
        FROM SBCES.ScPartsUsed SUS
        LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
        WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'MB' AND SUS.RebuiltPart = 'Y'
        UNION ALL
        SELECT 
            TRY_CAST(SBCES.FinalCost(CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(NSUS.Cost, 0), 0) AS DECIMAL(18,2)) AS Cost,
            'NSC' AS Type
        FROM SBCES.NscPartsUsed NSUS 
        WHERE NSUS.LinkCode = @Id AND NSUS.LinkType = 'MB'
    )
    SELECT 
        ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'SC'), 0) AS SCPartsMaterialCost,
        ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'RB'), 0) AS RBPartsMaterialCost,
        ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'NSC'), 0) AS NSCSCPartsMaterialCost,
        ISNULL((SELECT SUM(CoreCost) FROM SBCES.SCPartsUsed WHERE LinkCode = @Id AND LinkType = 'MB'), 0) AS CoreCost",
            new { Id = id });

        // STEP 3: Labour costs
        var labourCosts = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
            @"
    DECLARE @NonProductiveAdj DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'), ',', '.') AS DECIMAL(18,6));
    DECLARE @Fringe DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'FRINGE'), '0'), ',', '.') AS DECIMAL(18,6));
    DECLARE @Benefit DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'BENEFIT'), '0'), ',', '.') AS DECIMAL(18,6));
    DECLARE @Overhead DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'OVERHEAD'), '0'), ',', '.') AS DECIMAL(18,6));
    DECLARE @TaxRate DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'TAX_RATE'), '0'), ',', '.') AS DECIMAL(18,6));

    WITH LabourData AS (
        SELECT 
            (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
             CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60) AS DecimalHrs,
            CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) AS UsagePercent,
            ISNULL((SELECT TOP 1 ES.RatePerHour FROM CES.SBCES.EmployeeSalaries ES
                    WHERE ES.WageGroup = (SELECT TOP 1 EC.WageGroup FROM CES.SBCES.EmplClass EC
                                          WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')), 0) AS RatePerHour,
            EL.LabourDefn
        FROM SBCES.EmployeeLabour EL
        WHERE EL.LinkNumber = @Id AND EL.TypeId = 'MB'
    )
    SELECT 
        ISNULL(SUM(
            (DecimalHrs * UsagePercent / 100) / @NonProductiveAdj * RatePerHour
        ), 0) AS TotalLabourCost,
        @Fringe AS FringeRate,
        @Benefit AS BenefitRate,
        @Overhead AS OverheadRate,
        @TaxRate AS TaxRate
    FROM LabourData",
            new { Id = id });

        // STEP 4: Labour tasks
        var labourTasks = await _dbConnection.QueryAsync<LabourTaskSummary>(
            @"
    DECLARE @NonProductiveAdj DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'), ',', '.') AS DECIMAL(18,6));

    WITH LabourData AS (
        SELECT 
            EL.Task,
            EL.LabourDefn,
            EL.CostCentre as CC,

            (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
             CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60) AS DecimalHrs,
            CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) AS UsagePercent,
            ISNULL((SELECT TOP 1 ES.RatePerHour FROM CES.SBCES.EmployeeSalaries ES
                    WHERE ES.WageGroup = (SELECT TOP 1 EC.WageGroup FROM CES.SBCES.EmplClass EC
                                          WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')), 0) AS RatePerHour
        FROM SBCES.EmployeeLabour EL
        WHERE EL.LinkNumber = @Id AND EL.TypeId = 'MB'
    )
    SELECT 
        ISNULL(Task, 'Unnamed Task') AS Task,
        ISNULL(LabourDefn, 'N/A') AS LabourDefinition,
        ISNULL(CC, '') AS CC,
        COUNT(*) AS Count,
        SUM(DecimalHrs) AS Hours,
        SUM(DecimalHrs * UsagePercent / 100) AS EffectiveHours,
        SUM(DecimalHrs / @NonProductiveAdj) AS AdjustedHours,
        AVG(RatePerHour) AS RatePerHour,
        SUM((DecimalHrs * UsagePercent / 100) / @NonProductiveAdj * RatePerHour) AS TotalCost
    FROM LabourData
    GROUP BY Task, LabourDefn, CC
    ORDER BY Task",
            new { Id = id });

        // STEP 5: Stock parts (material lines)
        var stockParts = await _dbConnection.QueryAsync<dynamic>(
            @"
    SELECT 
        'Stock' AS Type,
        SUS.MMSStockCode AS StockCode,
        SUS.CostCentre as CC,
        ISNULL(SCP.DetailedDesc, 'N/A') AS Description,
        SUS.QtyReqd AS Quantity,
        ISNULL(SCP.MmsNewCost, 0) AS UnitCost,
        SUS.PercentUsage,
        TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SCP.MmsNewCost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
        '' AS Supplier
    FROM SBCES.ScPartsUsed SUS
    LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
    WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'MB' AND SUS.RebuiltPart = 'N'
    ORDER BY SUS.MMSStockCode",
            new { Id = id });

        // STEP 6: Rebuilt parts (material lines)
        var rebuiltParts = await _dbConnection.QueryAsync<dynamic>(
            @"
    SELECT 
        'Rebuilt' AS Type,
        SUS.MMSStockCode AS StockCode,
        SUS.CostCentre as CC,
        ISNULL(SCP.DetailedDesc, 'N/A') AS Description,
        SUS.QtyReqd AS Quantity,
        ISNULL(SUS.MmsCost, 0) AS UnitCost,
        SUS.PercentUsage,
        TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SUS.MmsCost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
        '' AS Supplier
    FROM SBCES.ScPartsUsed SUS
    LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
    WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'MB' AND SUS.RebuiltPart = 'Y'
    ORDER BY SUS.MMSStockCode",
            new { Id = id });

        // STEP 7: Non-stock parts (material lines)
        var nonStockParts = await _dbConnection.QueryAsync<dynamic>(
            @"
    SELECT 
        'Non-Stock' AS Type,
        NSUS.OrigSuppNum AS StockCode,
        NSUS.CostCentre as CC,
        ISNULL(NSUS.OrigSupplierName, 'N/A') AS Description,
        NSUS.QtyReqd AS Quantity,
        ISNULL(NSUS.Cost, 0) AS UnitCost,
        NSUS.PercentUsage,
        TRY_CAST(SBCES.FinalCost(CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(NSUS.Cost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
        ISNULL(NSUS.OrigSupplierName, '') AS Supplier
    FROM SBCES.NscPartsUsed NSUS
    WHERE NSUS.LinkCode = @Id AND NSUS.LinkType = 'MB'
    ORDER BY NSUS.OrigSuppNum",
            new { Id = id });

        // STEP 8: Build the result object
        // (object) casts keep these calls statically bound (no dynamic dispatch)
        var totalCost = new TotalCostInEstimates
        {
            LinkCode = id,

            // Make vs Buy header (all strings, display only)
            MbPrefix = MbText((object)mb?.MbPrefix),
            MbNumber = MbText((object)mb?.MbNumber),
            Keyword = MbText((object)mb?.Keyword),
            Description = MbText((object)mb?.Description),
            BusType = MbText((object)mb?.BusType),
            NumBusComp = MbText((object)mb?.NumBusComp),
            VendorPartNum = MbText((object)mb?.VendorPartNum),
            BuyCode = MbText((object)mb?.BuyCode),
            RebuildCode = MbText((object)mb?.RebuildCode),
            CoreCode = MbText((object)mb?.CoreCode),
            AnnualUsage = MbText((object)mb?.AnnualUsage),
            BenchNumber = MbText((object)mb?.BenchNumber),
            SampleProvided = MbText((object)mb?.SampleProvided),
            Recommendation = MbText((object)mb?.Recommendation),
            RemanCost = MbText((object)mb?.RemanCost),
            ExternalCost = MbText((object)mb?.ExternalCost),
            BuyNewCost = MbText((object)mb?.BuyNewCost),
            InternalCost = MbText((object)mb?.InternalCost),
            MbCoreCost = MbText((object)mb?.CoreCost),   // MbList.CoreCost (separate from parts CoreCost below)
            SopNumber = MbText((object)mb?.SopNumber),
            JobNumber = MbText((object)mb?.JobNumber),
            Readmanualnewprice = MbText((object)mb?.Readmanualnewprice),
            DateOpened = (mb != null && (object)mb.DateOpened is DateTime opened) ? opened : (DateTime?)null,

            // Vehicle series: one or many
            VehicleSeriesList = seriesList,
            VehicleSeries = seriesList.Count > 0 ? string.Join(", ", seriesList) : "N/A",

            // Material costs
            SCPartsMaterialCost = Convert.ToDecimal(materialCosts?.SCPartsMaterialCost ?? 0),
            NSCSCPartsMaterialCost = Convert.ToDecimal(materialCosts?.NSCSCPartsMaterialCost ?? 0),
            RBPartsMaterialCost = Convert.ToDecimal(materialCosts?.RBPartsMaterialCost ?? 0),
            CoreCost = Convert.ToDecimal(materialCosts?.CoreCost ?? 0),

            // Material summary
            TotalStockPartsCount = stockParts.Count(),
            TotalNonStockPartsCount = nonStockParts.Count(),
            TotalRebuiltPartsCount = rebuiltParts.Count(),
        };

        // Material totals
        var scPartsCost = totalCost.SCPartsMaterialCost;
        var rbPartsCost = totalCost.RBPartsMaterialCost;
        var nscPartsCost = totalCost.NSCSCPartsMaterialCost;
        var materialTotalNoTax = scPartsCost + rbPartsCost + nscPartsCost;
        var taxRate = Convert.ToDecimal(labourCosts?.TaxRate ?? 0);
        var materialTax = (materialTotalNoTax * taxRate) / 100;
        var materialTotalWithTax = materialTotalNoTax + materialTax;

        totalCost.MaterialTotalCostNoTax = materialTotalNoTax;
        totalCost.MaterialTotalTaxAmount = materialTax;
        totalCost.MaterialTotalWithTax = materialTotalWithTax;

        // Averages
        totalCost.AverageStockPartCost = stockParts.Any() ? Convert.ToDecimal(stockParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;
        totalCost.AverageNonStockPartCost = nonStockParts.Any() ? Convert.ToDecimal(nonStockParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;
        totalCost.AverageRebuiltPartCost = rebuiltParts.Any() ? Convert.ToDecimal(rebuiltParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;

        // Labour costs (same formulas as Vehicle)
        var totalLabourCost = Convert.ToDecimal(labourCosts?.TotalLabourCost ?? 0);
        var fringeRate = Convert.ToDecimal(labourCosts?.FringeRate ?? 0);
        var benefitRate = Convert.ToDecimal(labourCosts?.BenefitRate ?? 0);
        var overheadRate = Convert.ToDecimal(labourCosts?.OverheadRate ?? 0);

        var labourFringe = totalLabourCost * fringeRate;
        var labourBenefits = (totalLabourCost + labourFringe) * benefitRate;
        var blendedFringeBenefitPercent = totalLabourCost > 0 ? ((labourFringe + labourBenefits) / totalLabourCost) * 100 : 0;
        var blendedFringeBenefitCost = labourFringe + labourBenefits;
        var labourOverhead = totalLabourCost * overheadRate;
        var finalLabourCost = totalLabourCost + labourFringe + labourBenefits + labourOverhead;

        totalCost.TotalLabourCost = totalLabourCost;
        totalCost.LabourFringe = labourFringe;
        totalCost.LabourBenefits = labourBenefits;
        totalCost.BlendedFringeBenefitPercent = blendedFringeBenefitPercent;
        totalCost.BlendedFringeBenefitCost = blendedFringeBenefitCost;
        totalCost.LabourOverhead = labourOverhead;
        totalCost.FinalLabourCost = finalLabourCost;

        // Labour hours summary
        totalCost.LabourTasks = labourTasks.ToList();
        totalCost.TotalLabourHours = labourTasks.Sum(t => t.Hours);
        totalCost.TotalEffectiveHours = labourTasks.Sum(t => t.EffectiveHours);
        totalCost.TotalAdjustedHours = labourTasks.Sum(t => t.AdjustedHours);

        // Material lines
        var materialLines = new List<MaterialLineItem>();
        AddMaterialLines(materialLines, stockParts);
        AddMaterialLines(materialLines, rebuiltParts);
        AddMaterialLines(materialLines, nonStockParts);

        totalCost.MaterialLines = materialLines
            .Where(m => m.TotalCost > 0)
            .OrderBy(m => m.Type)
            .ThenBy(m => m.StockCode)
            .ToList();

        // Grand totals
        totalCost.TotalWithoutTax = finalLabourCost + materialTotalNoTax;
        totalCost.TotalWithTax = finalLabourCost + materialTotalWithTax;

        result.Add(totalCost);
        return result;
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error in GetTotalCostInMakeVsBuyEstimatesWithDetails: {ex.Message}");
        Console.WriteLine($"Stack Trace: {ex.StackTrace}");
        throw;
    }
}
