# Make vs Buy Estimate: Cost Summary & Reports

Adds a Make vs Buy cost summary tab and reports that mirror the Vehicle ones.
Vehicle code is **not modified** (except `ViewReport`, which gains a Make vs Buy branch; the Vehicle path is unchanged).

## Package contents

| File | Where it goes |
|---|---|
| `Views/Shared/_MakeVsBuy_FullEstimateReport.cshtml` | New view: the Make vs Buy tab (loads data via AJAX, menu, PDF/clipboard) |
| `Views/Shared/_MakeVsBuy_LabourDetails.cshtml` | New view: server-rendered Labour Details report |
| `Views/Shared/_MakeVsBuy_MaterialsEstimateReport.cshtml` | New view: server-rendered Materials Estimate report |
| `Controllers/TotalCostController.MakeVsBuy.cs` | Controller changes (A to D below), copy into `TotalCostController` |
| `Models/TotalCostInEstimates.MakeVsBuy.additions.cs` | Properties to add to `TotalCostInEstimates` |
| `Sql/MakeVsBuyFinalEstimate.sql` | The two header/series queries, for testing in SSMS |

The views reuse `~/css/_VehicleReportStyles.css`. No new CSS file is needed.

## Install steps

1. **Model**: add the properties from `TotalCostInEstimates.MakeVsBuy.additions.cs`.
   `DateOpened` must be `DateTime?`.
2. **Controller** (`TotalCostController`), from `TotalCostController.MakeVsBuy.cs`:
   - **A. Replace** `ViewReport` (adds Make vs Buy routing; Vehicle path unchanged).
   - **B. Add** `GetMakeVsBuyReportViewName`.
   - **C. Add** `MapMakeVsBuyDataToViewBag`.
   - **D. Replace** `GetTotalCostInMakeVsBuyEstimatesWithDetails`, and add the two small helpers above it (`MbText`, `AddMaterialLines`).
   - Not changed: `GetTotalCostInEstimates` (already routes `MakeVsBuyGrid`), `GetReportViewName`, `MapDataToViewBag`.
3. **Views**: copy the three `.cshtml` files into `Views/Shared/`
   (if your Vehicle views live elsewhere, copy them next to those and update the three paths in
   `GetMakeVsBuyReportViewName`).
4. **Make vs Buy tab**: wherever the tab renders the Vehicle summary partial, render
   `_MakeVsBuy_FullEstimateReport` instead, with
   `ViewBag.PartNum = <MbNumber>` and `ViewBag.GridType = "MakeVsBuyGrid"`
   (the view defaults `GridType` to `MakeVsBuyGrid` if it is not set).

## What changed vs. your first attempt

**Controller**
- Header query selected `NumBusComp` twice and used `ISNULL(col, 'N/A')` on columns that may be numeric/money (conversion errors). It now selects the raw columns; null handling is done in C#.
- `Keyword`, `BusType`, `CoreCode`, `BenchNumber`, `SampleProvided`, `JobNumber`, `MbPrefix`, `Readmanualnewprice` were read but never selected, so they were always "N/A". They are now selected.
- Vehicle series (one or many) come from `SBCES.MbListOfBuses` joined to `SBCES.ListOfBuses` and are returned as `VehicleSeriesList`.
- `ViewReport` compared `gridType == "MAKEVSBUY"`, but the tab sends `MakeVsBuyGrid`. Both are accepted now.
- `ViewReport` called `MapDataToViewBag` / `GetReportViewName`, which are Vehicle-specific, for Make vs Buy. It now uses its own mapping and view selection.
- Report-type matching is keyword-based (`labour` / `material`), because the tab menu sends `labourdetails`, `materialsestimate` and `fullreport` while the old switch only knew `full` / `labour` / `materials`.

**Views / JavaScript**
- Same layout, CSS classes, section order, menu and export logic as the Vehicle versions.
- "Vehicle Details" section is replaced by "Make vs Buy Details" in the same grid (Description is the wide item). Vehicle series show as plain comma-separated text.
- Internal / Reman / External / Buy New cost are ordinary items in that grid.
- Audit row keeps the same layout but shows **Date Opened** and **Job Number**, because `MbList` has no Modified By / Date columns.
- `openReportView` used a hard-coded `gridType=VehicleGrid`; it now uses the `gridType` variable.
- Copy/PDF used keys that never matched the title/filename lookups, so every export fell back to the default. A small `normalizeReportType()` maps them to `full` / `labour` / `materials`. (If you want strict parity with Vehicle, remove it; titles will then keep falling back to the default.)
- Text/numeric fields from `MbList` arrive as strings and may be "N/A", so `textOrDash()` and `moneyOrDash()` handle them.

## Things to verify

- **JSON casing**: the tab JavaScript reads PascalCase (`costData.MbNumber`), same as the Vehicle view. If your JSON serializer is camelCase, the Vehicle tab would already be broken, so this should match.
- **Series table/column names**: `SBCES.MbListOfBuses (MbNumber, ListId)` and `SBCES.ListOfBuses (ListId, Description)` as per your query. The series name is `Description`.
- **Core cost**: `MbList.CoreCost` is stored as `MbCoreCost`; `CoreCost` remains the sum from `ScPartsUsed`. The views do not display either (fields not in the Vehicle-style grid). Add an item to the details grid if you need it.
- **Fields not shown**: Keyword, Bus Type, Core Code, Bench Number, Sample Provided, Prefix, Manual New Price, SOP Number, # Bus Comp are loaded into the model but not displayed. Add `vehicle-info-item` rows in the three views if needed.
- **Dates**: `DateOpened` is nullable. It shows "-" if empty.
- **Link type**: labour/material queries use `'MB'` (as in your code). Make sure the estimate id passed in is the `MbNumber` (for example `MB0105`).
- **Not compiled or run**: this was prepared without access to your solution or database. Build, then test with a Make vs Buy that has 0, 1 and several series.

## Test checklist

1. Open the Make vs Buy tab for `MB0105`; the details, series, material and labour sections load.
2. Reports menu: **Labour Details** and **Materials Estimate** open in a new tab with Make vs Buy data.
3. **Copy to clipboard** and **Save as PDF** work for all three report types.
4. Vehicle tab and Vehicle reports behave exactly as before.
5. An MB with no series shows "-"; an MB with several shows them comma-separated.
