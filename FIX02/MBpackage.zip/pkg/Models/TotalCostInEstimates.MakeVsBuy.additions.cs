// ============================================================================
// ADD these properties to your existing TotalCostInEstimates class.
// Skip any that already exist (check names AND types).
// All Make vs Buy header fields are strings on purpose: display-only, and it
// avoids dynamic -> typed conversion errors with numeric/money columns.
// ============================================================================

// ---- Make vs Buy header (SBCES.MbList) ----
public string MbPrefix { get; set; }
public string MbNumber { get; set; }
public string Keyword { get; set; }
public string BusType { get; set; }
public string NumBusComp { get; set; }
public string VendorPartNum { get; set; }
public string BuyCode { get; set; }
public string RebuildCode { get; set; }
public string CoreCode { get; set; }
public string AnnualUsage { get; set; }
public string BenchNumber { get; set; }
public string SampleProvided { get; set; }
public string Recommendation { get; set; }
public string RemanCost { get; set; }
public string ExternalCost { get; set; }
public string BuyNewCost { get; set; }
public string InternalCost { get; set; }
public string MbCoreCost { get; set; }            // MbList.CoreCost (CoreCost = parts core cost, already exists)
public string SopNumber { get; set; }
public string JobNumber { get; set; }
public string Readmanualnewprice { get; set; }
public DateTime? DateOpened { get; set; }         // must be nullable; if it already exists as DateTime, change it to DateTime?

// ---- Vehicle series: one or many (SBCES.MbListOfBuses + SBCES.ListOfBuses) ----
public List<string> VehicleSeriesList { get; set; } = new List<string>();

// Already used by the Vehicle code (leave as is):
//   Description, VehicleSeries, LinkCode, CoreCost, and all the cost/labour/material properties.
// If Description or SopNumber are typed differently on your class, adjust the types/assignments.
