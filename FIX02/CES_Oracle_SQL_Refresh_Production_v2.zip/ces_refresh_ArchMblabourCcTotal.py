# CES Oracle -> SQL Server Refresh
# Generated from supplied Oracle/MS SQL DDL.
# IMPORTANT: Oracle is READ ONLY in these scripts.
# Oracle statements are SELECT COUNT(*) and SELECT ... only.

# REVIEW REQUIRED - NOT INCLUDED IN ces_refresh_all.bat
# Source Oracle table: ARCH_RB_LABOUR_CC_TOTAL
# Target SQL table: SBCES.ArchMblabourCcTotal
# The supplied DDL pairs ARCH_RB_LABOUR_CC_TOTAL with ArchMblabourCcTotal, but the Oracle columns contain ARCH_RB_MASTERLIST_ID
# while the SQL target expects ArchMbMasterlistId. No Oracle ARCH_MB_LABOUR_CC_TOTAL DDL was supplied.
# This script intentionally does NOT perform any database operation.

import logging
logging.basicConfig(level=logging.INFO)
logger=logging.getLogger(__name__)

def main():
    logger.error("REVIEW REQUIRED: ARCH_RB_LABOUR_CC_TOTAL -> SBCES.ArchMblabourCcTotal mapping is inconsistent in supplied DDL. Script disabled.")

if __name__ == "__main__":
    main()
