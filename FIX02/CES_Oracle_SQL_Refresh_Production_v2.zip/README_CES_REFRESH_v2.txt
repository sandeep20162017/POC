CES ORACLE -> SQL SERVER REFRESH PACKAGE v2

SAFETY
- Oracle connection is READ ONLY: scripts execute SELECT COUNT(*) and SELECT only.
- DELETE statements execute only against SQL Server target tables under SBCES.
- No Oracle INSERT/UPDATE/DELETE/MERGE/TRUNCATE/DROP is present.
- FULL mode deletes the SQL target and inserts Oracle data inside one SQL transaction per table; on insert failure the SQL transaction is rolled back.
- Scripts do not use return 0/1/2 or sys.exit(). Errors are logged and the process ends normally.

USAGE
1. Edit ces_refresh_config.json if connection settings differ.
2. Run ces_refresh_all.bat for FK-safe order.
3. Individual scripts default to FULL. Set CES_REFRESH_MODE=DELETE or INSERT for targeted operation.

IMPORTANT DDL REVIEW
- ARCH_MB_MASTERLIST Oracle contains ARCHIVED_BY, but SBCES.ArchMbMasterlist does not have ArchivedBy. The generated script therefore does NOT select ARCHIVED_BY and does not attempt to insert ArchivedBy.
- The supplied DDL pairs ARCH_RB_LABOUR_CC_TOTAL with SBCES.ArchMblabourCcTotal, but the Oracle row uses ARCH_RB_MASTERLIST_ID while the SQL table expects ArchMbMasterlistId. No Oracle ARCH_MB_LABOUR_CC_TOTAL DDL was supplied. This mapping is marked REVIEW_REQUIRED and is excluded from the batch.

TABLES
- ARCH_RB_LABOUR_CC_TOTAL -> SBCES.ArchMblabourCcTotal [REVIEW_REQUIRED] | extra SQL target columns: CostCentre, ArchMbMasterlistId, TotalHours
- ARCH_MB_EMPLOYEE_LABOUR -> SBCES.ArchMbEmployeeLabour [ACTIVE] | extra SQL target columns: Id
- ARCH_MB_LIST_BUSES -> SBCES.ArchMbListBuses [ACTIVE]
- ARCH_MB_MASTERLIST -> SBCES.ArchMbMasterlist [ACTIVE]
- ARCH_MB_MATERIALS_CC_TOTAL -> SBCES.ArchMbmaterielsCcTotal [ACTIVE]
- ARCH_MB_NSC_PARTS_USED -> SBCES.ArchMbNscPartsUsed [ACTIVE]
- ARCH_MB_SC_PARTS_USED -> SBCES.ArchMbScPartsUsed [ACTIVE]
- ARCH_RB_EMPLOYEE_LABOUR -> SBCES.ArchRbEmployeeLabour [ACTIVE] | extra SQL target columns: Id
- ARCH_RB_LABOUR_CC_TOTAL -> SBCES.ArchRbLabourCcTotal [ACTIVE]
- ARCH_RB_LIST_BUSES -> SBCES.ArchRbListBuses [ACTIVE]
- ARCH_RB_MASTERLIST -> SBCES.ArchRbMasterlist [ACTIVE]
- ARCH_RB_MATERIALS_CC_TOTAL -> SBCES.ArchRbMaterialsCcTotal [ACTIVE]
- ARCH_RB_NSC_PARTS_USED -> SBCES.ArchRbNscPartsUsed [ACTIVE]
- ARCH_RB_SC_PARTS_USED -> SBCES.ArchRbScPartsUsed [ACTIVE]
- ARCH_VEH_EMPLOYEE_LABOUR -> SBCES.ArchVehEmployeeLabour [ACTIVE] | extra SQL target columns: ID
- ARCH_VEHICLE_LIST -> SBCES.ArchVehicleList [ACTIVE]
- ARCH_VEH_KITS -> SBCES.ArchVehKits [ACTIVE]
- ARCH_VEH_LABOUR_CC_TOTAL -> SBCES.ArchVehLabourCcTotal [ACTIVE]
- ARCH_VEH_MATERIALS_CC_TOTAL -> SBCES.ArchVehMaterialsCcTotal [ACTIVE]
- ARCH_VEH_NSC_PARTS_USED -> SBCES.ArchVehNscPartsUsed [ACTIVE]
- ARCH_VEH_SC_PARTS_USED -> SBCES.ArchVehScPartsUsed [ACTIVE]

LOGS
Each script writes logs\<TargetTable>_refresh.log. The batch writes logs\ces_refresh_all.log.
