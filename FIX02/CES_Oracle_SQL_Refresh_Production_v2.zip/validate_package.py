import ast, pathlib, re
root=pathlib.Path(__file__).resolve().parent
for p in root.glob('ces_refresh_*.py'):
    if p.name=='validate_package.py': continue
    s=p.read_text(encoding='utf-8')
    ast.parse(s)
    for bad in ['sys.exit(', 'return 0', 'return 1', 'return 2']:
        if bad in s: raise SystemExit(f'BAD {bad}: {p.name}')
print('ALL PYTHON SCRIPTS: SYNTAX OK; no sys.exit()/return 0/1/2')
