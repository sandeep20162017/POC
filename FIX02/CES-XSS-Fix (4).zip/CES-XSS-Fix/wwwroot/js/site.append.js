// ---- CES: show a Kendo dialog when the server rejects an invalid id / gridType ----
// APPEND this block to the END of your existing wwwroot/js/site.js (do not replace the file).
(function ($) {
    var lastShown = 0;

    $(document).ajaxError(function (event, xhr) {
        if (!xhr || xhr.status !== 400 ||
            xhr.getResponseHeader('X-CES-Validation') !== 'InvalidParameter') {
            return;
        }

        // Several grids can fail at once; show a single dialog.
        var now = Date.now();
        if (now - lastShown < 2000) { return; }
        lastShown = now;

        var isId = xhr.getResponseHeader('X-CES-Invalid-Param') === 'id';
        var title = isId ? 'Invalid ID' : 'Invalid Request';
        var message = isId
            ? 'The ID in this request is not valid. IDs may contain only letters, numbers, hyphens (-) and underscores (_). Please check the record and try again.'
            : 'This grid request is not valid. Please reload the page and try again.';

        $('<div></div>').appendTo(document.body).kendoDialog({
            title: title,
            content: message,
            modal: true,
            closable: true,
            width: 420,
            actions: [{ text: 'OK', primary: true }],
            close: function () {
                var d = this;
                setTimeout(function () { d.destroy(); }, 0);
            }
        });
    });
})(jQuery);
