using System.Text.RegularExpressions;
using Microsoft.Extensions.Primitives;

namespace BCES.Middleware
{
    /// <summary>
    /// Rejects unsafe 'id' / 'gridType' values on the "...Partial" actions of the
    /// RebuiltParts, MakeVsBuy and Vehicles controllers (the pattern flagged as
    /// Cross-site Scripting in the Invicti scan).
    /// Checks the URL path id, the query string and (for POST) the form body.
    /// </summary>
    public class InputValidationMiddleware
    {
        // Controllers whose "...Partial" actions take id / gridType.
        private static readonly HashSet<string> ProtectedControllers = new(StringComparer.OrdinalIgnoreCase)
        {
            "RebuiltParts",
            "MakeVsBuy",
            "Vehicles"
        };

        private const string ActionSuffix = "Partial";

        // gridType values found in the CES source (controllers and shared views).
        private static readonly HashSet<string> AllowedGridTypes = new(StringComparer.Ordinal)
        {
            "RebuiltGrid",            // seen in the Invicti scan report
            "VehicleGrid",
            "MakeVsBuyGrid",
            "ArchivedVehicleGrid",
            "ArchivedMakeVsBuyGrid",
            "ArchivedRebuiltGrid",
            "NonStockCodedPartsGrid", // Views/Parts/NonStockCodedParts/Index.cshtml
            "MakeVsBuy",              // AutoComplete calls in MakeVsBuy/Index.cshtml
            "RebuiltPart",            // AutoComplete calls in RebuiltParts/Index.cshtml
            "Vehicle",                // AutoComplete calls in Vehicles/Index.cshtml
            "MAKEVSBUY",              // TotalCostController.ViewReport
            "NscGrid",                // default in _NscPartsUsed.cshtml
            "RbGrid"                  // default in _RbPartsUsed.cshtml / _ScPartsUsed.cshtml
        };

        // Letters, digits, hyphen, underscore. \z (not $) so a trailing newline cannot slip through.
        private static readonly Regex SafeId =
            new(@"\A[A-Za-z0-9_-]{1,64}\z", RegexOptions.Compiled | RegexOptions.CultureInvariant);

        private readonly RequestDelegate _next;
        private readonly ILogger<InputValidationMiddleware> _logger;

        public InputValidationMiddleware(
            RequestDelegate next,
            ILogger<InputValidationMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var segments = (context.Request.Path.Value ?? string.Empty)
                .Split('/', StringSplitOptions.RemoveEmptyEntries);

            if (segments.Length >= 2 &&
                ProtectedControllers.Contains(segments[0]) &&
                segments[1].EndsWith(ActionSuffix, StringComparison.OrdinalIgnoreCase))
            {
                string? invalid = null;

                // id supplied in the URL path: /Controller/Action/{id}
                if (segments.Length > 2 && !SafeId.IsMatch(segments[2]))
                    invalid = "id";

                // id / gridType in the query string
                invalid ??= Check(context.Request.Query["id"], context.Request.Query["gridType"]);

                // id / gridType in a form body (some actions bind id with [FromForm])
                if (invalid == null && context.Request.HasFormContentType)
                {
                    IFormCollection? form = null;
                    try
                    {
                        form = await context.Request.ReadFormAsync();
                    }
                    catch (InvalidDataException)
                    {
                        // Malformed form: let MVC handle it as it does today.
                    }

                    if (form != null)
                        invalid = Check(form["id"], form["gridType"]);
                }

                if (invalid != null)
                {
                    _logger.LogWarning(
                        "Blocked request: invalid '{Param}' on {Controller}/{Action} from {RemoteIp}",
                        invalid, segments[0], segments[1], context.Connection.RemoteIpAddress);

                    context.Response.StatusCode = StatusCodes.Status400BadRequest;
                    context.Response.Headers["X-CES-Validation"] = "InvalidParameter";
                    context.Response.Headers["X-CES-Invalid-Param"] = invalid;
                    context.Response.ContentType = "text/plain; charset=utf-8";
                    await context.Response.WriteAsync("Invalid request parameter.");
                    return;
                }
            }

            await _next(context);
        }

        // Returns the name of the first invalid parameter, or null when both are fine.
        // Missing or empty values pass through unchanged; anything else must match.
        private static string? Check(StringValues ids, StringValues gridTypes)
        {
            foreach (var v in ids)
            {
                if (!string.IsNullOrEmpty(v) && !SafeId.IsMatch(v))
                    return "id";
            }

            foreach (var v in gridTypes)
            {
                if (!string.IsNullOrEmpty(v) && !AllowedGridTypes.Contains(v))
                    return "gridType";
            }

            return null;
        }
    }
}
