# CES: Fix for the 7 High findings (Cross-site Scripting)

Source: Invicti OWASP Top 10 2021 scan of `ces.uat.int.ttc.ca`, 14 Oct 2026.
The 7 High findings are all Cross-site Scripting on Rebuilt Parts partial pages, through the
`id` and `gridType` query-string values:

- `/RebuiltParts/LabourDetailsPartial`
- `/RebuiltParts/ScDetailsPartial`
- `/RebuiltParts/RebuiltPartsPartial`
- `/RebuiltParts/NonStockPartsPartial`

The same `id` / `gridType` pattern exists in the `...Partial` actions of the MakeVsBuy and
Vehicles controllers, so the fix covers those too (a future scan of those modules should come
back clean as well).

## What this fix does

A small middleware checks `id` and `gridType` on the `...Partial` actions of the
`RebuiltParts`, `MakeVsBuy` and `Vehicles` controllers **before** any view or controller runs.
It checks the URL path id, the query string and, for POST, the form body (some actions bind
`id` with `[FromForm]`).

- `id` must be letters, digits, `-` or `_` (1 to 64 characters). Examples that pass:
  `1234`, `abcd123`, `123abcd`, `abcd_123`, `abcd-123`. Missing or empty values pass through unchanged.
- `gridType` must be one of the allowed grid names (below). Missing or empty passes through
  (the controllers apply their own defaults).
- Anything else gets HTTP 400, and the user sees a Kendo dialog ("Invalid ID" or "Invalid Request").

No view or controller changes are needed.

## Allowed grid names

Taken from the CES controller and view search results:

`RebuiltGrid`, `VehicleGrid`, `MakeVsBuyGrid`, `ArchivedVehicleGrid`, `ArchivedMakeVsBuyGrid`,
`ArchivedRebuiltGrid`, `NscGrid`, `RbGrid`, `NonStockCodedPartsGrid`, `MakeVsBuy`, `RebuiltPart`,
`Vehicle`, `MAKEVSBUY`

The last five are sent by other endpoints (AutoComplete, ViewReport, non-stock parts delete), not by
the partial actions. They are listed so they are never blocked if the middleware is extended.

If you add a new grid type in code, add its name to `AllowedGridTypes` in the middleware.

## Contents

| File | What to do |
|---|---|
| `Middleware/InputValidationMiddleware.cs` | Add to the project (new file) |
| `Startup.cs` | Two changes: `using BCES.Middleware;` and one `app.UseMiddleware<...>()` line. A full patched copy is included; **compare with your own before overwriting** |
| `wwwroot/js/site.append.js` | **Append** the contents to the end of your existing `wwwroot/js/site.js` (do not replace the file) |
| `Tests/Test-XssFix.ps1` | Optional PowerShell smoke test using the scan's payload shapes |
| `README.md` | This file |

`Program.cs` is unchanged.

## Install

1. Copy `Middleware/InputValidationMiddleware.cs` into the project (keep the `Middleware` folder).
2. In `Startup.cs`:
   - add `using BCES.Middleware;` at the top
   - in `Configure`, add this right after `app.UseStaticFiles();` and before the session validation middleware:
     ```csharp
     app.UseMiddleware<InputValidationMiddleware>();
     ```
3. Append `wwwroot/js/site.append.js` to the end of `wwwroot/js/site.js`.
   `site.js` is loaded after jQuery and Kendo in the layout, so no view change is needed.
4. Build and deploy to UAT.

## Verify

1. Run `Tests/Test-XssFix.ps1` (use `-Site` if the URL differs). Attack lines should return 400; valid lines should not.
2. Open the Rebuilt Parts, Make vs Buy and Vehicles screens and confirm the grids load normally.
3. Re-run the Invicti scan. All seven High findings should be gone.

## Notes and limits

- **Scope:** only `...Partial` actions on the three controllers above are checked. Other endpoints
  that take `gridType` (for example `TotalCost/ViewReport`, `AutoComplete/GetRbPartDetails`) were not
  flagged by the scan and are not touched. If a future scan flags them, add the controller or action
  to the middleware.
- **Root cause is not removed.** The views still write `id` / `gridType` into script blocks without
  encoding. This fix blocks the attack at the entry point. For a lasting fix, encode output in the
  views (for example `Url.Action(...)` or `Json.Serialize(...)` instead of string concatenation) and
  add a Content Security Policy with script nonces. Add this to the backlog.
- **Dialog:** relies on jQuery AJAX (`ajaxError`). If a partial is loaded another way, such as `fetch`,
  the 400 still happens but the dialog will not show.
- **Out of scope:** the Medium and Low findings (HSTS, cookie Secure flag, CORS `AllowAll`, header and
  version disclosure, stack trace, autocomplete) are not addressed here.
- **Logging:** blocked requests are logged as warnings (parameter name, controller, action, client IP;
  not the value).
