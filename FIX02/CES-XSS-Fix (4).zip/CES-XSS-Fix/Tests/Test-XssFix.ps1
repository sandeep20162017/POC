# Quick check of the XSS fix using the payload shapes from the Invicti scan.
# Run from a Windows machine that can reach the site. Uses your Windows credentials.
# Expected: every "attack" line prints 400, every "valid" line prints something other than 400.

param(
    [string]$Site = "https://ces.uat.int.ttc.ca"
)

# Controller -> partial actions (from the CES source)
$targets = @{
    "RebuiltParts" = "LabourDetailsPartial","ScDetailsPartial","RebuiltPartsPartial","NonStockPartsPartial","AllLabourInRBPartial"
    "MakeVsBuy"    = "LabourDetailsPartial","ScDetailsPartial","LabourHourSummaryPartial","AllLabourInRBPartial","MaterialCostSummaryPartial","NonStockPartsPartial","RebuiltPartsPartial","TotalCostPartial"
    "Vehicles"     = "LabourDetailsPartial","ScDetailsPartial","LabourHourSummaryPartial","AllLabourInRBPartial","MaterialCostSummaryPartial","NonStockPartsPartial","RebuiltPartsPartial","TotalCostPartial"
}

$payloads = @(
    "'`"--></style></scRipt><scRipt>netsparker(0x00568A)</scRipt>",
    "<scRipt>ns(0x005DDE)</scRipt>"
)

function Try-Get($url) {
    try   { [int](Invoke-WebRequest $url -UseDefaultCredentials -UseBasicParsing).StatusCode }
    catch { [int]$_.Exception.Response.StatusCode }
}

function Try-Post($url, $body) {
    try   { [int](Invoke-WebRequest $url -Method Post -Body $body -ContentType "application/x-www-form-urlencoded" -UseDefaultCredentials -UseBasicParsing).StatusCode }
    catch { [int]$_.Exception.Response.StatusCode }
}

foreach ($c in $targets.Keys) {
    foreach ($a in $targets[$c]) {
        $base = "$Site/$c/$a"
        foreach ($p in $payloads) {
            $e = [uri]::EscapeDataString($p)
            "{0,-13}{1,-28} GET id-attack        -> {2}   (expect 400)" -f $c, $a, (Try-Get "$base`?gridType=RebuiltGrid&id=$e")
            "{0,-13}{1,-28} GET gridType-attack  -> {2}   (expect 400)" -f $c, $a, (Try-Get "$base`?gridType=$e&id=3")
            "{0,-13}{1,-28} POST id-attack       -> {2}   (expect 400)" -f $c, $a, (Try-Post $base "id=$e&gridType=VehicleGrid")
        }
        foreach ($id in "1234","abcd123","123abcd","abcd_123","abcd-123") {
            "{0,-13}{1,-28} GET valid id {2,-9} -> {3}   (expect not 400)" -f $c, $a, $id, (Try-Get "$base`?gridType=VehicleGrid&id=$id")
        }
    }
}
