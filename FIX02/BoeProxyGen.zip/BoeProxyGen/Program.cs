// Minimal ASP.NET Core 8 app. It exists only so the project builds and the
// generated BOEService/Reference.cs can be compiled and checked.
var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();
app.MapGet("/", () => "BoeProxyGen: run generate-reference.ps1 to create Connected Services/BOEService/Reference.cs");
app.Run();
