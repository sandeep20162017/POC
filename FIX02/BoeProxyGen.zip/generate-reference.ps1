# Generates the WCF proxy (Reference.cs) for the TTC BOE ReportService.
# Run on a TTC-network machine with the .NET 8 SDK. No login or password is needed:
# only the service metadata (WSDL/XSD) is read.
#
#   powershell -ExecutionPolicy Bypass -File .\generate-reference.ps1
#
# Mirrors the Visual Studio wizard settings in the TTC guide: namespace BOEService,
# public classes, synchronous operations, System.Array collections.

$ErrorActionPreference = "Stop"
$wsdl = "https://boeservice.prod.int.ttc.ca/ReportService.svc?wsdl"
$proj = Join-Path $PSScriptRoot "BoeProxyGen"
$out  = Join-Path $proj "Connected Services\BOEService"

Write-Host "1/4 .NET SDK version:"
dotnet --version

Write-Host "2/4 Installing dotnet-svcutil (once)..."
dotnet tool update --global dotnet-svcutil

Write-Host "3/4 Generating proxy from $wsdl ..."
New-Item -ItemType Directory -Force -Path $out | Out-Null
Push-Location $proj
dotnet-svcutil $wsdl `
    --outputDir $out `
    --outputFile Reference.cs `
    --namespace "*,BOEService" `
    --collectionType System.Array `
    --sync `
    --targetFramework net8.0
Pop-Location

Write-Host "4/4 Done. Send back: $out\Reference.cs"
Write-Host "If the folder also has dotnet-svcutil.params.json, send that too."
Write-Host "If a step failed, copy the console output and send it instead."
