# BoeProxyGen: get the BOE ReportService contract (Reference.cs)

Purpose: produce `Reference.cs` for `https://boeservice.prod.int.ttc.ca/ReportService.svc`
so the CES controller can be written against the real `Connect` and `GetOpenDocURL`
signatures. No login or password is needed: this only reads the service metadata.

## Option A: Visual Studio (matches the TTC guide)

1. Open `BoeProxyGen\BoeProxyGen.csproj` in Visual Studio 2022, on the TTC network.
2. Right-click the project, then **Add > Connected Service > WCF Web Service**.
3. URI: `https://boeservice.prod.int.ttc.ca/ReportService.svc`, click **Go**, then **Next**.
4. Namespace: `BOEService`. Click **Next**.
5. Data type options: Collection type `System.Array`, dictionary type
   `System.Collections.Generic.Dictionary`, **Reuse types in all referenced assemblies**. **Next**.
6. Client options: Access level **Public**, tick **Generate Synchronous Operations**. **Finish**.
7. Send back `Connected Services\BOEService\Reference.cs`.

## Option B: Command line

Needs the .NET 8 SDK:

    powershell -ExecutionPolicy Bypass -File .\generate-reference.ps1

Send back `BoeProxyGen\Connected Services\BOEService\Reference.cs`.
If it fails, send the console output.

## Fallback: only the contract, no generated code

Open these in a browser on the TTC network and save each as a file:

- `https://boeservice.prod.int.ttc.ca/ReportService.svc?xsd=xsd0`
- `https://boeservice.prod.int.ttc.ca/ReportService.svc?xsd=xsd2`

## What to check before sending

Search `Reference.cs` for `Connect` and `GetOpenDocURL`. Do not send anything that
contains real passwords or live logon tokens. The generated file should not have any.
