using BCES.Controllers.Base;
using BCES.Data;
using BCES.Models.Reports;
using BOEService;                       // namespace of the generated Reference.cs
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.ServiceModel;
using System.Text.Json;

namespace BCES.Controllers.Reports
{
    /// <summary>
    /// Runs Crystal reports published in BOE 4.3 through the TTC ReportService (WCF).
    /// Flow per request: Connect -> GetReport (PDF bytes) -> Disconnect.
    /// All BOE logic is private helpers on this controller (CES convention: no Services layer).
    /// </summary>
    public class ReportsController : BaseController
    {
        private readonly IDbConnection _db;   // own field, so it does not depend on BaseController's access level

        public ReportsController(DapperContext dapper, IHttpContextAccessor httpContextAccessor)
            : base(dapper, httpContextAccessor)
        {
            _db = dapper.CreateConnection();
        }

        // GET /Reports  -> list of reports the current role may run
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var reports = await GetAvailableReportsAsync();
            return View(reports);
        }

        // GET /Reports/Viewer?code=COST_VARIANCE  -> parameter form + PDF frame
        [HttpGet]
        public async Task<IActionResult> Viewer(string code)
        {
            var report = await GetReportByCodeAsync(code);
            if (report == null) return NotFound("Report not found.");
            if (!HasAccess(report)) return StatusCode(403, "Access denied to this report.");

            var model = new ReportViewerModel
            {
                Report = report,
                Parameters = (await GetParameterDefsAsync(report.ReportId)).ToList()
            };
            return View(model);
        }

        // GET /Reports/Run?code=COST_VARIANCE&p_Start%20Date=2026-01-01   (parameters in the query string, prefix "p_")
        [HttpGet]
        public async Task<IActionResult> Run(string code)
        {
            var sw = Stopwatch.StartNew();
            var report = await GetReportByCodeAsync(code);
            if (report == null) return NotFound("Report not found.");
            if (!HasAccess(report)) return StatusCode(403, "Access denied to this report.");

            int? userId = await GetCurrentUserIdAsync();
            var defs = (await GetParameterDefsAsync(report.ReportId)).ToList();

            // Only parameters defined in BoeReportParameter are accepted (whitelist); everything else is ignored.
            var values = new Dictionary<string, string>();
            var dates = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
            foreach (var d in defs)
            {
                var raw = Request.Query["p_" + d.ParamName].ToString();
                if (string.IsNullOrWhiteSpace(raw))
                {
                    if (d.IsRequired) return BadRequest($"Parameter '{d.Label}' is required.");
                    continue;
                }
                if (!TryNormalize(d, raw.Trim(), out var normalized))
                    return BadRequest($"Parameter '{d.Label}' has an invalid value.");
                values[d.ParamName] = normalized;
                if (d.DataType == "Date" &&
                    DateTime.TryParse(raw, CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsedDate))
                    dates[d.ParamName] = parsedDate;
            }

            // startDate must not be after endDate
            if (dates.TryGetValue("startDate", out var sd) && dates.TryGetValue("endDate", out var ed) && sd > ed)
                return BadRequest("Start Date must be on or before End Date.");

            ReportServiceClient client = null;
            string token = null;
            try
            {
                if (report.BoeReportName.StartsWith("REPLACE_WITH", StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("BoeReportName is not configured for report " + report.ReportCode + ".");

                var cfg = await GetBoeConfigAsync();
                client = CreateClient(cfg);

                token = await client.ConnectAsync(new BOEConnection
                {
                    BOEUserName = cfg.UserName,
                    BOEPassword = cfg.Password,
                    EnvironmentCode = cfg.EnvironmentCode,
                    PasswordEncrypted = cfg.PasswordEncrypted
                });
                if (string.IsNullOrEmpty(token))
                    throw new InvalidOperationException("BOE returned an empty session token.");

                var request = new BOEReportRequest
                {
                    ReportFolder = string.IsNullOrWhiteSpace(report.BoeReportFolder) ? cfg.ReportFolder : report.BoeReportFolder,
                    ReportName = report.BoeReportName,
                    OutputFormat = BOEService.ReportType.PDF,
                    ReportSearchScope = BOEService.SearchScope.Shallow,
                    ReportParameters = defs.Where(d => values.ContainsKey(d.ParamName))
                        .Select(d => (RptParameter)new RptInputSingleValueParameter
                        {
                            ParamName = d.ParamName,
                            IsUse = true,
                            ParamValue = new RptParameterSingleValue { Value = values[d.ParamName] }
                        }).ToArray()
                };

                byte[] pdf = await client.GetReportAsync(token, request);
                if (pdf == null || pdf.Length == 0)
                    throw new InvalidOperationException("BOE returned an empty report.");

                sw.Stop();
                await AuditAsync(cfg, report.ReportId, userId, values, 200, null, sw.ElapsedMilliseconds);

                Response.Headers["Cache-Control"] = "no-store";
                Response.Headers["Content-Disposition"] = $"inline; filename=\"{report.ReportCode}.pdf\"";
                return new FileContentResult(pdf, "application/pdf");
            }
            catch (FaultException<RequestFault> ex)   // bad report name, folder or parameter: safe to show
            {
                sw.Stop();
                var msg = ex.Detail?.Message ?? ex.Message;
                await SafeAuditAsync(report.ReportId, userId, values, 502, "BOE RequestFault: " + msg, sw.ElapsedMilliseconds);
                return StatusCode(502, "BOE rejected the request: " + msg);
            }
            catch (FaultException<BOESessionFault> ex)
            {
                sw.Stop();
                await SafeAuditAsync(report.ReportId, userId, values, 502,
                    "BOE SessionFault: " + (ex.Detail?.Message ?? ex.Message), sw.ElapsedMilliseconds);
                return StatusCode(502, "The BOE session could not be established. Please contact support.");
            }
            catch (FaultException<GeneralFault> ex)
            {
                sw.Stop();
                await SafeAuditAsync(report.ReportId, userId, values, 502,
                    "BOE GeneralFault: " + (ex.Detail?.Message ?? ex.Message), sw.ElapsedMilliseconds);
                return StatusCode(502, "The report service reported an error. Please contact support.");
            }
            catch (FaultException ex)   // any other SOAP fault
            {
                sw.Stop();
                await SafeAuditAsync(report.ReportId, userId, values, 502, "BOE fault: " + ex.Message, sw.ElapsedMilliseconds);
                return StatusCode(502, "The report service rejected the request. " + ex.Message);
            }
            catch (Exception ex)
            {
                sw.Stop();
                await SafeAuditAsync(report.ReportId, userId, values, 500, ex.Message, sw.ElapsedMilliseconds);
                return StatusCode(500, "Report execution failed. Please contact support.");
            }
            finally
            {
                await CloseAsync(client, token);
            }
        }

        // ------------------------------------------------------------------ helpers

        // Same logic BaseController uses: DOMAIN\userid -> Users.UserADId -> Users.UserId (NOT the role id)
        private async Task<int?> GetCurrentUserIdAsync()
        {
            var name = HttpContext?.User?.Identity?.Name;
            if (string.IsNullOrWhiteSpace(name)) return null;
            var adId = name.Contains('\\') ? name.Split('\\')[1] : name;
            return await _db.QueryFirstOrDefaultAsync<int?>(
                "SELECT [UserId] FROM [SBCES].[Users] WHERE [UserADId] = @UserADId", new { UserADId = adId });
        }

        private bool HasAccess(BoeReportViewModel r)
        {
            int roleId = Convert.ToInt32((object)ViewBag.RoleId ?? 0);
            return r.IsActive && (r.RequiredRoleId == null || r.RequiredRoleId == roleId);
        }

        private async Task<IEnumerable<BoeReportViewModel>> GetAvailableReportsAsync()
        {
            int roleId = Convert.ToInt32((object)ViewBag.RoleId ?? 0);
            const string sql = @"
                SELECT [ReportId],[ReportCode],[DisplayName],[BoeReportName],[BoeReportFolder],
                       [Description],[RequiredRoleId],[SortOrder],[IsActive]
                FROM [SBCES].[BoeReportMapping]
                WHERE [IsActive] = 1 AND ([RequiredRoleId] IS NULL OR [RequiredRoleId] = @RoleId)
                ORDER BY [SortOrder],[DisplayName]";
            return await _db.QueryAsync<BoeReportViewModel>(sql, new { RoleId = roleId });
        }

        private async Task<BoeReportViewModel> GetReportByCodeAsync(string code)
        {
            if (string.IsNullOrWhiteSpace(code)) return null;
            const string sql = @"
                SELECT [ReportId],[ReportCode],[DisplayName],[BoeReportName],[BoeReportFolder],
                       [Description],[RequiredRoleId],[SortOrder],[IsActive]
                FROM [SBCES].[BoeReportMapping]
                WHERE [ReportCode] = @Code AND [IsActive] = 1";
            return await _db.QueryFirstOrDefaultAsync<BoeReportViewModel>(sql, new { Code = code });
        }

        private async Task<IEnumerable<BoeReportParameterModel>> GetParameterDefsAsync(int reportId)
        {
            const string sql = @"
                SELECT [ParameterId],[ReportId],[ParamName],[Label],[DataType],[BoeFormat],[IsRequired],[SortOrder]
                FROM [SBCES].[BoeReportParameter]
                WHERE [ReportId] = @ReportId ORDER BY [SortOrder],[ParamName]";
            return await _db.QueryAsync<BoeReportParameterModel>(sql, new { ReportId = reportId });
        }

        internal static bool TryNormalize(BoeReportParameterModel d, string raw, out string normalized)
        {
            normalized = raw;
            switch (d.DataType)
            {
                case "Date":
                    if (!DateTime.TryParse(raw, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt)) return false;
                    normalized = dt.ToString(string.IsNullOrWhiteSpace(d.BoeFormat) ? "yyyy-MM-dd" : d.BoeFormat, CultureInfo.InvariantCulture);
                    return true;
                case "Number":
                    if (!decimal.TryParse(raw, NumberStyles.Number, CultureInfo.InvariantCulture, out var n)) return false;
                    normalized = n.ToString(CultureInfo.InvariantCulture);
                    return true;
                default:
                    return raw.Length <= 500;
            }
        }

        // ---- BOE configuration (all from [SBCES].[CesSettings]) ----

        private class BoeConfig
        {
            public string ServiceUrl, EnvironmentCode, UserName, Password, ReportFolder;
            public bool PasswordEncrypted, AuditEnabled;
            public int TimeoutSeconds;
        }

        private async Task<BoeConfig> GetBoeConfigAsync()
        {
            var rows = await _db.QueryAsync<CesSettingRow>(
                "SELECT [Parameter],[Value] FROM [SBCES].[CesSettings] WHERE [Parameter] LIKE 'BOE[_]%'");
            var s = rows.ToDictionary(r => r.Parameter, r => r.Value, StringComparer.OrdinalIgnoreCase);

            string Req(string key)
            {
                if (!s.TryGetValue(key, out var v) || string.IsNullOrWhiteSpace(v) || v.StartsWith("REPLACE_WITH"))
                    throw new InvalidOperationException($"CesSettings '{key}' is not configured.");
                return v.Trim();
            }

            var cfg = new BoeConfig
            {
                ServiceUrl = Req("BOE_ServiceUrl"),
                EnvironmentCode = Req("BOE_EnvironmentCode"),
                UserName = Req("BOE_UserName"),
                Password = Req("BOE_Password"),
                ReportFolder = s.TryGetValue("BOE_ReportFolder", out var f) ? f?.Trim() : null,
                PasswordEncrypted = s.TryGetValue("BOE_PasswordEncrypted", out var pe) && string.Equals(pe, "true", StringComparison.OrdinalIgnoreCase),
                AuditEnabled = s.TryGetValue("BOE_EnableAudit", out var a) && string.Equals(a, "true", StringComparison.OrdinalIgnoreCase),
                TimeoutSeconds = s.TryGetValue("BOE_Timeout", out var t) && int.TryParse(t, out var ti) && ti > 0 ? ti : 60
            };

            if (!cfg.ServiceUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("BOE_ServiceUrl must use HTTPS.");
            return cfg;
        }

        // ---- WCF client built in code (no web.config/appsettings endpoint needed) ----

        private static ReportServiceClient CreateClient(BoeConfig cfg)
        {
            var binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport)
            {
                MaxReceivedMessageSize = 50 * 1024 * 1024,   // PDF comes back as base64 inside the SOAP message
                MaxBufferSize = 50 * 1024 * 1024,
                OpenTimeout = TimeSpan.FromSeconds(cfg.TimeoutSeconds),
                SendTimeout = TimeSpan.FromSeconds(cfg.TimeoutSeconds),
                ReceiveTimeout = TimeSpan.FromSeconds(cfg.TimeoutSeconds),
                CloseTimeout = TimeSpan.FromSeconds(15)
            };
            binding.ReaderQuotas.MaxArrayLength = 50 * 1024 * 1024;
            binding.ReaderQuotas.MaxStringContentLength = 50 * 1024 * 1024;
            return new ReportServiceClient(binding, new EndpointAddress(cfg.ServiceUrl));
        }

        private static async Task CloseAsync(ReportServiceClient client, string token)
        {
            if (client == null) return;
            try
            {
                if (!string.IsNullOrEmpty(token)) await client.DisconnectAsync(token);   // best effort, frees the BOE session
            }
            catch { /* session may already be gone */ }
            try
            {
                if (client.State == CommunicationState.Faulted) client.Abort(); else await client.CloseAsync();
            }
            catch { client.Abort(); }
        }

        // ---- audit: report id, user, parameter values, status. Never tokens or passwords ----

        private async Task AuditAsync(BoeConfig cfg, int reportId, int? userId, Dictionary<string, string> values,
                                      int status, string error, long ms)
        {
            if (!cfg.AuditEnabled) return;
            await InsertAuditAsync(reportId, userId, values, status, error, ms);
        }

        private async Task SafeAuditAsync(int reportId, int? userId, Dictionary<string, string> values,
                                          int status, string error, long ms)
        {
            try
            {
                var enabled = await _db.QueryFirstOrDefaultAsync<string>(
                    "SELECT [Value] FROM [SBCES].[CesSettings] WHERE [Parameter]='BOE_EnableAudit'");
                if (string.Equals(enabled, "true", StringComparison.OrdinalIgnoreCase))
                    await InsertAuditAsync(reportId, userId, values, status, error, ms);
            }
            catch { /* auditing must never mask the original error */ }
        }

        private Task InsertAuditAsync(int reportId, int? userId, Dictionary<string, string> values,
                                      int status, string error, long ms)
        {
            const string sql = @"
                INSERT INTO [SBCES].[BoeReportAudit]
                    ([ReportId],[UserId],[Parameters],[StatusCode],[ErrorMessage],[ExecutionDurationMs])
                VALUES (@ReportId,@UserId,@Parameters,@StatusCode,@ErrorMessage,@Ms)";
            return _db.ExecuteAsync(sql, new
            {
                ReportId = reportId,
                UserId = userId,
                Parameters = values.Count > 0 ? JsonSerializer.Serialize(values) : null,
                StatusCode = status,
                ErrorMessage = error != null && error.Length > 2000 ? error.Substring(0, 2000) : error,
                Ms = (int)ms
            });
        }
    }
}
