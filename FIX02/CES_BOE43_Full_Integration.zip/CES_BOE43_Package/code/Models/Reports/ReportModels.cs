using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Reports
{
    public class BoeReportViewModel
    {
        public int ReportId { get; set; }
        [Required, StringLength(50)]  public string ReportCode { get; set; }
        [Required, StringLength(100)] public string DisplayName { get; set; }
        [Required, StringLength(200)] public string BoeReportName { get; set; }
        [StringLength(200)] public string BoeReportFolder { get; set; }
        [StringLength(500)] public string Description { get; set; }
        public int? RequiredRoleId { get; set; }
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
    }

    public class BoeReportParameterModel
    {
        public int ParameterId { get; set; }
        public int ReportId { get; set; }
        public string ParamName { get; set; }
        public string Label { get; set; }
        public string DataType { get; set; }   // String | Date | Number
        public string BoeFormat { get; set; }  // Date only
        public bool IsRequired { get; set; }
        public int SortOrder { get; set; }
    }

    public class ReportViewerModel
    {
        public BoeReportViewModel Report { get; set; }
        public List<BoeReportParameterModel> Parameters { get; set; } = new();
    }

    /// <summary>Row from [SBCES].[CesSettings].</summary>
    public class CesSettingRow
    {
        public string Parameter { get; set; }
        public string Value { get; set; }
    }
}
