using BCES.Controllers.Reports;   // EDIT: namespace of ReportsController
using BCES.Models.Reports;        // EDIT: namespace of BoeReportParameterModel
using Xunit;

namespace CES.BoeReports.Tests
{
    /// <summary>Pure logic tests. No database, no BOE, no network.</summary>
    public class ParameterNormalizeTests
    {
        private static BoeReportParameterModel Def(string type, string format = null) =>
            new BoeReportParameterModel { ParamName = "startDate", Label = "Start Date", DataType = type, BoeFormat = format };

        [Theory]
        [InlineData("2026-01-31", "2026-01-31")]
        [InlineData("2026-1-5", "2026-01-05")]
        [InlineData("01/31/2026", "2026-01-31")]
        public void Date_valid_values_use_the_default_format(string raw, string expected)
        {
            Assert.True(ReportsController.TryNormalize(Def("Date"), raw, out var result));
            Assert.Equal(expected, result);
        }

        [Fact]
        public void Date_uses_the_format_stored_in_BoeFormat()
        {
            Assert.True(ReportsController.TryNormalize(Def("Date", "MM/dd/yyyy"), "2026-01-31", out var result));
            Assert.Equal("01/31/2026", result);
        }

        [Theory]
        [InlineData("abc")]
        [InlineData("2026-13-45")]
        [InlineData("31/31/2026")]
        public void Date_invalid_values_are_rejected(string raw)
        {
            Assert.False(ReportsController.TryNormalize(Def("Date"), raw, out _));
        }

        [Theory]
        [InlineData("12.50", "12.50")]
        [InlineData("1,234.5", "1234.5")]
        [InlineData("-7", "-7")]
        public void Number_valid_values_are_normalised(string raw, string expected)
        {
            Assert.True(ReportsController.TryNormalize(Def("Number"), raw, out var result));
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData("abc")]
        [InlineData("1.2.3")]
        public void Number_invalid_values_are_rejected(string raw)
        {
            Assert.False(ReportsController.TryNormalize(Def("Number"), raw, out _));
        }

        [Fact]
        public void String_up_to_500_characters_is_accepted()
        {
            Assert.True(ReportsController.TryNormalize(Def("String"), new string('a', 500), out _));
        }

        [Fact]
        public void String_over_500_characters_is_rejected()
        {
            Assert.False(ReportsController.TryNormalize(Def("String"), new string('a', 501), out _));
        }
    }
}
