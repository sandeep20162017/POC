using System.ServiceModel;
using BOEService;
using Xunit;

namespace CES.BoeReports.Tests
{
    /// <summary>
    /// Calls the real ReportService, WITHOUT CES. Skipped unless the BOE_TEST_* environment variables are set.
    /// Use a DEV account. Credentials come from environment variables only, never from source code.
    ///   BOE_TEST_URL       https://boeservice.prod.int.ttc.ca/ReportService.svc/soap
    ///   BOE_TEST_USER      BOE application user
    ///   BOE_TEST_PASSWORD  its password (plain text, PasswordEncrypted = false)
    ///   BOE_TEST_ENV       EnvironmentCode for DEV (from the BOE Administrator)
    ///   BOE_TEST_FOLDER    BOE report folder
    ///   BOE_TEST_REPORT    exact report name
    ///   Optional: BOE_TEST_START_NAME (default startDate), BOE_TEST_END_NAME (default endDate),
    ///             BOE_TEST_START (default 2026-01-01), BOE_TEST_END (default 2026-01-31)
    /// </summary>
    public class BoeServiceSmokeTests
    {
        private static string Env(string name, string fallback = null)
        {
            var v = Environment.GetEnvironmentVariable(name);
            return string.IsNullOrWhiteSpace(v) ? fallback : v;
        }

        private static bool Configured =>
            new[] { "BOE_TEST_URL", "BOE_TEST_USER", "BOE_TEST_PASSWORD", "BOE_TEST_ENV", "BOE_TEST_FOLDER", "BOE_TEST_REPORT" }
                .All(k => !string.IsNullOrWhiteSpace(Env(k)));

        private const string SkipText = "Set the BOE_TEST_* environment variables to run this test.";

        private static ReportServiceClient NewClient()
        {
            var binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport)
            {
                MaxReceivedMessageSize = 50 * 1024 * 1024,
                MaxBufferSize = 50 * 1024 * 1024,
                SendTimeout = TimeSpan.FromSeconds(120),
                ReceiveTimeout = TimeSpan.FromSeconds(120)
            };
            binding.ReaderQuotas.MaxArrayLength = 50 * 1024 * 1024;
            binding.ReaderQuotas.MaxStringContentLength = 50 * 1024 * 1024;
            return new ReportServiceClient(binding, new EndpointAddress(Env("BOE_TEST_URL")));
        }

        private static BOEConnection Connection() => new BOEConnection
        {
            BOEUserName = Env("BOE_TEST_USER"),
            BOEPassword = Env("BOE_TEST_PASSWORD"),
            EnvironmentCode = Env("BOE_TEST_ENV"),
            PasswordEncrypted = false
        };

        private static BOEReportRequest Request(string reportName) => new BOEReportRequest
        {
            ReportFolder = Env("BOE_TEST_FOLDER"),
            ReportName = reportName,
            OutputFormat = BOEService.ReportType.PDF,
            ReportSearchScope = BOEService.SearchScope.Shallow,
            ReportParameters = new RptParameter[]
            {
                new RptInputSingleValueParameter
                {
                    ParamName = Env("BOE_TEST_START_NAME", "startDate"), IsUse = true,
                    ParamValue = new RptParameterSingleValue { Value = Env("BOE_TEST_START", "2026-01-01") }
                },
                new RptInputSingleValueParameter
                {
                    ParamName = Env("BOE_TEST_END_NAME", "endDate"), IsUse = true,
                    ParamValue = new RptParameterSingleValue { Value = Env("BOE_TEST_END", "2026-01-31") }
                }
            }
        };

        [SkippableFact]
        public async Task Connect_returns_a_token_and_Disconnect_succeeds()
        {
            Skip.IfNot(Configured, SkipText);
            var client = NewClient();
            string token = null;
            try
            {
                token = await client.ConnectAsync(Connection());
                Assert.False(string.IsNullOrWhiteSpace(token));
            }
            finally
            {
                if (token != null) await client.DisconnectAsync(token);
                client.Abort();
            }
        }

        [SkippableFact]
        public async Task GetReport_returns_a_pdf()
        {
            Skip.IfNot(Configured, SkipText);
            var client = NewClient();
            string token = null;
            try
            {
                token = await client.ConnectAsync(Connection());
                byte[] pdf = await client.GetReportAsync(token, Request(Env("BOE_TEST_REPORT")));
                Assert.NotNull(pdf);
                Assert.True(pdf.Length > 4);
                Assert.Equal("%PDF", System.Text.Encoding.ASCII.GetString(pdf, 0, 4));
            }
            finally
            {
                if (token != null) await client.DisconnectAsync(token);
                client.Abort();
            }
        }

        [SkippableFact]
        public async Task GetReport_with_an_unknown_report_name_faults()
        {
            Skip.IfNot(Configured, SkipText);
            var client = NewClient();
            string token = null;
            try
            {
                token = await client.ConnectAsync(Connection());
                await Assert.ThrowsAnyAsync<FaultException>(() =>
                    client.GetReportAsync(token, Request("THIS_REPORT_DOES_NOT_EXIST_12345")));
            }
            finally
            {
                if (token != null) { try { await client.DisconnectAsync(token); } catch { } }
                client.Abort();
            }
        }

        [SkippableFact]
        public async Task Connect_with_a_wrong_password_faults()
        {
            Skip.IfNot(Configured, SkipText);
            var client = NewClient();
            try
            {
                var bad = Connection();
                bad.BOEPassword = "definitely-wrong-password";
                await Assert.ThrowsAnyAsync<FaultException>(() => client.ConnectAsync(bad));
            }
            finally { client.Abort(); }
        }
    }
}
