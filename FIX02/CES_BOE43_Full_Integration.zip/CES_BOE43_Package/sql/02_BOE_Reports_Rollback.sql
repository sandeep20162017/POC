/* Rollback for the BOE 4.3 reports module (dependency order). */
DROP TABLE IF EXISTS [SBCES].[BoeReportAudit];
DROP TABLE IF EXISTS [SBCES].[BoeReportParameter];
DROP TABLE IF EXISTS [SBCES].[BoeReportMapping];
DELETE FROM [SBCES].[CesSettings] WHERE [Parameter] LIKE 'BOE[_]%';
GO
