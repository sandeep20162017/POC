/* =====================================================================
   CES - BOE 4.3 reports module: tables + CesSettings seed
   Run once per environment (DEV / UAT / PROD). Safe to re-run.
   Edit the DECLARE blocks first (section 4 and section 5).
   Assumes existing tables [SBCES].[Roles]([RoleId]) and [SBCES].[Users]([UserID]).
   ===================================================================== */

/* ---------- 1. Report mapping ---------- */
IF OBJECT_ID('[SBCES].[BoeReportMapping]') IS NULL
BEGIN
    CREATE TABLE [SBCES].[BoeReportMapping](
        [ReportId]         int IDENTITY(1,1) NOT NULL,
        [ReportCode]       varchar(50)  NOT NULL,   -- stable key used in URLs/menu, e.g. COST_VARIANCE
        [DisplayName]      varchar(100) NOT NULL,   -- shown in CES
        [BoeReportName]    varchar(200) NOT NULL,   -- exact report name in the BOE folder
        [BoeReportFolder]  varchar(200) NULL,       -- NULL = use CesSettings BOE_ReportFolder
        [Description]      varchar(500) NULL,
        [RequiredRoleId]   int NULL,                -- NULL = any logged-in role
        [SortOrder]        int NOT NULL CONSTRAINT DF_BoeReportMapping_Sort DEFAULT 0,
        [IsActive]         bit NOT NULL CONSTRAINT DF_BoeReportMapping_Active DEFAULT 1,
        [DateCreated]      datetime NOT NULL CONSTRAINT DF_BoeReportMapping_Created DEFAULT GETDATE(),
        [CreatedBy]        varchar(50) NOT NULL,
        [LastModifiedDate] datetime NULL,
        [LastModifiedBy]   varchar(50) NULL,
        CONSTRAINT [PK_BoeReportMapping] PRIMARY KEY CLUSTERED ([ReportId]),
        CONSTRAINT [UK_BoeReportMapping_Code] UNIQUE NONCLUSTERED ([ReportCode]),
        CONSTRAINT [FK_BoeReportMapping_Roles] FOREIGN KEY ([RequiredRoleId]) REFERENCES [SBCES].[Roles]([RoleId])
    );
END
GO

/* ---------- 2. Report parameters (drive the parameter form) ---------- */
IF OBJECT_ID('[SBCES].[BoeReportParameter]') IS NULL
BEGIN
    CREATE TABLE [SBCES].[BoeReportParameter](
        [ParameterId] int IDENTITY(1,1) NOT NULL,
        [ReportId]    int NOT NULL,
        [ParamName]   varchar(200) NOT NULL,   -- exact prompt name in the Crystal report
        [Label]       varchar(100) NOT NULL,   -- caption in CES
        [DataType]    varchar(10)  NOT NULL CONSTRAINT DF_BoeReportParameter_Type DEFAULT 'String', -- String | Date | Number
        [BoeFormat]   varchar(50)  NULL,       -- Date only: format sent to BOE, e.g. yyyy-MM-dd (confirm in DEV)
        [IsRequired]  bit NOT NULL CONSTRAINT DF_BoeReportParameter_Req DEFAULT 0,
        [SortOrder]   int NOT NULL CONSTRAINT DF_BoeReportParameter_Sort DEFAULT 0,
        CONSTRAINT [PK_BoeReportParameter] PRIMARY KEY CLUSTERED ([ParameterId]),
        CONSTRAINT [UK_BoeReportParameter] UNIQUE NONCLUSTERED ([ReportId],[ParamName]),
        CONSTRAINT [FK_BoeReportParameter_Report] FOREIGN KEY ([ReportId]) REFERENCES [SBCES].[BoeReportMapping]([ReportId]),
        CONSTRAINT [CK_BoeReportParameter_Type] CHECK ([DataType] IN ('String','Date','Number'))
    );
END
GO

/* ---------- 3. Audit (never stores tokens or passwords) ---------- */
IF OBJECT_ID('[SBCES].[BoeReportAudit]') IS NULL
BEGIN
    CREATE TABLE [SBCES].[BoeReportAudit](
        [AuditId]             int IDENTITY(1,1) NOT NULL,
        [ReportId]            int NOT NULL,
        [UserId]              int NULL,
        [ExecutionDate]       datetime NOT NULL CONSTRAINT DF_BoeReportAudit_Date DEFAULT GETDATE(),
        [Parameters]          nvarchar(max) NULL,
        [StatusCode]          int NULL,
        [ErrorMessage]        nvarchar(2000) NULL,
        [ExecutionDurationMs] int NULL,
        CONSTRAINT [PK_BoeReportAudit] PRIMARY KEY CLUSTERED ([AuditId]),
        CONSTRAINT [FK_BoeReportAudit_Report] FOREIGN KEY ([ReportId]) REFERENCES [SBCES].[BoeReportMapping]([ReportId]),
        CONSTRAINT [FK_BoeReportAudit_Users]  FOREIGN KEY ([UserId])   REFERENCES [SBCES].[Users]([UserID])
    );
    CREATE NONCLUSTERED INDEX [IX_BoeReportAudit_User_Date]   ON [SBCES].[BoeReportAudit]([UserId],[ExecutionDate] DESC)   INCLUDE ([ReportId],[StatusCode]);
    CREATE NONCLUSTERED INDEX [IX_BoeReportAudit_Report_Date] ON [SBCES].[BoeReportAudit]([ReportId],[ExecutionDate] DESC) INCLUDE ([UserId],[StatusCode]);
END
GO

/* ---------- 4. Report + its startDate / endDate parameters ----------
   Edit the DECLARE block, then run. Repeat the block for each report.
   @p1 / @p2 must match the Crystal prompt names EXACTLY (case and spaces).      */
DECLARE @code  varchar(50)  = 'REPORT_1';                       -- stable key used in URLs
DECLARE @title varchar(100) = 'REPLACE_WITH_DISPLAY_NAME';      -- shown in CES
DECLARE @boe   varchar(200) = 'REPLACE_WITH_BOE_REPORT_NAME';   -- report name in the BOE folder
DECLARE @p1    varchar(200) = 'startDate';                      -- Crystal prompt name
DECLARE @p2    varchar(200) = 'endDate';                        -- Crystal prompt name

IF NOT EXISTS (SELECT 1 FROM [SBCES].[BoeReportMapping] WHERE [ReportCode] = @code)
    INSERT INTO [SBCES].[BoeReportMapping]([ReportCode],[DisplayName],[BoeReportName],[SortOrder],[CreatedBy])
    VALUES (@code, @title, @boe, 10, 'SYSTEM');

INSERT INTO [SBCES].[BoeReportParameter]([ReportId],[ParamName],[Label],[DataType],[BoeFormat],[IsRequired],[SortOrder])
SELECT r.[ReportId], @p1, 'Start Date', 'Date', 'yyyy-MM-dd', 1, 10
FROM [SBCES].[BoeReportMapping] r
WHERE r.[ReportCode] = @code
  AND NOT EXISTS (SELECT 1 FROM [SBCES].[BoeReportParameter] x WHERE x.[ReportId] = r.[ReportId] AND x.[ParamName] = @p1);

INSERT INTO [SBCES].[BoeReportParameter]([ReportId],[ParamName],[Label],[DataType],[BoeFormat],[IsRequired],[SortOrder])
SELECT r.[ReportId], @p2, 'End Date', 'Date', 'yyyy-MM-dd', 1, 20
FROM [SBCES].[BoeReportMapping] r
WHERE r.[ReportCode] = @code
  AND NOT EXISTS (SELECT 1 FROM [SBCES].[BoeReportParameter] x WHERE x.[ReportId] = r.[ReportId] AND x.[ParamName] = @p2);
GO

/* ---------- 5. CesSettings (all configurable; one set of rows per environment DB) ---------- */
DECLARE @env     varchar(10)  = 'DEV';   -- DEV | UAT | PROD
DECLARE @user    varchar(200) = 'REPLACE_WITH_BOE_APP_USER_FROM_BOE_ADMIN';
DECLARE @pwd     varchar(200) = 'REPLACE_WITH_BOE_APP_PASSWORD';   -- plain text (intranet decision); restrict who can read CesSettings
DECLARE @folder  varchar(200) = 'REPLACE_WITH_BOE_REPORT_FOLDER';   -- e.g. the RDM DevOps folder for this env
DECLARE @envCode varchar(50)  = @env;    -- value the service expects as EnvironmentCode: CONFIRM with BOE Admin

DECLARE @s TABLE (Parameter varchar(100), Value varchar(200));
INSERT INTO @s VALUES
 ('BOE_ServiceUrl',         'https://boeservice.prod.int.ttc.ca/ReportService.svc/soap'),  -- same URL for every env (TTC guide)
 ('BOE_EnvironmentCode',    @envCode),
 ('BOE_UserName',           @user),
 ('BOE_Password',           @pwd),        -- plain text; sent with PasswordEncrypted = false
 ('BOE_PasswordEncrypted',  'false'),
 ('BOE_ReportFolder',       @folder),
 ('BOE_Timeout',            '60'),        -- seconds, applies to connect and report calls
 ('BOE_EnableAudit',        'true');

INSERT INTO [SBCES].[CesSettings]([CesSettingsId],[Parameter],[Value])
SELECT (SELECT ISNULL(MAX(CesSettingsId),0) FROM [SBCES].[CesSettings]) + ROW_NUMBER() OVER (ORDER BY s.Parameter),
       s.Parameter, s.Value
FROM @s s
WHERE NOT EXISTS (SELECT 1 FROM [SBCES].[CesSettings] c WHERE c.Parameter = s.Parameter);
GO
