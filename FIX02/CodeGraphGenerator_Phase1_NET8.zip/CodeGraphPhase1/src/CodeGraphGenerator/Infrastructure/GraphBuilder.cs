using CodeGraphGenerator.Models;
using System.Security.Cryptography;
using System.Text;

namespace CodeGraphGenerator.Infrastructure;

public sealed class GraphBuilder
{
    private readonly Dictionary<string,GraphNode> _nodes = new(StringComparer.Ordinal);
    private readonly Dictionary<string,GraphEdge> _edges = new(StringComparer.Ordinal);
    public IEnumerable<GraphNode> Nodes => _nodes.Values;
    public IEnumerable<GraphEdge> Edges => _edges.Values;

    public GraphNode AddNode(GraphNode node)
    {
        if (!_nodes.ContainsKey(node.Id)) _nodes[node.Id] = node;
        return _nodes[node.Id];
    }

    public void AddEdge(GraphEdge edge)
    {
        if (!_nodes.ContainsKey(edge.From) || !_nodes.ContainsKey(edge.To)) return;
        _edges.TryAdd(edge.Id, edge);
    }

    public static string Id(string kind, string value) => $"{kind}:{value}";
    public static string EdgeId(string from, string to, string type, string evidence) =>
        "edge:" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes($"{from}|{to}|{type}|{evidence}"))).ToLowerInvariant()[..24];

    public GraphPackage BuildPackage(GraphMetadata metadata)
    {
        var p = new GraphPackage { Metadata = metadata, Nodes = _nodes.Values.OrderBy(x=>x.Id).ToList(), Edges = _edges.Values.OrderBy(x=>x.Id).ToList() };
        foreach (var n in p.Nodes)
        {
            if (!string.IsNullOrWhiteSpace(n.Name)) AddIndex(p.Indexes.Symbols, n.Name, n.Id);
            if (n.Location is not null) AddIndex(p.Indexes.Files, n.Location.Path, n.Id);
            if (n.Type is "view" or "partial_view" or "layout") AddIndex(p.Indexes.Views, n.Name, n.Id);
            if (n.Type is "javascript_function" or "javascript_event") AddIndex(p.Indexes.JavaScript, n.Name, n.Id);
            if (n.Type is "route" or "controller_action") AddIndex(p.Indexes.Routes, n.Name, n.Id);
            if (n.Type is "sql_statement" or "dapper_query") AddIndex(p.Indexes.Sql, n.Name, n.Id);
            if (n.Type is "database_table" or "database_view" or "database_function" or "database_procedure") AddIndex(p.Indexes.Database, n.Name, n.Id);
        }
        metadata.Statistics.NodeCount = p.Nodes.Count;
        metadata.Statistics.EdgeCount = p.Edges.Count;
        metadata.Statistics.NodesByType = p.Nodes.GroupBy(x=>x.Type,StringComparer.OrdinalIgnoreCase).ToDictionary(g=>g.Key,g=>g.Count(),StringComparer.OrdinalIgnoreCase);
        metadata.Statistics.EdgesByType = p.Edges.GroupBy(x=>x.Type,StringComparer.OrdinalIgnoreCase).ToDictionary(g=>g.Key,g=>g.Count(),StringComparer.OrdinalIgnoreCase);
        return p;
    }
    private static void AddIndex(Dictionary<string,List<string>> index, string key, string id)
    {
        if (!index.TryGetValue(key,out var list)) index[key]=list=[];
        if (!list.Contains(id,StringComparer.Ordinal)) list.Add(id);
    }
}
