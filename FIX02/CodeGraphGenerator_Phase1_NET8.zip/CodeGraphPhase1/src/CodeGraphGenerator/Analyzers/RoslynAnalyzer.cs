using CodeGraphGenerator.Infrastructure;
using CodeGraphGenerator.Models;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.MSBuild;
using System.Collections.Concurrent;

namespace CodeGraphGenerator.Analyzers;

public sealed class RoslynAnalyzer
{
    private readonly GraphBuilder _g;
    public RoslynAnalyzer(GraphBuilder g) => _g=g;

    public async Task AnalyzeAsync(string solutionPath, CancellationToken ct)
    {
        using var workspace = MSBuildWorkspace.Create();
        workspace.WorkspaceFailed += (_, e) => Console.Error.WriteLine($"[Roslyn] {e.Diagnostic.Kind}: {e.Diagnostic.Message}");
        var solution = await workspace.OpenSolutionAsync(solutionPath, ct);
        foreach (var project in solution.Projects)
        {
            Console.WriteLine($"[Roslyn] Project: {project.Name}");
            foreach (var doc in project.Documents.Where(d=>d.SourceCodeKind==SourceCodeKind.Regular))
            {
                ct.ThrowIfCancellationRequested();
                var root = await doc.GetSyntaxRootAsync(ct);
                var model = await doc.GetSemanticModelAsync(ct);
                if (root is null || model is null) continue;
                AnalyzeDocument(doc, root, model, project.Name, ct);
            }
        }
    }

    private void AnalyzeDocument(Document doc, SyntaxNode root, SemanticModel model, string project, CancellationToken ct)
    {
        var file = doc.FilePath ?? doc.Name;
        foreach (var cls in root.DescendantNodes().OfType<ClassDeclarationSyntax>())
        {
            ct.ThrowIfCancellationRequested();
            var symbol = model.GetDeclaredSymbol(cls, ct);
            if (symbol is null) continue;
            var id = GraphBuilder.Id("class", symbol.ToDisplayString(SymbolDisplayFormat.FullyQualifiedFormat));
            _g.AddNode(new GraphNode { Id=id, Type="class", Name=symbol.Name, Namespace=symbol.ContainingNamespace?.ToDisplayString(), Project=project, Location=Loc(doc, cls), Properties = new() { ["fully_qualified_name"]=symbol.ToDisplayString(), ["accessibility"]=symbol.DeclaredAccessibility.ToString() } });
            foreach (var iface in symbol.Interfaces)
            {
                var iid=GraphBuilder.Id("interface",iface.ToDisplayString(SymbolDisplayFormat.FullyQualifiedFormat));
                _g.AddNode(new GraphNode { Id=iid, Type="interface", Name=iface.Name, Namespace=iface.ContainingNamespace?.ToDisplayString(), Project=project });
                _g.AddEdge(new GraphEdge { Id=GraphBuilder.EdgeId(id,iid,"implements",file), From=id, To=iid, Type="implements", Evidence=Loc(doc,cls) });
            }
            if (symbol.BaseType is { } bt && bt.SpecialType!=SpecialType.System_Object)
            {
                var bid=GraphBuilder.Id("class",bt.ToDisplayString(SymbolDisplayFormat.FullyQualifiedFormat));
                _g.AddNode(new GraphNode { Id=bid, Type="class", Name=bt.Name, Namespace=bt.ContainingNamespace?.ToDisplayString(), Project=project });
                _g.AddEdge(new GraphEdge { Id=GraphBuilder.EdgeId(id,bid,"inherits",file), From=id, To=bid, Type="inherits", Evidence=Loc(doc,cls) });
            }
        }
        foreach (var method in root.DescendantNodes().OfType<MethodDeclarationSyntax>())
        {
            ct.ThrowIfCancellationRequested();
            var symbol=model.GetDeclaredSymbol(method,ct); if(symbol is null) continue;
            var mid=MethodId(symbol);
            var containing=symbol.ContainingType;
            var cid=containing is null ? null : GraphBuilder.Id("class",containing.ToDisplayString(SymbolDisplayFormat.FullyQualifiedFormat));
            if(cid is not null) _g.AddNode(new GraphNode { Id=cid, Type=containing!.TypeKind==TypeKind.Interface?"interface":"class", Name=containing.Name, Namespace=containing.ContainingNamespace?.ToDisplayString(), Project=project });
            _g.AddNode(new GraphNode { Id=mid, Type=IsControllerAction(symbol)?"controller_action":"method", Name=symbol.Name, Namespace=symbol.ContainingNamespace?.ToDisplayString(), Project=project, Location=Loc(doc,method), Properties = new() { ["signature"]=symbol.ToDisplayString(), ["return_type"]=symbol.ReturnType.ToDisplayString(), ["is_async"]=symbol.IsAsync, ["containing_type"]=containing?.ToDisplayString() } });
            if(cid is not null) _g.AddEdge(new GraphEdge { Id=GraphBuilder.EdgeId(mid,cid,"member_of",file+method.SpanStart), From=mid, To=cid, Type="member_of", Evidence=Loc(doc,method) });
            if(IsControllerAction(symbol)) AnalyzeControllerAction(doc,method,model,symbol,mid);
            foreach(var inv in method.DescendantNodes().OfType<InvocationExpressionSyntax>())
            {
                var target=model.GetSymbolInfo(inv,ct).Symbol as IMethodSymbol;
                if(target is null) continue;
                var tid=MethodId(target);
                _g.AddNode(new GraphNode { Id=tid, Type=IsControllerAction(target)?"controller_action":"method", Name=target.Name, Namespace=target.ContainingNamespace?.ToDisplayString(), Project=project, Properties = new() { ["signature"]=target.ToDisplayString(), ["return_type"]=target.ReturnType.ToDisplayString(), ["containing_type"]=target.ContainingType?.ToDisplayString() } });
                _g.AddEdge(new GraphEdge { Id=GraphBuilder.EdgeId(mid,tid,"calls",file+inv.SpanStart), From=mid, To=tid, Type="calls", Evidence=Loc(doc,inv), Properties=new() { ["target_symbol"]=target.ToDisplayString() } });
                if(IsDapperMethod(target)) AnalyzeDapperInvocation(doc, inv, model, mid);
            }
            foreach(var ret in method.DescendantNodes().OfType<ReturnStatementSyntax>())
            {
                var expr=ret.Expression?.ToString(); if(expr is null) continue;
                if(expr.Contains("View(",StringComparison.Ordinal) || expr.Contains("PartialView(",StringComparison.Ordinal))
                    _g.AddNode(new GraphNode { Id=GraphBuilder.Id("view_reference",$"{file}:{ret.SpanStart}"), Type="view_reference", Name=expr, Project=project, Location=Loc(doc,ret), Properties=new(){["expression"]=expr} });
            }
        }
        foreach(var prop in root.DescendantNodes().OfType<PropertyDeclarationSyntax>())
        {
            var symbol=model.GetDeclaredSymbol(prop,ct); if(symbol is null) continue;
            _g.AddNode(new GraphNode { Id=GraphBuilder.Id("property",symbol.ToDisplayString()), Type="property", Name=symbol.Name, Namespace=symbol.ContainingNamespace?.ToDisplayString(), Project=project, Location=Loc(doc,prop), Properties=new(){["type"]=symbol.Type.ToDisplayString()} });
        }
    }

    private void AnalyzeControllerAction(Document doc, MethodDeclarationSyntax method, SemanticModel model, IMethodSymbol symbol, string mid)
    {
        var controller=symbol.ContainingType?.Name ?? "";
        var action=symbol.Name;
        var route=GraphBuilder.Id("route",$"/{controller.Replace("Controller","")}/{action}");
        _g.AddNode(new GraphNode { Id=route, Type="route", Name=$"/{controller.Replace("Controller","")}/{action}", Project=doc.Project.Name, Location=Loc(doc,method), Properties=new(){["controller"]=controller,["action"]=action,["route_kind"]="conventional_candidate"} });
        _g.AddEdge(new GraphEdge { Id=GraphBuilder.EdgeId(route,mid,"routes_to",doc.FilePath+method.SpanStart), From=route, To=mid, Type="routes_to", Confidence="candidate", Evidence=Loc(doc,method) });
        foreach(var attr in method.AttributeLists.SelectMany(x=>x.Attributes))
        {
            var name=attr.Name.ToString();
            if(name.Contains("Route",StringComparison.OrdinalIgnoreCase) || name.Contains("HttpGet",StringComparison.OrdinalIgnoreCase) || name.Contains("HttpPost",StringComparison.OrdinalIgnoreCase) || name.Contains("HttpPut",StringComparison.OrdinalIgnoreCase) || name.Contains("HttpDelete",StringComparison.OrdinalIgnoreCase))
            {
                var text=attr.ArgumentList?.ToString() ?? "";
                _g.AddEdge(new GraphEdge { Id=GraphBuilder.EdgeId(route,mid,"route_attribute",doc.FilePath+attr.SpanStart), From=route, To=mid, Type="route_attribute", Evidence=Loc(doc,attr), Properties=new(){["attribute"]=name,["arguments"]=text} });
            }
        }
    }

    private void AnalyzeDapperInvocation(Document doc, InvocationExpressionSyntax inv, SemanticModel model, string caller)
    {
        var text=inv.ToString();
        var dn=GraphBuilder.Id("dapper_query",$"{doc.FilePath}:{inv.SpanStart}");
        _g.AddNode(new GraphNode { Id=dn, Type="dapper_query", Name=text, Project=doc.Project.Name, Location=Loc(doc,inv), Properties=new(){["operation"]=model.GetSymbolInfo(inv).Symbol?.Name,["expression"]=text} });
        _g.AddEdge(new GraphEdge { Id=GraphBuilder.EdgeId(caller,dn,"dapper_query",doc.FilePath+inv.SpanStart), From=caller, To=dn, Type="dapper_query", Evidence=Loc(doc,inv) });
    }

    private static bool IsDapperMethod(IMethodSymbol s) => s.ContainingNamespace?.ToDisplayString().Equals("Dapper",StringComparison.OrdinalIgnoreCase)==true || new[]{"Query","QueryAsync","QueryFirst","QueryFirstAsync","QuerySingle","QuerySingleAsync","Execute","ExecuteAsync","QueryMultiple","QueryMultipleAsync"}.Contains(s.Name,StringComparer.OrdinalIgnoreCase);
    private static bool IsControllerAction(IMethodSymbol s) => s.ContainingType?.Name.EndsWith("Controller",StringComparison.Ordinal)==true && s.MethodKind==MethodKind.Ordinary && s.DeclaredAccessibility==Accessibility.Public;
    private static string MethodId(IMethodSymbol s) => GraphBuilder.Id("method",s.ToDisplayString(SymbolDisplayFormat.CSharpErrorMessageFormat));
    private static SourceLocation Loc(Document d, SyntaxNode n)
    {
        var lp=n.SyntaxTree.GetLineSpan(n.Span);
        return new SourceLocation { Path=Path.GetRelativePath(Path.GetDirectoryName(d.Project.Solution.FilePath!)!,d.FilePath!), FullPath=Path.GetFullPath(d.FilePath!), StartLine=lp.StartLinePosition.Line+1, StartColumn=lp.StartLinePosition.Character+1, EndLine=lp.EndLinePosition.Line+1, EndColumn=lp.EndLinePosition.Character+1, StartOffset=n.Span.Start, EndOffset=n.Span.End };
    }
}
