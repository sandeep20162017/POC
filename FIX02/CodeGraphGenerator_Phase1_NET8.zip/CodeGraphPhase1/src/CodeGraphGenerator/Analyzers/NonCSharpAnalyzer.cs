using CodeGraphGenerator.Infrastructure;
using CodeGraphGenerator.Models;
using System.Text.RegularExpressions;

namespace CodeGraphGenerator.Analyzers;

public sealed class NonCSharpAnalyzer
{
    private readonly GraphBuilder _g;
    private static readonly Regex ScriptRx=new("<script\b[^>]*>(?<body>[\s\\S]*?)</script\s*>",RegexOptions.IgnoreCase|RegexOptions.Compiled);
    private static readonly Regex JsFnRx=new(@"(?:function\s+(?<name>[A-Za-z_$][\w$]*)\s*\\([^)]*\\)|(?<name2>[A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\\([^)]*\\)\s*=>)",RegexOptions.Compiled);
    private static readonly Regex AjaxRx=new(@"(?:url\s*:\s*|\\.ajax\s*\\(\s*\\{[\s\\S]*?url\s*:\s*)(?<url>['\"])(?<value>.*?)\\1",RegexOptions.IgnoreCase|RegexOptions.Compiled);
    private static readonly Regex PartialRx=new(@"(?:<partial\s+name\s*=\s*|PartialAsync\s*\\(\s*|RenderPartialAsync\s*\\(\s*)(?:@)?[\"'](?<name>[^\"']+)",RegexOptions.IgnoreCase|RegexOptions.Compiled);
    private static readonly Regex ModelRx=new("@model\s+(?<model>[^\r\n]+)",RegexOptions.IgnoreCase|RegexOptions.Compiled);
    private static readonly Regex TelerikActionRx=new("\\.Action\s*\\(\s*[\"'](?<action>[^\"']+)[\"']\s*,\s*[\"'](?<controller>[^\"']+)[\"']",RegexOptions.IgnoreCase|RegexOptions.Compiled);
    private static readonly Regex SqlObjectRx=new(@"\b(?:FROM|JOIN|UPDATE|INTO|DELETE\s+FROM|MERGE\s+INTO)\s+(?<obj>(?:\[[^\]]+\]|[A-Za-z0-9_]+)(?:\s*\\.\s*(?:\[[^\]]+\]|[A-Za-z0-9_]+)){0,2})",RegexOptions.IgnoreCase|RegexOptions.Compiled);
    private static readonly Regex TableRx=new(@"CREATE\s+(?:TABLE|VIEW)\s+(?:IF\s+NOT\s+EXISTS\s+)?(?<obj>(?:\[[^\]]+\]|[A-Za-z0-9_]+)(?:\s*\\.\s*(?:\[[^\]]+\]|[A-Za-z0-9_]+)){0,2})",RegexOptions.IgnoreCase|RegexOptions.Compiled);
    private static readonly Regex SqlStmtRx=new(@"(?is)\b(SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM|MERGE\s+INTO)\b[\s\\S]*?(?=;|$)",RegexOptions.Compiled);

    public NonCSharpAnalyzer(GraphBuilder g)=>_g=g;

    public void AnalyzeDirectory(string root)
    {
        foreach(var file in Directory.EnumerateFiles(root,"*.cshtml",SearchOption.AllDirectories)) AnalyzeRazor(file,root);
        foreach(var file in Directory.EnumerateFiles(root,"*.sql",SearchOption.AllDirectories)) AnalyzeSqlFile(file,root);
    }
    public void AnalyzeSchema(string schema,string root)
    {
        if(!File.Exists(schema)) return;
        AnalyzeSqlText(schema,File.ReadAllText(schema),root,"schema.sql",true);
    }

    private void AnalyzeRazor(string file,string root)
    {
        var text=File.ReadAllText(file); var rel=Path.GetRelativePath(root,file); var viewType=Path.GetFileName(file).StartsWith("_",StringComparison.Ordinal)?"partial_view":"view";
        if(Path.GetFileName(file).Equals("_ViewStart.cshtml",StringComparison.OrdinalIgnoreCase)) viewType="layout";
        var vid=GraphBuilder.Id("view",rel); _g.AddNode(new GraphNode{Id=vid,Type=viewType,Name=Path.GetFileName(file),Location=Loc(file,root,text,0),Properties=new(){["relative_path"]=rel,["model_directive"]=ModelRx.Match(text).Groups["model"].Value.Trim()}});
        foreach(Match m in PartialRx.Matches(text)) { var target=m.Groups["name"].Value.Trim(); var pid=GraphBuilder.Id("view",target); _g.AddNode(new GraphNode{Id=pid,Type="view_reference",Name=target,Properties=new(){["unresolved"]=true}}); _g.AddEdge(new GraphEdge{Id=GraphBuilder.EdgeId(vid,pid,"renders",rel+m.Index),From=vid,To=pid,Type="renders",Confidence="exact",Evidence=Loc(file,root,text,m.Index)}); }
        foreach(Match s in ScriptRx.Matches(text)) AnalyzeScript(file,root,text,vid,s);
        foreach(Match t in TelerikActionRx.Matches(text)) { var route=GraphBuilder.Id("route",$"/{t.Groups["controller"].Value}/{t.Groups["action"].Value}"); _g.AddNode(new GraphNode{Id=route,Type="route",Name=$"/{t.Groups["controller"].Value}/{t.Groups["action"].Value}",Properties=new(){["source"]= "telerik"}}); _g.AddEdge(new GraphEdge{Id=GraphBuilder.EdgeId(vid,route,"telerik_endpoint",rel+t.Index),From=vid,To=route,Type="telerik_endpoint",Evidence=Loc(file,root,text,t.Index),Properties=new(){["controller"]=t.Groups["controller"].Value,["action"]=t.Groups["action"].Value}}); }
    }
    private void AnalyzeScript(string file,string root,string full,string view,string script)
    {
        var body=script.Groups["body"].Value; var baseOffset=script.Groups["body"].Index; foreach(Match f in JsFnRx.Matches(body)) { var name=!string.IsNullOrWhiteSpace(f.Groups["name"].Value)?f.Groups["name"].Value:f.Groups["name2"].Value; var id=GraphBuilder.Id("javascript",$"{file}:{name}:{baseOffset+f.Index}"); _g.AddNode(new GraphNode{Id=id,Type="javascript_function",Name=name,Location=Loc(file,root,full,baseOffset+f.Index),Properties=new(){["embedded_in_view"]=view}}); _g.AddEdge(new GraphEdge{Id=GraphBuilder.EdgeId(view,id,"contains_javascript",file+f.Index),From=view,To=id,Type="contains_javascript",Evidence=Loc(file,root,full,baseOffset+f.Index)}); foreach(Match a in AjaxRx.Matches(body.Substring(f.Index))) { var url=a.Groups["value"].Value; var rid=GraphBuilder.Id("route",url); _g.AddNode(new GraphNode{Id=rid,Type="route",Name=url,Properties=new(){["source"]="javascript_ajax"}}); var off=baseOffset+f.Index+a.Index; _g.AddEdge(new GraphEdge{Id=GraphBuilder.EdgeId(id,rid,"ajax_calls",file+off),From=id,To=rid,Type="ajax_calls",Evidence=Loc(file,root,full,off),Properties=new(){["url"]=url}}); } } }
    private void AnalyzeSqlFile(string file,string root) => AnalyzeSqlText(file,File.ReadAllText(file),root,Path.GetRelativePath(root,file),false);
    private void AnalyzeSqlText(string file,string text,string root,string display,bool schema)
    {
        foreach(Match m in TableRx.Matches(text)) { var obj=Clean(m.Groups["obj"].Value); var id=GraphBuilder.Id("database_table",obj); _g.AddNode(new GraphNode{Id=id,Type=m.Value.Contains("VIEW",StringComparison.OrdinalIgnoreCase)?"database_view":"database_table",Name=obj,Location=Loc(file,root,text,m.Index),Properties=new(){["schema_source"]=schema}}); }
        foreach(Match m in SqlStmtRx.Matches(text)) { var sid=GraphBuilder.Id("sql",$"{file}:{m.Index}"); _g.AddNode(new GraphNode{Id=sid,Type="sql_statement",Name=display+"#"+m.Index,Location=Loc(file,root,text,m.Index),Properties=new(){["statement"]=m.Value.Trim()}}); foreach(Match o in SqlObjectRx.Matches(m.Value)) { var obj=Clean(o.Groups["obj"].Value); var tid=GraphBuilder.Id("database_table",obj); _g.AddNode(new GraphNode{Id=tid,Type="database_table",Name=obj,Properties=new(){["unresolved"] = true}}); _g.AddEdge(new GraphEdge{Id=GraphBuilder.EdgeId(sid,tid,"sql_references",file+m.Index+o.Index),From=sid,To=tid,Type="sql_references",Evidence=Loc(file,root,text,m.Index+o.Index),Properties=new(){["object"]=obj}}); } }
    }
    private static string Clean(string s)=>Regex.Replace(s.Trim().Replace("[","").Replace("]","").Replace(" ",""),"\s*\\.\s*",".");
    private static SourceLocation Loc(string file,string root,string text,int offset){ var before=text.AsSpan(0,Math.Clamp(offset,0,text.Length)); var line=1; var col=1; for(int i=0;i<before.Length;i++){if(before[i]=='\n'){line++;col=1;}else col++;} return new SourceLocation{Path=Path.GetRelativePath(root,file),FullPath=Path.GetFullPath(file),StartLine=line,StartColumn=col,EndLine=line,EndColumn=col,StartOffset=offset,EndOffset=offset}; }
}
