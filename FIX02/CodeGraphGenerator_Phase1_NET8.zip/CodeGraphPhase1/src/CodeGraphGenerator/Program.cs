using CodeGraphGenerator.Analyzers;
using Microsoft.Build.Locator;
using CodeGraphGenerator.Infrastructure;
using System.Text.Json;
using System.Text.Json.Serialization;

static void Usage(){Console.WriteLine("CodeGraphGenerator .NET 8\nUsage:\n  CodeGraphGenerator --solution <Solution.sln> --schema <schema.sql> --output <output-directory> [--root <source-root>] [--no-noncsharp]\n\nExamples:\n  CodeGraphGenerator --solution C:\\CES\\CES.sln --schema C:\\CES\\schema.sql --output C:\\CES\\codegraph");}
string? solution=null,schema=null,output=null,root=null; bool noNon=false;
for(int i=0;i<args.Length;i++){switch(args[i].ToLowerInvariant()){case "--solution": solution=Next(args,ref i);break;case "--schema":schema=Next(args,ref i);break;case "--output":output=Next(args,ref i);break;case "--root":root=Next(args,ref i);break;case "--no-noncsharp":noNon=true;break;case "--help":case "-h":Usage();return;default:Console.Error.WriteLine($"Unknown argument: {args[i]}");Usage();Environment.ExitCode=2;return;}}
if(string.IsNullOrWhiteSpace(solution)||string.IsNullOrWhiteSpace(schema)||string.IsNullOrWhiteSpace(output)){Usage();Environment.ExitCode=2;return;}
solution=Path.GetFullPath(solution); schema=Path.GetFullPath(schema); output=Path.GetFullPath(output); root=Path.GetFullPath(root??Path.GetDirectoryName(solution)!);
if(!File.Exists(solution)){Console.Error.WriteLine($"Solution not found: {solution}");Environment.ExitCode=3;return;} if(!File.Exists(schema)){Console.Error.WriteLine($"schema.sql not found: {schema}");Environment.ExitCode=3;return;}
Directory.CreateDirectory(output);
var g=new GraphBuilder(); var roslyn=new RoslynAnalyzer(g); Console.WriteLine("=== CODE GRAPH GENERATOR .NET 8 ==="); Console.WriteLine($"Solution : {solution}"); Console.WriteLine($"Schema   : {schema}"); Console.WriteLine($"Root     : {root}"); Console.WriteLine($"Output   : {output}");
try{
MSBuildLocator.RegisterDefaults();
await roslyn.AnalyzeAsync(solution,CancellationToken.None); if(!noNon){var n=new NonCSharpAnalyzer(g); n.AnalyzeDirectory(root); n.AnalyzeSchema(schema,root);}}
catch(Exception ex){Console.Error.WriteLine("FATAL: "+ex); Environment.ExitCode=10; return;}
var metadata=new CodeGraphGenerator.Models.GraphMetadata{SolutionPath=solution,SolutionDirectory=Path.GetDirectoryName(solution)!,SchemaSqlPath=schema,AnalyzerCapabilities=noNon?["roslyn-csharp"]:["roslyn-csharp","mvc-actions","razor-views","embedded-javascript","ajax-endpoints","telerik-endpoints","dapper-detection","sql-statements","schema-objects"]};
var pkg=g.BuildPackage(metadata); var opts=new JsonSerializerOptions{WriteIndented=true,DefaultIgnoreCondition=JsonIgnoreCondition.WhenWritingNull};
await File.WriteAllTextAsync(Path.Combine(output,"roslyn_graph.json"),JsonSerializer.Serialize(pkg,opts));
await File.WriteAllTextAsync(Path.Combine(output,"master.json"),JsonSerializer.Serialize(pkg,opts));
await WriteSpecialized(pkg,output,opts);
Console.WriteLine($"DONE. Nodes={pkg.Nodes.Count}, Edges={pkg.Edges.Count}"); Console.WriteLine($"Master: {Path.Combine(output,"master.json")}");
static string Next(string[] a,ref int i)=>++i<a.Length?a[i]:throw new ArgumentException($"Missing value for {a[i-1]}");
static async Task WriteSpecialized(CodeGraphGenerator.Models.GraphPackage p,string output,JsonSerializerOptions opts){var dirs=new[]{"graphs","indexes"};foreach(var d in dirs)Directory.CreateDirectory(Path.Combine(output,d));
var groups=p.Nodes.GroupBy(n=>n.Type switch{ "method" or "class" or "interface" or "property" or "controller_action"=>"csharp", "view" or "partial_view" or "layout" or "view_reference"=>"razor", "javascript_function" or "javascript_event"=>"javascript", "route"=>"mvc", "dapper_query"=>"dapper", "sql_statement"=>"sql", "database_table" or "database_view" or "database_function" or "database_procedure"=>"database", _=>"other"});
foreach(var grp in groups) await File.WriteAllTextAsync(Path.Combine(output,"graphs",grp.Key+".json"),JsonSerializer.Serialize(new{schema_version=p.SchemaVersion,nodes=grp.ToList(),edges=p.Edges.Where(e=>grp.Any(n=>n.Id==e.From)||grp.Any(n=>n.Id==e.To)).ToList()},opts));
await File.WriteAllTextAsync(Path.Combine(output,"indexes","symbols.json"),JsonSerializer.Serialize(p.Indexes.Symbols,opts)); await File.WriteAllTextAsync(Path.Combine(output,"indexes","routes.json"),JsonSerializer.Serialize(p.Indexes.Routes,opts)); await File.WriteAllTextAsync(Path.Combine(output,"indexes","views.json"),JsonSerializer.Serialize(p.Indexes.Views,opts)); await File.WriteAllTextAsync(Path.Combine(output,"indexes","javascript.json"),JsonSerializer.Serialize(p.Indexes.JavaScript,opts)); await File.WriteAllTextAsync(Path.Combine(output,"indexes","sql.json"),JsonSerializer.Serialize(p.Indexes.Sql,opts)); await File.WriteAllTextAsync(Path.Combine(output,"indexes","database.json"),JsonSerializer.Serialize(p.Indexes.Database,opts)); await File.WriteAllTextAsync(Path.Combine(output,"indexes","files.json"),JsonSerializer.Serialize(p.Indexes.Files,opts));}
