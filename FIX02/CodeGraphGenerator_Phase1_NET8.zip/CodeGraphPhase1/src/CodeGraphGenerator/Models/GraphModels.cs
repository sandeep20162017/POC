using System.Text.Json.Serialization;

namespace CodeGraphGenerator.Models;

public sealed class GraphPackage
{
    public string SchemaVersion { get; set; } = "1.0";
    public GraphMetadata Metadata { get; set; } = new();
    public List<GraphNode> Nodes { get; set; } = [];
    public List<GraphEdge> Edges { get; set; } = [];
    public GraphIndexes Indexes { get; set; } = new();
}

public sealed class GraphMetadata
{
    public string Generator { get; set; } = "CodeGraphGenerator";
    public string GeneratorVersion { get; set; } = "1.0.0";
    public string GeneratedAtUtc { get; set; } = DateTime.UtcNow.ToString("O");
    public string SolutionPath { get; set; } = "";
    public string SolutionDirectory { get; set; } = "";
    public string SchemaSqlPath { get; set; } = "";
    public string TargetFramework { get; set; } = "net8.0";
    public string[] AnalyzerCapabilities { get; set; } = [];
    public GraphStatistics Statistics { get; set; } = new();
}

public sealed class GraphStatistics
{
    public int NodeCount { get; set; }
    public int EdgeCount { get; set; }
    public Dictionary<string,int> NodesByType { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string,int> EdgesByType { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class SourceLocation
{
    public string Path { get; set; } = "";
    public string FullPath { get; set; } = "";
    public int StartLine { get; set; }
    public int StartColumn { get; set; }
    public int EndLine { get; set; }
    public int EndColumn { get; set; }
    public int StartOffset { get; set; }
    public int EndOffset { get; set; }
}

public sealed class GraphNode
{
    public string Id { get; set; } = "";
    public string Type { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Namespace { get; set; }
    public string? Project { get; set; }
    public SourceLocation? Location { get; set; }
    public Dictionary<string,object?> Properties { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class GraphEdge
{
    public string Id { get; set; } = "";
    public string From { get; set; } = "";
    public string To { get; set; } = "";
    public string Type { get; set; } = "";
    public string Confidence { get; set; } = "exact";
    public SourceLocation? Evidence { get; set; }
    public Dictionary<string,object?> Properties { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class GraphIndexes
{
    public Dictionary<string,List<string>> Symbols { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string,List<string>> Routes { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string,List<string>> Views { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string,List<string>> JavaScript { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string,List<string>> Sql { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string,List<string>> Database { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string,List<string>> Files { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}
