$ErrorActionPreference = 'Stop'
dotnet restore "$PSScriptRoot\..\CodeGraphGenerator.sln"
dotnet build "$PSScriptRoot\..\CodeGraphGenerator.sln" -c Release
