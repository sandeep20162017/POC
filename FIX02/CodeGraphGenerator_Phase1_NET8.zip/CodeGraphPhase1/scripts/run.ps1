param(
  [Parameter(Mandatory=$true)][string]$Solution,
  [Parameter(Mandatory=$true)][string]$Schema,
  [Parameter(Mandatory=$true)][string]$Output,
  [string]$Root = ""
)
$ErrorActionPreference = 'Stop'
$proj = Join-Path $PSScriptRoot '..\src\CodeGraphGenerator\CodeGraphGenerator.csproj'
$args = @('--solution',$Solution,'--schema',$Schema,'--output',$Output)
if ($Root) { $args += @('--root',$Root) }
dotnet run --project $proj -c Release -- @args
