# CodeGraphGenerator Phase 1 — ASP.NET Core 8 / Roslyn

Production-oriented Phase 1 generator for an ASP.NET Core MVC + Razor + Telerik + Dapper application.

## What it generates

- `roslyn_graph.json` — authoritative .NET/Roslyn graph.
- `master.json` — baseline complete graph, also ready for Python post-processing/enrichment.
- `graphs/*.json` — specialized graph partitions.
- `indexes/*.json` — symbol, route, view, JavaScript, SQL, database and file indexes.

The generator loads the real `.sln` through Roslyn/MSBuild, resolves C# symbols semantically, detects controller actions and calls, identifies Dapper invocations, scans `.cshtml` for views/partials/embedded JavaScript/AJAX/Telerik action references, scans SQL, and parses database objects from `schema.sql`.

## Requirements

- Windows recommended for MSBuild/.NET solution loading.
- .NET SDK 8.x.
- Visual Studio 2022 or Build Tools installed so Microsoft.Build.Locator can locate MSBuild.
- NuGet restore/network access on first build.

## Build

```powershell
dotnet restore .\CodeGraphGenerator.sln
dotnet build .\CodeGraphGenerator.sln -c Release
```

## Run

```powershell
dotnet run --project .\src\CodeGraphGenerator\CodeGraphGenerator.csproj -c Release -- `
  --solution "C:\CES\CES.sln" `
  --schema "C:\CES\schema.sql" `
  --output "C:\CES\codegraph"
```

Or after publish:

```powershell
dotnet publish .\src\CodeGraphGenerator\CodeGraphGenerator.csproj -c Release -o .\publish
.\publish\CodeGraphGenerator.exe --solution "C:\CES\CES.sln" --schema "C:\CES\schema.sql" --output "C:\CES\codegraph"
```

## Important design notes

1. C# relationships are Roslyn-semantic where possible.
2. Conventional MVC routes are marked `confidence=candidate` unless a route attribute gives stronger evidence.
3. Dynamic JavaScript URLs are not guessed; unresolved/dynamic relationships should be handled in later enhancement passes.
4. SQL object references are evidence-based. A filename such as `_VehicleTotalCost.cshtml` is never treated as a database table name.
5. Absolute paths are included in every source location so Phase 2 can retrieve exact files/line ranges.
6. Line numbers are 1-based.
7. The graph is deterministic enough for regeneration; edge IDs are SHA-256 derived from relationship evidence.

## Phase 1 Python companion

`python/` contains the final assembly/validation utilities. The .NET generator emits both `roslyn_graph.json` and a baseline `master.json`; Python can then normalize/enrich the graph and merge additional analyzer fragments without requiring Roslyn at AI/RAG runtime.

## Current scope / next hardening

This is the first production baseline, not a claim of perfect static analysis. The next hardening pass should add:

- exact ASP.NET endpoint routing metadata from compiled model where available
- robust Razor parser integration instead of regex-only Razor discovery
- JavaScript AST parsing for nested functions/events and URL construction
- interpolation/concatenation-aware SQL extraction
- C# string/data-flow tracking from variables into Dapper calls
- SQL dependency parsing for views/functions/procedures/FKs/columns
- generated-code filtering and framework/vendor exclusion rules
- incremental graph generation using file hashes
- validation report for unresolved references
