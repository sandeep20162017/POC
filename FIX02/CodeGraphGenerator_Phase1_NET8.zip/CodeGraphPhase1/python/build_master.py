"""Build the final deterministic master.json from the .NET Phase 1 graph.

The .NET executable is authoritative for C# semantic relationships. This script
is deliberately dependency-free and is the recommended final assembly step for
RAG preparation. It can also merge additional graph fragments produced later.
"""
import argparse, json
from pathlib import Path
from collections import Counter, defaultdict


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def merge(base, fragments):
    nodes = {n["id"]: n for n in base.get("nodes", []) if "id" in n}
    edges = {e["id"]: e for e in base.get("edges", []) if "id" in e}
    for fragment in fragments:
        for n in fragment.get("nodes", []):
            if "id" in n:
                nodes[n["id"]] = n
        for e in fragment.get("edges", []):
            if "id" in e:
                edges[e["id"]] = e
    base["nodes"] = sorted(nodes.values(), key=lambda x: x["id"])
    base["edges"] = sorted(edges.values(), key=lambda x: x["id"])
    return base


def rebuild_indexes(data):
    indexes = {
        "symbols": defaultdict(list),
        "routes": defaultdict(list),
        "views": defaultdict(list),
        "javascript": defaultdict(list),
        "sql": defaultdict(list),
        "database": defaultdict(list),
        "files": defaultdict(list),
    }
    for n in data.get("nodes", []):
        name = n.get("name")
        typ = n.get("type", "")
        loc = n.get("location") or {}
        path = loc.get("path")
        if name:
            indexes["symbols"][name].append(n["id"])
        if path:
            indexes["files"][path].append(n["id"])
        if typ in {"view", "partial_view", "layout", "view_reference"} and name:
            indexes["views"][name].append(n["id"])
        if typ in {"javascript_function", "javascript_event"} and name:
            indexes["javascript"][name].append(n["id"])
        if typ == "route" and name:
            indexes["routes"][name].append(n["id"])
        if typ in {"sql_statement", "dapper_query"} and name:
            indexes["sql"][name].append(n["id"])
        if typ in {"database_table", "database_view", "database_function", "database_procedure"} and name:
            indexes["database"][name].append(n["id"])
    return {k: {key: sorted(set(vals)) for key, vals in sorted(v.items())}
            for k, v in indexes.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="roslyn_graph.json or another graph JSON")
    ap.add_argument("--output", required=True, help="final master.json")
    ap.add_argument("--fragment", action="append", default=[], help="optional additional graph JSON; repeatable")
    args = ap.parse_args()

    base = load(Path(args.input))
    fragments = [load(Path(p)) for p in args.fragment]
    data = merge(base, fragments)
    data["indexes"] = rebuild_indexes(data)
    meta = data.setdefault("metadata", {})
    meta["post_processor"] = "python/build_master.py"
    meta["node_count"] = len(data.get("nodes", []))
    meta["edge_count"] = len(data.get("edges", []))
    meta["statistics"] = {
        "nodes_by_type": dict(sorted(Counter(n.get("type", "") for n in data.get("nodes", [])).items())),
        "edges_by_type": dict(sorted(Counter(e.get("type", "") for e in data.get("edges", [])).items())),
    }
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {args.output}: {meta['node_count']} nodes, {meta['edge_count']} edges")


if __name__ == "__main__":
    main()
