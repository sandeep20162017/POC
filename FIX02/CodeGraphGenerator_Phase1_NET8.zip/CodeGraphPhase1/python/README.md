# Python companion

The Phase 1 .NET executable is the authoritative Roslyn analyzer and already emits `master.json`.

These Python utilities are reserved for graph post-processing/RAG preparation. They do not replace Roslyn for C# semantic analysis.

The intended Phase 1/Phase 2 pipeline is:

.NET 8 + Roslyn -> master.json -> Python normalization/indexing -> AI/RAG retrieval -> GPT model
