# Phase 1 pipeline

1. Run the .NET 8 executable against the real solution and schema:

```powershell
CodeGraphGenerator.exe --solution "C:\CES\CES.sln" --schema "C:\CES\schema.sql" --output "C:\CES\codegraph"
```

2. The executable emits `roslyn_graph.json` and a baseline `master.json`, plus `graphs/` and `indexes/`.

3. Python is the final assembly/post-processing layer. This is where later Razor/JavaScript/SQL AST enrichers can emit graph fragments without changing the Roslyn analyzer:

```powershell
python .\python\build_master.py --input "C:\CES\codegraph\roslyn_graph.json" --output "C:\CES\codegraph\master.json"
```

4. Validate before publishing to RAG:

```powershell
python .\python\validate_master.py "C:\CES\codegraph\master.json"
```

For later enrichment, repeat `--fragment` for additional JSON graph fragments.
