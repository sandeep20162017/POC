import json, sys
from pathlib import Path

def main():
    if len(sys.argv) != 2:
        print("Usage: python validate_master.py <master.json>")
        return 2
    p = Path(sys.argv[1])
    data = json.loads(p.read_text(encoding="utf-8"))
    nodes = {n["id"] for n in data.get("nodes", []) if "id" in n}
    missing = [e for e in data.get("edges", []) if e.get("from") not in nodes or e.get("to") not in nodes]
    print(f"nodes={len(nodes)} edges={len(data.get('edges', []))} missing_edge_endpoints={len(missing)}")
    if missing:
        for e in missing[:20]: print(json.dumps(e, indent=2))
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
