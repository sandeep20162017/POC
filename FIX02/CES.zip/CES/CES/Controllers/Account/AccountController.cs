﻿using Microsoft.AspNetCore.Mvc;

namespace BCES.Controllers.Account
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
