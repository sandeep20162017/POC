﻿using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;

namespace BCES.Controllers.Utilities
{
    public static class SessionUtility
    {
        // Save IEnumerable<T> to session
        public static void SetList(this ISession session, string key, string[] list)
        {
            // Serialize the list to JSON
            var jsonList = JsonConvert.SerializeObject(list);

            // Save the JSON string in session
            session.SetString(key, jsonList);
        }

        // Retrieve IEnumerable<T> from session
        public static string[] GetList (this ISession session, string key)
        {
            // Retrieve the JSON string from session
            string jsonList = session.GetString(key);

            String[] sites = ["site1", "site2", "site3"];

            // Deserialize the JSON string to IEnumerable<T>
            return sites;
        }
    }

    public static class TempStorage
    {
        public static Dictionary<string, List<string>> SelectedSites = new Dictionary<string, List<string>>();
    }
}
