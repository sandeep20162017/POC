﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Parts;
using  BCES.Models.Vehicle;
using BCES.Models.Common;
using BCES.Models.Parts;
using System.Data;
using OfficeOpenXml;
using System.IO;
using MailKit.Net.Smtp;
using MimeKit;
using MailKit.Security;



using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Azure.Core;
using BCES.Controllers.Admin;
using System.Net.Mail;
using Multipart = MimeKit.Multipart;
using SmtpClient = MailKit.Net.Smtp.SmtpClient;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Authorization;
using System.Text.Encodings.Web;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using System.Reflection;
using CommandType = System.Data.CommandType;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.Blazor;
using BCES.Models.ArchVehicle;
using System.Security.Cryptography;

//using System.Net.Mime;
//using CES.Views.Shared;
namespace BCES.Controllers.Parts
{
    // [Route("api/[controller]")]
    public class VehiclesController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IServiceProvider _serviceProvider;
        private readonly BusesController _busesController;
        private readonly LabourDetailsController _labourDetailsController;
        private static List<string> _selectedBuses = new List<string>();


        public VehiclesController(DapperContext dapper, IHttpContextAccessor httpContextAccessor,
                                      IServiceProvider serviceProvider, BusesController busesController,
                                      LabourDetailsController labourDetailsController
                                    ) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
            _serviceProvider = serviceProvider;
            _busesController = busesController;
            _labourDetailsController = labourDetailsController;
        }

        [HttpGet("VehiclesIndex")]
        [AllowAnonymous]
        public IActionResult VehiclesIndex()
        {
            // return View();
            //GetRebuiltPartsData();
            return View("~/Views/Vehicles/Index.cshtml");
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult ArchivedIndex()
        {
            // return View();
            //GetRebuiltPartsData();
            return View("~/Views/Vehicles/_ArchivedVehicleIndex.cshtml");
           // return View("~/Views/Vehicles/ArchivedIndex.cshtml");
        }

        //[AllowAnonymous]
        //public IActionResult ArchivedIndex()
        //{
        //    // return View();
        //    return View("~/Views/Vehicles/ArchivedIndex.cshtml");
        //}

        [HttpGet]
        [AllowAnonymous]
        public async Task<JsonResult> GetVehiclesView([DataSourceRequest] DataSourceRequest request)
        {
            try
            {
                var model = await GetVehiclesData();
                return Json(model.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                return Json(new { error = ex.Message });
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<JsonResult> GetArchivedVehiclesView([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid 
            try
            {
                var model = await GetArchivedVehiclesData();

                return Json(model.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                return Json(ex);
            }
        }

        public ActionResult GetVehicleById(int id, bool readOnly = false)
        {
           
            var vehicle = id == 0
                ? new VehicleViewModel() // Add mode san Sept 2
                : _dbConnection.QueryFirstOrDefault<VehicleViewModel>(@"
            SELECT  [VehicleListId]
                                              ,[VehSeriesCode]
                                              ,[NumOfVehicles]
                                              ,[ProjDesc]
                                              ,[DateEntered]
                                              ,[EnteredBy]
                                              ,[ModifiedLastBy]
                                              ,[ModifiedLastDate]
                                              ,[Make]
                                              ,[Model] as VehModel  
                                              ,[Year]
                                              ,[Engine]
                                              ,[Transmission]
                                              ,[Differential]
                                              ,[Sopnumber]
                                          FROM [CES].[SBCES].[VehicleList] WHERE VehicleListId = @Id", new { Id = id });

            if (vehicle == null)
                return Content("Vehicle not found");

            ViewBag.ReadOnly = readOnly;
            ViewBag.ParentId = id;  /*save parent id*/
            ViewBag.FormattedDate = vehicle.ModifiedLastDate;

            return PartialView("~/Views/Shared/_VehPopUp.cshtml", vehicle);
        }
        [AllowAnonymous]
        private async Task<IEnumerable<VehicleViewModel>> GetVehiclesData()
        {
            try
            {
                var vehiclesQuery = @"
                                         SELECT  [VehicleListId]
                                              ,[VehSeriesCode]
                                              ,[NumOfVehicles]
                                              ,[ProjDesc]
                                              ,[DateEntered]
                                              ,[EnteredBy]
                                              ,[ModifiedLastBy]
                                              ,[ModifiedLastDate]
                                              ,[Make]
                                              ,[Model] as VehModel
                                              ,[Year]
                                              ,[Engine]
                                              ,[Transmission]
                                              ,[Differential]
                                              ,[Sopnumber]
                                          FROM [CES].[SBCES].[VehicleList]
                                         
                                          ORDER BY VehicleListId DESC   
                                                                    ";


                var vehicles = _dbConnection.Query<VehicleViewModel>(vehiclesQuery).ToList();


                return vehicles.Distinct().ToList();

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching vehicles data: {ex.Message}");
                return Enumerable.Empty<VehicleViewModel>();
            }
        }



        [HttpPost]
        public async Task<IActionResult> UpdateVehiclesView([FromBody] VehicleViewModel vehicleViewModel)
        {
            if (vehicleViewModel == null)
                return BadRequest("Model binding failed.");

            try
            {
                await UpdateVehiclesAsync(vehicleViewModel);

                var updated = await GetVehicleJsonByIdAsync(vehicleViewModel.VehicleListId);

                // return Ok(updated);
                return Ok(new { VehicleListId = vehicleViewModel.VehicleListId, Success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Update failed: " + ex.Message);
            }
        }

        [AllowAnonymous]
        private async Task UpdateVehiclesAsync(VehicleViewModel vehicleViewModel)
        {
            var userName = ViewBag.UserName;
            _dbConnection.Open();
            using (var transaction = _dbConnection.BeginTransaction())
            {
                try
                {
                    // Update the [VehicleListId] table
                    var updateVehiclelistQuery = @"
                                                    UPDATE SBCES.[VehicleList]
                                                    SET 
                                                        Sopnumber = @Sopnumber,
                                                        ProjDesc =@ProjDesc,
                                                        Differential = @Differential,
                                                        Engine = @Engine,
                                                        NumOfVehicles = @NumOfVehicles,
                                                        
                                                        Make = @Make,
                                                        Model = @VehModel,
                                                        Transmission = @Transmission,
                                                        VehSeriesCode = @VehSeriesCode,
                                                        Year = @Year,
                                                        

                                                        ModifiedLastBy = @LastModifiedBy,
                                                        ModifiedLastDate = @ModifiedLastDate
                    
                                                    WHERE VehicleListId = @VehicleListId;
                                                ";

                    await _dbConnection.ExecuteAsync(updateVehiclelistQuery, new
                    {
                        vehicleViewModel.Sopnumber,
                        vehicleViewModel.ProjDesc,
                        vehicleViewModel.Differential,
                        vehicleViewModel.Engine,
                        vehicleViewModel.NumOfVehicles,


                        vehicleViewModel.Make,
                        vehicleViewModel.VehModel,
                        vehicleViewModel.Transmission,
                        vehicleViewModel.VehSeriesCode,
                        vehicleViewModel.Year,

                        LastModifiedBy = userName,
                        ModifiedLastDate = DateTime.Now,
                        vehicleViewModel.VehicleListId

                    }, transaction);


                    // Commit the transaction
                    transaction.Commit();

                }
                catch (Exception ex)
                {
                    // Rollback the transaction in case of an error
                    transaction.Rollback();
                    Console.WriteLine($"Error updating vehicle estimate: {ex.Message}");
                    throw; // Re-throw the exception to propagate it
                }
            }
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteVehicle(string VehicleListId)
        {

            try
            {
                if (string.IsNullOrEmpty(VehicleListId))
                {
                    return BadRequest("Invalid data.");
                }

                var deletePartSql = "DELETE FROM SBCES.[VehicleList] WHERE VehicleListId = '" + VehicleListId + "'";

                await _dbConnection.ExecuteAsync(deletePartSql, new { VehicleListId });

                //Delete Labour
                string deleteLabourQuery = @"
                    DELETE FROM SBCES.EmployeeLabour 
                    WHERE LINKNUMBER = '" + VehicleListId + "' AND TypeId = 'BUS'";

                await _dbConnection.ExecuteAsync(deleteLabourQuery, new { VehicleListId });

                //Delete SC Parts
                string deleteScPartsQuery = @"DELETE FROM SBCES.SCPartsUsed
                                            WHERE
                                                LINKTYPE = 'BUS'
                                                AND RebuiltPart = 'N'
                                                AND LinkCode = '" + VehicleListId + "'";
                await _dbConnection.ExecuteAsync(deleteScPartsQuery, new { VehicleListId });

                //Delete NSC Parts
                string deleteNscPartsQuery = @"
                              DELETE FROM SBCES.NSCPartsUsed 
                              WHERE  LINKTYPE = 'BUS'                                                
                             AND LinkCode = '" + VehicleListId + "'";
                await _dbConnection.ExecuteAsync(deleteNscPartsQuery, new { VehicleListId });

                //Delete SC Parts
                string deleteRbPartsQuery = @"DELETE FROM SBCES.SCPartsUsed
                                            WHERE
                                                LINKTYPE = 'BUS'
                                                AND RebuiltPart = 'Y'
                                                AND LinkCode = '" + VehicleListId + "'";
                await _dbConnection.ExecuteAsync(deleteRbPartsQuery, new { VehicleListId });


                return Json(new { success = true });
                //return RedirectToAction("VehiclesIndex");
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Internal server error: {ex.Message}" });
            }
        }


        [AllowAnonymous]
        private async Task<IEnumerable<VehicleViewModel>> GetArchivedVehiclesData()
        {
            try
            {
                // Base query for rebuilt parts data
                var vehQuery = @"            
                                        SELECT         
                                               
                             ROW_NUMBER() OVER (
                                        PARTITION BY OldId
                                        ORDER BY DateEntered ASC
                                  ) AS VersionNo,

                                  [OldId],
                                  [ArchVehicleListId],
                                  [VehSeriesCode],
                                  [NumOfVehicles],
                                  [ProjDesc],
                                  [DateEntered],
                                  [EnteredBy],
                                  [Make],
                                  [Model],
                                  [Year],
                                  [Engine],
                                  [Transmission],
                                  [Differential],
                                  [LabourCost],
                                  [LabourOverheadAmount],
                                  [LabourTotal],
                                  [MaterialsTotal],
                                  [TotalBusEstimateCost],
                                  [TotalTax],
                                  [TotalCostTax],
                                  [OemKitsTotal],
                                  [Sopnumber]     
                            FROM [CES].[SBCES].[ArchVehicleList]
                            ORDER BY Oldid desc, VersionNo desc;
                                            ";

                var vehArchived = (await _dbConnection.QueryAsync<VehicleViewModel>(vehQuery)).ToList();


                return vehArchived;
            }
            catch (Exception ex)
            {
                // Handle errors gracefully
                return null;
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddVehiclesView([FromBody] VehicleViewModel vehicleViewModel)
        {
            if (vehicleViewModel == null)
                return BadRequest("Unable to save. Model data is missing.");

            if (!ModelState.IsValid)
            {
                return BadRequest("Unable to save. Required fields are missing.");
            }

            try
            {
                var newId = await AddVehicleAsync(vehicleViewModel);

                // Re-fetch full model from DB
                var updated = await GetVehicleJsonByIdAsync(newId);

                // return Ok(updated);
                return Ok(new { VehicleListId = newId, Success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Add failed: " + ex.Message);
            }
        }

      

        private async Task<VehicleViewModel> GetVehicleJsonByIdAsync(int id)
        {
            var model = new List<BCES.Models.Parts.StockCodedPartsViewModel> { };
            return await _dbConnection.QueryFirstOrDefaultAsync<VehicleViewModel>(
           @"
            SELECT 
                VehicleListId,                
                VehSeriesCode,
                NumOfVehicles,
                ProjDesc,
                DateEntered,
                EnteredBy,
                ModifiedLastBy,
                ModifiedLastDate,
                Make,
                Model,
                Year,
                Engine,
                Transmission,
                Differential,
                Sopnumber                
            FROM SBCES.VehicleList
            WHERE VehicleListId = @id", new { id });
          }

        [HttpGet] 
        public ActionResult GetVehicleEstimatePopup(int id)
        {
            try
            {
                if (id == 0)
                {
                    // Create a new vehicle for add mode
                    var newVehicle = new VehicleViewModel();
                    ViewBag.ParentId = 0;
                    ViewBag.FormattedDate = "System Generated";
                    return PartialView("_VehEstimatePopUp", newVehicle);
                }

                // Get existing vehicle data using Dapper
                var vehicle = _dbConnection.QueryFirstOrDefault<VehicleViewModel>(@"
                SELECT  
                    [VehicleListId],
                    [VehSeriesCode],
                    [NumOfVehicles],
                    [ProjDesc],
                    [Sopnumber],
                    [Make],
                    [Model] as VehModel,
                    [Year],
                    [Engine],
                    [Transmission],
                    [Differential],
                    [ModifiedLastBy],
                    [ModifiedLastDate]
                FROM [CES].[SBCES].[VehicleList] 
                WHERE VehicleListId = @Id",
                            new { Id = id });

                if (vehicle == null)
                {
                    return Content("Vehicle not found");
                }

                ViewBag.ParentId = id;
                ViewBag.FormattedDate = vehicle.ModifiedLastDate ;

                return PartialView("_VehPopUp", vehicle);
            }
            catch (Exception ex)
            {  
                return null;
            }
            
        }
        private async Task<int> AddVehicleAsync([FromBody] VehicleViewModel vehicleViewModel)
        {
            //if (!ModelState.IsValid)
            //{
            //    var errors = ModelState.Values
            //        .SelectMany(v => v.Errors)
            //        .Select(e => e.ErrorMessage);
            //    return BadRequest(new { Errors = errors }); <---- How to send errors to user
            //}
            var userName = ViewBag.UserName;
            var maxVehicleListId =
                        _dbConnection.QueryFirstOrDefault<int>(@"SELECT MAX(VehicleListId) + 1  FROM SBCES.VehicleList");

            _dbConnection.Open();
            using (var transaction = _dbConnection.BeginTransaction())
            {
                try
                {
                    // Insert into the main RbMasterlist table
                    var insertVehlistQuery = @"
                                                        INSERT INTO SBCES.VehicleList ( VehicleListId,NumOfVehicles,
                                                            Sopnumber, ProjDesc, Differential, Engine, 
                                                             Make, Model, VehSeriesCode, Year, Transmission,  EnteredBy,
                                                            DateEntered, ModifiedLastBy, ModifiedLastDate
                                                        )
                                                        VALUES (
                                                            @VehicleListId,@NumOfVehicles, @Sopnumber, @ProjDesc, @Differential, @Engine, 
                                                             @Make, @VehModel, @VehSeriesCode, @Year, @Transmission, @EnteredBy,
                                                            @DateEntered, @ModifiedLastBy, @ModifiedLastDate
                                                        );
                                                        
                                                    ";

                    await _dbConnection.ExecuteAsync(insertVehlistQuery, new
                    {
                        VehicleListId = maxVehicleListId,
                        vehicleViewModel.NumOfVehicles,
                        vehicleViewModel.Sopnumber,
                        vehicleViewModel.ProjDesc,
                        vehicleViewModel.Differential,
                        vehicleViewModel.Engine,

                        vehicleViewModel.Make,
                        vehicleViewModel.VehModel,
                        vehicleViewModel.Transmission,
                        vehicleViewModel.VehSeriesCode,
                        vehicleViewModel.Year,


                        EnteredBy = userName,
                        DateEntered = DateTime.Now,
                        ModifiedLastBy = userName,
                        ModifiedLastDate = DateTime.Now

                    }, transaction);



                    // Commit the transaction
                    transaction.Commit();

                    return maxVehicleListId;

                }
                catch (Exception ex)
                {
                    // Rollback the transaction in case of an error
                    // transaction.Rollback();
                    Console.WriteLine($"Error creating Vehicle data: {ex.Message}");
                    throw; // Re-throw the exception to propagate it
                }
            }

        }

        [HttpGet]
        public ActionResult GetLabourDetailsTabContent(int vehicleId)
        {
            // Fetch data for labour details
            var labourDetails = _dbConnection.Query<LabourDetailsRebuiltPartsViewModel>(
                "SELECT * FROM LabourDetails WHERE VehicleId = @VehicleId",
                new { VehicleId = vehicleId });

            return PartialView("_LabourDetails", labourDetails);
        }

        [AllowAnonymous]
        public IActionResult LabourDetailsPartial( string id,  string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParenId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_LabourDetails", new List<LabourDetailsRebuiltPartsViewModel>());
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult ScDetailsPartial([FromForm] string id, string gridType)
        {
            ViewBag.ParentId = id;
            ViewBag.PartNum = id;
            if (gridType == null)
            {
                ViewBag.GridType = "VehicleGrid";
            }
            else
            {
                ViewBag.GridType = gridType;

            }

            var model = new List<BCES.Models.Parts.StockCodedPartsViewModel> { };

            return PartialView("_ScPartsUsed", model);

        }

        [AllowAnonymous]
        public IActionResult LabourHourSummaryPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParentId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_LabourHourSummary", new List<LabourDetailsRebuiltPartsViewModel>());
        }

        [AllowAnonymous]
        public IActionResult AllLabourInRBPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParentId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            
            return PartialView("_AllLabour", new List<LabourDetailsRebuiltPartsViewModel>());
        }


        [AllowAnonymous]
        public IActionResult MaterialCostSummaryPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParentId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_MaterialCostSummary", new List<MaterialCostSummaryInRbViewModel>());
        }

        [AllowAnonymous]
        public IActionResult NonStockPartsPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParentId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_NscPartsUsed", new List<NscPartsUsedViewModel>());

        }


        [AllowAnonymous]
        public IActionResult RebuiltPartsPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParenId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_RbPartsUsed", new List<RebuiltPartsViewModel>());
        }

        [AllowAnonymous]
        public IActionResult TotalCostPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParenId = id;
            if (gridType == null)
            {
                ViewBag.GridType = "VehicleGrid";
            }
            else
            {
                ViewBag.GridType = gridType;

            }
            var model = new List<BCES.Models.Parts.TotalCostInEstimates> { };
            

            return PartialView("_VehicleTotalCost", model);
        }

        private async Task<IEnumerable<NscPartsUsedViewModel>> GetNonStockParts(string id)
        {
            try
            {
                return await _dbConnection.QueryAsync<NscPartsUsedViewModel>(@"
            SELECT * 
            FROM SBCES.NSCPartsUsed 
            WHERE LinkCode = @Id AND LinkType = 'BUS'",
                    new { Id = id });
            }
            catch
            {
                return new List<NscPartsUsedViewModel>();
            }
        }

        private async Task<IEnumerable<RebuiltPartsViewModel>> GetRebuiltParts(string id)
        {
            try
            {
                return await _dbConnection.QueryAsync<RebuiltPartsViewModel>(@"
            SELECT * 
            FROM SBCES.SCPartsUsed 
            WHERE LinkCode = @Id AND LinkType = 'BUS' AND RebuiltPart = 'Y'",
                    new { Id = id });
            }
            catch
            {
                return new List<RebuiltPartsViewModel>();
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public IActionResult SaveDetails()
        {
            // Save logic here
            return Json(new { success = true, message = "Saved Details successfully." });
        }


        [HttpPost]
        [AllowAnonymous]
        public IActionResult CancelDetails(int vehicleListId)
        {
            try
            {
                // Return a success response
                return Json(new { success = true, message = "Changes discarded successfully." });
            }
            catch (Exception ex)
            {

                return Json(new { success = false, message = "An error occurred while discarding changes. Please try again." });
            }
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ArchiveVehicleDetails([FromBody] ArchiveVehicleRequestModel payload)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@VehicleListId", payload.VehicleListId);
                parameters.Add("@ReturnValue", dbType: DbType.Int32, direction: ParameterDirection.ReturnValue);

                await _dbConnection.ExecuteAsync(
                    "[SBCES].[ArchiveVehicleV2]",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                var retVal = parameters.Get<int>("@ReturnValue");

                return Json(new
                {
                    success = retVal == 0,
                    message = retVal == 0
                        ? $"Archived Vehicle List Id: {payload.VehicleListId}"
                        : $"Archive failed with return value: {retVal}"
                });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    message = $"Archive failed: {ex.Message}"
                });
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> SendEmail(string to, string subject, string body, string rebuiltPartNum)
        {
            try
            {
                // Resolve the ExportController from the service provider
                var exportController = _serviceProvider.GetRequiredService<ExportController>();

                // Generate the Excel file in memory by calling SaveToExcel
                var memoryStream = await exportController.SaveToExcel(rebuiltPartNum);


                // Send the email with the attached Excel file
                var message = new MimeMessage();
                message.From.Add(new MailboxAddress("Sandeep Kanao", "sandeep.kanao@ttc.ca"));
                message.To.Add(new MailboxAddress("Sandeep.Kanao@ttc.ca", to));
                message.Subject = subject;
                message.Body = new TextPart("plain") { Text = body };

                var attachment = new MimePart("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                {
                    Content = new MimeContent((Stream)memoryStream),
                    ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                    ContentTransferEncoding = ContentEncoding.Base64,
                    FileName = $"{rebuiltPartNum}_Vehicle_Estimate.xlsx"
                };

                var multipart = new Multipart("mixed");
                multipart.Add(message.Body);
                multipart.Add(attachment);
                message.Body = multipart;

                using (var client = new SmtpClient())
                {
                    await client.ConnectAsync("smtp.freesmtpservers.com", 25, SecureSocketOptions.StartTls);
                    // await client.AuthenticateAsync("sandeep.kanao@gmail.com", "Perf4you@");
                    await client.SendAsync(message);
                    await client.DisconnectAsync(true);
                }

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Log the exception 
                Console.WriteLine($"Error sending email: {ex.Message}");

                return Json(new { success = false, message = ex.Message });
            }
        }

        [AllowAnonymous]
        public IActionResult DownloadExcel(string filePath)
        {
            var fileBytes = System.IO.File.ReadAllBytes(filePath);
            return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", Path.GetFileName(filePath));
        }


        [HttpPost]
        [AllowAnonymous]
        public IActionResult CopyEstimate(
        [FromBody] CopyEstimateRequest request) // Create this DTO class
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@VehicleListId", request.vehicleListId, DbType.Int32);
                parameters.Add("@BusSeriesCode", request.newVehSeriesCode, DbType.String);
                parameters.Add("@ProjDesc", request.newprojDesc, DbType.String);
                parameters.Add("@EnteredBy", ViewBag.UserName, DbType.String);
                parameters.Add("@EstimateType", "BUS", DbType.String);
                parameters.Add("@NewVehicleListId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                _dbConnection.Execute("SBCES.CopyEstimate", parameters, commandType: CommandType.StoredProcedure);

                int newVehicleListId = parameters.Get<int>("@NewVehicleListId");
                return Json(new { success = true, newVehicleListId });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public class CopyEstimateRequest
        {
            public int vehicleListId { get; set; }
            public string oldVehSeriesCode { get; set; }
            public string newVehSeriesCode { get; set; }
            public string oldprojDesc { get; set; }
            public string newprojDesc { get; set; }
        }

        //////////////////////////////////////////////////
       
        // === Popup Details Action ===
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ArchiveDetails(int id)
        {
            try
            {
                var vm = await GetArchVehiclePopup(id);
                return PartialView("_ArchVehiclePopup", vm);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        private async Task<ArchVehiclePopupViewModel> GetArchVehiclePopup(int id)
        {
            try
            {
                // Master
                var masterSql = @"SELECT  [ArchVehicleListId]
                      ,[VehSeriesCode]
                      ,[NumOfVehicles]
                      ,[ProjDesc]
                      ,[DateEntered] as ArchivedDate
                      ,[EnteredBy] as ArchivedBy
                      ,[Make]
                      ,[Model]
                      ,[Year]
                      ,[Engine]
                      ,[Transmission]
                      ,[Differential]
                      ,[LabourCost]
                      ,[LabourOverheadAmount]
                      ,[LabourTotal]
                      ,[MaterialsTotal]
                      ,[TotalBusEstimateCost]
                      ,[TotalTax]
                      ,[TotalCostTax]
                      ,[OemKitsTotal]
                      ,[Sopnumber]
                      ,[OldId]
                  FROM [CES].[SBCES].[ArchVehicleList] WHERE ARCHVEHICLELISTID =" + id;
                var master = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(masterSql, new { id });

                // SC Parts
                var scSql = @"SELECT MMSSTOCKCODE, SCDESCRIPTION, QTYREQD, TOTALCOST, REBUILTPART, LINKTYPE, LINKCODE
                              FROM SBCES.ARCHVEHSCPARTSUSED
                              WHERE REBUILTPART = 'N' and ARCHVEHICLELISTID =" + id;
                var scParts = await _dbConnection.QueryAsync<ScPartUsedViewModel>(scSql, new { id });

                // NSC Parts
                var nscSql = @"SELECT ORIGSUPPNUM, ORIGSUPPLIERNAME, QTYREQD, TOTALCOST, LINKTYPE, LINKCODE
                               FROM [SBCES].[ArchVehNscPartsUsed]
                               WHERE [ArchVehicleListId] =" + id;
                var nscParts = await _dbConnection.QueryAsync<NscPartUsedViewModel>(nscSql, new { id });

                var rbSql = @"SELECT MMSSTOCKCODE, SCDESCRIPTION, QTYREQD, TOTALCOST, REBUILTPART, LINKTYPE, LINKCODE
                              FROM SBCES.ARCHVEHSCPARTSUSE
                              WHERE REBUILTPART ='Y' and ARCHVEHICLELISTID =" + id;
                var rbParts = await _dbConnection.QueryAsync<ScPartUsedViewModel>(scSql, new { id });

                // Employee Labour
                var labourSql = @"SELECT LABOURDEFN, TASK, HRSREQD, ADJHRS, TIMEADDITION
                                  FROM SBCES.ARCHVEHEMPLOYEELABOUR
                                  WHERE ARCHVEHICLELISTID =" + id;
                var labour = await _dbConnection.QueryAsync<EmployeeLabourViewModel>(labourSql, new { id });

                // Labour Totals
                var labourTotalsSql = @"SELECT COSTCENTRE, TOTALHOURS
                                        FROM SBCES.ARCHVEHLABOURCCTOTAL
                                        WHERE ARCHVEHICLELISTID =" +  id;
                var labourTotals = await _dbConnection.QueryAsync<LabourCcTotalViewModel>(labourTotalsSql, new { id });

                ArchVehiclePopupViewModel archVehiclePopupViewModel =  new ArchVehiclePopupViewModel
                {
                    ArchVehicleListId = master.ArchVehicleListId,
                    Make = master.Make,
                    Model = master.Model,
                    Year = master.Year,
                    Engine = master.Engine,
                    Transmission = master.Transmission,
                    Differential = master.Differential,
                    LabourTotal = master.LabourTotal,
                    MaterialsTotal = master.MaterialsTotal,
                    TotalBusEstimateCost = master.TotalBusEstimateCost,
                    ScPartsUsed = scParts,
                    NscPartsUsed = nscParts,
                    EmployeeLabours = labour,
                    LinkCode = master.LinkCode,
                    LinkType = master.LinkType,
                    LabourCcTotals = labourTotals,
                    ArchivedBy = master.ArchivedBy,
                    ArchivedDate = master.ArchivedDate
                };

                return new ArchVehiclePopupViewModel
                {
                    ArchVehicleListId = master.ArchVehicleListId,
                    OldId = master.OldId,
                    VehSeriesCode = master.VehSeriesCode,
                    NumOfVehicles = master.NumOfVehicles,
                    ProjDesc = master.ProjDesc,
                    Make = master.Make,
                    Model = master.Model,
                    Year = master.Year,
                    Engine = master.Engine,
                    Transmission = master.Transmission,
                    Differential = master.Differtial,
                    LabourCost = master.LabourCost,
                    LabourOverheadAmount = master.LabourOverheadAmount,
                    LabourTotal = master.labourTotal,

                    MaterialsTotal = master.MaterialsTotal,
                    TotalBusEstimateCost = master.TotalBusEstimateCost,
                    TotalTax = master.TotalTax,
                    TotalCostTax = master.TotalCostTax,
                    ScPartsUsed = scParts,
                    NscPartsUsed = nscParts,
                    RbPartsUsed = rbParts,
                    EmployeeLabours = labour,
                    LabourCcTotals = labourTotals,
                    ArchivedBy = master.ArchivedBy,
                    ArchivedDate = master.ArchivedDate

                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching archive details: {ex.Message}");
                return new ArchVehiclePopupViewModel();
            }
        }

        ///////////////////////////////////////////////////
     
    }

}