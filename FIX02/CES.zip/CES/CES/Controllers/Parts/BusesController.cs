﻿using BCES.Data;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using BCES.Controllers.Base;
using BCES.Models.Parts;

using BCES.Models.Admin;
using System.Data.Common;
using Dapper;

namespace BCES.Controllers.Parts
{
    public class BusesController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public BusesController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<IEnumerable<BusesModel>> GetBusDetails(string rebuiltStockNum)
        {
            var query = @"
            SELECT rlb.[RebuiltStockNum],
                   lb.[ListId],
                   lb.[Description]
            FROM [SBCES].[RbListOfBuses] rlb
            INNER JOIN [SBCES].[ListOfBuses] lb ON rlb.[ListId] = lb.[ListId]
            WHERE rlb.[RebuiltStockNum] = @RebuiltStockNum"
            ;

            return await _dbConnection.QueryAsync<BusesModel>(query, new { RebuiltStockNum = rebuiltStockNum });
        }
    }


    
}


