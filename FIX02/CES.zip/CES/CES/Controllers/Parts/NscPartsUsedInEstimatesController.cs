﻿using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using BCES.Models.Parts;
using BCES.Controllers.Base;
using BCES.Data;
using System.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Data.SqlClient;
using System.Globalization;
using BCES.Controllers.Common;


namespace BCES.Controllers.Parts
{
    public class NscPartsUsedInEstimatesController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public NscPartsUsedInEstimatesController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetNscPartsUsedInEstimates([DataSourceRequest] DataSourceRequest request, [FromQuery] string id, [FromQuery] string gridType)
        {
            // Fetch data for the grid
                 

           
            if (string.IsNullOrEmpty(id))
            {
                BadRequest("id is required for gridType :" + gridType);
            }

            // Fetch data for the grid 

            if (gridType == "RebuiltGrid")
            {
                var rbNscModel = await GetNscPartsUsedInRBEstimates(id, gridType);
                return Json(rbNscModel.ToDataSourceResult(request));
            }
            if (gridType == "VehicleGrid")
            {
                var vehNscmodel = await GetNscPartsUsedInVehicleEstimates(id, gridType);
                return Json(vehNscmodel.ToDataSourceResult(request));
            }
            if (gridType == "ArchivedVehicleGrid")
            {
                var vehNscmodel = await GetArchivedNscPartsUsedInVehicleEstimates(id, gridType);
                return Json(vehNscmodel.ToDataSourceResult(request));
            }
            if (gridType == "MakeVsBuyGrid")
            {
                var vehNscmodel = await GetNscPartsUsedInMbEstimates(id, gridType);
                return Json(vehNscmodel.ToDataSourceResult(request));
               // return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            if (gridType == "ArchivedMakeVsBuyGrid")
            {
                return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            if (gridType == "ArchivedRebuiltGrid")
            {
                return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            return StatusCode(500, "An error occurred while fetching data.");


        }

        private async Task<IEnumerable<NscPartsUsedViewModel>> GetArchivedNscPartsUsedInVehicleEstimates(string partNum, string gridType)
        {
            try
            {
                var query = @"
                           SELECT  [OrigSuppNum]
                                  ,[OrigSupplierName]
                                  ,[CostCentre]
                                  ,[QtyReqd]
                                  ,[PercentUsage]
                                  ,[DateEntered]
                                  ,[EnteredBy]
                                  ,[LinkCode]
                                  ,[Cost]
                                  ,[LinkType]
                                  ,[Corecost]
                                  ,[ArchVehicleListId]
                                  ,[TotalCost]
                              FROM [CES].[SBCES].[ArchVehNscPartsUsed]
                              where [ArchVehicleListId] = @id";


                var parameters = new { id = partNum };

                var result = await _dbConnection.QueryAsync<NscPartsUsedViewModel>(query, parameters);


                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourDetailsData: {ex.Message}");
                throw; // Rethrow the exception for centralized handling
            }
        }
        [AllowAnonymous]
        private async Task<IEnumerable<NscPartsUsedViewModel>> GetNscPartsUsedInRBEstimates(string id, string gridType)
        {

            try
            {
                var linkCode =  id?.ToUpper(); ;
                if (gridType == "RebuiltGrid")
                {
                    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                   "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                   new { Id = id }

                    );
                  

                }
               
                var query = @"
                             DECLARE @VehicleListId VARCHAR(30) = '" + linkCode + "'" +
                            @"
                              SELECT
                                    Oid,
                                    UPPER(NonStockCodedParts.OrigSupplierNum) AS [OrigSuppNum],
                                    UPPER(NonStockCodedParts.OrigSupplierName) AS [OrigSupplierName],
                                    NonStockCodedParts.OemPartCost AS [UnitCost],
                                    NscPartsUsed.Cost ,
                                    UPPER(NscPartsUsed.QtyReqd) AS [QTY],
                                    REPLACE(NscPartsUsed.PercentUsage, ',', '.') AS [Percentage],
                                    ISNULL(NscPartsUsed.CoreCost, 0) AS [CoreCost],
                                    REPLACE(SBCES.FINALCOST(ISNULL(NscPartsUsed.PercentUsage,0), ISNULL(NscPartsUsed.QtyReqd,0), ISNULL(NonStockCodedParts.OemPartCost,0), ISNULL(NscPartsUsed.CoreCost, 0)), ',', '.') AS [TotalCost],
                                    UPPER(NscPartsUsed.CostCentre) AS [CC],
                                    ISNULL(UPPER(NonStockCodedParts.DetailedDesc), '') AS [Description],
                                    ISNULL(UPPER(NonStockCodedParts.Keyword), '') AS [KeyWord],
                                    UPPER(NscPartsUsed.Id) AS [ID],                                   
                                     UPPER(NscPartsUsed.LastModifiedDate) AS [LastModifiedDate],
                                    UPPER(NscPartsUsed.LastModifiedBy) AS [LastModifiedBy],
                                     UPPER(NSCPARTSUSED.LastModifiedBy) AS LastModifiedBy
                                   -- NscPartsUsed.RowId
                                FROM SBCES.NscPartsUsed AS NscPartsUsed
                                RIGHT JOIN SBCES.NonStockCodedParts AS NonStockCodedParts 
                                    ON NonStockCodedParts.Id = NscPartsUsed.Id
                                WHERE
                                    NscPartsUsed.LinkCode = '" + linkCode + @"'
                                    AND NscPartsUsed.LinkType = 'RB'
                                ORDER BY
                                    NonStockCodedParts.OrigSupplierNum;
                                ";
                return await _dbConnection.QueryAsync<NscPartsUsedViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [AllowAnonymous]
        private async Task<IEnumerable<NscPartsUsedViewModel>> GetNscPartsUsedInVehicleEstimates(string VehicleListId, string gridType)
        {
            //TODO use GridType
            ViewBag.PartNum = VehicleListId;
            try
            {

                var query = @"
                             DECLARE @VehicleListId VARCHAR(30) = '" + VehicleListId + "'" +
                             @"
                              SELECT
                                    Oid,
                                    UPPER(NonStockCodedParts.OrigSupplierNum) AS [OrigSuppNum],
                                    UPPER(NonStockCodedParts.OrigSupplierName) AS [OrigSupplierName],
                                    NonStockCodedParts.OemPartCost AS [UnitCost],
                                    NscPartsUsed.Cost ,
                                    UPPER(NscPartsUsed.QtyReqd) AS [QTY],
                                    REPLACE(NscPartsUsed.PercentUsage, ',', '.') AS [Percentage],
                                    REPLACE(SBCES.FINALCOST(NscPartsUsed.PercentUsage, NscPartsUsed.QtyReqd, NscPartsUsed.CoreCost, 0), ',', '.') AS [CoreCost],
                                    REPLACE(SBCES.FINALCOST(NscPartsUsed.PercentUsage, NscPartsUsed.QtyReqd, NonStockCodedParts.OemPartCost, 0), ',', '.') AS [TotalCost],
                                    UPPER(NscPartsUsed.CostCentre) AS [CC],
                                    ISNULL(UPPER(NonStockCodedParts.DetailedDesc), '') AS [Description],
                                    ISNULL(UPPER(NonStockCodedParts.Keyword), '') AS [KeyWord],
                                    UPPER(NscPartsUsed.Id) AS [ID],                                   
                                     UPPER(NscPartsUsed.LastModifiedDate) AS [LastModifiedDate],
                                    UPPER(NscPartsUsed.LastModifiedBy) AS [LastModifiedBy]
                                   -- NscPartsUsed.RowId
                                FROM SBCES.NscPartsUsed AS NscPartsUsed
                                RIGHT JOIN SBCES.NonStockCodedParts AS NonStockCodedParts 
                                    ON NonStockCodedParts.Id = NscPartsUsed.Id
                                WHERE
                                    NscPartsUsed.LinkCode = @VehicleListId
                                    AND NscPartsUsed.LinkType = 'BUS'
                                ORDER BY
                                    NonStockCodedParts.OrigSupplierNum;
                                ";

                                        return await _dbConnection.QueryAsync<NscPartsUsedViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        //GetNscPartsUsedInMbEstimates
        private async Task<IEnumerable<NscPartsUsedViewModel>> GetNscPartsUsedInMbEstimates(string id, string gridType)
        {

            try
            {

                var query = @"
                             DECLARE @MbNumber VARCHAR(30) = '" + id + "'" +
                             @"
                              SELECT 
                                UPPER(SBCES.NONSTOCKCODEDPARTS.ORIGSUPPLIERNUM) AS [OrigSuppNum],
                                UPPER(SBCES.NONSTOCKCODEDPARTS.ORIGSUPPLIERNAME) AS [OrigSupplierName],
                                SBCES.NONSTOCKCODEDPARTS.OEMPARTCOST AS [UnitCost],
                                UPPER(SBCES.NSCPARTSUSED.QTYREQD) AS [QTY],
                                REPLACE(SBCES.NSCPARTSUSED.PERCENTUSAGE, ',', '.') AS [Percentage],
                                -- Casting logic with SBCES.FINALCOST
                                CAST(SBCES.FINALCOST(
                                    CAST(SBCES.NSCPARTSUSED.PERCENTUSAGE AS NUMERIC(18,2)), 
                                    CAST(SBCES.NSCPARTSUSED.QTYREQD AS NUMERIC(18,2)), 
                                    SBCES.NSCPARTSUSED.CORECOST, 
                                    0
                                ) AS DECIMAL(18,2)) AS [CoreCost],
                                CAST(SBCES.FINALCOST(
                                    CAST(SBCES.NSCPARTSUSED.PERCENTUSAGE AS NUMERIC(18,2)), 
                                    CAST(SBCES.NSCPARTSUSED.QTYREQD AS NUMERIC(18,2)), 
                                    SBCES.NONSTOCKCODEDPARTS.OEMPARTCOST, 
                                    0
                                ) AS DECIMAL(18,2)) AS [TotalCost],
                                UPPER(SBCES.NSCPARTSUSED.COSTCENTRE) AS [CC],
                                ISNULL(UPPER(SBCES.NONSTOCKCODEDPARTS.DETAILEDDESC), '') AS [DESCRIPTION],
                                ISNULL(UPPER(SBCES.NONSTOCKCODEDPARTS.KEYWORD), '') AS [KEYWORD],
                                UPPER(SBCES.NSCPARTSUSED.ID) AS [ID],
                                UPPER(SBCES.NSCPARTSUSED.LASTMODIFIEDDATE) AS [LASTMODIFIEDDATE],
                                 UPPER(SBCES.NSCPARTSUSED.LastModifiedBy) AS LastModifiedBy
   
                            FROM 
                                SBCES.NSCPARTSUSED  -- Schema applied
                            LEFT JOIN 
                                SBCES.NONSTOCKCODEDPARTS  -- Schema applied
                                ON SBCES.NONSTOCKCODEDPARTS.ID = SBCES.NSCPARTSUSED.ID
                            WHERE 
                                SBCES.NSCPARTSUSED.LINKCODE = @MbNumber
                               AND SBCES.NSCPARTSUSED.LINKTYPE = 'MB'
                            ORDER BY 
                                SBCES.NONSTOCKCODEDPARTS.ORIGSUPPLIERNUM;

                                ";

                return await _dbConnection.QueryAsync<NscPartsUsedViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [AcceptVerbs("Post")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateNscPartsUsedInEstimates(
    [DataSourceRequest] DataSourceRequest request,
    NscPartsUsedViewModel model,
    [FromQuery] string id,
    [FromQuery] string gridType)
        {
            if (!ModelState.IsValid)
            {
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
            }

            _dbConnection.Open();
            using var transaction = _dbConnection.BeginTransaction();

            try
            {
                var enteredBy = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM";
                var dateModified = DateTime.Now;

                // ---------------------------------------------------------
                // Determine LinkType
                // ---------------------------------------------------------
                string linkType = gridType switch
                {
                    "RebuiltGrid" => "RB",
                    "VehicleGrid" => "BUS",
                    "MakeVsBuyGrid" => "MB",
                    _ => ""
                };

                // ---------------------------------------------------------
                // Determine LinkCode
                // ---------------------------------------------------------
                var linkCode = id?.ToUpper(); ;

                if (gridType == "RebuiltGrid")
                {
                    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                        "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                        new { Id = id },
                        transaction
                     );
                    //linkCode = id?.ToUpper();
                   
                }
              

                // ---------------------------------------------------------
                // NEW: DYNAMIC ID LOOKUP FROM NonStockCodedParts
                // ---------------------------------------------------------
                var dynamicIdSql = @"
            SELECT Id
            FROM SBCES.NonStockCodedParts
            WHERE UPPER(OrigSupplierName) = @OrigSupplierName
              AND UPPER(OrigSupplierNum) = @OrigSupplierNum;
        ";

                var dynamicId = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                    dynamicIdSql,
                    new
                    {
                        OrigSupplierName = model.OrigSupplierName?.ToUpperInvariant(),
                        OrigSupplierNum = model.OrigSuppNum?.ToUpperInvariant()
                    },
                    transaction
                );

                if (dynamicId == null)
                {
                    ModelState.AddModelError("Id",
                        "Unable to locate a matching NonStockCodedParts record for the supplied Supplier Name and Number.");
                    return Json(new[] { model }.ToDataSourceResult(request, ModelState));
                }

                // ---------------------------------------------------------
                // UPDATE NSCPartsUsed USING dynamicId + linkCode + linkType
                // ---------------------------------------------------------
                var parameters = new DynamicParameters();
                parameters.Add("Id", dynamicId);
                parameters.Add("LinkCode", linkCode);
                parameters.Add("LinkType", linkType);
                parameters.Add("CC", model.CC?.ToUpperInvariant() ?? " ");
                parameters.Add("UnitCost", model.UnitCost);
                parameters.Add("Qty", model.Qty);
                parameters.Add("Percentage", model.Percentage);
                parameters.Add("CoreCost", model.CoreCost);
                parameters.Add("LastModifiedBy", enteredBy);
                parameters.Add("LastModifiedDate", dateModified);

                var sql = @"
            UPDATE SBCES.NSCPartsUsed
            SET 
                CostCentre = UPPER(@CC),
                Cost = @UnitCost,
                QtyReqd = @Qty,
                PercentUsage = @Percentage,
                CoreCost = @CoreCost,
                LastModifiedBy = UPPER(@LastModifiedBy),
                LastModifiedDate = @LastModifiedDate
            WHERE 
                Id = @Id
                AND UPPER(LinkCode) = UPPER(@LinkCode)
                AND UPPER(LinkType) = UPPER(@LinkType);
        ";

                await _dbConnection.ExecuteAsync(sql, parameters, transaction);

                transaction.Commit();

                // ---------------------------------------------------------
                // Update vehicle totals if needed
                // ---------------------------------------------------------
                //if (gridType == "VehicleGrid")
                //{
                //    await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                //}

                return Json(new[] { model }.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                ModelState.AddModelError("", $"Error updating record: {ex.Message}");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
            }
        }

        //public async Task<IActionResult> UpdateNscPartsUsedInEstimates(
        //                                           [DataSourceRequest] DataSourceRequest request,
        //                                           NscPartsUsedViewModel model,
        //                                           [FromQuery] string id,
        //                                           [FromQuery] string gridType)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //       // return Json(models.ToDataSourceResult(request, ModelState));
        //        return Json(new[] { model }.ToDataSourceResult(request, ModelState));
        //    }
        //    _dbConnection.Open();
        //    using var transaction = _dbConnection.BeginTransaction();
        //    try
        //    {
        //        var enteredBy = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM";
        //        var dateModified = DateTime.Now;
        //        string linkType = "";
        //        if (gridType == "RebuiltGrid")
        //        {
        //            linkType = "RB";
        //        }
        //        else if (gridType == "VehicleGrid")
        //        {
        //            linkType = "BUS";
        //        }
        //        else if (gridType == "MakeVsBuyGrid")
        //        {
        //            linkType = "MB";
        //        }
        //        var linkCode = "";
        //        if (gridType == "RebuiltGrid")
        //        {
        //            linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
        //               "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
        //               new { Id = id }

        //           );
        //        }
        //        else
        //        {
        //            linkCode = id?.ToUpper();
        //        }
        //        // foreach (var model in models)
        //        {
        //            var parameters = new DynamicParameters();
        //            parameters.Add("Id", model.Id);
        //            parameters.Add("CC", model.CC?.ToUpperInvariant() ?? " ");
        //            parameters.Add("UnitCost", model.UnitCost);
        //            parameters.Add("Qty", (model.Qty));
        //            parameters.Add("Percentage", (model.Percentage));
        //            parameters.Add("CoreCost", model.CoreCost);
        //            parameters.Add("RebuiltPartNum", id?.ToUpperInvariant());
        //            parameters.Add("LastModifiedBy", enteredBy);
        //            parameters.Add("LastModifiedDate", dateModified);

        //            var sql = @"
        //                        UPDATE SBCES.NSCPartsUsed 
        //                        SET 
        //                            CostCentre = UPPER(@CC),
        //                            Cost = @UnitCost,
        //                            QtyReqd = UPPER(@Qty),
        //                            PercentUsage = UPPER(@Percentage),
        //                            coreCost = @CoreCost,
        //                            LastModifiedBy = @LastModifiedBy,
        //                            LastModifiedDate = @LastModifiedDate
        //                        WHERE 
        //                            Id = " + "'" + linkCode +"'" + " --  AND MMSRebuiltCode = @RebuiltPartNum";

        //            await _dbConnection.ExecuteAsync(sql, parameters, transaction);
        //        }

        //        transaction.Commit();

        //        if (gridType == "VehicleGrid")
        //        {
        //            //update estimates
        //            await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
        //        }

        //        //return Json(models.ToDataSourceResult(request));
        //        return Json(new[] { model }.ToDataSourceResult(request));
        //    }
        //    catch (Exception ex)
        //    {
        //        transaction.Rollback();
        //        ModelState.AddModelError("", $"Error updating record: {ex.Message}");
        //        return Json(new[] { model }.ToDataSourceResult(request, ModelState));
        //        //return Json(models.ToDataSourceResult(request, ModelState));
        //    }
        //}

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateNscPartsUsedInEstimatess(
    [DataSourceRequest] DataSourceRequest request,
    NscPartsUsedViewModel model,
    [FromQuery] string id,
    [FromQuery] string gridType)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage);
                return BadRequest(new { Errors = errors });
            }

            _dbConnection.Open();
            using var transaction = _dbConnection.BeginTransaction();

            try
            {
                var enteredBy = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM";
                var dateEntered = DateTime.Now;

                string linkType = gridType switch
                {
                    "RebuiltGrid" => "RB",
                    "VehicleGrid" => "BUS",
                    "MakeVsBuyGrid" => "MB",
                    _ => ""
                };

                // ---------------------------------------------------------
                // DETERMINE LINKCODE (same as before)
                // ---------------------------------------------------------
                var linkCode = id.ToUpper();
                if (gridType == "RebuiltGrid")
                {
                    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                            "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                            new { Id = id },
                            transaction
                        );


                }

                if (model == null)
                {
                    ModelState.AddModelError("", "No data submitted.");
                    return Json(new[] { model }.ToDataSourceResult(request, ModelState));
                }

                var supplierNum = model.OrigSuppNum?.ToUpperInvariant();
                var supplierName = model.OrigSupplierName?.ToUpperInvariant();

                // ---------------------------------------------------------
                // NEW: DYNAMICALLY GET @Id FROM NonStockCodedParts
                // ---------------------------------------------------------
                var dynamicIdSql = @"
            SELECT Id 
            FROM SBCES.NonStockCodedParts
            WHERE UPPER(OrigSupplierName) = @OrigSupplierName
              AND UPPER(OrigSupplierNum) = @OrigSupplierNum;
        ";

                var dynamicId = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                    dynamicIdSql,
                    new
                    {
                        OrigSupplierName = supplierName,
                        OrigSupplierNum = supplierNum
                    },
                    transaction
                );

                if (dynamicId == null)
                {
                    ModelState.AddModelError("Id",
                        "Unable to locate a matching NonStockCodedParts record for the supplied Supplier Name and Number.");
                    return BadRequest("Matching NonStockCodedParts ID not found.");
                }

                // ---------------------------------------------------------
                //  DUPLICATE CHECK (uses dynamicId)
                // ---------------------------------------------------------
                var duplicateCheckSql = @"
            SELECT COUNT(*)
            FROM SBCES.NSCPartsUsed
            WHERE UPPER(OrigSuppNum) = @OrigSuppNum
              AND UPPER(LinkCode) = @LinkCode
              AND UPPER(LinkType) = @LinkType
              AND Id = @Id;
        ";

                var duplicateCount = await _dbConnection.ExecuteScalarAsync<int>(
                    duplicateCheckSql,
                    new
                    {
                        OrigSuppNum = supplierNum,
                        LinkCode = linkCode,
                        LinkType = linkType,
                        Id = dynamicId
                    },
                    transaction
                );

                if (duplicateCount > 0)
                {
                    var msg = $"Supplier Number '{model.OrigSuppNum}' already exists for this estimate.";
                    ModelState.AddModelError("OrigSuppNum", msg);
                    return BadRequest(msg);
                }

                // ---------------------------------------------------------
                // INSERT PARAMETERS (uses dynamicId)
                // ---------------------------------------------------------
                var parameters = new DynamicParameters();

                parameters.Add("OrigSuppNum", supplierNum);
                parameters.Add("OrigSupplierName", supplierName);
                parameters.Add("CostCentre", model.CC?.ToUpperInvariant());
                parameters.Add("QtyReqd", model.Qty);
                parameters.Add("PercentUsage", model.Percentage);
                parameters.Add("DateEntered", dateEntered);
                parameters.Add("EnteredBy", enteredBy);
                parameters.Add("LastModifiedBy", enteredBy);
                parameters.Add("LastModifiedDate", dateEntered);
                parameters.Add("LinkCode", linkCode);
                parameters.Add("Cost", model.UnitCost);
                parameters.Add("LinkType", linkType);
                parameters.Add("CoreCost", model.CoreCost ?? 0m);
                parameters.Add("Id", dynamicId);   // dynamic

                // ---------------------------------------------------------
                // INSERT INTO NSCPartsUsed
                // ---------------------------------------------------------
                var sql = @"
            INSERT INTO SBCES.NSCPartsUsed (
                OrigSuppNum,
                OrigSupplierName,
                CostCentre,
                QtyReqd,
                PercentUsage,
                DateEntered,
                EnteredBy,
                LastModifiedBy,
                LastModifiedDate,
                LinkCode,
                Cost,
                LinkType,
                CoreCost,
                Id
            )
            VALUES (
                UPPER(@OrigSuppNum),
                UPPER(@OrigSupplierName),
                UPPER(@CostCentre),
                @QtyReqd,
                @PercentUsage,
                @DateEntered,
                UPPER(@EnteredBy),
                UPPER(@LastModifiedBy),
                @LastModifiedDate,
                UPPER(@LinkCode),
                @Cost,
                UPPER(@LinkType),
                @CoreCost,
                @Id
            );
        ";

                await _dbConnection.ExecuteAsync(sql, parameters, transaction);

                transaction.Commit();

                //if (gridType == "VehicleGrid")
                //{
                //    await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                //}

                return Json(new[] { model }.ToDataSourceResult(request));
            }
            catch (SqlException sqlEx)
            {
                transaction.Rollback();
                ModelState.AddModelError("", $"Database error: {sqlEx.Message}");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                ModelState.AddModelError("", $"Unexpected error: {ex.Message}");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
            }
        }

        //    public async Task<IActionResult> CreateNscPartsUsedInEstimatess(
        //[DataSourceRequest] DataSourceRequest request,
        //NscPartsUsedViewModel model,
        //[FromQuery] string id,
        //[FromQuery] string gridType)
        //    {
        //        if (!ModelState.IsValid)
        //        {
        //            var errors = ModelState.Values
        //                .SelectMany(v => v.Errors)
        //                .Select(e => e.ErrorMessage);
        //            return BadRequest(new { Errors = errors });
        //        }

        //        _dbConnection.Open();
        //        using var transaction = _dbConnection.BeginTransaction();

        //        try
        //        {
        //            // User + timestamps
        //            var enteredBy = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM";
        //            var dateEntered = DateTime.Now;

        //            // Determine LinkType
        //            string linkType = gridType switch
        //            {
        //                "RebuiltGrid" => "RB",
        //                "VehicleGrid" => "BUS",
        //                "MakeVsBuyGrid" => "MB",
        //                _ => ""
        //            };

        //            // Determine LinkCode
        //            string linkCode;
        //            if (gridType == "RebuiltGrid")
        //            {
        //                linkCode = id?.ToUpper();
        //                //linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
        //                //    "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
        //                //    new { Id = id }, transaction);
        //            }
        //            else
        //            {
        //                linkCode = id?.ToUpper();
        //            }

        //            if (model == null)
        //            {
        //                ModelState.AddModelError("", "No data submitted.");
        //                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
        //            }

        //            var supplierNum = model.OrigSuppNum?.ToUpperInvariant();

        //            // ---------------------------------------------------------
        //            // FIXED DUPLICATE CHECK (parameterized + transaction)
        //            // ---------------------------------------------------------
        //            var duplicateCheckSql = @"
        //        SELECT COUNT(*)
        //        FROM SBCES.NSCPartsUsed
        //        WHERE UPPER(OrigSuppNum) = @OrigSuppNum
        //          AND UPPER(LinkCode) = @LinkCode
        //          AND UPPER(LinkType) = @LinkType;
        //    ";

        //            var duplicateCount = await _dbConnection.ExecuteScalarAsync<int>(
        //                duplicateCheckSql,
        //                new
        //                {
        //                    OrigSuppNum = supplierNum,
        //                    LinkCode = linkCode.ToUpper(),
        //                    LinkType = linkType
        //                },
        //                transaction
        //            );

        //            if (duplicateCount > 0)
        //            {
        //                var msg = $"Supplier Number '{model.OrigSuppNum}' already exists for this estimate.";
        //                ModelState.AddModelError("OrigSuppNum", msg);
        //                return BadRequest(msg);
        //            }

        //            // ---------------------------------------------------------
        //            // INSERT PARAMETERS
        //            // ---------------------------------------------------------
        //            var parameters = new DynamicParameters();

        //            parameters.Add("OrigSuppNum", model.OrigSuppNum?.ToUpperInvariant());
        //            parameters.Add("OrigSupplierName", model.OrigSupplierName?.ToUpperInvariant());
        //            parameters.Add("CostCentre", model.CC?.ToUpperInvariant());
        //            parameters.Add("QtyReqd", model.Qty);
        //            parameters.Add("PercentUsage", model.Percentage);
        //            parameters.Add("DateEntered", dateEntered);
        //            parameters.Add("EnteredBy", enteredBy);
        //            parameters.Add("LastModifiedBy", enteredBy);
        //            parameters.Add("LastModifiedDate", dateEntered);
        //            parameters.Add("LinkCode", linkCode);   // <-- FIXED
        //            parameters.Add("Cost", model.UnitCost);
        //            parameters.Add("LinkType", linkType);
        //            parameters.Add("CoreCost", model.CoreCost ?? 0m);
        //            parameters.Add("Id", id);

        //            // ---------------------------------------------------------
        //            // linkCode
        //            // ---------------------------------------------------------
        //            var sql = @"
        //        INSERT INTO SBCES.NSCPartsUsed (
        //            OrigSuppNum,
        //            OrigSupplierName,
        //            CostCentre,
        //            QtyReqd,
        //            PercentUsage,
        //            DateEntered,
        //            EnteredBy,
        //            LastModifiedBy,
        //            LastModifiedDate,
        //            LinkCode,
        //            Cost,
        //            LinkType,
        //            CoreCost,
        //            Id
        //        )
        //        VALUES (
        //            UPPER(@OrigSuppNum),
        //            UPPER(@OrigSupplierName),
        //            UPPER(@CostCentre),
        //            @QtyReqd,
        //            @PercentUsage,
        //            @DateEntered,
        //            UPPER(@EnteredBy),
        //            UPPER(@LastModifiedBy),
        //            @LastModifiedDate,
        //            UPPER(@LinkCode),    
        //            @Cost,
        //            UPPER(@LinkType),
        //            @CoreCost,
        //            @Id
        //        );
        //    ";

        //            await _dbConnection.ExecuteAsync(sql, parameters, transaction);

        //            transaction.Commit();

        //            // Update vehicle totals if needed
        //            if (gridType == "VehicleGrid")
        //            {
        //                await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
        //            }

        //            return Json(new[] { model }.ToDataSourceResult(request));
        //        }
        //        catch (SqlException sqlEx)
        //        {
        //            transaction.Rollback();
        //            ModelState.AddModelError("", $"Database error: {sqlEx.Message}");
        //            return Json(new[] { model }.ToDataSourceResult(request, ModelState));
        //        }
        //        catch (Exception ex)
        //        {
        //            transaction.Rollback();
        //            ModelState.AddModelError("", $"Unexpected error: {ex.Message}");
        //            return Json(new[] { model }.ToDataSourceResult(request, ModelState));
        //        }
        //    }


        [HttpGet]
        public async Task<IActionResult> RefreshNscPartDetails(string origSuppNum)
        {
            if (string.IsNullOrEmpty(origSuppNum))
            {
                return BadRequest(new { Message = "Supplier Number is required." });
            }

            try
            {
                var query = @"
                            SELECT TOP 1 
                                OrigSupplierName AS OrigSupplierName,
                                Keyword AS KeyWord,
                                detaileddesc AS Description,
                                OemPartCost
                            FROM [CES].[SBCES].[NonStockCodedParts]
                            WHERE origsuppliernum = @origSuppNum";

                using (var connection = _db.CreateConnection())
                {
                    var result = await connection.QueryFirstOrDefaultAsync(query, new { origSuppNum });

                    if (result == null)
                    {
                        return NotFound(new { Message = "Supplier Number not found." });
                    }

                    // Validate OemPartCost
                    if (result.OemPartCost < 0)
                    {
                        return Ok(new
                        {
                            Message = "Invalid Part Cost - must be greater than 0",
                            Data = result // Send data anyway if needed
                        });
                    }

                    return Ok(new
                    {
                        OrigSupplierName = result.OrigSupplierName,
                        KeyWord = result.KeyWord,
                        Description = result.Description,
                        OemPartCost = result.OemPartCost
                    });
                }
            }
            catch (Exception ex)
            {
                // _logger.LogError(ex, "Error refreshing NSC part details");
                return StatusCode(500, new { Message = "An error occurred while refreshing part details." });
            }
        }

        [HttpPost]
        public async Task<IActionResult> RecalculateTotalCost([FromForm] decimal percentage,
                                                      [FromForm] decimal qty,
                                                      [FromForm] decimal oemPartCost)
        {
            try
            {
                string sql = "SELECT SBCES.FINALCOST(@Percentage, @Qty, @OemPartCost, 0) AS TotalCost";

                using (var connection = _db.CreateConnection())
                {
                    var totalCost = await connection.ExecuteScalarAsync<decimal>(sql, new
                    {
                        Percentage = percentage,
                        Qty = qty,
                        OemPartCost = oemPartCost
                    });
                    return Ok(new
                    {
                        success = true,
                        totalCost = totalCost  // Match client-side property name
                    });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    success = false,
                    message = ex.Message
                });
            }
        }

        //[HttpPost]
        //[AllowAnonymous]
        //public async Task<IActionResult> DeleteNscPartsUsedInEstimates(

        //                                                [DataSourceRequest] DataSourceRequest request,
        //                                                 NscPartsUsedViewModel model,
        //                                                [FromForm] string parentPartId,
        //                                                [FromForm] string id,
        //                                                 [FromForm] string gridType)
        //{

        //    _dbConnection.Open();
        //    using (var transaction = _dbConnection.BeginTransaction())
        //    {
        //        try
        //        {

        //            var sql = @"
        //                      DELETE FROM SBCES.NSCPartsUsed 
        //                      WHERE 
        //                          OrigSuppNum ='" + id + "'AND LinkCode ='" +  parentPartId + "'";

        //            var parameters = new { model.OrigSuppNum, parentPartId };

        //            int affectedRows = await _dbConnection.ExecuteAsync(sql, parameters, transaction);

        //            if (affectedRows == 0)
        //            {
        //                ModelState.AddModelError("", $"Record with ID {id} not found.");
        //            }

        //            transaction.Commit();


        //            if (gridType == "VehicleGrid")
        //            {
        //                //update estimates
        //                await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
        //            }


        //           // return Json(models.ToDataSourceResult(request));
        //            return Json(new[] { model }.ToDataSourceResult(request, ModelState));
        //        }
        //        catch (Exception ex)
        //        {
        //            transaction.Rollback();


        //            Console.WriteLine($"Error in deleting NSC part: {ex.Message}");

        //            ModelState.AddModelError("", "An error occurred while deleting data.");
        //            return Json(new[] { model }.ToDataSourceResult(request, ModelState));
        //            // return Json(models.ToDataSourceResult(request, ModelState));
        //        }


        //    }
        //}


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteNscPartsUsedInEstimates(
                                                                         string id,
                                                                         string partNum,
                                                                         string gridType)
        {
            try
            {

                string pid = ViewBag.PartNum;
                string pid2 = ViewBag.ParentId;

                string linkType = "";
                if (gridType == "RebuiltGrid")
                {
                    linkType = "RB";
                }
                else if (gridType == "VehicleGrid")
                {
                    linkType = "BUS";
                }
                else if (gridType == "MakeVsBuyGrid")
                {
                    linkType = "MB";
                }
                _dbConnection.Open();
                using var transaction = _dbConnection.BeginTransaction();

                var linkCode = id.ToUpper();
                if (gridType == "RebuiltGrid")
                {
                    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                            "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                            new { Id = id },
                            transaction
                        );


                }

                var sql = @"
                              DELETE FROM SBCES.NSCPartsUsed 
                              WHERE 
                               OrigSuppNum ='" + partNum + "' AND LinkCode ='" + linkCode + "'";

              
                var parameters = new
                {
                    id,
                    partNum
                    
                };

                int affectedRows = await _dbConnection.ExecuteAsync(sql, parameters, transaction);
                transaction.Commit();

                //if (gridType == "VehicleGrid")
                //{
                //    await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, partNum);
                //}

                return Json(new { success = affectedRows > 0 });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Delete failed: {ex.Message}");
            }
        }

    }
}
