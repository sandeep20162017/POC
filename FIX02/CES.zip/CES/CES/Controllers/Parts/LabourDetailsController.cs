﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using BCES.Models.Parts;
using BCES.Controllers.Base;
using BCES.Data;
using System.Data;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.CodeAnalysis;
using BCES.Models.Admin;
using BCES.Controllers.Common;
using System.Data.Common;
using CommandType = System.Data.CommandType;


namespace BCES.Controllers.Parts
{

    public class LabourDetailsController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private string _rebuiltPartNum;


        public LabourDetailsController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetLabourDetails([DataSourceRequest] DataSourceRequest request, [FromQuery] string id, [FromQuery] string gridType)
        {
            if (string.IsNullOrEmpty(id))
            {
                BadRequest("id is required for gridType :" + gridType);
            }
            ViewBag.PartNum = id;
            try
            {

                if (gridType == "RebuiltGrid")
                {
                    var rbId = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                    "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                    new { Id = id }

                );
                    var rbNscModel = await GetLabourDetailsInRBEstimates(rbId, gridType);
                    return Json(rbNscModel.ToDataSourceResult(request));
                }
                if (gridType == "VehicleGrid")
                {
                    var vehNscmodel = await GetLabourDetailsInVehicleEstimates(id, gridType);

                    return Json(vehNscmodel.ToDataSourceResult(request));
                }
                if (gridType == "MakeVsBuyGrid")
                {
                    var vehNscmodel = await GetLabourDetailsInMbEstimates(id, gridType);

                    return Json(vehNscmodel.ToDataSourceResult(request));
                    //return StatusCode(500, "An error occurred while fetching data, in GetLabourDetailsInRBEstimates. Implement this.");
                }
                if (gridType == "ArchivedMakeVsBuyGrid")
                {
                    return StatusCode(500, "An error occurred while fetching data, in ArchivedMakeVsBuyGrid. Implement this.");
                }
                if (gridType == "ArchivedRebuiltGrid")
                {
                    return StatusCode(500, "An error occurred while fetching data, in ArchivedRebuiltGrid. Implement this.");
                }
                if (gridType == "ArchivedVehicleGrid")
                {
                    var vehNscmodel = await GetArchivedLabourDetailsInEstimates(id, gridType);

                    return Json(vehNscmodel.ToDataSourceResult(request));
                }

                

                return StatusCode(500, "An error occurred while fetching data, in GetLabourDetailsInRBEstimates.");
            }
            catch (Exception ex)
            {
                // Log the error
                Console.WriteLine($"Error in GetLabourDetails: {ex.Message}");
                return StatusCode(500, "An error occurred while fetching data.");
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllRbLabourDetails([DataSourceRequest] DataSourceRequest request, [FromQuery] string id, [FromQuery] string gridType)
        {
            if (string.IsNullOrEmpty(id))
            {
                BadRequest("id is required for gridType :" + gridType);
            }
            ViewBag.PartNum = id;
            try
            {
                
                    var rbNscModel = await GetAllLabourDetails(id, gridType);
                    return Json(rbNscModel.ToDataSourceResult(request));               
                
            }
            catch (Exception ex)
            {
                // Log the error
                Console.WriteLine($"Error in GetAllLabourDetails: {ex.Message}");
                return StatusCode(500, "An error occurred while fetching data.");
            }
        }

        private async Task<IEnumerable<AllLabourDetailsModel>> GetAllLabourDetails(
            string linkCode,
            string gridType)
        {
            try
            {
                string linkType = ""; 
                if (gridType == "RebuiltGrid")
                {
                    linkType = "RB";

                }
                if (gridType == "VehicleGrid")
                {
                    linkType = "BUS";

                }
                if (gridType == "MakeVsBuyGrid")
                {
                    linkType = "MB";

                }
                var parameters = new DynamicParameters();
                parameters.Add("@viIdnum", linkCode);
                parameters.Add("@viType", linkType);
                parameters.Add("@VFinalPrice", 0);

                // Stored proc returns full TempLabourList result set
                var result = await _dbConnection.QueryAsync<AllLabourDetailsModel>(
                    "SBCES.GetLabourCost",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return result;
            }
            catch (Exception ex)
            {
                // Log exception if needed
                throw;
            }
        }

        //private async Task<IEnumerable<LabourDetailsRebuiltPartsViewModel>> GetLabourDetailsInRBEstimates(string partNum, string gridType)
        //{
        //    try
        //    {
        //        var query = @"
        //                    SELECT 
        //                        EL.Id,
        //                        EL.LinkNumber,
        //                        EL.LabourDefn,
        //                        EL.CostCentre,
        //                        EL.Task,
        //                        REPLACE(EL.Usage, ',', '.') AS [Usage],
        //                        EL.HrsReqd,
        //                        ES.RatePerHour,
        //                        EL.TimeAddition,
        //                        UPPER(CONVERT(VARCHAR, EL.DateRevised, 120)) AS [DateRevised],	
        //                     EL.LastModifiedBy
        //                    FROM 
        //                        SBCES.EmployeeLabour EL
        //                        JOIN SBCES.EmplClass EC ON EL.LabourDefn = UPPER(EC.LabourDefn)
        //                        JOIN SBCES.EmployeeSalaries ES ON EC.WageGroup = ES.WageGroup
        //                    WHERE 
        //                        EL.LinkNumber = @RebuiltPartNumber";

        //        var parameters = new { RebuiltPartNumber = partNum };

        //        var result = await _dbConnection.QueryAsync<LabourDetailsRebuiltPartsViewModel>(query, parameters);

        //        // Split HrsReqd into LabourHrs and LabourMins
        //        foreach (var item in result)
        //        {
        //            if (!string.IsNullOrEmpty(item.HrsReqd))
        //            {
        //                var parts = item.HrsReqd.Split(':');
        //                item.LabourHrs = int.Parse(parts[0]);
        //                item.LabourMins = int.Parse(parts[1]);
        //            }
        //        }

        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"Error in GetLabourDetailsData: {ex.Message}");
        //        throw; // Rethrow the exception for centralized handling
        //    }
        //}

        private async Task<IEnumerable<LabourDetailsRebuiltPartsViewModel>> GetArchivedLabourDetailsInEstimates(string partNum, string gridType)
        {
            try
            {
                var query = @"
                            SELECT [LabourDefn]
                          ,[DateEntered]
                          ,[LinkNumber]
                          ,[TypeId]
                          ,[Costcentre]
                          ,[Task]
                          ,[LabourType]
                          ,[Usage]
                          ,[HrsReqd]
                          ,[AdjHrs]
                          ,[TimeAddition]
                          ,[ArchVehicleListId]
                      FROM [CES].[SBCES].[ArchVehEmployeeLabour]
                        where ArchVehicleListId = @id" ;
                            

                var parameters = new { id = partNum };

                var result = await _dbConnection.QueryAsync<LabourDetailsRebuiltPartsViewModel>(query, parameters);

                // Split HrsReqd into LabourHrs and LabourMins
                foreach (var item in result)
                {
                    if (!string.IsNullOrEmpty(item.HrsReqd))
                    {
                        var parts = item.HrsReqd.Split(':');
                        item.LabourHrs = int.Parse(parts[0]);
                        item.LabourMins = int.Parse(parts[1]);
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourDetailsData: {ex.Message}");
                throw; // Rethrow the exception for centralized handling
            }
        }

        private async Task<IEnumerable<LabourDetailsRebuiltPartsViewModel>> GetLabourDetailsInVehicleEstimates(string partNum, string gridType)
        {
            try
            {
                var query = @"
                            SELECT 
                                EL.Id,
                                EL.LinkNumber,
                                EL.LabourDefn,
                                EL.CostCentre,
                                EL.Task,
                                REPLACE(EL.Usage, ',', '.') AS [Usage],
                                EL.HrsReqd,
                              --  ES.RatePerHour,
                                EL.TimeAddition,
                                UPPER(CONVERT(VARCHAR, EL.DateRevised, 120)) AS [DateRevised],	
	                            EL.LastModifiedBy
                            FROM 
                                SBCES.EmployeeLabour EL
                            --    JOIN SBCES.EmplClass EC ON EL.LabourDefn = UPPER(EC.LabourDefn)
                            --    JOIN SBCES.EmployeeSalaries ES ON EC.WageGroup = ES.WageGroup
                            WHERE 
                                EL.LinkNumber = @id";

                var parameters = new { id = partNum };

                var result = await _dbConnection.QueryAsync<LabourDetailsRebuiltPartsViewModel>(query, parameters);

                // Split HrsReqd into LabourHrs and LabourMins
                foreach (var item in result)
                {
                    if (!string.IsNullOrEmpty(item.HrsReqd))
                    {
                        var parts = item.HrsReqd.Split(':');
                        item.LabourHrs = int.Parse(parts[0]);
                        item.LabourMins = int.Parse(parts[1]);
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourDetailsData: {ex.Message}");
                throw; // Rethrow the exception for centralized handling
            }
        }

        private async Task<IEnumerable<LabourDetailsRebuiltPartsViewModel>> GetLabourDetailsInRBEstimates(string partNum, string gridType)
        {
            try
            {
                var linkCode = partNum?.ToUpper(); ;
                //if (gridType == "RebuiltGrid")
                //{
                //    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                //   "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId ='" + linkCode + "'");

                //}

                var query = @"
                            SELECT 
                                EL.Id,
                                EL.LinkNumber,
                                EL.LabourDefn,
                                EL.CostCentre,
                                EL.Task,
                                REPLACE(EL.Usage, ',', '.') AS [Usage],
                                EL.HrsReqd,
                                ES.RatePerHour,
                                EL.TimeAddition,
                                UPPER(CONVERT(VARCHAR, EL.DateRevised, 120)) AS [DateRevised],	
	                            EL.LastModifiedBy as LastModifiedBy
                            FROM 
                                SBCES.EmployeeLabour EL
                                JOIN SBCES.EmplClass EC ON EL.LabourDefn = UPPER(EC.LabourDefn)
                                JOIN SBCES.EmployeeSalaries ES ON EC.WageGroup = ES.WageGroup
                            WHERE 
                                EL.LinkNumber = '" + linkCode + "'";

                var parameters = new { RebuiltPartNumber = partNum };

                var result = await _dbConnection.QueryAsync<LabourDetailsRebuiltPartsViewModel>(query, parameters);

                // Split HrsReqd into LabourHrs and LabourMins
                foreach (var item in result)
                {
                    if (!string.IsNullOrEmpty(item.HrsReqd))
                    {
                        var parts = item.HrsReqd.Split(':');
                        item.LabourHrs = int.Parse(parts[0]);
                        item.LabourMins = int.Parse(parts[1]);
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourDetailsData: {ex.Message}");
                throw; // Rethrow the exception for centralized handling
            }
        }

        //GetLabourDetailsInMbEstimates
        private async Task<IEnumerable<LabourDetailsRebuiltPartsViewModel>> GetLabourDetailsInMbEstimates(string partNum, string gridType)
        {
            try
            {
                var query = @"
                            SELECT 
                                EL.Id,
                                EL.LinkNumber,
                                EL.LabourDefn,
                                EL.CostCentre,
                                EL.Task,
                                REPLACE(EL.Usage, ',', '.') AS [Usage],
                                EL.HrsReqd,
                                ES.RatePerHour,
                                EL.TimeAddition,
                                UPPER(CONVERT(VARCHAR, EL.DateRevised, 120)) AS [DateRevised],	
	                            EL.LastModifiedBy as LastModifiedBy
                            FROM 
                                SBCES.EmployeeLabour EL
                                JOIN SBCES.EmplClass EC ON EL.LabourDefn = UPPER(EC.LabourDefn)
                                JOIN SBCES.EmployeeSalaries ES ON EC.WageGroup = ES.WageGroup
                            WHERE 
                                EL.LinkNumber = @MbNumber";

                var parameters = new { MbNumber = partNum };

                var result = await _dbConnection.QueryAsync<LabourDetailsRebuiltPartsViewModel>(query, parameters);

                // Split HrsReqd into LabourHrs and LabourMins
                foreach (var item in result)
                {
                    if (!string.IsNullOrEmpty(item.HrsReqd))
                    {
                        var parts = item.HrsReqd.Split(':');
                        item.LabourHrs = int.Parse(parts[0]);
                        item.LabourMins = int.Parse(parts[1]);
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourDetailsData: {ex.Message}");
                throw; // Rethrow the exception for centralized handling
            }
        }
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateLabourDetail(
    [DataSourceRequest] DataSourceRequest request,
    LabourDetailsRebuiltPartsViewModel model,
    [FromQuery] string id, 
    [FromQuery] string gridType
            )
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage);
                return BadRequest(new { Errors = errors });
            }

            var linkCode = id?.ToUpper();

            if (gridType == "RebuiltGrid")
            {
                linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                   "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                   new { Id = id }
               );

            }


            string linkType = ""; // gridType == "RebuiltGrid" ? "RB" : "BUS";
            if (gridType == "RebuiltGrid")
            {
                linkType = "RB";

            }
            if (gridType == "VehicleGrid")
            {
                linkType = "BUS";

            }
            if (gridType == "MakeVsBuyGrid")
            {
                linkType = "MB";

            }
            //////////////////////

            //if (!ModelState.IsValid)
            //    return Json(models.ToDataSourceResult(request, ModelState));

            _dbConnection.Open();
                using (var transaction = _dbConnection.BeginTransaction())
                {
                    try
                    {
                    string hrsReqd = $"{model.LabourHrs}:{model.LabourMins}";

                    // foreach (var model in models)
                    {
                        // model.HrsReqd = $"{model.LabourHrs}:{model.LabourMins:D2}";

                        string query = @"
                        INSERT INTO SBCES.EMPLOYEELABOUR (
                            LABOURDEFN, DATEENTERED, LINKNUMBER, TYPEID, 
                            COSTCENTRE, TASK, LABOURTYPE, USAGE, HRSREQD, 
                            ADJHRS, DATEREVISED, TIMEADDITION, REBUILTPARTNUM, LASTMODIFIEDBY
                        ) VALUES (
                            @LabourDefn, @DateEntered, @LinkNumber, @TypeId,
                            @CostCentre, @Task, @LabourType, @Usage, @HrsReqd,
                            @AdjHrs, @DateRevised, @TimeAddition, @RebuiltPartNum, @LastModifiedBy
                        )";

                            var parameters = new
                            {
                                model.LabourDefn,
                                DateEntered = DateTime.Now,
                                LinkNumber = linkCode,
                                TypeId = linkType,
                                model.CostCentre,
                                model.Task,
                                model.LabourType,
                                model.Usage,
                                HrsReqd = hrsReqd, 
                                model.AdjHrs,
                                DateRevised = DateTime.Now,
                                model.TimeAddition,
                                RebuiltPartNum = linkCode,
                                LastModifiedBy = ViewBag.UserName
                            };
                          
                        await _dbConnection.ExecuteAsync(query, parameters, transaction);
                        transaction.Commit();
                        //pass id to model
                        var maxId = _dbConnection.QueryFirstOrDefault<int>(@"SELECT MAX(id) + 1 FROM SBCES.[EmployeeLabour]");
                        model.Id = maxId;
                    }
                    //update estimates
                    if (gridType == "VehicleGrid")
                    {
                        await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                    }
                    // return Json(models.ToDataSourceResult(request));
                    return Json(new[] { model }.ToDataSourceResult(request));
                }

                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Console.WriteLine($"Error in CreateLabourDetail: {ex.Message}");
                        ModelState.AddModelError("", "An error occurred while saving data.");

                    //return Json(models.ToDataSourceResult(request, ModelState));
                    return Json(new[] { model }.ToDataSourceResult(request, ModelState));
                }
                    finally { 
                      //  transaction.Commit(); 
                      //  _dbConnection.Close();
                    }
            }
        }


        [AcceptVerbs("Post")]
        public IActionResult UpdateLabourDetail(
            [DataSourceRequest] DataSourceRequest request,
            LabourDetailsRebuiltPartsViewModel model,
            [FromQuery] string id,
            [FromQuery] string gridType)
        {
            
            if (model != null)
            {
                try
                {
                  //  foreach (var model in labourDetails)
                    {
                        model.HrsReqd = $"{model.LabourHrs}:{model.LabourMins:D2}";
                        var enteredBy = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM";
                        var dateModified = DateTime.Now;

                        string query = @"
                    UPDATE SBCES.EMPLOYEELABOUR 
                    SET 
                        LABOURDEFN = @LabourDefn,
                        COSTCENTRE = @CostCentre,
                        TASK = @Task,
                        USAGE = @Usage,
                        HRSREQD = @HrsReqd,
                        LASTMODIFIEDBY = @LastModifiedBy,
                        [DateRevised] = @DateRevised,
                        REBUILTPARTNUM = @LinkNumber 
                    WHERE [LinkNumber] ='" + id + "' AND Id ='" + model.Id + "'" ;

                        var parameters = new
                        {
                            model.LabourDefn,
                            model.CostCentre,
                            model.Task,
                            model.Usage,
                            model.HrsReqd,
                            model.LinkNumber,
                            DateRevised = DateTime.Now,
                            LastModifiedBy = ViewBag.UserName,
                            // model.RebuiltPartNum,
                            model.Id
                        };

                        _dbConnection.Execute(query, parameters);
                        
                    }
                    if (gridType == "VehicleGrid")
                    {
                        //update estimates
                        VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                    }
                    return Json(new[] { model }.ToDataSourceResult(request));
                   // return Json(labourDetails.ToDataSourceResult(request));
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error in UpdateLabourDetail: {ex.Message}");
                    ModelState.AddModelError("", "An error occurred while updating data.");
                    //return Json(labourDetails.ToDataSourceResult(request, ModelState));
                    return Json(new[] { model }.ToDataSourceResult(request, ModelState));
                }
            }

            // return Json(labourDetails.ToDataSourceResult(request, ModelState));
            return Json(new[] { model }.ToDataSourceResult(request, ModelState));
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteLabourDetail(
                                    [DataSourceRequest] DataSourceRequest request,
                                                         RebuiltPartsViewModel model,
                                                         string id,
                                                         string partNum,
                                                          string gridType)
        {
            
            _dbConnection.Open();
            using (var transaction = _dbConnection.BeginTransaction())
            {
                try
                {
                    var linkCode = id.ToUpper();
                    if (gridType == "RebuiltGrid")
                    {
                        linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                                "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                                new { Id = id },
                                transaction
                            );


                    }

                    string query = @"
                    DELETE FROM SBCES.EmployeeLabour 
                    WHERE Id = " + partNum + " and LinkNumber = '" + linkCode + "'";

                       // var parameters = new { Id= model.Id };

                        int affectedRows = await _dbConnection.ExecuteAsync(query, null, transaction);

                        if (affectedRows == 0)
                        {
                            ModelState.AddModelError("", $"Record with ID {id} not found.");
                        }

                    transaction.Commit();

                    if (gridType == "VehicleGrid")
                    {
                        //update estimates
                        await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                    }
                    return Json(new[] { model }.ToDataSourceResult(request));
                   // return Json(models.ToDataSourceResult(request));
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    // Log the error (you can use ILogger if available)
                    Console.WriteLine($"Error in DeleteLabourDetails: {ex.Message}");

                    ModelState.AddModelError("", "An error occurred while deleting data.");
                    return Json(new[] { model }.ToDataSourceResult(request, ModelState));
                    //return Json(models.ToDataSourceResult(request, ModelState));
                }
            }
        }

    }
}
