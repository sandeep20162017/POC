﻿using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using BCES.Models.Parts;
using Microsoft.Extensions.Logging;
using BCES.Data;
using Microsoft.AspNetCore.Http;
using System;
using Kendo.Mvc.UI;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Parts
{
    public class ExportController : Controller
    {
        private readonly ILogger<ExportController> _logger;
        private readonly DapperContext _dapperContext;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ExportController(
            ILogger<ExportController> logger,
            DapperContext dapperContext,
            IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _dapperContext = dapperContext;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<MemoryStream> SaveToExcel([FromQuery] string rebuiltPartNum)
        {
            try
            {
                // Fetch data from existing controllers
              //  var mainGridData = await GetDataFromController<RebuiltPartsViewModel>("RebuiltParts", "GetRebuiltPartsView");
                var labourDetails = await GetDataFromController<LabourDetailsRebuiltPartsViewModel>("LabourDetails", "GetLabourDetails", new { rebuiltPartNum });
                var labourHourSummary = await GetDataFromController<LabourDetailsRebuiltPartsViewModel>("LabourHourSummary", "GetLabourHourSummaryInRbParts", new { rebuiltPartNum });
                var materialCostSummary = await GetDataFromController<MaterialCostSummaryInRbViewModel>("MaterialCostSummary", "GetMaterialCostSummaryInRbParts", new { rebuiltPartNum });
                var scParts = await GetDataFromController<StockCodedPartsViewModel>("ScPartsUsedInEstimates", "GetScPartsUsedInRbParts", new { rebuiltPartNum });
                var nscParts = await GetDataFromController<NscPartsUsedViewModel>("NscPartsUsedInEstimates", "GetNscPartsUsedInEstimates", new { rebuiltPartNum });
                var rbParts = await GetDataFromController<RebuiltPartsViewModel>("RbPartsUsedInEstimates", "GetRbPartsUsedInRbParts", new { rebuiltPartNum });
                var totalCost = await GetDataFromController<TotalCostInEstimates>("TotalCostsInEstimates", "GetTotalCostInRbParts", new { rebuiltPartNum });

                // Create Excel package
                using (var package = new ExcelPackage())
                {
                    // Add main grid data
                  //  var mainGridSheet = package.Workbook.Worksheets.Add("Main Grid");
                  //  mainGridSheet.Cells.LoadFromCollection(mainGridData, true);

                    // Add subgrid data
                    var labourDetailsSheet = package.Workbook.Worksheets.Add("Labour Details");
                    labourDetailsSheet.Cells.LoadFromCollection(labourDetails, true);

                    var labourHourSummarySheet = package.Workbook.Worksheets.Add("Labour Hour Summary");
                    labourHourSummarySheet.Cells.LoadFromCollection(labourHourSummary, true);

                    var materialCostSummarySheet = package.Workbook.Worksheets.Add("Material Cost Summary");
                    materialCostSummarySheet.Cells.LoadFromCollection(materialCostSummary, true);

                    var scPartsSheet = package.Workbook.Worksheets.Add("SC Parts");
                    scPartsSheet.Cells.LoadFromCollection(scParts, true);

                    var nscPartsSheet = package.Workbook.Worksheets.Add("NSC Parts");
                    nscPartsSheet.Cells.LoadFromCollection(nscParts, true);

                    var rbPartsSheet = package.Workbook.Worksheets.Add("RB Parts");
                    rbPartsSheet.Cells.LoadFromCollection(rbParts, true);

                    var totalCostSheet = package.Workbook.Worksheets.Add("Total Cost");
                    totalCostSheet.Cells.LoadFromCollection(totalCost, true);

                    // Save the Excel file to a memory stream
                    var memoryStream = new MemoryStream();
                    package.SaveAs(memoryStream);
                    memoryStream.Position = 0; // Reset the stream position to the beginning

                    return memoryStream;
                    // Return the file for download
                   // return File(memoryStream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"{rebuiltPartNum}_RebuiltParts_Estimate.xlsx");

                    
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while generating the Excel file.");
                return null;
            }
        }
        private async Task<IEnumerable<T>> GetDataFromController<T>(string controllerName, string actionName, object routeValues = null)
        {
            try
            {
                // Resolve the controller type
                var controllerType = Type.GetType($"BCES.Controllers.Parts.{controllerName}Controller");
                if (controllerType == null)
                {
                    throw new InvalidOperationException($"Controller {controllerName} not found.");
                }

                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext == null)
                {
                    throw new InvalidOperationException($"HttpContext is not available for {controllerName}.");
                }

                // Create an instance of the controller using dependency injection            
                 var controller = ActivatorUtilities.CreateInstance(_httpContextAccessor.HttpContext.RequestServices, controllerType);
               
                // Get the action method
                var methodInfo = controllerType.GetMethod(actionName);
                if (methodInfo == null)
                {
                    throw new InvalidOperationException($"Action {actionName} not found in controller {controllerName}.");
                }

                // Prepare parameters for the action method
                var parameters = methodInfo.GetParameters();
                var arguments = new object[parameters.Length];

                for (int i = 0; i < parameters.Length; i++)
                {
                    var parameter = parameters[i];

                    if (parameter.ParameterType == typeof(DataSourceRequest))
                    {
                        // Create a default DataSourceRequest for actions that require it
                        arguments[i] = new DataSourceRequest();
                    }
                    else if (routeValues != null && parameter.Name == "rebuiltPartNum")
                    {
                        // Pass the rebuiltPartNum parameter
                        arguments[i] = ((dynamic)routeValues).rebuiltPartNum;
                    }
                    else
                    {
                        // Pass null for other parameters (if applicable)
                        arguments[i] = null;
                    }
                }

                // Invoke the action method with the prepared arguments
                var result = methodInfo.Invoke(controller, arguments);

                // Handle the result based on its type
                if (result is Task taskResult)
                {
                    // Await the task to get the actual result
                    await taskResult;

                    // Use reflection to get the Result property of the Task
                    var resultProperty = taskResult.GetType().GetProperty("Result");
                    if (resultProperty != null)
                    {
                        var actionResult = resultProperty.GetValue(taskResult);

                        if (actionResult is JsonResult jsonResult)
                        {
                            // Check if the JsonResult.Value is a DataSourceResult
                            if (jsonResult.Value is DataSourceResult dataSourceResult)
                            {
                                // Return the Data property as IEnumerable<T>
                                return (IEnumerable<T>)dataSourceResult.Data;
                            }
                            else
                            {
                                throw new InvalidOperationException($"Action {actionName} returned an unexpected result type: {jsonResult.Value.GetType().Name}.");
                            }
                        }
                        else if (actionResult is IActionResult)
                        {
                            throw new InvalidOperationException($"Action {actionName} returned an unexpected result type: {actionResult.GetType().Name}.");
                        }
                    }
                }

                throw new InvalidOperationException($"Action {actionName} did not return a valid JSON result.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while fetching data from {controllerName}.{actionName}.");
                throw;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public IActionResult TestExcel()
        {
            using (var package = new ExcelPackage())
            {
                var sheet = package.Workbook.Worksheets.Add("Test Sheet");
                sheet.Cells["A1"].Value = "Hello";
                sheet.Cells["B1"].Value = "World";

                var memoryStream = new MemoryStream();
                package.SaveAs(memoryStream);
                memoryStream.Position = 0;

                return File(memoryStream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Test.xlsx");
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult TestExcel([FromQuery]string rebuiltPartNum)
        {
            try
            {
                using (var package = new ExcelPackage())
                {
                    var sheet = package.Workbook.Worksheets.Add("Test Sheet");
                    sheet.Cells["A1"].Value = "Hello";
                    sheet.Cells["B1"].Value = "World";

                    var memoryStream = new MemoryStream();
                    package.SaveAs(memoryStream);
                    memoryStream.Position = 0;

                    // Return the file for download
                    // return File(memoryStream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"{rebuiltPartNum}_Test.xlsx");
                    return (IActionResult)memoryStream;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while generating the Excel file.");
                return StatusCode(500, "An error occurred while generating the Excel file.");
            }
        }



    }
}



    


