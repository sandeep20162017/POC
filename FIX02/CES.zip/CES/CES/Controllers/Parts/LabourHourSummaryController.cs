﻿using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using BCES.Models.Parts;
using BCES.Controllers.Base;
using BCES.Data;
using System.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;


namespace BCES.Controllers.Parts
{
    public class LabourHourSummaryController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public LabourHourSummaryController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetLabourHourSummaryInEstimates(
           [DataSourceRequest] DataSourceRequest request,
           [FromQuery] string id,
           [FromQuery] string gridType)
        {
            if (string.IsNullOrEmpty(id))
            {
                return Json(new { success = false, message = "id is required in :" + gridType });
            }

            try
            {
                //var model = await GetLabourHourSummaryInRbPartsData(id, gridType);

                //if (model == null || !model.Any())
                //{
                //    return Json(new { success = false, message = "No data found." });
                //}

                //return Json(model.ToDataSourceResult(request));
                if (gridType == "RebuiltGrid")
                {
                    var rbNscModel = await GetLabourHourSummaryInRbEstimates(id, gridType);
                    return Json(rbNscModel.ToDataSourceResult(request));
                }
                if (gridType == "VehicleGrid")
                {
                    var vehNscmodel = await GetLabourHourSummaryInVehicleEstimates(id, gridType);

                    return Json(vehNscmodel.ToDataSourceResult(request));
                }
                if (gridType == "ArchivedVehicleGrid")
                {
                    var vehNscmodel = await GetArchivedLabourHourSummaryInVehicleEstimates(id, gridType);

                    return Json(vehNscmodel.ToDataSourceResult(request));
                }
                if (gridType == "MakeVsBuyGrid")
                {
                    var vehNscmodel = await GetLabourHourSummaryInMbEstimates(id, gridType);

                    return Json(vehNscmodel.ToDataSourceResult(request));
                    //return StatusCode(500, "An error occurred while fetching data. Implement this.");
                }
                if (gridType == "ArchivedMakeVsBuyGrid")
                {
                    return StatusCode(500, "An error occurred while fetching data. Implement this.");
                }
                if (gridType == "ArchivedRebuiltGrid")
                {
                    return StatusCode(500, "An error occurred while fetching data. Implement this.");
                }

                return StatusCode(500, "An error occurred while fetching data, in GetLabourDetailsInRBEstimates.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourHourSummaryInEstimates: {ex.Message}");
                return null;
            }
        }
        private async Task<IEnumerable<LabourDetailsRebuiltPartsViewModel>> GetArchivedLabourHourSummaryInVehicleEstimates(
          string id,
          string gridType)
        {
            try
            {
                var query = @"
                              SELECT [ArchVehicleListId]
                                  ,[CostCentre]
                                  ,[TotalHours] as CostCentreTotalHrs
                              FROM [CES].[SBCES].[ArchVehLabourCcTotal]
                              where ArchVehicleListId = @id";

                var parameters = new { id = id.Trim() };

                var result = await _dbConnection.QueryAsync<LabourDetailsRebuiltPartsViewModel>(query, parameters);

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourHourSummaryInEstimates: {ex.Message}");
                throw;
            }
        }

        [AllowAnonymous]
        private async Task<IEnumerable<LabourDetailsRebuiltPartsViewModel>> GetLabourHourSummaryInVehicleEstimates(
           string id,
           string gridType)
        {
            try
            {
                var query = @"
                            WITH SplitData AS (
                                SELECT
                                    CostCentre,
                                    -- Extract hours (left of colon) with error handling
                                    ISNULL(TRY_CAST(
                                        CASE 
                                            WHEN CHARINDEX(':', HrsReqd) > 0 
                                            THEN SUBSTRING(HrsReqd, 1, CHARINDEX(':', HrsReqd) - 1)
                                            ELSE '0' 
                                        END 
                                    AS INT), 0) AS hours,
                                    -- Extract minutes (right of colon) with error handling
                                    ISNULL(TRY_CAST(
                                        CASE 
                                            WHEN CHARINDEX(':', HrsReqd) > 0 
                                            THEN SUBSTRING(HrsReqd, CHARINDEX(':', HrsReqd) + 1, LEN(HrsReqd))
                                            ELSE '0' 
                                        END 
                                    AS INT), 0) AS minutes
                                FROM 
                                    SBCES.EmployeeLabour
                                WHERE
                                    LinkNumber = @id
                                    --AND TypeId = 'BUS'  
                            ),
                            AggregatedData AS (
                                SELECT
                                    CostCentre,
                                    SUM((hours * 60) + minutes) AS total_minutes
                                FROM 
                                    SplitData
                                GROUP BY 
                                    CostCentre
                            )
                            SELECT
                                CostCentre,
                                -- Handle hours > 99 by removing VARCHAR(2) truncation
                                CAST(total_minutes / 60 AS VARCHAR(10)) + ':' + 
                                RIGHT('0' + CAST(total_minutes % 60 AS VARCHAR(2)), 2) AS CostCentreTotalHrs
                            FROM 
                                AggregatedData;
                            ";

                var parameters = new { id = id.Trim() };

                var result = await _dbConnection.QueryAsync<LabourDetailsRebuiltPartsViewModel>(query, parameters);

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourHourSummaryInVehicleEstimates: {ex.Message}");
                throw;
            }
        }

        //GetLabourHourSummaryInMbEstimates
        private async Task<IEnumerable<LabourDetailsRebuiltPartsViewModel>> GetLabourHourSummaryInMbEstimates(
           string id,
           string gridType)
        {
            try
            {
                var query = @"
                            WITH SplitData AS (
                                SELECT
                                    CostCentre,
                                    -- Extract hours (left of colon) with error handling
                                    ISNULL(TRY_CAST(
                                        CASE 
                                            WHEN CHARINDEX(':', HrsReqd) > 0 
                                            THEN SUBSTRING(HrsReqd, 1, CHARINDEX(':', HrsReqd) - 1)
                                            ELSE '0' 
                                        END 
                                    AS INT), 0) AS hours,
                                    -- Extract minutes (right of colon) with error handling
                                    ISNULL(TRY_CAST(
                                        CASE 
                                            WHEN CHARINDEX(':', HrsReqd) > 0 
                                            THEN SUBSTRING(HrsReqd, CHARINDEX(':', HrsReqd) + 1, LEN(HrsReqd))
                                            ELSE '0' 
                                        END 
                                    AS INT), 0) AS minutes
                                FROM 
                                    SBCES.EmployeeLabour
                                WHERE
                                    LinkNumber = @id
                                   -- AND TypeId = 'MB'  
                            ),
                            AggregatedData AS (
                                SELECT
                                    CostCentre,
                                    SUM((hours * 60) + minutes) AS total_minutes
                                FROM 
                                    SplitData
                                GROUP BY 
                                    CostCentre
                            )
                            SELECT
                                CostCentre,
                                -- Handle hours > 99 by removing VARCHAR(2) truncation
                                CAST(total_minutes / 60 AS VARCHAR(10)) + ':' + 
                                RIGHT('0' + CAST(total_minutes % 60 AS VARCHAR(2)), 2) AS CostCentreTotalHrs
                            FROM 
                                AggregatedData;
                            ";

                var parameters = new { id = id.Trim() };

                var result = await _dbConnection.QueryAsync<LabourDetailsRebuiltPartsViewModel>(query, parameters);

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourHourSummaryInMbEstimates: {ex.Message}");
                throw;
            }
        }
        [AllowAnonymous]
        private async Task<IEnumerable<LabourDetailsRebuiltPartsViewModel>> GetLabourHourSummaryInRbEstimates(
            string id,
            string gridType)
        {
            try
            {
                var query = @"
                            WITH SplitData AS (
                                SELECT
                                    CostCentre,
                                    -- Extract hours (left of colon) with error handling
                                    ISNULL(TRY_CAST(
                                        CASE 
                                            WHEN CHARINDEX(':', HrsReqd) > 0 
                                            THEN SUBSTRING(HrsReqd, 1, CHARINDEX(':', HrsReqd) - 1)
                                            ELSE '0' 
                                        END 
                                    AS INT), 0) AS hours,
                                    -- Extract minutes (right of colon) with error handling
                                    ISNULL(TRY_CAST(
                                        CASE 
                                            WHEN CHARINDEX(':', HrsReqd) > 0 
                                            THEN SUBSTRING(HrsReqd, CHARINDEX(':', HrsReqd) + 1, LEN(HrsReqd))
                                            ELSE '0' 
                                        END 
                                    AS INT), 0) AS minutes
                                FROM 
                                    SBCES.EmployeeLabour
                                WHERE
                                    LinkNumber = @id
                                  --TODO check out  AND TypeId = 'RB'  
                            ),
                            AggregatedData AS (
                                SELECT
                                    CostCentre,
                                    SUM((hours * 60) + minutes) AS total_minutes
                                FROM 
                                    SplitData
                                GROUP BY 
                                    CostCentre
                            )
                            SELECT
                                CostCentre,
                                -- Handle hours > 99 by removing VARCHAR(2) truncation
                                CAST(total_minutes / 60 AS VARCHAR(10)) + ':' + 
                                RIGHT('0' + CAST(total_minutes % 60 AS VARCHAR(2)), 2) AS CostCentreTotalHrs
                            FROM 
                                AggregatedData;
                            ";

                var parameters = new { id = id.Trim() };

                var result = await _dbConnection.QueryAsync<LabourDetailsRebuiltPartsViewModel>(query, parameters);               

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourHourSummaryEstimate: {ex.Message}");
                throw;
            }
        }

        private async Task<decimal> GetNonProductiveAdjustment()
        {
            try
            {
                var query = @"SELECT [Value] FROM [CES].[SBCES].[CesSettings] WHERE [Parameter] = 'NON_PRODUCTIVE_ADJUSTMENT'";
                var value = await _dbConnection.ExecuteScalarAsync<string>(query);
                return decimal.TryParse(value, out var result) ? result : 0;
            }
            catch
            {
                return 0;
            }
        }

        private async Task<decimal> GetLabourRate(string labourDefn)
        {
            try
            {
                var wageGroupQuery = @"
                    SELECT [WageGroup] 
                    FROM [CES].[SBCES].[EmplClass] 
                    WHERE [LabourDefn] LIKE '%' + @LabourDefn + '%'";

                var wageGroup = await _dbConnection.ExecuteScalarAsync<string>(wageGroupQuery, new { LabourDefn = labourDefn });

                if (!string.IsNullOrEmpty(wageGroup))
                {
                    var rateQuery = @"
                        SELECT [RatePerHour] 
                        FROM [CES].[SBCES].[EmployeeSalaries] 
                        WHERE [WageGroup] = @WageGroup";

                    var rate = await _dbConnection.ExecuteScalarAsync<decimal?>(rateQuery, new { WageGroup = wageGroup });
                    return rate ?? 0;
                }

                return 0;
            }
            catch
            {
                return 0;
            }
        }

        private async Task<decimal> GetOverheadPercentage()
        {
            try
            {
                var query = @"SELECT [Value] FROM [CES].[SBCES].[CesSettings] WHERE [Parameter] = 'OVERHEAD'";
                var value = await _dbConnection.ExecuteScalarAsync<string>(query);
                return decimal.TryParse(value, out var result) ? result : 0;
            }
            catch
            {
                return 0;
            }
        }

    }
}
