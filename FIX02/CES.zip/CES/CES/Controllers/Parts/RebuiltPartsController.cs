﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Parts;
using BCES.Models.Common;
using BCES.Models.Parts;
using System.Data;
using OfficeOpenXml;
using System.IO;
using MailKit.Net.Smtp;
using MimeKit;
using MailKit.Security;



using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Azure.Core;
using BCES.Controllers.Admin;
using System.Net.Mail;
using Multipart = MimeKit.Multipart;
using SmtpClient = MailKit.Net.Smtp.SmtpClient;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Authorization;
using System.Text.Encodings.Web;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using System.Reflection;
using CommandType = System.Data.CommandType;
using BCES.Models.Vehicle;

//using System.Net.Mime;
//using CES.Views.Shared;
namespace BCES.Controllers.Parts
{
    // [Route("api/[controller]")]
    public class RebuiltPartsController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IServiceProvider _serviceProvider;
        private readonly BusesController _busesController;
        private readonly LabourDetailsController _labourDetailsController;
        private static List<string> _selectedBuses = new List<string>();


        public RebuiltPartsController(DapperContext dapper, IHttpContextAccessor httpContextAccessor,
                                      IServiceProvider serviceProvider, BusesController busesController,
                                      LabourDetailsController labourDetailsController
                                    ) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
            _serviceProvider = serviceProvider;
            _busesController = busesController;
            _labourDetailsController = labourDetailsController;
        }

        [HttpGet("RebuiltPartsIndex")]
        [AllowAnonymous]
        public IActionResult RebuiltPartsIndex()
        {
            // return View();
            //GetRebuiltPartsData();
            return View("~/Views/Parts/RebuiltParts/Index.cshtml");
        }

        [AllowAnonymous]
        public IActionResult ArchivedIndex()
        {
            // return View();
            return View("~/Views/Parts/RebuiltParts/ArchivedIndex.cshtml");
        }

        public ActionResult GetRbById( int rebuiltId, bool readOnly = true)
        {

            var rebuiltPart = rebuiltId == 0
                ? new RebuiltPartsViewModel() // Add mode
                : _dbConnection.QueryFirstOrDefault<RebuiltPartsViewModel>(@"
                SELECT rbm.RbMasterlistId as RebuiltId,
                                            rbm.[RebuiltStockNum],
                                            rbm.[MmsStockCode],
                                            rbm.[Keyword],
                                            rbm.JobNumber,
                                            rbm.[CorePartNum],
                                            rbm.[DetailedDesc] AS Description,
                                            rbm.[CoreCharge],
                                            rbm.[EstimatedCost],
                                            rbm.[BuyNewCost],
                                            rbm.[RemanCost],
                                            rbm.[ExternalCost],
                                            --rbl.listid,
                                            STRING_AGG(CAST(lb.listid AS VARCHAR), ',') AS BusId,
                                            STRING_AGG(lb.description, ',') AS BusName,
                                            rbm.DateEntered,
							                rbm.LastModifiedBy
                                            FROM 
                                                SBCES.RbMasterlist rbm
                                            LEFT JOIN 
                                                SBCES.RBLISTOFBUSES rbl ON rbm.RebuiltStockNum = rbl.RebuiltStockNum
                                            LEFT JOIN 
                                                SBCES.LISTOFBUSES lb ON rbl.listid = lb.listid
	                                            WHERE  --rbl.listid is not null and 
                                                 rbm.RbMasterlistId = @Id
	                                             GROUP BY
	                                             rbm.RbMasterlistId,
                                                rbm.[RebuiltStockNum],
                                                rbm.[MmsStockCode],
                                                rbm.[Keyword],
                                                rbm.JobNumber,
                                                rbm.[CorePartNum],
                                                rbm.[DetailedDesc],
                                                rbm.[CoreCharge],
                                                rbm.[EstimatedCost],
                                                rbm.[BuyNewCost],
                                                rbm.[RemanCost],
                                                rbm.[ExternalCost],
                                                rbm.DateEntered,
                                                rbm.LastModifiedBy
                                                --rbl.listid
                                                  order by rbm.RbMasterlistId desc
                ", new { Id = rebuiltId });

            if (rebuiltPart == null)
                return Content("Rb not found");

            ViewBag.ReadOnly = readOnly;
            ViewBag.ParentId = rebuiltId;  /*save parent id*/
            ViewBag.FormattedDate = rebuiltPart.LastModifiedDate;

            return PartialView("~/Views/Shared/_RbPopUp.cshtml", rebuiltPart);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetRebuiltPartsView([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid 
            var model = await GetRebuiltPartsData();
            return Json(model.ToDataSourceResult(request));
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult ScDetailsPartial( string id, string gridType)
        {
            ViewBag.ParentId = id;
            ViewBag.PartNum = id;
            
            ViewBag.GridType = gridType;


            var model = new List<BCES.Models.Parts.StockCodedPartsViewModel> { };

            return PartialView("_ScPartsUsed", model);

        }
        [AllowAnonymous]
        public IActionResult NonStockPartsPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParentId = id;
            ViewBag.GridType = gridType ?? "RebuiltGrid";
            return PartialView("_NscPartsUsed", new List<NscPartsUsedViewModel>());

        }

        [AllowAnonymous]
        public IActionResult RebuiltPartsPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParenId = id;
            ViewBag.GridType = gridType ?? "RebuiltGrid";
            return PartialView("_RbPartsUsed", new List<RebuiltPartsViewModel>());
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<JsonResult> GetArchivedRebuiltPartsView([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid (you can use Dapper or any other method)
            var model = await GetArchivedRebuiltPartsData();
            return Json(model.ToDataSourceResult(request));
        }
        //private async Task<IEnumerable<RebuiltPartsViewModel>> GetRebuiltPartsData()
        //{
        //    try
        //    {
        //        // Step 1: Query base data for rebuilt parts
        //        var rebuiltPartsQuery = @"
        //SELECT rbm.RbMasterlistId,
        //       rbm.[RebuiltStockNum],
        //       rbm.[MmsStockCode],
        //       rbm.[Keyword],
        //       rbm.JobNumber,
        //       rbm.[CorePartNum],
        //       rbm.[DetailedDesc],
        //       rbm.[CoreCharge],
        //       rbm.[EstimatedCost],
        //       rbm.[BuyNewCost],
        //       rbm.[RemanCost],
        //       rbm.[ExternalCost]
        //FROM [SBCES].[RbMasterlist] rbm";

        //        var rebuiltParts = (await _dbConnection.QueryAsync<RebuiltPartsViewModel>(rebuiltPartsQuery)).ToList();

        //        if (!rebuiltParts.Any())
        //        {
        //            return rebuiltParts;
        //        }

        //        // Step 2: Prepare parallel tasks for fetching data
        //        var tasks = rebuiltParts.Select(async part =>
        //        {
        //            // Fetch bus details in parallel
        //            var busDetails = await _busesController.GetBusDetails(part.RebuiltStockNum);
        //            part.VehicleSeries = busDetails.Select(bus => new BusesModel
        //            {
        //                ListId = bus.ListId,
        //                Description = bus.Description
        //            }).ToList();

        //            // Fetch labour details in parallel
        //            var labourDetails = await _labourDetailsController.GetLabourDetailsData(part.RebuiltStockNum);
        //            part.LabourDetailsRebuiltParts = labourDetails.ToList();

        //            return part;
        //        });

        //        // Step 3: Await all tasks concurrently
        //        var completedParts = await Task.WhenAll(tasks);

        //        return completedParts;
        //    }
        //    catch (Exception ex)
        //    {
        //        // Handle errors gracefully
        //        return null;
        //    }
        //}

        ////Good one below  but slow
        //private async Task<IEnumerable<RebuiltPartsViewModel>> GetRebuiltPartsData()
        //{
        //    try
        //    {
        //        var rebuiltPartsQuery = @"
        //                                 SELECT rbm.RbMasterlistId,
        //                                   rbm.[RebuiltStockNum],
        //                                   rbm.[MmsStockCode],
        //                                   rbm.[Keyword],
        //                                   rbm.JobNumber,
        //                                   rbm.[CorePartNum],
        //                                   rbm.[DetailedDesc],
        //                                   rbm.[CoreCharge],
        //                                   rbm.[EstimatedCost],
        //                                   rbm.[BuyNewCost],
        //                                   rbm.[RemanCost],
        //                                   rbm.[ExternalCost],
        //                                rbl.listid,
        //                                    lb.description
        //                                  FROM [SBCES].[RbMasterlist] rbm
        //                               join SBCES.RBLISTOFBUSES rbl on rbm.RebuiltStockNum = rbl.RebuiltStockNum  
        //                               join SBCES.LISTOFBUSES lb on rbl.listid = lb.listid

        //        ";
        //        // Base query for rebuilt parts data
        //        //var rebuiltPartsQuery = @"
        //        //                            SELECT rbm.RbMasterlistId,
        //        //                                   rbm.[RebuiltStockNum],
        //        //                                   rbm.[MmsStockCode],
        //        //                                   rbm.[Keyword],
        //        //                                   rbm.JobNumber,
        //        //                                   rbm.[CorePartNum],
        //        //                                   rbm.[DetailedDesc],
        //        //                                   rbm.[CoreCharge],
        //        //                                   rbm.[EstimatedCost],
        //        //                                   rbm.[BuyNewCost],
        //        //                                   rbm.[RemanCost],
        //        //                                   rbm.[ExternalCost]
        //        //                            FROM [SBCES].[RbMasterlist] rbm";

        //        var rebuiltParts = (await _dbConnection.QueryAsync<RebuiltPartsViewModel>(rebuiltPartsQuery)).ToList();

        //        //Following logic for archieving, its slow, enable MARS (connection string) on SQL server, or use LINQ
        //        //foreach (var part in rebuiltParts)
        //        //{
        //        //    // Call the BusesController method to get bus details
        //        //    var busDetails = await _busesController.GetBusDetails(part.RebuiltStockNum);
        //        //    part.VehicleSeries = busDetails.Select(bus => new BusesModel
        //        //    {
        //        //        ListId = bus.ListId,
        //        //        Description = bus.Description
        //        //    }).ToList();

        //        //    // Call the LabourDetailsController method to get labour details
        //        //    var labourDetails = await _labourDetailsController.GetLabourDetailsData(part.RebuiltStockNum);
        //        //    part.LabourDetailsRebuiltParts = labourDetails.ToList();
        //        //}

        //        return rebuiltParts;
        //    }
        //    catch (Exception ex)
        //    {
        //        // Handle errors gracefully
        //        return null;
        //    }
        //}


        
        [AllowAnonymous]       
        private async Task<IEnumerable<RebuiltPartsViewModel>> GetRebuiltPartsData() 
        {
            try
            {
                var rebuiltPartsQuery = @"
                                         
                                         
                                         SELECT rbm.RbMasterlistId as RebuiltId,
                                            rbm.[RebuiltStockNum],
                                            rbm.[MmsStockCode],
                                            rbm.[Keyword],
                                            rbm.JobNumber,
                                            rbm.[CorePartNum],
                                            rbm.[DetailedDesc] AS Description,
                                            rbm.[CoreCharge],
                                            rbm.[EstimatedCost],
                                            rbm.[BuyNewCost],
                                            rbm.[RemanCost],
                                            rbm.[ExternalCost],
                                            --rbl.listid,
                                            STRING_AGG(CAST(lb.listid AS VARCHAR), ',') AS BusId,
                                            STRING_AGG(lb.description, ',') AS BusName,
											rbm.DateEntered,
											rbm.LastModifiedBy

                                            FROM 
                                                SBCES.RbMasterlist rbm
                                            inner JOIN 
                                                SBCES.RBLISTOFBUSES rbl ON rbm.RebuiltStockNum = rbl.RebuiltStockNum
                                            inner JOIN 
                                                SBCES.LISTOFBUSES lb ON rbl.listid = lb.listid
	                                            WHERE  --rbl.listid is not null
												--and 
                                                rbm.BuyNewCost is not NULL
												and rbm.RemanCost is not NULL
												and rbm.BuyNewCost not like '%$%'
                                               -- and  rbm.RbMasterlistId =862
												--and rbm.BuyNewCost not like ' '
	                                             GROUP BY
	                                             rbm.RbMasterlistId,
                                                rbm.[RebuiltStockNum],
                                                rbm.[MmsStockCode],
                                                rbm.[Keyword],
                                                rbm.JobNumber,
                                                rbm.[CorePartNum],
                                                rbm.[DetailedDesc],
                                                rbm.[CoreCharge],
                                                rbm.[EstimatedCost],
                                                rbm.[BuyNewCost],
                                                rbm.[RemanCost],
                                                rbm.[ExternalCost],
												rbm.DateEntered,
												rbm.LastModifiedBy
												

                                                --rbl.listid
                                                ORDER BY  rbm.RbMasterlistId DESC
                                         
                                         
                                         ";
                

                var buses = _dbConnection.Query<RebuiltPartsViewModel>(rebuiltPartsQuery).ToList();

                // Parse SiteIdsString into SiteIds
                foreach (var bus in buses)
                {
                    bus.BusIds = string.IsNullOrEmpty(bus.BusId)
                        ? new List<int>()
                        : bus.BusId.Split(',').Select(int.Parse).ToList();

                    bus.BusNames = string.IsNullOrEmpty(bus.BusName)
                        ? new List<string>()
                        : bus.BusName.Split(',').ToList();

                    List<int> busIdList = bus.BusId.Split(',').Select(int.Parse).ToList();
                    List<string> busNameList = bus.BusName.Split(',').ToList();


                    var busModelList = busIdList.Zip(busNameList, (id, name) => new BusesModel
                    {
                        BusId = id,
                        BusName = name
                    }).ToList();
                    bus.Buses = busModelList;
                }

                return buses.Distinct().ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching rebuilt parts data: {ex.Message}");
                return Enumerable.Empty<RebuiltPartsViewModel>();
            }
        }

        // Function to update the Buses list based on selectedBusIds and selectedBusNames
        [AllowAnonymous]
        public static RebuiltPartsViewModel UpdateBusInModel(RebuiltPartsViewModel busView, List<string> selectedBusIds, List<string> selectedBusNames)
        {
            // Clear the existing Sites list to avoid duplicates
            // busView.Buses.Clear();
            // busView.BusNames.Clear();

            // Iterate through the selectedSiteIds and selectedSiteNames
            for (int i = 0; i < selectedBusIds.Count; i++)
            {
                try
                {
                    // Parse the SiteId from string to int
                    if (int.TryParse(selectedBusIds[i], out int busId))
                    {
                        // Create a new SiteModel instance
                        var bus = new BusesModel
                        {
                            BusId = busId,
                            BusName = selectedBusNames[i]
                        };

                        // Add the new SiteModel to the Sites list
                        busView.Buses.Add(bus);
                    }
                    else
                    {
                        // Handle the case where the SiteId cannot be parsed
                        throw new FormatException($"Invalid SiteId format: {selectedBusIds[i]}");
                    }
                }
                catch (Exception ex)
                {
                    // Log the exception or handle it as needed
                    Console.WriteLine($"Error updating bus: {ex.Message}");
                }
            }
                // Return the updated UserViewModel
                return busView;            
        }

        [HttpPost]
        [AllowAnonymous]
        //[Consumes("application/x-www-form-urlencoded")]
        public async Task<IActionResult> UpdateRebuiltPartsView([FromBody] RebuiltPartsViewModel partsViewModel)
        {
            partsViewModel.LastModifiedBy = ViewBag.UserName;
            partsViewModel.EnteredBy = ViewBag.UserName;
            partsViewModel.DateEntered = DateTime.Now;
            ModelState.Clear();
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values
                        .SelectMany(v => v.Errors)
                        .Select(e => e.ErrorMessage);
                    return BadRequest(new { Errors = errors });
                }

                if (partsViewModel != null) 
                {

                    partsViewModel.SelectedBuses = _selectedBuses;
                    // convert to it to pass to query
                    var busIds = _selectedBuses.Select(int.Parse).ToList();

                    //list of all the SiteNames for binding
                    string selectedBusNames = GetUserSelectedBusNames(busIds);
                    //update model for binding
                    partsViewModel.BusName = selectedBusNames;

                    //Update SiteModel
                    // Split the comma-separated strings into lists
                    var busIdsList = _selectedBuses;
                    var busNamesList = selectedBusNames.Split(',').ToList();
                    var updatedPartView = RebuiltPartsController.UpdateBusInModel(partsViewModel, busIdsList, busNamesList);

                    await UpdateRebuiltPartsAsync(partsViewModel);
                }

                // return RedirectToAction("Index");
                //return Json(new[] { partsViewModel }.ToDataSourceResult(request, ModelState));
                return Ok(new { RebuiltId = partsViewModel.RebuiltId, Success = true });


            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the rebuilt part.");
            }
        }

        [AllowAnonymous]
        private async Task UpdateRebuiltPartsAsync(RebuiltPartsViewModel rebuiltPartsViewModel)
        {
            rebuiltPartsViewModel.LastModifiedBy = ViewBag.UserName;
            rebuiltPartsViewModel.EnteredBy = ViewBag.UserName;
            rebuiltPartsViewModel.DateEntered = DateTime.Now;   // FIX: use DateTime, not string

            _dbConnection.Open();

            using (var transaction = _dbConnection.BeginTransaction())
            {
                try
                {
                    // -----------------------------
                    // UPDATE MAIN TABLE
                    // -----------------------------
                    var updateSql = @"
                UPDATE SBCES.RbMasterlist
                SET 
                    MmsStockCode     = @MmsStockCode,
                    RebuiltStockNum  = @RebuiltStockNum,
                    DetailedDesc     = @Description,
                    Keyword          = @Keyword, 
                    JobNumber        = @JobNumber,
                    CoreCharge       = @CoreCharge,
                    CorePartNum      = @CorePartNum,
                    BuyNewCost       = @BuyNewCost,
                    RemanCost        = @RemanCost,
                    LastModifiedBy   = @LastModifiedBy,
                    DateEntered      = @DateEntered
                WHERE RbMasterlistId = @RebuiltId;
            ";

                    await _dbConnection.ExecuteAsync(updateSql, new
                    {
                        rebuiltPartsViewModel.MmsStockCode,
                        rebuiltPartsViewModel.RebuiltStockNum,
                        rebuiltPartsViewModel.Description,
                        rebuiltPartsViewModel.KeyWord,
                        rebuiltPartsViewModel.JobNumber,
                        rebuiltPartsViewModel.CoreCharge,
                        rebuiltPartsViewModel.CorePartNum,
                        rebuiltPartsViewModel.BuyNewCost,
                        rebuiltPartsViewModel.RemanCost,
                        rebuiltPartsViewModel.LastModifiedBy,
                        rebuiltPartsViewModel.DateEntered,
                        rebuiltPartsViewModel.RebuiltId
                    }, transaction);   // transaction passed


                    // -----------------------------
                    // UPDATE BUS LIST
                    // -----------------------------
                    if (_selectedBuses.Count > 0)
                    {
                        // DELETE old buses
                        var deleteSql = @"
                    DELETE FROM SBCES.RBLISTOFBUSES
                    WHERE RebuiltStockNum = @RebuiltStockNum;
                ";

                        await _dbConnection.ExecuteAsync(deleteSql,
                            new { rebuiltPartsViewModel.RebuiltStockNum },
                            transaction);   // FIX: transaction passed


                        // INSERT new buses
                        var insertSql = @"
                    INSERT INTO SBCES.RBLISTOFBUSES (RebuiltStockNum, listid)
                    VALUES (@RebuiltStockNum, @BusId);
                ";

                        foreach (var bus in rebuiltPartsViewModel.Buses)
                        {
                            await _dbConnection.ExecuteAsync(insertSql, new
                            {
                                RebuiltStockNum = rebuiltPartsViewModel.RebuiltStockNum,
                                BusId = bus.BusId
                            }, transaction);   // transaction passed
                        }
                    }

                    // COMMIT
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    Console.WriteLine($"Error updating rebuilt parts data: {ex.Message}");
                    throw;
                }
            }
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteRebuiltPart(string RebuiltId)
        {
            
            try
            {
                if (string.IsNullOrEmpty(RebuiltId))
                {
                    return BadRequest("Invalid data.");
                }

                var deletePartSql = "DELETE FROM SBCES.RbMasterlist WHERE RbMasterlistId = '" + RebuiltId + "'";
                //  var deleteBusesSql = "DELETE FROM SBCES.RBLISTOFBUSES WHERE RebuiltStockNum = '" + RebuiltStockNum + "'";

                //  await _dbConnection.ExecuteAsync(deleteBusesSql, new { RebuiltStockNum });
                int affectedRows = await _dbConnection.ExecuteAsync(deletePartSql, new { RebuiltId });

                return Json(new { success = affectedRows > 0 });
                //return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Unable to delete, part is used in archived estimates.");
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ReadBuses([DataSourceRequest] DataSourceRequest request)
        {
            var buses = await GetVehicleSeries();
            return Json(buses);
        }

        [AllowAnonymous]
        private async Task<IEnumerable<BusesModel>> GetVehicleSeries() //multiselect
        {
            try 
            { 
                var query = @"
                         SELECT distinct [ListId] as BusId
                          ,[Description] as BusName
                          FROM [CES].[SBCES].[ListOfBuses]";
                var buses = await _dbConnection.QueryAsync<BusesModel>(query);
                return buses.ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [AllowAnonymous]
        private string GetUserSelectedBusNames(List<int> selectedBusIds)
        {
            // Ensure the list of selected site IDs is not empty
            if (selectedBusIds == null || !selectedBusIds.Any())
            {
                return string.Empty;
            }

            try
            {
                // Create the SQL query with placeholders for the site IDs
                var query = "SELECT   Description FROM [SBCES].[ListOfBuses] WHERE ListId IN @SelectedBusIds";

                // Execute the query using Dapper
                var busNames = _dbConnection.Query<string>(query, new { SelectedBusIds = selectedBusIds });

                // Concatenate the site names into a single string
                return string.Join(", ", busNames);
            }
            catch (Exception ex)
            {
                // Log the exception 
                Console.WriteLine($"An error occurred: {ex.Message}");

                // Rethrow the exception or return a default value
                throw; // or return string.Empty;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> GetSelectedBuses([FromBody] dynamic data)
        {
            var buses = data?.buses?.ToObject<List<string>>() ?? Enumerable.Empty<string>();
            _selectedBuses = buses;
            var viewModel = new RebuiltPartsViewModel { SelectedBuses = buses };
            return Json(viewModel);
        }

        [AllowAnonymous]
        private async Task<IEnumerable<RebuiltPartsViewModel>> GetArchivedRebuiltPartsData()
        {
            try
            {
                // Base query for rebuilt parts data
                var rebuiltPartsQuery = @"
                                          SELECT
                                               rbm.ArchRbMasterlistId,
                                               rbm.[RebuiltStockNum],
                                               rbm.[MmsStockCode],
                                               rbm.[Keyword],
                                               rbm.JobNumber,
                                               rbm.[CorePartNum],
                                               rbm.[DetailedDesc],
                                               rbm.[CoreCharge],
                                               rbm.[EstimatedCost],
	                                           rbm.[MaterialsTotal],
	                                           rbm.[LabourTotal],
		                                        rbm.[MaterialsTotal],
		                                        rbm.[TotalRebuiltPartCost],
		                                        rbm.[TotalCostTax],      
	                                           rbm.[EnteredBy],
                                              rbm.[DateEntered] 
                                        FROM [SBCES].[ArchRbMasterlist] rbm
                                            ";

                var rebuiltParts = (await _dbConnection.QueryAsync<RebuiltPartsViewModel>(rebuiltPartsQuery)).ToList();

                //Following logic for archieving, its slow, enable MARS (connection string) on SQL server, or use LINQ
                //foreach (var part in rebuiltParts)
                //{
                //    // Call the BusesController method to get bus details
                //    var busDetails = await _busesController.GetBusDetails(part.RebuiltStockNum);
                //    part.VehicleSeries = busDetails.Select(bus => new BusesModel
                //    {
                //        ListId = bus.ListId,
                //        Description = bus.Description
                //    }).ToList();

                //    // Call the LabourDetailsController method to get labour details
                //    var labourDetails = await _labourDetailsController.GetLabourDetailsData(part.RebuiltStockNum);
                //    part.LabourDetailsRebuiltParts = labourDetails.ToList();
                //}

                return rebuiltParts;
            }
            catch (Exception ex)
            {
                // Handle errors gracefully
                return null;
            }
        }

        //private async Task<IEnumerable<RebuiltPartsViewModel>> GetRebuiltPartsData()
        //{
        //    try
        //    {
        //        var query = @"
        //                    SELECT rbm.RbMasterlistId,
        //                    rbm.[RebuiltStockNum],
        //                    rbm.[MmsStockCode],
        //                    rbm.[Keyword],
        //                    rbm.JobNumber,
        //                    rbm.[CorePartNum],
        //                    rbm.[DetailedDesc],
        //                    rbm.[CoreCharge],
        //                    rbm.[EstimatedCost],
        //                    rbm.[BuyNewCost],
        //                    rbm.[RemanCost],
        //                    rbm.[ExternalCost],
        //                    lb.ListId,
        //                    lb.Description AS Description,
        //                    EL.LINKNUMBER,
        //              EL.LabourDefn AS [LabourType],
        //                     EL.LabourDefn AS [LabourType],
        //                    EL.CostCentre AS [CC],
        //                    EL.Task AS [Task],
        //                    REPLACE(EL.Usage, ',', '.') AS [Usage],
        //                    EL.HrsReqd AS [Time],
        //                    ES.RatePerHour AS [RATE PER HOUR],
        //                    EL.TimeAddition AS [TIME ADDITION]

        //                        FROM [SBCES].[RbMasterlist] rbm
        //                        INNER JOIN [SBCES].[RbListOfBuses] rlb ON rlb.[RebuiltStockNum] = rbm.[RebuiltStockNum]
        //                        INNER JOIN [SBCES].[ListOfBuses] lb ON rlb.ListId = lb.ListId
        //                        left join [SBCES].[EmployeeLabour] el ON el.[LinkNumber] = rbm.[RebuiltStockNum]
        //                        JOIN SBCES.EmplClass EC ON EL.LabourDefn = UPPER(EC.LabourDefn)
        //                        JOIN SBCES.EmployeeSalaries ES ON EC.WageGroup = ES.WageGroup
        //                        ";

        //        var rbParts = _dbConnection.Query<RebuiltPartsViewModel, ListOfBusesModel, LabourDetailsRebuiltPartsViewModel, RebuiltPartsViewModel>(
        //            query,
        //            (rbPart, vehicle, labourDetail) =>
        //            {
        //                rbPart.VehicleSeries.Add(vehicle);
        //                if (labourDetail != null)
        //                {
        //                    rbPart.LabourDetailsRebuiltParts.Add(labourDetail);
        //                }
        //                return rbPart;
        //            },
        //            splitOn: "ListId,LinkNumber"
        //        ).GroupBy(rbPart => rbPart.RbMasterlistId).Select(g =>
        //        {
        //            var groupedRbPart = g.First();
        //            groupedRbPart.VehicleSeries = g.SelectMany(rbPart => rbPart.VehicleSeries).Distinct().ToList();
        //            groupedRbPart.LabourDetailsRebuiltParts = g.SelectMany(rbPart => rbPart.LabourDetailsRebuiltParts).Distinct().ToList();
        //            return groupedRbPart;
        //        }).ToList();

        //        return rbParts;
        //    }
        //    catch (Exception ex)
        //    {
        //        return null;
        //    }
        //}


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> AddRebuiltPartsView([DataSourceRequest] DataSourceRequest request,[FromBody] RebuiltPartsViewModel rebuiltPartsViewModel)
        {
            try
            {               
                var buses = _selectedBuses;
                rebuiltPartsViewModel.SelectedBuses = _selectedBuses;
                rebuiltPartsViewModel.LastModifiedBy = ViewBag.UserName;
                rebuiltPartsViewModel.EnteredBy = ViewBag.UserName;
                rebuiltPartsViewModel.DateEntered = DateTime.Now;
                rebuiltPartsViewModel.LastModifiedDate = DateTime.Now.ToString();
                //names for display
                string selectedBusIds = string.Join(",", _selectedBuses);
                //update model
                rebuiltPartsViewModel.BusId = selectedBusIds;

                //convert to it to pass to query
                var busIds = buses.Select(int.Parse).ToList();
                //list of all the SiteNames for binding
                string selectedBusNames = GetUserSelectedBusNames(busIds);
                //update model for binding
                rebuiltPartsViewModel.BusName = selectedBusNames;

                //site related
                // Split the comma-separated strings into lists
                var busIdsList = _selectedBuses;
                var busNamesList = selectedBusNames.Split(',').ToList();
                var updatedRebuiltPartsView = RebuiltPartsController.UpdateBusInModel(rebuiltPartsViewModel, busIdsList, busNamesList);


                var newId = await AddRebuiltPartAsync(rebuiltPartsViewModel);
                rebuiltPartsViewModel.RebuiltId = newId;
                // ModelState.Clear();
                //return Json(new[] { rebuiltPartsViewModel }.ToDataSourceResult(request, ModelState));
                //return Json(new { RebuiltId = newId });
                // IMPORTANT: Reload full DB record
                // return GetRbById(newId, true);

                return Json(new { RebuiltId = newId });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while adding the Rebuilt Part.");
            }
        }

  
        private async Task<int> AddRebuiltPartAsync([FromBody] RebuiltPartsViewModel rebuiltPartsViewModel)
        {
            var userName = ViewBag.UserName;
            
            _dbConnection.Open();
            using (var transaction =  _dbConnection.BeginTransaction())
            {
                try
                {
                    // Insert into the main RbMasterlist table
                    var insertRbMasterlistQuery = @"
                        INSERT INTO SBCES.RbMasterlist (
                            RebuiltStockNum,
                            MmsStockCode,
                            DetailedDesc,
                            Keyword,
                            JobNumber,
                            CoreCharge,
                            CorePartNum,
                            BuyNewCost,
                            RemanCost,
                            LastModifiedBy,
                            DateEntered
                        )
                        VALUES (
                            @RebuiltStockNum,
                            @MmsStockCode,
                            @DetailedDesc,
                            @Keyword,
                            @JobNumber,
                            @CoreCharge,
                            @CorePartNum,
                            @BuyNewCost,
                            @RemanCost,
                            @LastModifiedBy,
                            @DateEntered
                        );

                        SELECT CAST(SCOPE_IDENTITY() AS INT);
                    ";
                    var rbMasterlistId = await _dbConnection.QuerySingleAsync<int>(
            insertRbMasterlistQuery,
            new
            {
                RebuiltStockNum = rebuiltPartsViewModel.RebuiltStockNum,
                MmsStockCode = rebuiltPartsViewModel.MmsStockCode,
                DetailedDesc = rebuiltPartsViewModel.Description,   
                Keyword = rebuiltPartsViewModel.KeyWord,           
                JobNumber = rebuiltPartsViewModel.JobNumber,
                CoreCharge = rebuiltPartsViewModel.CoreCharge,
                CorePartNum = rebuiltPartsViewModel.CorePartNum,
                BuyNewCost = rebuiltPartsViewModel.BuyNewCost,
                RemanCost = rebuiltPartsViewModel.RemanCost,
                LastModifiedBy = ViewBag.UserName,                         
                DateEntered = DateTime.Now
            },
            transaction
        );

                    // Insert bus associations
                    var insertBusesQuery = @"
                                            INSERT INTO SBCES.RBLISTOFBUSES (RebuiltStockNum, listid)
                                            VALUES (@RebuiltStockNum,@BusId)";

                    var tt=0;
                    foreach (var bus in rebuiltPartsViewModel.Buses)
                    {
                        await _dbConnection.ExecuteAsync(insertBusesQuery, new
                        {
                            rebuiltPartsViewModel.RebuiltStockNum,
                            BusId = bus.BusId
                        }, transaction);
                    }

                    // Commit the transaction
                     transaction.Commit();

                    return rbMasterlistId;
                }
                catch (Exception ex)
                {
                    // Rollback the transaction in case of an error
                    transaction.Rollback();
                    Console.WriteLine($"Error creating rebuilt parts data: {ex.Message}");
                    throw; // Re-throw the exception to propagate it
                }
            }

        }

        //[HttpPost]
        //public async Task<IActionResult> UpdateRebuiltPartsView([DataSourceRequest] DataSourceRequest request, RebuiltPartsViewModel rebuiltPartsViewModel)
        //{
        //    try
        //    {
        //        // var userId = await UpdateRebuiltPartsView(rebuiltPartsViewModel);
        //        // return RedirectToAction("Index");
        //        return Ok();
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, "An error occurred while adding Rebuilt Part.");
        //    }
        //}

        [AllowAnonymous]
        public IActionResult LabourDetailsPartial([FromQuery] string id)
        {
            // Pass the rebuiltPartNum to the partial view
            ViewBag.PartNum = id;
            ViewBag.GridType = "RebuiltGrid";
            var model = new List<LabourDetailsRebuiltPartsViewModel> { };
            return PartialView("_LabourDetails", model);
        }
        [AllowAnonymous]
        public IActionResult ScPartsUsedInEstimates([FromQuery] string id)
        {
            // Pass the rebuiltPartNum to the partial view
            ViewBag.PartNum = id;
            ViewBag.GridType = "RebuiltGrid";
            var model = new List<BCES.Models.Parts.StockCodedPartsViewModel> { };

            return PartialView("_ScPartsUsed", model);

        }

        [AllowAnonymous]
        public IActionResult LabourHourSummaryPartial([FromQuery] string id)
        {
            
            ViewBag.PartNum = id;
            ViewBag.GridType = "RebuiltGrid";
            var model = new List<BCES.Models.Parts.LabourDetailsRebuiltPartsViewModel> { };
            return PartialView("_LabourHourSummary", model);
        }

        [AllowAnonymous]
        public IActionResult MaterialCostSummaryPartial([FromQuery] string id)
        {
            
            ViewBag.PartNum = id;
            ViewBag.GridType = "RebuiltGrid";
            var model = new List<BCES.Models.Parts.MaterialCostSummaryInRbViewModel> { };
            return PartialView("_MaterialCostSummary", model);
        }
        [AllowAnonymous]
        public IActionResult NscDetailsPartial([FromQuery] string id)
        {
            
            ViewBag.PartNum = id;
            ViewBag.GridType = "RebuiltGrid";
            var model = new List<BCES.Models.Parts.NscPartsUsedViewModel> { };

            return PartialView("_NscPartsUsed", model);

        }
        [AllowAnonymous]
        public IActionResult RbDetailsPartial([FromQuery] string id)
        {
            // Pass the rebuiltPartNum to the partial view
            ViewBag.PartNum = id;
            ViewBag.GridType = "RebuiltGrid";
            var model = new List<BCES.Models.Parts.RebuiltPartsViewModel> { };

           
            return PartialView("_RbPartsUsed", model);
        }

        [AllowAnonymous]
        public IActionResult TotalCostPartial([FromQuery] string id)
        {
            // Pass the rebuiltPartNum to the partial view
            ViewBag.PartNum = id;
            ViewBag.GridType = "RebuiltGrid";
            var model = new List<BCES.Models.Parts.TotalCostInEstimates> { };
            return PartialView("_TotalCost", model);
           // return PartialView("_RebuiltPartTotalCost", model);
        }

        [HttpPost]
        [AllowAnonymous]
        public IActionResult SaveDetails()
        {
            // Save logic here
            return Json(new { success = true, message = "Saved Details successfully." });
        }


        [HttpPost]
        [AllowAnonymous]
        public IActionResult CancelDetails(int rebuiltPartNum)
        {
            try
            {
                // Return a success response
                return Json(new { success = true, message = "Changes discarded successfully." });
            }
            catch (Exception ex)
            {

                return Json(new { success = false, message = "An error occurred while discarding changes. Please try again." });
            }
        }
                

        [HttpPost]
        [AllowAnonymous]
        
        public async Task<IActionResult> ArchiveRBDetails([FromBody] RebuiltPartsViewModel rebuiltPartsViewModel)
        {
            try
            {
                var parameters = new
                {
                    RebuiltPartNum = rebuiltPartsViewModel.RebuiltStockNum,
                    LinkNumber = rebuiltPartsViewModel.RebuiltStockNum, 
                    TypeId = "RB", // Default value from stored proc
                    Username = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM" 
                };

                await _dbConnection.ExecuteAsync(
                    "[SBCES].[ArchiveRBEstimate]",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Json(new
                {
                    success = true,
                    message = $"Archived rebuilt part number: {rebuiltPartsViewModel.RebuiltStockNum}",
                    rebuiltPartsViewModel.RebuiltStockNum
                });
            }
            catch (Exception ex)
            {
                //log exception 
                return Json(new
                {
                    success = false,
                    message = $"Archive failed: {ex.Message}"
                });
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> SendEmail(string to, string subject, string body, string rebuiltPartNum)
        {
            try
            {
                // Resolve the ExportController from the service provider
                var exportController = _serviceProvider.GetRequiredService<ExportController>();

                // Generate the Excel file in memory by calling SaveToExcel
                var memoryStream = await exportController.SaveToExcel(rebuiltPartNum);


                // Send the email with the attached Excel file
                var message = new MimeMessage();
                message.From.Add(new MailboxAddress("Sandeep Kanao", "sandeep.kanao@ttc.ca"));
                message.To.Add(new MailboxAddress("Sandeep.Kanao@ttc.ca", to));
                message.Subject = subject;
                message.Body = new TextPart("plain") { Text = body };

                var attachment = new MimePart("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                {
                    Content = new MimeContent((Stream)memoryStream),
                    ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                    ContentTransferEncoding = ContentEncoding.Base64,
                    FileName = $"{rebuiltPartNum}_RebuiltParts_Estimate.xlsx"
                };

                var multipart = new Multipart("mixed");
                multipart.Add(message.Body);
                multipart.Add(attachment);
                message.Body = multipart;

                using (var client = new SmtpClient())
                {
                    await client.ConnectAsync("smtp.freesmtpservers.com", 25, SecureSocketOptions.StartTls);
                   // await client.AuthenticateAsync("sandeep.kanao@gmail.com", "Perf4you@");
                    await client.SendAsync(message);
                    await client.DisconnectAsync(true);
                }

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Log the exception 
                Console.WriteLine($"Error sending email: {ex.Message}");

                return Json(new { success = false, message = ex.Message });
            }
        }

        [AllowAnonymous]
        public IActionResult DownloadExcel(string filePath)
        {
            var fileBytes = System.IO.File.ReadAllBytes(filePath);
            return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", Path.GetFileName(filePath));
        }

        [AllowAnonymous]
        public IActionResult AllLabourInRBPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParentId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_AllLabour", new List<LabourDetailsRebuiltPartsViewModel>());
        }

        [HttpPost]
        [AllowAnonymous]
        public IActionResult CopyEstimate(
        [FromBody] CopyEstimateRequest request) // Create this DTO class
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@RebuiltId", request.rebuiltId, DbType.Int32);
                parameters.Add("@BusSeriesCode", request.newMmsBuyCode, DbType.String);
                parameters.Add("@ProjDesc", request.newKeyWord, DbType.String);
                parameters.Add("@EnteredBy", ViewBag.UserName, DbType.String);
                parameters.Add("@EstimateType", "RB", DbType.String);
                parameters.Add("@NewRebuiltId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                _dbConnection.Execute("SBCES.CopyEstimate", parameters, commandType: CommandType.StoredProcedure);

                int newVehicleListId = parameters.Get<int>("@NewRebuiltId");
                return Json(new { success = true, newVehicleListId });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public class CopyEstimateRequest
        {
            public int rebuiltId { get; set; }
            public string oldMmsBuyCode { get; set; }
            public string newMmsBuyCode { get; set; }
            public string oldKeyWord { get; set; }
            public string newKeyWord { get; set; }
        }

        

    }
}