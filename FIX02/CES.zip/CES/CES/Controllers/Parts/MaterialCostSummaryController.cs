﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using BCES.Models.Parts;
using BCES.Controllers.Base;
using BCES.Data;
using System.Data;
using Dapper;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Parts
{
    public class MaterialCostSummaryController : BaseController
    {
        
            private readonly DapperContext _db;
            private readonly IDbConnection _dbConnection;
            private readonly IHttpContextAccessor _httpContextAccessor;


            public MaterialCostSummaryController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
            {
                _db = dapper;
                _dbConnection = _db.CreateConnection();

                _httpContextAccessor = httpContextAccessor;
            }

   
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetMaterialCostSummaryInEstimates([DataSourceRequest] DataSourceRequest request, [FromQuery] string id, [FromQuery] string gridType)
        {
            // Fetch data for the grid

            if (string.IsNullOrEmpty(id))
            {
                BadRequest("id is required for gridType :" + gridType);
            }

            //// Fetch data for the grid using the rebuiltPartNum
            //var model = await GetMaterialCostSummaryInRbPartsData(rebuiltPartNum, gridType);
            //return Json(model.ToDataSourceResult(request));
            if (gridType == "RebuiltGrid")
            {
                var rbNscModel = await GetMaterialCostSummaryInRbEstimates(id, gridType);
                return Json(rbNscModel.ToDataSourceResult(request));
            }
            if (gridType == "VehicleGrid")
            {
                var vehNscmodel = await GetMaterialCostSummaryInVehicleEstimates(id, gridType);

                return Json(vehNscmodel.ToDataSourceResult(request));
            }
            if (gridType == "ArchivedVehicleGrid")
            {
                var vehNscmodel = await GetArchivedMaterialCostSummaryInVehicleEstimates(id, gridType);

                return Json(vehNscmodel.ToDataSourceResult(request));
            }
            if (gridType == "MakeVsBuyGrid")
            {
                var vehNscmodel = await GetMaterialCostSummaryInMbEstimates(id, gridType);

                return Json(vehNscmodel.ToDataSourceResult(request));
                //return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            if (gridType == "ArchivedMakeVsBuyGrid")
            {
                return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            if (gridType == "ArchivedRebuiltGrid")
            {
                return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            return StatusCode(500, "An error occurred while fetching data, in GetLabourDetailsInRBEstimates.");
        }
        private async Task<IEnumerable<MaterialCostSummaryInRbViewModel>> GetArchivedMaterialCostSummaryInVehicleEstimates(string id, string gridType)
        {
            try
            {
                var query = @"
                              SELECT  [CostCentre]
                                  ,[TotalCost]
                                  ,[ArchVehicleListId]
                              FROM [CES].[SBCES].[ArchVehMaterialsCcTotal]
                              where ArchVehicleListId = @id";

                var parameters = new { id = id.Trim() };

                var result = await _dbConnection.QueryAsync<MaterialCostSummaryInRbViewModel>(query, parameters);

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourHourSummaryInEstimates: {ex.Message}");
                throw;
            }
        }

        [AllowAnonymous]
        private async Task<IEnumerable<MaterialCostSummaryInRbViewModel>> GetMaterialCostSummaryInVehicleEstimates(string id, string gridType)
        {
            //TODO use GridType
            try
            {
                var query = @"
                             DECLARE @LinkCode VARCHAR(30) = '" + id + "'" +
                             " ,@TaxRateRaw VARCHAR(20);" +

                             @"
                          --  DECLARE @LinkCode VARCHAR(30) = '4488' ,@TaxRateRaw VARCHAR(20);

                            -- Fetch TAX_RATE from CESSETTINGS table
                            SELECT @TaxRateRaw = Value 
                            FROM SBCES.CESSETTINGS 
                            WHERE Parameter = 'TAX_RATE';

                            -- Convert TAX_RATE safely
                            DECLARE @TaxRate DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL(@TaxRateRaw, '0'), ',', '.') AS DECIMAL(18,6));

                            -- Temp table for Rebuilt Parts costs
                            IF OBJECT_ID('tempdb..#RebuiltCosts') IS NOT NULL DROP TABLE #RebuiltCosts;
                            CREATE TABLE #RebuiltCosts (
                                CostCentre VARCHAR(30),
                                TotalCost DECIMAL(18,2)
                            );

                            -- Process each Rebuilt Part
                            DECLARE @RbPartsId VARCHAR(30);
                            DECLARE cur CURSOR LOCAL STATIC FOR 
                                SELECT MmsStockCode as RbPartsId
                                FROM SBCES.ScPartsUsed
                                WHERE LinkCode = @LinkCode
                                  AND LinkType = 'BUS'
                                  AND RebuiltPart = 'Y';

                            OPEN cur;
                            FETCH NEXT FROM cur INTO @RbPartsId;

                            WHILE @@FETCH_STATUS = 0
                            BEGIN
                                -- Temporary table to capture SP results
                                CREATE TABLE #SPResults (
                                    CostCentre VARCHAR(30),
                                    TotalCost DECIMAL(18,2),
                                    TaxableCost DECIMAL(18,2)
                                );

                                -- Execute stored procedure and capture results
                                INSERT INTO #SPResults
                                EXEC SBCES.RetrieveRBPTotalCostV4 @vi_idnum = @RbPartsId, @vi_type = 'RB';

                                -- Insert into main temp table
                                INSERT INTO #RebuiltCosts (CostCentre, TotalCost)
                                SELECT CostCentre, TotalCost
                                FROM #SPResults;

                                DROP TABLE #SPResults;

                                FETCH NEXT FROM cur INTO @RbPartsId;
                            END

                            CLOSE cur;
                            DEALLOCATE cur;

                            -- Aggregate CTEs
                            WITH SUS_CTE AS (
                                SELECT 
                                    S.CostCentre,
                                    SUM(
                                        TRY_CAST(
                                            SBCES.FINALCOST(
                                                CAST(ISNULL(S.PercentUsage,'0') AS VARCHAR(20)),
                                                CAST(ISNULL(S.QtyReqd,'0') AS VARCHAR(20)),
                                                ISNULL(SCP.MMSNewCost, 0),   -- FIXED HERE
                                                0
                                            ) AS DECIMAL(18,2)
                                        )
                                    ) AS SCPartsMaterialCost
                                FROM SBCES.ScPartsUsed S
                                LEFT JOIN SBCES.StockCodedParts SCP 
                                    ON SCP.MMSStockCode = S.MMSStockCode   -- FIXED JOIN
                                WHERE 
                                    S.RebuiltPart = 'N' 
                                    AND S.LinkType = 'BUS' 
                                    AND S.LinkCode = @LinkCode
                                GROUP BY S.CostCentre
                            ),
                            NSUS_CTE AS (
                                SELECT 
                                    CostCentre,
                                    SUM(
                                        TRY_CAST(
                                            SBCES.FINALCOST(
                                                CAST(ISNULL(PercentUsage,'0') AS VARCHAR(20)),
                                                CAST(ISNULL(QtyReqd,'0') AS VARCHAR(20)),
                                                ISNULL(Cost, 0),
                                                0
                                            ) AS DECIMAL(18,2)
                                        )
                                    ) AS NSCSCPartsMaterialCost
                                FROM SBCES.NscPartsUsed
                                WHERE 
                                    LinkType = 'BUS' 
                                    AND LinkCode = @LinkCode
                                GROUP BY CostCentre
                            ),
                            RebuiltAggregate AS (
                                SELECT 
                                    CostCentre,
                                    SUM(TotalCost) AS RBCost
                                FROM #RebuiltCosts
                                GROUP BY CostCentre
                            ),
                            Combined AS (
                                SELECT 
                                    COALESCE(S.CostCentre, N.CostCentre, R.CostCentre) AS CostCentre,
                                    ISNULL(S.SCPartsMaterialCost, 0) AS SCPartsMaterialCost,
                                    ISNULL(N.NSCSCPartsMaterialCost, 0) AS NSCSCPartsMaterialCost,
                                    ISNULL(R.RBCost, 0) AS RBCost
                                FROM SUS_CTE S
                                FULL OUTER JOIN NSUS_CTE N ON S.CostCentre = N.CostCentre
                                FULL OUTER JOIN RebuiltAggregate R ON R.CostCentre = COALESCE(S.CostCentre, N.CostCentre)
                            )

                            SELECT 
                                CostCentre,
                                CAST(ROUND(SCPartsMaterialCost + NSCSCPartsMaterialCost + RBCost, 2) AS DECIMAL(18,2)) AS TotalCost
                            FROM Combined
                            ORDER BY CostCentre;

                            IF OBJECT_ID('tempdb..#RebuiltCosts') IS NOT NULL DROP TABLE #RebuiltCosts;
                             ";

                return await _dbConnection.QueryAsync<MaterialCostSummaryInRbViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }
        //GetMaterialCostSummaryInMbEstimates
        private async Task<IEnumerable<MaterialCostSummaryInRbViewModel>> GetMaterialCostSummaryInMbEstimates(string id, string gridType)
        {
            //TODO use GridType
            try
            {
                var query = @"
                             DECLARE @LinkCode VARCHAR(30) = '" + id + "'" +
                             " ,@TaxRateRaw VARCHAR(20);" +

                             @"
                           -- DECLARE @LinkCode VARCHAR(30) = '4488' ,@TaxRateRaw VARCHAR(20);

                            -- Fetch TAX_RATE from CESSETTINGS table
                            SELECT @TaxRateRaw = Value 
                            FROM SBCES.CESSETTINGS 
                            WHERE Parameter = 'TAX_RATE';

                            -- Convert TAX_RATE safely
                            DECLARE @TaxRate DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL(@TaxRateRaw, '0'), ',', '.') AS DECIMAL(18,6));

                            -- Temp table for Rebuilt Parts costs
                            IF OBJECT_ID('tempdb..#RebuiltCosts') IS NOT NULL DROP TABLE #RebuiltCosts;
                            CREATE TABLE #RebuiltCosts (
                                CostCentre VARCHAR(30),
                                TotalCost DECIMAL(18,2)
                            );

                            -- Process each Rebuilt Part
                            DECLARE @RbPartsId VARCHAR(30);
                            DECLARE cur CURSOR LOCAL STATIC FOR 
                                SELECT MmsStockCode as RbPartsId
                                FROM SBCES.ScPartsUsed
                                WHERE LinkCode = @LinkCode
                                  AND LinkType = 'MB'
                                  AND RebuiltPart = 'Y';

                            OPEN cur;
                            FETCH NEXT FROM cur INTO @RbPartsId;

                            WHILE @@FETCH_STATUS = 0
                            BEGIN
                                -- Temporary table to capture SP results
                                CREATE TABLE #SPResults (
                                    CostCentre VARCHAR(30),
                                    TotalCost DECIMAL(18,2),
                                    TaxableCost DECIMAL(18,2)
                                );

                                -- Execute stored procedure and capture results
                                INSERT INTO #SPResults
                                EXEC SBCES.RetrieveRBPTotalCostV4 @vi_idnum = @RbPartsId, @vi_type = 'RB';

                                -- Insert into main temp table
                                INSERT INTO #RebuiltCosts (CostCentre, TotalCost)
                                SELECT CostCentre, TotalCost
                                FROM #SPResults;

                                DROP TABLE #SPResults;

                                FETCH NEXT FROM cur INTO @RbPartsId;
                            END

                            CLOSE cur;
                            DEALLOCATE cur;

                            -- Aggregate CTEs
                            WITH SUS_CTE AS (
                                SELECT 
                                    S.CostCentre,
                                    SUM(
                                        TRY_CAST(
                                            SBCES.FINALCOST(
                                                CAST(ISNULL(S.PercentUsage,'0') AS VARCHAR(20)),
                                                CAST(ISNULL(S.QtyReqd,'0') AS VARCHAR(20)),
                                                ISNULL(SCP.MMSNewCost, 0),  
                                                0
                                            ) AS DECIMAL(18,2)
                                        )
                                    ) AS SCPartsMaterialCost
                                FROM SBCES.ScPartsUsed S
                                LEFT JOIN SBCES.StockCodedParts SCP 
                                    ON SCP.MMSStockCode = S.MMSStockCode  
                                WHERE 
                                    S.RebuiltPart = 'N' 
                                    AND S.LinkType = 'MB' 
                                    AND S.LinkCode = @LinkCode
                                GROUP BY S.CostCentre
                            ),
                            NSUS_CTE AS (
                                SELECT 
                                    CostCentre,
                                    SUM(
                                        TRY_CAST(
                                            SBCES.FINALCOST(
                                                CAST(ISNULL(PercentUsage,'0') AS VARCHAR(20)),
                                                CAST(ISNULL(QtyReqd,'0') AS VARCHAR(20)),
                                                ISNULL(Cost, 0),
                                                0
                                            ) AS DECIMAL(18,2)
                                        )
                                    ) AS NSCSCPartsMaterialCost
                                FROM SBCES.NscPartsUsed
                                WHERE 
                                    LinkType = 'MB' 
                                    AND LinkCode = @LinkCode
                                GROUP BY CostCentre
                            ),
                            RebuiltAggregate AS (
                                SELECT 
                                    CostCentre,
                                    SUM(TotalCost) AS RBCost
                                FROM #RebuiltCosts
                                GROUP BY CostCentre
                            ),
                            Combined AS (
                                SELECT 
                                    COALESCE(S.CostCentre, N.CostCentre, R.CostCentre) AS CostCentre,
                                    ISNULL(S.SCPartsMaterialCost, 0) AS SCPartsMaterialCost,
                                    ISNULL(N.NSCSCPartsMaterialCost, 0) AS NSCSCPartsMaterialCost,
                                    ISNULL(R.RBCost, 0) AS RBCost
                                FROM SUS_CTE S
                                FULL OUTER JOIN NSUS_CTE N ON S.CostCentre = N.CostCentre
                                FULL OUTER JOIN RebuiltAggregate R ON R.CostCentre = COALESCE(S.CostCentre, N.CostCentre)
                            )

                            SELECT 
                                CostCentre,
                                CAST(ROUND(SCPartsMaterialCost + NSCSCPartsMaterialCost + RBCost, 2) AS DECIMAL(18,2)) AS TotalCost
                            FROM Combined
                            ORDER BY CostCentre;

                            IF OBJECT_ID('tempdb..#RebuiltCosts') IS NOT NULL DROP TABLE #RebuiltCosts;         
                             ";

                return await _dbConnection.QueryAsync<MaterialCostSummaryInRbViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }
        [AllowAnonymous]
        private async Task<IEnumerable<MaterialCostSummaryInRbViewModel>> GetMaterialCostSummaryInRbEstimates(string id, string gridType)
        {
            //TODO use GridType
            try
            {
                var query = @"
                             DECLARE @LinkCode VARCHAR(30) = '" + id + "'" +
                             " ,@TaxRateRaw VARCHAR(20);" +
                   
                             @"
                                 --        DECLARE @LinkCode VARCHAR(30) = '4488' ,@TaxRateRaw VARCHAR(20);

                                -- Fetch TAX_RATE from CESSETTINGS table
                                SELECT @TaxRateRaw = Value 
                                FROM SBCES.CESSETTINGS 
                                WHERE Parameter = 'TAX_RATE';

                                -- Convert TAX_RATE safely
                                DECLARE @TaxRate DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL(@TaxRateRaw, '0'), ',', '.') AS DECIMAL(18,6));

                                -- Temp table for Rebuilt Parts costs
                                IF OBJECT_ID('tempdb..#RebuiltCosts') IS NOT NULL DROP TABLE #RebuiltCosts;
                                CREATE TABLE #RebuiltCosts (
                                    CostCentre VARCHAR(30),
                                    TotalCost DECIMAL(18,2)
                                );

                                -- Process each Rebuilt Part
                                DECLARE @RbPartsId VARCHAR(30);
                                DECLARE cur CURSOR LOCAL STATIC FOR 
                                    SELECT MmsStockCode as RbPartsId
                                    FROM SBCES.ScPartsUsed
                                    WHERE LinkCode = @LinkCode
                                      AND LinkType = 'RB'
                                      AND RebuiltPart = 'Y';

                                OPEN cur;
                                FETCH NEXT FROM cur INTO @RbPartsId;

                                WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    -- Temporary table to capture SP results
                                    CREATE TABLE #SPResults (
                                        CostCentre VARCHAR(30),
                                        TotalCost DECIMAL(18,2),
                                        TaxableCost DECIMAL(18,2)
                                    );

                                    -- Execute stored procedure and capture results
                                    INSERT INTO #SPResults
                                    EXEC SBCES.RetrieveRBPTotalCostV4 @vi_idnum = @RbPartsId, @vi_type = 'RB';

                                    -- Insert into main temp table
                                    INSERT INTO #RebuiltCosts (CostCentre, TotalCost)
                                    SELECT CostCentre, TotalCost
                                    FROM #SPResults;

                                    DROP TABLE #SPResults;

                                    FETCH NEXT FROM cur INTO @RbPartsId;
                                END

                                CLOSE cur;
                                DEALLOCATE cur;

                                -- Aggregate CTEs
                                WITH SUS_CTE AS (
                                    SELECT 
                                        S.CostCentre,
                                        SUM(
                                            TRY_CAST(
                                                SBCES.FINALCOST(
                                                    CAST(ISNULL(S.PercentUsage,'0') AS VARCHAR(20)),
                                                    CAST(ISNULL(S.QtyReqd,'0') AS VARCHAR(20)),
                                                    ISNULL(SCP.MMSNewCost, 0),  
                                                    0
                                                ) AS DECIMAL(18,2)
                                            )
                                        ) AS SCPartsMaterialCost
                                    FROM SBCES.ScPartsUsed S
                                    LEFT JOIN SBCES.StockCodedParts SCP 
                                        ON SCP.MMSStockCode = S.MMSStockCode   
                                    WHERE 
                                        S.RebuiltPart = 'N' 
                                        AND S.LinkType = 'RB' 
                                        AND S.LinkCode = @LinkCode
                                    GROUP BY S.CostCentre
                                ),
                                NSUS_CTE AS (
                                    SELECT 
                                        CostCentre,
                                        SUM(
                                            TRY_CAST(
                                                SBCES.FINALCOST(
                                                    CAST(ISNULL(PercentUsage,'0') AS VARCHAR(20)),
                                                    CAST(ISNULL(QtyReqd,'0') AS VARCHAR(20)),
                                                    ISNULL(Cost, 0),
                                                    0
                                                ) AS DECIMAL(18,2)
                                            )
                                        ) AS NSCSCPartsMaterialCost
                                    FROM SBCES.NscPartsUsed
                                    WHERE 
                                        LinkType = 'RB' 
                                        AND LinkCode = @LinkCode
                                    GROUP BY CostCentre
                                ),
                                RebuiltAggregate AS (
                                    SELECT 
                                        CostCentre,
                                        SUM(TotalCost) AS RBCost
                                    FROM #RebuiltCosts
                                    GROUP BY CostCentre
                                ),
                                Combined AS (
                                    SELECT 
                                        COALESCE(S.CostCentre, N.CostCentre, R.CostCentre) AS CostCentre,
                                        ISNULL(S.SCPartsMaterialCost, 0) AS SCPartsMaterialCost,
                                        ISNULL(N.NSCSCPartsMaterialCost, 0) AS NSCSCPartsMaterialCost,
                                        ISNULL(R.RBCost, 0) AS RBCost
                                    FROM SUS_CTE S
                                    FULL OUTER JOIN NSUS_CTE N ON S.CostCentre = N.CostCentre
                                    FULL OUTER JOIN RebuiltAggregate R ON R.CostCentre = COALESCE(S.CostCentre, N.CostCentre)
                                )

                                SELECT 
                                    CostCentre,
                                    CAST(ROUND(SCPartsMaterialCost + NSCSCPartsMaterialCost + RBCost, 2) AS DECIMAL(18,2)) AS TotalCost
                                FROM Combined
                                ORDER BY CostCentre;

                                IF OBJECT_ID('tempdb..#RebuiltCosts') IS NOT NULL DROP TABLE #RebuiltCosts;
                                                                                 ";

                return await _dbConnection.QueryAsync<MaterialCostSummaryInRbViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        //end old code

    }
    }

