﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using BCES.Models.Parts;
using BCES.Controllers.Base;
using BCES.Data;
using System.Data;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;

namespace BCES.Controllers.Parts
{
    public class TotalCostController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public TotalCostController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetTotalCostInEstimates([DataSourceRequest] DataSourceRequest request, [FromQuery] string id, [FromQuery] string gridType)
        {
            if (string.IsNullOrEmpty(id))
            {
                return BadRequest("id is required for gridType :" + gridType);
            }

            try
            {
                if (gridType == "RebuiltGrid")
                {
                    var rbNscModel = await GetTotalCostInRebuiltPartsEstimatesWithDetails(id, gridType);
                    return Json(rbNscModel.ToDataSourceResult(request));
                }
                if (gridType == "VehicleGrid")
                {
                    var vehNscmodel = await GetTotalCostInVehicleEstimatesWithDetails(id, gridType);
                    return Json(vehNscmodel.ToDataSourceResult(request));
                }
                if (gridType == "ArchivedVehicleGrid")
                {
                    var vehArchNscmodel = await GetTotalCostInArchVehicleEstimates(id, gridType);
                    return Json(vehArchNscmodel.ToDataSourceResult(request));
                }
                if (gridType == "MakeVsBuyGrid")
                {
                    var vehNscmodel = await GetTotalCostInMakeVsBuyEstimatesWithDetails(id, gridType);
                    return Json(vehNscmodel.ToDataSourceResult(request));
                }
                if (gridType == "ArchivedMakeVsBuyGrid")
                {
                    return StatusCode(500, "An error occurred while fetching data. Implement this.");
                }
                if (gridType == "ArchivedRebuiltGrid")
                {
                    return StatusCode(500, "An error occurred while fetching data. Implement this.");
                }
                return StatusCode(500, "An error occurred while fetching data.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetTotalCostInEstimates: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                return StatusCode(500, new { error = ex.Message, stack = ex.StackTrace });
            }
        }
        private async Task<IEnumerable<TotalCostInEstimates>> GetTotalCostInVehicleEstimatesWithDetails(string id, string gridType)
        {
            try
            {
                var result = new List<TotalCostInEstimates>();
                var vehicleId = id;

                // STEP 1: Get Vehicle Details
                var vehicleDetails = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                @"SELECT 
                    ISNULL(ProjDesc, 'N/A') AS ProjDesc, 
                    ISNULL(VehSeriesCode, 'N/A') AS VehSeriesCode,
                    ISNULL(Make, 'N/A') AS Make,
                    ISNULL(Model, 'N/A') AS Model,
                    ISNULL([Year], 0) AS [Year],
                    ISNULL(NumOfVehicles, 0) AS NumOfVehicles,
                    ISNULL(Engine, 'N/A') AS Engine,
                    ISNULL(Transmission, 'N/A') AS Transmission,
                    ISNULL(Differential, 'N/A') AS Differential,
                    ISNULL(ModifiedLastBy, 'N/A') AS ModifiedLastBy,
                    ISNULL(ModifiedLastDate, GETDATE()) AS ModifiedLastDate,
                    ISNULL(EnteredBy, 'N/A') AS EnteredBy,
                    ISNULL(DateEntered, GETDATE()) AS DateEntered,
                    ISNULL(Sopnumber, 'N/A') AS Sopnumber
                FROM SBCES.VehicleList WHERE VehicleListId = @Id",
                new { Id = vehicleId });

                // STEP 2: Get Material Costs - Using CTE to avoid subquery in aggregate
                var materialCosts = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                    @"
            WITH MaterialCosts AS (
                SELECT 
                    TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SCP.MmsNewCost, 0), 0) AS DECIMAL(18,2)) AS Cost,
                    'SC' AS Type
                FROM SBCES.ScPartsUsed SUS
                LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
                WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'BUS' AND SUS.RebuiltPart = 'N'
                UNION ALL
                SELECT 
                    TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SUS.MmsCost, 0), 0) AS DECIMAL(18,2)) AS Cost,
                    'RB' AS Type
                FROM SBCES.ScPartsUsed SUS
                LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
                WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'BUS' AND SUS.RebuiltPart = 'Y'
                UNION ALL
                SELECT 
                    TRY_CAST(SBCES.FinalCost(CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(NSUS.Cost, 0), 0) AS DECIMAL(18,2)) AS Cost,
                    'NSC' AS Type
                FROM SBCES.NscPartsUsed NSUS 
                WHERE NSUS.LinkCode = @Id AND NSUS.LinkType = 'BUS'
            )
            SELECT 
                ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'SC'), 0) AS SCPartsMaterialCost,
                ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'RB'), 0) AS RBPartsMaterialCost,
                ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'NSC'), 0) AS NSCSCPartsMaterialCost,
                ISNULL((SELECT SUM(CoreCost) FROM SBCES.SCPartsUsed WHERE LinkCode = @Id AND LinkType = 'BUS'), 0) AS CoreCost",
                    new { Id = vehicleId });

                // STEP 3: Get Labour Costs - Simplified with CTE
                var labourCosts = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                    @"
            DECLARE @NonProductiveAdj DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'), ',', '.') AS DECIMAL(18,6));
            DECLARE @Fringe DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'FRINGE'), '0'), ',', '.') AS DECIMAL(18,6));
            DECLARE @Benefit DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'BENEFIT'), '0'), ',', '.') AS DECIMAL(18,6));
            DECLARE @Overhead DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'OVERHEAD'), '0'), ',', '.') AS DECIMAL(18,6));
            DECLARE @TaxRate DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'TAX_RATE'), '0'), ',', '.') AS DECIMAL(18,6));

            -- Get labour data with rate lookup in a CTE
            WITH LabourData AS (
                SELECT 
                    (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                     CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60) AS DecimalHrs,
                    CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) AS UsagePercent,
                    ISNULL((SELECT TOP 1 ES.RatePerHour FROM CES.SBCES.EmployeeSalaries ES
                            WHERE ES.WageGroup = (SELECT TOP 1 EC.WageGroup FROM CES.SBCES.EmplClass EC
                                                  WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')), 0) AS RatePerHour,
                    EL.LabourDefn
                FROM SBCES.EmployeeLabour EL
                WHERE EL.LinkNumber = @Id AND EL.TypeId = 'BUS'
            )
            SELECT 
                ISNULL(SUM(
                    (DecimalHrs * UsagePercent / 100) / @NonProductiveAdj * RatePerHour
                ), 0) AS TotalLabourCost,
                @Fringe AS FringeRate,
                @Benefit AS BenefitRate,
                @Overhead AS OverheadRate,
                @TaxRate AS TaxRate
            FROM LabourData",
                    new { Id = vehicleId });

                // STEP 4: Get Labour Tasks - Simplified with CTE
                var labourTasks = await _dbConnection.QueryAsync<LabourTaskSummary>(
                    @"
            DECLARE @NonProductiveAdj DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'), ',', '.') AS DECIMAL(18,6));

            WITH LabourData AS (
                SELECT 
                    EL.Task,
                    EL.LabourDefn,
                        EL.CostCentre as CC,

                    (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                     CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60) AS DecimalHrs,
                    CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) AS UsagePercent,
                    ISNULL((SELECT TOP 1 ES.RatePerHour FROM CES.SBCES.EmployeeSalaries ES
                            WHERE ES.WageGroup = (SELECT TOP 1 EC.WageGroup FROM CES.SBCES.EmplClass EC
                                                  WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')), 0) AS RatePerHour
                FROM SBCES.EmployeeLabour EL
                WHERE EL.LinkNumber = @Id AND EL.TypeId = 'BUS'
            )
            SELECT 
                ISNULL(Task, 'Unnamed Task') AS Task,
                ISNULL(LabourDefn, 'N/A') AS LabourDefinition,
                 ISNULL(CC, '') AS CC,
                COUNT(*) AS Count,
                SUM(DecimalHrs) AS Hours,
                SUM(DecimalHrs * UsagePercent / 100) AS EffectiveHours,
                SUM(DecimalHrs / @NonProductiveAdj) AS AdjustedHours,
                AVG(RatePerHour) AS RatePerHour,
                SUM((DecimalHrs * UsagePercent / 100) / @NonProductiveAdj * RatePerHour) AS TotalCost
            FROM LabourData
            GROUP BY Task, LabourDefn,CC
            ORDER BY Task",
                    new { Id = vehicleId });

                // STEP 5: Get Stock Parts (Material Lines)
                var stockParts = await _dbConnection.QueryAsync<dynamic>(
                    @"
            SELECT 
                'Stock' AS Type,
                SUS.MMSStockCode AS StockCode,
                 SUS.CostCentre as CC,
                ISNULL(SCP.DetailedDesc, 'N/A') AS Description,
                SUS.QtyReqd AS Quantity,
                ISNULL(SCP.MmsNewCost, 0) AS UnitCost,
                SUS.PercentUsage,
                TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SCP.MmsNewCost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
                '' AS Supplier
            FROM SBCES.ScPartsUsed SUS
            LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
            WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'BUS' AND SUS.RebuiltPart = 'N'
            ORDER BY SUS.MMSStockCode",
                    new { Id = vehicleId });

                // STEP 6: Get Rebuilt Parts (Material Lines)
                var rebuiltParts = await _dbConnection.QueryAsync<dynamic>(
                    @"
            SELECT 
                'Rebuilt' AS Type,
                SUS.MMSStockCode AS StockCode,
                SUS.CostCentre as CC,
                ISNULL(SCP.DetailedDesc, 'N/A') AS Description,
                SUS.QtyReqd AS Quantity,
                ISNULL(SUS.MmsCost, 0) AS UnitCost,
                SUS.PercentUsage,
                TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SUS.MmsCost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
                '' AS Supplier
            FROM SBCES.ScPartsUsed SUS
            LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
            WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'BUS' AND SUS.RebuiltPart = 'Y'
            ORDER BY SUS.MMSStockCode",
                    new { Id = vehicleId });

                // STEP 7: Get Non-Stock Parts (Material Lines)
                var nonStockParts = await _dbConnection.QueryAsync<dynamic>(
                    @"
            SELECT 
                'Non-Stock' AS Type,
                NSUS.OrigSuppNum AS StockCode,
                NSUS.CostCentre as CC,

                ISNULL(NSUS.OrigSupplierName, 'N/A') AS Description,
                NSUS.QtyReqd AS Quantity,
                ISNULL(NSUS.Cost, 0) AS UnitCost,
                NSUS.PercentUsage,
                TRY_CAST(SBCES.FinalCost(CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(NSUS.Cost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
                ISNULL(NSUS.OrigSupplierName, '') AS Supplier
            FROM SBCES.NscPartsUsed NSUS
            WHERE NSUS.LinkCode = @Id AND NSUS.LinkType = 'BUS'
            ORDER BY NSUS.OrigSuppNum",
                    new { Id = vehicleId });

                // STEP 8: Build the result object
                var totalCost = new TotalCostInEstimates
                {
                    LinkCode = vehicleId,
                    VehicleDescription = vehicleDetails?.ProjDesc ?? "N/A",
                    VehicleSeries = vehicleDetails?.VehSeriesCode ?? "N/A",
                    Make = vehicleDetails?.Make ?? "N/A",
                    Model = vehicleDetails?.Model ?? "N/A",
                    Year = Convert.ToInt32(vehicleDetails?.Year ?? 0),
                    NumOfVehicles = Convert.ToInt32(vehicleDetails?.NumOfVehicles ?? 0),
                    Engine = vehicleDetails?.Engine ?? "N/A",
                    Transmission = vehicleDetails?.Transmission ?? "N/A",
                    Differential = vehicleDetails?.Differential ?? "N/A",
                    ModifiedLastBy = vehicleDetails?.ModifiedLastBy ?? "N/A",
                    ModifiedLastDate = vehicleDetails?.ModifiedLastDate ?? DateTime.Now,
                    EnteredBy = vehicleDetails?.EnteredBy ?? "N/A",
                    DateEntered = vehicleDetails?.DateEntered ?? DateTime.Now,
                    Sopnumber = vehicleDetails?.Sopnumber ?? "N/A",

                    // Material Costs
                    SCPartsMaterialCost = Convert.ToDecimal(materialCosts?.SCPartsMaterialCost ?? 0),
                    NSCSCPartsMaterialCost = Convert.ToDecimal(materialCosts?.NSCSCPartsMaterialCost ?? 0),
                    RBPartsMaterialCost = Convert.ToDecimal(materialCosts?.RBPartsMaterialCost ?? 0),
                    CoreCost = Convert.ToDecimal(materialCosts?.CoreCost ?? 0),

                    // Material Summary
                    TotalStockPartsCount = stockParts.Count(),
                    TotalNonStockPartsCount = nonStockParts.Count(),
                    TotalRebuiltPartsCount = rebuiltParts.Count(),
                };

                // Calculate material totals
                var scPartsCost = totalCost.SCPartsMaterialCost;
                var rbPartsCost = totalCost.RBPartsMaterialCost;
                var nscPartsCost = totalCost.NSCSCPartsMaterialCost;
                var materialTotalNoTax = scPartsCost + rbPartsCost + nscPartsCost;
                var taxRate = Convert.ToDecimal(labourCosts?.TaxRate ?? 0);
                var materialTax = (materialTotalNoTax * taxRate)/100;
                var materialTotalWithTax = materialTotalNoTax + materialTax;

                totalCost.MaterialTotalCostNoTax = materialTotalNoTax;
                totalCost.MaterialTotalTaxAmount = materialTax;
                totalCost.MaterialTotalWithTax = materialTotalWithTax;

                // Calculate averages
                totalCost.AverageStockPartCost = stockParts.Any() ? Convert.ToDecimal(stockParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;
                totalCost.AverageNonStockPartCost = nonStockParts.Any() ? Convert.ToDecimal(nonStockParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;
                totalCost.AverageRebuiltPartCost = rebuiltParts.Any() ? Convert.ToDecimal(rebuiltParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;

                // Labour Costs
                var totalLabourCost = Convert.ToDecimal(labourCosts?.TotalLabourCost ?? 0);
                var fringeRate = Convert.ToDecimal(labourCosts?.FringeRate ?? 0);
                var benefitRate = Convert.ToDecimal(labourCosts?.BenefitRate ?? 0);
                var overheadRate = Convert.ToDecimal(labourCosts?.OverheadRate ?? 0);

                var labourFringe = totalLabourCost * fringeRate;
                var labourBenefits = (totalLabourCost + labourFringe) * benefitRate;
                var blendedFringeBenefitPercent = totalLabourCost > 0 ? ((labourFringe + labourBenefits) / totalLabourCost) * 100 : 0;
                var blendedFringeBenefitCost = labourFringe + labourBenefits;
                var labourOverhead = totalLabourCost * overheadRate;
                var finalLabourCost = totalLabourCost + labourFringe + labourBenefits + labourOverhead;

                totalCost.TotalLabourCost = totalLabourCost;
                totalCost.LabourFringe = labourFringe;
                totalCost.LabourBenefits = labourBenefits;
                totalCost.BlendedFringeBenefitPercent = blendedFringeBenefitPercent;
                totalCost.BlendedFringeBenefitCost = blendedFringeBenefitCost;
                totalCost.LabourOverhead = labourOverhead;
                totalCost.FinalLabourCost = finalLabourCost;

                // Labour Hours Summary
                totalCost.LabourTasks = labourTasks.ToList();
                totalCost.TotalLabourHours = labourTasks.Sum(t => t.Hours);
                totalCost.TotalEffectiveHours = labourTasks.Sum(t => t.EffectiveHours);
                totalCost.TotalAdjustedHours = labourTasks.Sum(t => t.AdjustedHours);

                // Material Lines
                var materialLines = new List<MaterialLineItem>();
                foreach (var p in stockParts)
                {
                    materialLines.Add(new MaterialLineItem
                    {
                        Type = p.Type,
                        StockCode = p.StockCode,
                        CC = p.CC,
                        Description = p.Description,
                        Quantity = Convert.ToDecimal(p.Quantity ?? 0),
                        UnitCost = Convert.ToDecimal(p.UnitCost ?? 0),
                        PercentUsage = Convert.ToDecimal(p.PercentUsage ?? 0),
                        TotalCost = Convert.ToDecimal(p.TotalCost ?? 0),
                        Supplier = p.Supplier
                    });
                }
                foreach (var p in rebuiltParts)
                {
                    materialLines.Add(new MaterialLineItem
                    {
                        Type = p.Type,
                        StockCode = p.StockCode,
                        CC = p.CC,
                        Description = p.Description,
                        Quantity = Convert.ToDecimal(p.Quantity ?? 0),
                        UnitCost = Convert.ToDecimal(p.UnitCost ?? 0),
                        PercentUsage = Convert.ToDecimal(p.PercentUsage ?? 0),
                        TotalCost = Convert.ToDecimal(p.TotalCost ?? 0),
                        Supplier = p.Supplier
                    });
                }
                foreach (var p in nonStockParts)
                {
                    materialLines.Add(new MaterialLineItem
                    {
                        Type = p.Type,
                        StockCode = p.StockCode,
                        CC = p.CC,
                        Description = p.Description,
                        Quantity = Convert.ToDecimal(p.Quantity ?? 0),
                        UnitCost = Convert.ToDecimal(p.UnitCost ?? 0),
                        PercentUsage = Convert.ToDecimal(p.PercentUsage ?? 0),
                        TotalCost = Convert.ToDecimal(p.TotalCost ?? 0),
                        Supplier = p.Supplier
                    });
                }

                totalCost.MaterialLines = materialLines
                    .Where(m => m.TotalCost > 0)
                    .OrderBy(m => m.Type)
                    .ThenBy(m => m.StockCode)
                    .ToList();

                // Grand Totals
                totalCost.TotalWithoutTax = finalLabourCost + materialTotalNoTax;
                totalCost.TotalWithTax = finalLabourCost + materialTotalWithTax;

                result.Add(totalCost);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetTotalCostInVehicleEstimatesWithDetails: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                throw;
            }
        }

        private async Task<IEnumerable<TotalCostInEstimates>> GetTotalCostInMakeVsBuyEstimatesWithDetails(string id, string gridType)
        {
            try
            {
                var result = new List<TotalCostInEstimates>();
               

                // STEP 1: Get Vehicle Details
                var mbDetails = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                @"SELECT 
                    ISNULL(MBNumber, 'N/A') AS MBNumber, 
                    ISNULL(Description, 'N/A') AS Description,
                    ISNULL([NumBusComp], 'N/A') AS NumBusComp,
                    ISNULL(VendorPartNum, 'N/A') AS VendorPartNum,
                    ISNULL(BuyCode, 0) AS BuyCode,
                    ISNULL(NumBusComp, 0) AS NumBusComp,
                    ISNULL([RebuildCode], 'N/A') AS [RebuildCode],
                    ISNULL([AnnualUsage], 'N/A') AS [AnnualUsage],
                    ISNULL([Recommendation], 'N/A') AS [Recommendation],
                    ISNULL([RemanCost], 'N/A') AS [RemanCost],
                    ISNULL([ExternalCost], 'N/A') AS [ExternalCost],
                    ISNULL([BuyNewCost], 'N/A') AS [BuyNewCost],
					 ISNULL([InternalCost], 'N/A') AS [InternalCost],
					  ISNULL([SopNumber], 'N/A') AS [SopNumber],	
                    ISNULL([DateOpened], GETDATE()) AS [DateOpened]
                FROM SBCES.MbList WHERE 
				MbNumber = @Id",
                new { Id = id });

                // STEP 2: Get Material Costs - Using CTE to avoid subquery in aggregate
                var materialCosts = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                    @"
            WITH MaterialCosts AS (
                SELECT 
                    TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SCP.MmsNewCost, 0), 0) AS DECIMAL(18,2)) AS Cost,
                    'SC' AS Type
                FROM SBCES.ScPartsUsed SUS
                LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
                WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'MB' AND SUS.RebuiltPart = 'N'
                UNION ALL
                SELECT 
                    TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SUS.MmsCost, 0), 0) AS DECIMAL(18,2)) AS Cost,
                    'RB' AS Type
                FROM SBCES.ScPartsUsed SUS
                LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
                WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'MB' AND SUS.RebuiltPart = 'Y'
                UNION ALL
                SELECT 
                    TRY_CAST(SBCES.FinalCost(CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(NSUS.Cost, 0), 0) AS DECIMAL(18,2)) AS Cost,
                    'NSC' AS Type
                FROM SBCES.NscPartsUsed NSUS 
                WHERE NSUS.LinkCode = @Id AND NSUS.LinkType = 'MB'
            )
            SELECT 
                ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'SC'), 0) AS SCPartsMaterialCost,
                ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'RB'), 0) AS RBPartsMaterialCost,
                ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'NSC'), 0) AS NSCSCPartsMaterialCost,
                ISNULL((SELECT SUM(CoreCost) FROM SBCES.SCPartsUsed WHERE LinkCode = @Id AND LinkType = 'MB'), 0) AS CoreCost",
                    new { Id = id });

                // STEP 3: Get Labour Costs - Simplified with CTE
                var labourCosts = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                    @"
            DECLARE @NonProductiveAdj DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'), ',', '.') AS DECIMAL(18,6));
            DECLARE @Fringe DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'FRINGE'), '0'), ',', '.') AS DECIMAL(18,6));
            DECLARE @Benefit DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'BENEFIT'), '0'), ',', '.') AS DECIMAL(18,6));
            DECLARE @Overhead DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'OVERHEAD'), '0'), ',', '.') AS DECIMAL(18,6));
            DECLARE @TaxRate DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'TAX_RATE'), '0'), ',', '.') AS DECIMAL(18,6));

            -- Get labour data with rate lookup in a CTE
            WITH LabourData AS (
                SELECT 
                    (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                     CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60) AS DecimalHrs,
                    CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) AS UsagePercent,
                    ISNULL((SELECT TOP 1 ES.RatePerHour FROM CES.SBCES.EmployeeSalaries ES
                            WHERE ES.WageGroup = (SELECT TOP 1 EC.WageGroup FROM CES.SBCES.EmplClass EC
                                                  WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')), 0) AS RatePerHour,
                    EL.LabourDefn
                FROM SBCES.EmployeeLabour EL
                WHERE EL.LinkNumber = @Id AND EL.TypeId = 'MB'
            )
            SELECT 
                ISNULL(SUM(
                    (DecimalHrs * UsagePercent / 100) / @NonProductiveAdj * RatePerHour
                ), 0) AS TotalLabourCost,
                @Fringe AS FringeRate,
                @Benefit AS BenefitRate,
                @Overhead AS OverheadRate,
                @TaxRate AS TaxRate
            FROM LabourData",
                    new { Id = id });

                // STEP 4: Get Labour Tasks - Simplified with CTE
                var labourTasks = await _dbConnection.QueryAsync<LabourTaskSummary>(
                    @"
            DECLARE @NonProductiveAdj DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'), ',', '.') AS DECIMAL(18,6));

            WITH LabourData AS (
                SELECT 
                    EL.Task,
                    EL.LabourDefn,
                        EL.CostCentre as CC,

                    (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                     CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60) AS DecimalHrs,
                    CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) AS UsagePercent,
                    ISNULL((SELECT TOP 1 ES.RatePerHour FROM CES.SBCES.EmployeeSalaries ES
                            WHERE ES.WageGroup = (SELECT TOP 1 EC.WageGroup FROM CES.SBCES.EmplClass EC
                                                  WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')), 0) AS RatePerHour
                FROM SBCES.EmployeeLabour EL
                WHERE EL.LinkNumber = @Id AND EL.TypeId = 'MB'
            )
            SELECT 
                ISNULL(Task, 'Unnamed Task') AS Task,
                ISNULL(LabourDefn, 'N/A') AS LabourDefinition,
                 ISNULL(CC, '') AS CC,
                COUNT(*) AS Count,
                SUM(DecimalHrs) AS Hours,
                SUM(DecimalHrs * UsagePercent / 100) AS EffectiveHours,
                SUM(DecimalHrs / @NonProductiveAdj) AS AdjustedHours,
                AVG(RatePerHour) AS RatePerHour,
                SUM((DecimalHrs * UsagePercent / 100) / @NonProductiveAdj * RatePerHour) AS TotalCost
            FROM LabourData
            GROUP BY Task, LabourDefn,CC
            ORDER BY Task",
                    new { Id = id });

                // STEP 5: Get Stock Parts (Material Lines)
                var stockParts = await _dbConnection.QueryAsync<dynamic>(
                    @"
            SELECT 
                'Stock' AS Type,
                SUS.MMSStockCode AS StockCode,
                 SUS.CostCentre as CC,
                ISNULL(SCP.DetailedDesc, 'N/A') AS Description,
                SUS.QtyReqd AS Quantity,
                ISNULL(SCP.MmsNewCost, 0) AS UnitCost,
                SUS.PercentUsage,
                TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SCP.MmsNewCost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
                '' AS Supplier
            FROM SBCES.ScPartsUsed SUS
            LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
            WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'MB' AND SUS.RebuiltPart = 'N'
            ORDER BY SUS.MMSStockCode",
                    new { Id = id });

                // STEP 6: Get Rebuilt Parts (Material Lines)
                var rebuiltParts = await _dbConnection.QueryAsync<dynamic>(
                    @"
            SELECT 
                'Rebuilt' AS Type,
                SUS.MMSStockCode AS StockCode,
                SUS.CostCentre as CC,
                ISNULL(SCP.DetailedDesc, 'N/A') AS Description,
                SUS.QtyReqd AS Quantity,
                ISNULL(SUS.MmsCost, 0) AS UnitCost,
                SUS.PercentUsage,
                TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SUS.MmsCost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
                '' AS Supplier
            FROM SBCES.ScPartsUsed SUS
            LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
            WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'MB' AND SUS.RebuiltPart = 'Y'
            ORDER BY SUS.MMSStockCode",
                    new { Id = id });

                // STEP 7: Get Non-Stock Parts (Material Lines)
                var nonStockParts = await _dbConnection.QueryAsync<dynamic>(
                    @"
            SELECT 
                'Non-Stock' AS Type,
                NSUS.OrigSuppNum AS StockCode,
                NSUS.CostCentre as CC,

                ISNULL(NSUS.OrigSupplierName, 'N/A') AS Description,
                NSUS.QtyReqd AS Quantity,
                ISNULL(NSUS.Cost, 0) AS UnitCost,
                NSUS.PercentUsage,
                TRY_CAST(SBCES.FinalCost(CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(NSUS.Cost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
                ISNULL(NSUS.OrigSupplierName, '') AS Supplier
            FROM SBCES.NscPartsUsed NSUS
            WHERE NSUS.LinkCode = @Id AND NSUS.LinkType = 'MB'
            ORDER BY NSUS.OrigSuppNum",
                    new { Id = id });

                // STEP 8: Build the result object
                var totalCost = new TotalCostInEstimates
                {
                    LinkCode = id,

                    Keyword = mbDetails?.Keyword ?? "N/A",
                    Description = mbDetails?.Description ?? "N/A",
                    BusType = mbDetails?.BusType ?? "N/A",
                    NumBusComp = mbDetails?.NumBusComp ?? "N/A",
                    VendorPartNum = mbDetails?.VendorPartNum ?? "N/A",
                    BuyCode = mbDetails?.BuyCode ?? "N/A",
                    RebuildCode = mbDetails?.RebuildCode ?? "N/A",
                    CoreCode = mbDetails?.CoreCode ?? "N/A",
                    AnnualUsage = mbDetails?.AnnualUsage ?? "N/A",
                    BenchNumber = mbDetails?.BenchNumber ?? "N/A",
                    SampleProvided = mbDetails?.SampleProvided ?? "N/A",
                    Recommendation = mbDetails?.Recommendation ?? "N/A",
                    RemanCost = mbDetails?.RemanCost ?? "N/A",
                    ExternalCost = mbDetails?.ExternalCost ?? "N/A",
                    BuyNewCost = mbDetails?.BuyNewCost ?? "N/A",
                    InternalCost = mbDetails?.InternalCost ?? "N/A",
                    SopNumber = mbDetails?.SopNumber ?? "N/A",
                   
                    JobNumber = mbDetails?.JobNumber ?? "N/A",
                    
                    DateOpened = mbDetails?.DateOpened ?? DateTime.Now,
                    Readmanualnewprice = mbDetails?.Readmanualnewprice ?? "N/A",
                    MbPrefix = mbDetails?.MbPrefix ?? "N/A",

                    // Material Costs
                    SCPartsMaterialCost = Convert.ToDecimal(materialCosts?.SCPartsMaterialCost ?? 0),
                    NSCSCPartsMaterialCost = Convert.ToDecimal(materialCosts?.NSCSCPartsMaterialCost ?? 0),
                    RBPartsMaterialCost = Convert.ToDecimal(materialCosts?.RBPartsMaterialCost ?? 0),
                  //  CoreCost = Convert.ToDecimal(materialCosts?.CoreCost ?? 0),

                    // Material Summary
                    TotalStockPartsCount = stockParts.Count(),
                    TotalNonStockPartsCount = nonStockParts.Count(),
                    TotalRebuiltPartsCount = rebuiltParts.Count(),
                };

                // Calculate material totals
                var scPartsCost = totalCost.SCPartsMaterialCost;
                var rbPartsCost = totalCost.RBPartsMaterialCost;
                var nscPartsCost = totalCost.NSCSCPartsMaterialCost;
                var materialTotalNoTax = scPartsCost + rbPartsCost + nscPartsCost;
                var taxRate = Convert.ToDecimal(labourCosts?.TaxRate ?? 0);
                var materialTax = (materialTotalNoTax * taxRate) / 100;
                var materialTotalWithTax = materialTotalNoTax + materialTax;

                totalCost.MaterialTotalCostNoTax = materialTotalNoTax;
                totalCost.MaterialTotalTaxAmount = materialTax;
                totalCost.MaterialTotalWithTax = materialTotalWithTax;

                // Calculate averages
                totalCost.AverageStockPartCost = stockParts.Any() ? Convert.ToDecimal(stockParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;
                totalCost.AverageNonStockPartCost = nonStockParts.Any() ? Convert.ToDecimal(nonStockParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;
                totalCost.AverageRebuiltPartCost = rebuiltParts.Any() ? Convert.ToDecimal(rebuiltParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;

                // Labour Costs
                var totalLabourCost = Convert.ToDecimal(labourCosts?.TotalLabourCost ?? 0);
                var fringeRate = Convert.ToDecimal(labourCosts?.FringeRate ?? 0);
                var benefitRate = Convert.ToDecimal(labourCosts?.BenefitRate ?? 0);
                var overheadRate = Convert.ToDecimal(labourCosts?.OverheadRate ?? 0);

                var labourFringe = totalLabourCost * fringeRate;
                var labourBenefits = (totalLabourCost + labourFringe) * benefitRate;
                var blendedFringeBenefitPercent = totalLabourCost > 0 ? ((labourFringe + labourBenefits) / totalLabourCost) * 100 : 0;
                var blendedFringeBenefitCost = labourFringe + labourBenefits;
                var labourOverhead = totalLabourCost * overheadRate;
                var finalLabourCost = totalLabourCost + labourFringe + labourBenefits + labourOverhead;

                totalCost.TotalLabourCost = totalLabourCost;
                totalCost.LabourFringe = labourFringe;
                totalCost.LabourBenefits = labourBenefits;
                totalCost.BlendedFringeBenefitPercent = blendedFringeBenefitPercent;
                totalCost.BlendedFringeBenefitCost = blendedFringeBenefitCost;
                totalCost.LabourOverhead = labourOverhead;
                totalCost.FinalLabourCost = finalLabourCost;

                // Labour Hours Summary
                totalCost.LabourTasks = labourTasks.ToList();
                totalCost.TotalLabourHours = labourTasks.Sum(t => t.Hours);
                totalCost.TotalEffectiveHours = labourTasks.Sum(t => t.EffectiveHours);
                totalCost.TotalAdjustedHours = labourTasks.Sum(t => t.AdjustedHours);

                // Material Lines
                var materialLines = new List<MaterialLineItem>();
                foreach (var p in stockParts)
                {
                    materialLines.Add(new MaterialLineItem
                    {
                        Type = p.Type,
                        StockCode = p.StockCode,
                        CC = p.CC,
                        Description = p.Description,
                        Quantity = Convert.ToDecimal(p.Quantity ?? 0),
                        UnitCost = Convert.ToDecimal(p.UnitCost ?? 0),
                        PercentUsage = Convert.ToDecimal(p.PercentUsage ?? 0),
                        TotalCost = Convert.ToDecimal(p.TotalCost ?? 0),
                        Supplier = p.Supplier
                    });
                }
                foreach (var p in rebuiltParts)
                {
                    materialLines.Add(new MaterialLineItem
                    {
                        Type = p.Type,
                        StockCode = p.StockCode,
                        CC = p.CC,
                        Description = p.Description,
                        Quantity = Convert.ToDecimal(p.Quantity ?? 0),
                        UnitCost = Convert.ToDecimal(p.UnitCost ?? 0),
                        PercentUsage = Convert.ToDecimal(p.PercentUsage ?? 0),
                        TotalCost = Convert.ToDecimal(p.TotalCost ?? 0),
                        Supplier = p.Supplier
                    });
                }
                foreach (var p in nonStockParts)
                {
                    materialLines.Add(new MaterialLineItem
                    {
                        Type = p.Type,
                        StockCode = p.StockCode,
                        CC = p.CC,
                        Description = p.Description,
                        Quantity = Convert.ToDecimal(p.Quantity ?? 0),
                        UnitCost = Convert.ToDecimal(p.UnitCost ?? 0),
                        PercentUsage = Convert.ToDecimal(p.PercentUsage ?? 0),
                        TotalCost = Convert.ToDecimal(p.TotalCost ?? 0),
                        Supplier = p.Supplier
                    });
                }

                totalCost.MaterialLines = materialLines
                    .Where(m => m.TotalCost > 0)
                    .OrderBy(m => m.Type)
                    .ThenBy(m => m.StockCode)
                    .ToList();

                // Grand Totals
                totalCost.TotalWithoutTax = finalLabourCost + materialTotalNoTax;
                totalCost.TotalWithTax = finalLabourCost + materialTotalWithTax;

                result.Add(totalCost);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetTotalCostInMakeVsBuyEstimatesWithDetails: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                throw;
            }
        }

        private async Task<IEnumerable<TotalCostInEstimates>> GetTotalCostInRebuiltPartsEstimatesWithDetails(string id, string gridType)
        {
            try
            {
                var result = new List<TotalCostInEstimates>();

                var linkCode = id?.ToUpper();
                if (gridType == "RebuiltGrid")
                {
                    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                       "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                       new { Id = id }
                   );

                }

                // STEP 1: Get Vehicle Details
                var rbDetails = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                @"SELECT
                    ISNULL(rbm.[RebuiltStockNum], 'N/A') AS [MBNumber],
                    ISNULL(rbm.[DetailedDesc], 'N/A') AS [Description],
                    ISNULL(rbm.[Keyword], 'N/A') AS [Keyword],
                    ISNULL(rbm.[MmsStockCode], 'N/A') AS [MmsStockCode],
                    ISNULL(rbm.[ItemRefNumber], 'N/A') AS [ItemRefNumber],
                    ISNULL(rbm.[CorePartNum], 'N/A') AS [CorePartNum],
                    ISNULL(rbm.[CoreCharge], 'N/A') AS [CoreCharge],
                    ISNULL(rbm.[JobNumber], 'N/A') AS [JobNumber],
                    ISNULL(rbm.[EstimatedCost], 0) AS [EstimatedCost],
                    ISNULL(rbm.[BuyNewCost], 'N/A') AS [BuyNewCost],
                    ISNULL(rbm.[RemanCost], 'N/A') AS [RemanCost],
                    ISNULL(rbm.[ExternalCost], 'N/A') AS [ExternalCost],
                    ISNULL(rbm.[SopNumber], 'N/A') AS [SopNumber],
                    ISNULL(rbm.[Active], 0) AS [Active],
                    ISNULL(
                        STRING_AGG(lb.[description], ', '),
                        'N/A'
                    ) AS [RBListOfBuses],
                    ISNULL(rbm.[DateEntered], GETDATE()) AS [DateEntered],
                    ISNULL(rbm.[LastModifiedBy], 'N/A') AS [LastModifiedBy]
                FROM [SBCES].[RbMasterlist] rbm
                LEFT JOIN [SBCES].[RBLISTOFBUSES] rbl
                    ON rbm.[RebuiltStockNum] = rbl.[RebuiltStockNum]
                LEFT JOIN [SBCES].[LISTOFBUSES] lb
                    ON rbl.[listid] = lb.[listid]
                WHERE rbm.[RebuiltStockNum] = @Id
                GROUP BY
                    rbm.[RebuiltStockNum],
                    rbm.[DetailedDesc],
                    rbm.[Keyword],
                    rbm.[MmsStockCode],
                    rbm.[ItemRefNumber],
                    rbm.[CorePartNum],
                    rbm.[CoreCharge],
                    rbm.[JobNumber],
                    rbm.[EstimatedCost],
                    rbm.[BuyNewCost],
                    rbm.[RemanCost],
                    rbm.[ExternalCost],
                    rbm.[SopNumber],
                    rbm.[Active],
                    rbm.[DateEntered],
                    rbm.[LastModifiedBy]",
                new { Id = linkCode.ToString() });

                // STEP 2: Get Material Costs - Using CTE to avoid subquery in aggregate
                var materialCosts = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                    @"
            WITH MaterialCosts AS (
                SELECT 
                    TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SCP.MmsNewCost, 0), 0) AS DECIMAL(18,2)) AS Cost,
                    'SC' AS Type
                FROM SBCES.ScPartsUsed SUS
                LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
                WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'RB' AND SUS.RebuiltPart = 'N'
                UNION ALL
                SELECT 
                    TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SUS.MmsCost, 0), 0) AS DECIMAL(18,2)) AS Cost,
                    'RB' AS Type
                FROM SBCES.ScPartsUsed SUS
                LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
                WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'RB' AND SUS.RebuiltPart = 'Y'
                UNION ALL
                SELECT 
                    TRY_CAST(SBCES.FinalCost(CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(NSUS.Cost, 0), 0) AS DECIMAL(18,2)) AS Cost,
                    'NSC' AS Type
                FROM SBCES.NscPartsUsed NSUS 
                WHERE NSUS.LinkCode = @Id AND NSUS.LinkType = 'RB'
            )
            SELECT 
                ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'SC'), 0) AS SCPartsMaterialCost,
                ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'RB'), 0) AS RBPartsMaterialCost,
                ISNULL((SELECT SUM(Cost) FROM MaterialCosts WHERE Type = 'NSC'), 0) AS NSCSCPartsMaterialCost,
                ISNULL((SELECT SUM(CoreCost) FROM SBCES.SCPartsUsed WHERE LinkCode = @Id AND LinkType = 'RB'), 0) AS CoreCost",
                    new { Id = linkCode.ToString() });

                // STEP 3: Get Labour Costs - Simplified with CTE
                var labourCosts = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                    @"
            DECLARE @NonProductiveAdj DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'), ',', '.') AS DECIMAL(18,6));
            DECLARE @Fringe DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'FRINGE'), '0'), ',', '.') AS DECIMAL(18,6));
            DECLARE @Benefit DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'BENEFIT'), '0'), ',', '.') AS DECIMAL(18,6));
            DECLARE @Overhead DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'OVERHEAD'), '0'), ',', '.') AS DECIMAL(18,6));
            DECLARE @TaxRate DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'TAX_RATE'), '0'), ',', '.') AS DECIMAL(18,6));

            -- Get labour data with rate lookup in a CTE
            WITH LabourData AS (
                SELECT 
                    (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                     CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60) AS DecimalHrs,
                    CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) AS UsagePercent,
                    ISNULL((SELECT TOP 1 ES.RatePerHour FROM CES.SBCES.EmployeeSalaries ES
                            WHERE ES.WageGroup = (SELECT TOP 1 EC.WageGroup FROM CES.SBCES.EmplClass EC
                                                  WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')), 0) AS RatePerHour,
                    EL.LabourDefn
                FROM SBCES.EmployeeLabour EL
                WHERE EL.LinkNumber = @Id AND EL.TypeId = 'RB'
            )
            SELECT 
                ISNULL(SUM(
                    (DecimalHrs * UsagePercent / 100) / @NonProductiveAdj * RatePerHour
                ), 0) AS TotalLabourCost,
                @Fringe AS FringeRate,
                @Benefit AS BenefitRate,
                @Overhead AS OverheadRate,
                @TaxRate AS TaxRate
            FROM LabourData",
                    new { Id = linkCode.ToString() });

                // STEP 4: Get Labour Tasks - Simplified with CTE
                var labourTasks = await _dbConnection.QueryAsync<LabourTaskSummary>(
                    @"
            DECLARE @NonProductiveAdj DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'), ',', '.') AS DECIMAL(18,6));

            WITH LabourData AS (
                SELECT 
                    EL.Task,
                    EL.LabourDefn,
                        EL.CostCentre as CC,

                    (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                     CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60) AS DecimalHrs,
                    CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) AS UsagePercent,
                    ISNULL((SELECT TOP 1 ES.RatePerHour FROM CES.SBCES.EmployeeSalaries ES
                            WHERE ES.WageGroup = (SELECT TOP 1 EC.WageGroup FROM CES.SBCES.EmplClass EC
                                                  WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')), 0) AS RatePerHour
                FROM SBCES.EmployeeLabour EL
                WHERE EL.LinkNumber = @Id AND EL.TypeId = 'RB'
            )
            SELECT 
                ISNULL(Task, 'Unnamed Task') AS Task,
                ISNULL(LabourDefn, 'N/A') AS LabourDefinition,
                 ISNULL(CC, '') AS CC,
                COUNT(*) AS Count,
                SUM(DecimalHrs) AS Hours,
                SUM(DecimalHrs * UsagePercent / 100) AS EffectiveHours,
                SUM(DecimalHrs / @NonProductiveAdj) AS AdjustedHours,
                AVG(RatePerHour) AS RatePerHour,
                SUM((DecimalHrs * UsagePercent / 100) / @NonProductiveAdj * RatePerHour) AS TotalCost
            FROM LabourData
            GROUP BY Task, LabourDefn,CC
            ORDER BY Task",
                    new { Id = linkCode.ToString() });

                // STEP 5: Get Stock Parts (Material Lines)
                var stockParts = await _dbConnection.QueryAsync<dynamic>(
                    @"
            SELECT 
                'Stock' AS Type,
                SUS.MMSStockCode AS StockCode,
                 SUS.CostCentre as CC,
                ISNULL(SCP.DetailedDesc, 'N/A') AS Description,
                SUS.QtyReqd AS Quantity,
                ISNULL(SCP.MmsNewCost, 0) AS UnitCost,
                SUS.PercentUsage,
                TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SCP.MmsNewCost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
                '' AS Supplier
            FROM SBCES.ScPartsUsed SUS
            LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
            WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'RB' AND SUS.RebuiltPart = 'N'
            ORDER BY SUS.MMSStockCode",
                    new { Id = linkCode.ToString() });

                // STEP 6: Get Rebuilt Parts (Material Lines)
                var rebuiltParts = await _dbConnection.QueryAsync<dynamic>(
                    @"
            SELECT 
                'Rebuilt' AS Type,
                SUS.MMSStockCode AS StockCode,
                SUS.CostCentre as CC,
                ISNULL(SCP.DetailedDesc, 'N/A') AS Description,
                SUS.QtyReqd AS Quantity,
                ISNULL(SUS.MmsCost, 0) AS UnitCost,
                SUS.PercentUsage,
                TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SUS.MmsCost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
                '' AS Supplier
            FROM SBCES.ScPartsUsed SUS
            LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
            WHERE SUS.LinkCode = @Id AND SUS.LinkType = 'RB' AND SUS.RebuiltPart = 'Y'
            ORDER BY SUS.MMSStockCode",
                    new { Id = linkCode.ToString() });

                // STEP 7: Get Non-Stock Parts (Material Lines)
                var nonStockParts = await _dbConnection.QueryAsync<dynamic>(
                    @"
            SELECT 
                'Non-Stock' AS Type,
                NSUS.OrigSuppNum AS StockCode,
                NSUS.CostCentre as CC,

                ISNULL(NSUS.OrigSupplierName, 'N/A') AS Description,
                NSUS.QtyReqd AS Quantity,
                ISNULL(NSUS.Cost, 0) AS UnitCost,
                NSUS.PercentUsage,
                TRY_CAST(SBCES.FinalCost(CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(NSUS.Cost, 0), 0) AS DECIMAL(18,2)) AS TotalCost,
                ISNULL(NSUS.OrigSupplierName, '') AS Supplier
            FROM SBCES.NscPartsUsed NSUS
            WHERE NSUS.LinkCode = @Id AND NSUS.LinkType = 'RB'
            ORDER BY NSUS.OrigSuppNum",
                    new { Id = linkCode.ToString() });

                // STEP 8: Build the result object
                var totalCost = new TotalCostInEstimates
                {
                    LinkCode = id,

                    Keyword = rbDetails?.Keyword ?? "N/A",
                    Description = rbDetails?.Description ?? "N/A",
                    JobNumber = rbDetails?.JobNumber ?? "N/A",
                    EstimatedCost = rbDetails?.EstimatedCost ?? "N/A",
                    RBListOfBuses = rbDetails?.RBListOfBuses ?? "N/A",
                    //BuyCode = mbDetails?.BuyCode ?? "N/A",
                    //RebuildCode = mbDetails?.RebuildCode ?? "N/A",
                    //CoreCode = mbDetails?.CoreCode ?? "N/A",
                    //AnnualUsage = mbDetails?.AnnualUsage ?? "N/A",
                    //BenchNumber = mbDetails?.BenchNumber ?? "N/A",
                    //SampleProvided = mbDetails?.SampleProvided ?? "N/A",
                    //Recommendation = mbDetails?.Recommendation ?? "N/A",
                    RemanCost = rbDetails?.RemanCost ?? "N/A",
                    ExternalCost = rbDetails?.ExternalCost ?? "N/A",
                    BuyNewCost = rbDetails?.BuyNewCost ?? "N/A",
                    InternalCost = rbDetails?.InternalCost ?? "N/A",
                    SopNumber = rbDetails?.SopNumber ?? "N/A",

                    DateOpened = rbDetails?.DateOpened ?? DateTime.Now,
                   

                    // Material Costs
                    SCPartsMaterialCost = Convert.ToDecimal(materialCosts?.SCPartsMaterialCost ?? 0),
                    NSCSCPartsMaterialCost = Convert.ToDecimal(materialCosts?.NSCSCPartsMaterialCost ?? 0),
                    RBPartsMaterialCost = Convert.ToDecimal(materialCosts?.RBPartsMaterialCost ?? 0),
                    //  CoreCost = Convert.ToDecimal(materialCosts?.CoreCost ?? 0),

                    // Material Summary
                    TotalStockPartsCount = stockParts.Count(),
                    TotalNonStockPartsCount = nonStockParts.Count(),
                    TotalRebuiltPartsCount = rebuiltParts.Count(),
                };

                // Calculate material totals
                var scPartsCost = totalCost.SCPartsMaterialCost;
                var rbPartsCost = totalCost.RBPartsMaterialCost;
                var nscPartsCost = totalCost.NSCSCPartsMaterialCost;
                var materialTotalNoTax = scPartsCost + rbPartsCost + nscPartsCost;
                var taxRate = Convert.ToDecimal(labourCosts?.TaxRate ?? 0);
                var materialTax = (materialTotalNoTax * taxRate) / 100;
                var materialTotalWithTax = materialTotalNoTax + materialTax;

                totalCost.MaterialTotalCostNoTax = materialTotalNoTax;
                totalCost.MaterialTotalTaxAmount = materialTax;
                totalCost.MaterialTotalWithTax = materialTotalWithTax;

                // Calculate averages
                totalCost.AverageStockPartCost = stockParts.Any() ? Convert.ToDecimal(stockParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;
                totalCost.AverageNonStockPartCost = nonStockParts.Any() ? Convert.ToDecimal(nonStockParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;
                totalCost.AverageRebuiltPartCost = rebuiltParts.Any() ? Convert.ToDecimal(rebuiltParts.Average(p => (decimal?)p.UnitCost) ?? 0) : 0;

                // Labour Costs
                var totalLabourCost = Convert.ToDecimal(labourCosts?.TotalLabourCost ?? 0);
                var fringeRate = Convert.ToDecimal(labourCosts?.FringeRate ?? 0);
                var benefitRate = Convert.ToDecimal(labourCosts?.BenefitRate ?? 0);
                var overheadRate = Convert.ToDecimal(labourCosts?.OverheadRate ?? 0);

                var labourFringe = totalLabourCost * fringeRate;
                var labourBenefits = (totalLabourCost + labourFringe) * benefitRate;
                var blendedFringeBenefitPercent = totalLabourCost > 0 ? ((labourFringe + labourBenefits) / totalLabourCost) * 100 : 0;
                var blendedFringeBenefitCost = labourFringe + labourBenefits;
                var labourOverhead = totalLabourCost * overheadRate;
                var finalLabourCost = totalLabourCost + labourFringe + labourBenefits + labourOverhead;

                totalCost.TotalLabourCost = totalLabourCost;
                totalCost.LabourFringe = labourFringe;
                totalCost.LabourBenefits = labourBenefits;
                totalCost.BlendedFringeBenefitPercent = blendedFringeBenefitPercent;
                totalCost.BlendedFringeBenefitCost = blendedFringeBenefitCost;
                totalCost.LabourOverhead = labourOverhead;
                totalCost.FinalLabourCost = finalLabourCost;

                // Labour Hours Summary
                totalCost.LabourTasks = labourTasks.ToList();
                totalCost.TotalLabourHours = labourTasks.Sum(t => t.Hours);
                totalCost.TotalEffectiveHours = labourTasks.Sum(t => t.EffectiveHours);
                totalCost.TotalAdjustedHours = labourTasks.Sum(t => t.AdjustedHours);

                // Material Lines
                var materialLines = new List<MaterialLineItem>();
                foreach (var p in stockParts)
                {
                    materialLines.Add(new MaterialLineItem
                    {
                        Type = p.Type,
                        StockCode = p.StockCode,
                        CC = p.CC,
                        Description = p.Description,
                        Quantity = Convert.ToDecimal(p.Quantity ?? 0),
                        UnitCost = Convert.ToDecimal(p.UnitCost ?? 0),
                        PercentUsage = Convert.ToDecimal(p.PercentUsage ?? 0),
                        TotalCost = Convert.ToDecimal(p.TotalCost ?? 0),
                        Supplier = p.Supplier
                    });
                }
                foreach (var p in rebuiltParts)
                {
                    materialLines.Add(new MaterialLineItem
                    {
                        Type = p.Type,
                        StockCode = p.StockCode,
                        CC = p.CC,
                        Description = p.Description,
                        Quantity = Convert.ToDecimal(p.Quantity ?? 0),
                        UnitCost = Convert.ToDecimal(p.UnitCost ?? 0),
                        PercentUsage = Convert.ToDecimal(p.PercentUsage ?? 0),
                        TotalCost = Convert.ToDecimal(p.TotalCost ?? 0),
                        Supplier = p.Supplier
                    });
                }
                foreach (var p in nonStockParts)
                {
                    materialLines.Add(new MaterialLineItem
                    {
                        Type = p.Type,
                        StockCode = p.StockCode,
                        CC = p.CC,
                        Description = p.Description,
                        Quantity = Convert.ToDecimal(p.Quantity ?? 0),
                        UnitCost = Convert.ToDecimal(p.UnitCost ?? 0),
                        PercentUsage = Convert.ToDecimal(p.PercentUsage ?? 0),
                        TotalCost = Convert.ToDecimal(p.TotalCost ?? 0),
                        Supplier = p.Supplier
                    });
                }

                totalCost.MaterialLines = materialLines
                    .Where(m => m.TotalCost > 0)
                    .OrderBy(m => m.Type)
                    .ThenBy(m => m.StockCode)
                    .ToList();

                // Grand Totals
                totalCost.TotalWithoutTax = finalLabourCost + materialTotalNoTax;
                totalCost.TotalWithTax = finalLabourCost + materialTotalWithTax;

                result.Add(totalCost);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetTotalCostInMakeVsBuyEstimatesWithDetails: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                throw;
            }
        }

        // existing methods unchanged
        private async Task<IEnumerable<TotalCostInEstimates>> GetTotalCostInVehicleEstimates(string id, string gridType)
        {
            try
            {
                string query = " DECLARE @LinkCode VARCHAR(30) = '" + id + "'" +
                               @"
                                BEGIN TRY
                                    DECLARE @TaxRate DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'TAX_RATE'), '0'), ',', '.') AS DECIMAL(18,6));
                                    DECLARE @Fringe DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'FRINGE'), '0'), ',', '.') AS DECIMAL(18,6));
                                    DECLARE @Benefit DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'BENEFIT'), '0'), ',', '.') AS DECIMAL(18,6));
                                    DECLARE @Overhead DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'OVERHEAD'), '0'), ',', '.') AS DECIMAL(18,6));
                                    DECLARE @NonProductiveAdj DECIMAL(18,6) = TRY_CAST(REPLACE(ISNULL((SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'), ',', '.') AS DECIMAL(18,6));

                                    WITH MaterialCost AS (
                                        SELECT 
                                            ISNULL((SELECT SUM(TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SCP.MmsNewCost, 0), 0) AS DECIMAL(18,2)))
                                                    FROM SBCES.ScPartsUsed SUS
                                                    LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
                                                    WHERE SUS.LinkCode = @LinkCode AND SUS.LinkType = 'BUS' AND SUS.RebuiltPart = 'N'), 0) AS SCPartsMaterialCost,
                                            ISNULL((SELECT SUM(TRY_CAST(SBCES.FinalCost(CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(SUS.MmsCost, 0), 0) AS DECIMAL(18,2)))
                                                    FROM SBCES.ScPartsUsed SUS
                                                    LEFT JOIN SBCES.StockCodedParts SCP ON SUS.MMSStockCode = SCP.MMSStockCode
                                                    WHERE SUS.LinkCode = @LinkCode AND SUS.LinkType = 'BUS' AND SUS.RebuiltPart = 'Y'), 0) AS RBPartsMaterialCost,
                                            ISNULL((SELECT SUM(TRY_CAST(SBCES.FinalCost(CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)), CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)), ISNULL(NSUS.Cost, 0), 0) AS DECIMAL(18,2)))
                                                    FROM SBCES.NscPartsUsed NSUS 
                                                    WHERE NSUS.LinkCode = @LinkCode AND NSUS.LinkType = 'BUS'), 0) AS NSCSCPartsMaterialCost
                                    ),
                                    LabourRows AS (
                                        SELECT
                                            (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                             CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60) AS DecimalHrs,
                                            ((CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                              CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60)
                                              * CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) / 100) AS EffectiveHours,
                                            ISNULL((SELECT TOP 1 ES.RatePerHour FROM CES.SBCES.EmployeeSalaries ES
                                                    WHERE ES.WageGroup = (SELECT TOP 1 EC.WageGroup FROM CES.SBCES.EmplClass EC
                                                                          WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')), 0) AS LabourRate,
                                            (((CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                               CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60)
                                               * CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) / 100) 
                                              / @NonProductiveAdj
                                              * ISNULL((SELECT TOP 1 ES.RatePerHour FROM CES.SBCES.EmployeeSalaries ES
                                                        WHERE ES.WageGroup = (SELECT TOP 1 EC.WageGroup FROM CES.SBCES.EmplClass EC
                                                                              WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')), 0)) AS LabourCost
                                        FROM SBCES.EmployeeLabour EL
                                        WHERE EL.LinkNumber = @LinkCode AND EL.TypeId = 'BUS'
                                    ),
                                    LabourCost AS (
                                        SELECT
                                            SUM(LabourCost) AS TotalLabourCost
                                        FROM LabourRows
                                    ),
                                    FinalCalc AS (
                                        SELECT 
                                            MC.*,
                                            LC.TotalLabourCost,
                                            LC.TotalLabourCost * @Fringe AS LabourFringe,
                                            (LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit AS LabourBenefits,
                                            CASE WHEN LC.TotalLabourCost = 0 THEN 0 
                                                 ELSE ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) / LC.TotalLabourCost 
                                            END AS BlendedFringeBenefitPercent,
                                            ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) AS BlendedFringeBenefitCost,
                                            LC.TotalLabourCost * @Overhead AS LabourOverhead,
                                            LC.TotalLabourCost + ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) + (LC.TotalLabourCost * @Overhead) AS FinalLabourCost
                                        FROM MaterialCost MC
                                        CROSS JOIN LabourCost LC
                                    )
                                    SELECT
                                        @LinkCode AS LinkCode,
                                        ISNULL(MC.SCPartsMaterialCost,0) as SCPartsMaterialCost,
                                        ISNULL(MC.NSCSCPartsMaterialCost,0) as NSCSCPartsMaterialCost,
                                        ISNULL(MC.RBPartsMaterialCost,0) as RBPartsMaterialCost,
                                        CAST(ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0) AS DECIMAL(18,2)) AS MaterialTotalCostNoTax,
                                        CAST((ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0)) * @TaxRate AS DECIMAL(18,2)) AS MaterialTotalTaxAmount,
                                        CAST((ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0)) * (1 + @TaxRate) AS DECIMAL(18,2)) AS MaterialTotalWithTax,
                                        CAST(FC.TotalLabourCost AS DECIMAL(18,2)) AS TotalLabourCost,
                                        CAST(FC.LabourFringe AS DECIMAL(18,2)) AS LabourFringe,
                                        CAST(FC.LabourBenefits AS DECIMAL(18,2)) AS LabourBenefits,
                                        CAST(FC.BlendedFringeBenefitPercent * 100 AS DECIMAL(18,2)) AS BlendedFringeBenefitPercent,
                                        CAST(FC.BlendedFringeBenefitCost AS DECIMAL(18,2)) AS BlendedFringeBenefitCost,
                                        CAST(FC.LabourOverhead AS DECIMAL(18,2)) AS LabourOverhead,
                                        CAST(FC.FinalLabourCost AS DECIMAL(18,2)) AS FinalLabourCost,
                                        ISNULL((SELECT SUM(CoreCost) FROM SBCES.SCPartsUsed WHERE LinkCode = @LinkCode AND LinkType = 'BUS'), 0) AS CoreCost,
                                        CAST(FC.FinalLabourCost + (ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0)) AS DECIMAL(18,2)) AS TotalWithoutTax,
                                        CAST(FC.FinalLabourCost + ((ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0)) * (1 + @TaxRate)) AS DECIMAL(18,2)) AS TotalWithTax
                                    FROM MaterialCost MC
                                    CROSS JOIN FinalCalc FC;
                                END TRY
                                BEGIN CATCH
                                    SELECT @LinkCode AS LinkCode, 'Error: ' + ERROR_MESSAGE() AS ErrorMessage;
                                END CATCH;";

                var result = await _dbConnection.QueryAsync<TotalCostInEstimates>(query);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return null;
            }
        }
        
        //GetTotalCostInMbEstimates
        private async Task<IEnumerable<TotalCostInEstimates>> GetTotalCostInMbEstimates(string id, string gridType)
        {
            try
            {
                string query = " DECLARE @LinkCode VARCHAR(30) = '" + id + "'" +
                               @"
                              							--DECLARE @LinkCode VARCHAR(30) = 'MBH0096'
                           --    DECLARE @LinkCode VARCHAR(30) = '4352';
				 -- DECLARE @LinkCode VARCHAR(30) = '1107';
 							--DECLARE @LinkCode VARCHAR(30) = 'MBH0096'
                           --    DECLARE @LinkCode VARCHAR(30) = '4352';
				 -- DECLARE @LinkCode VARCHAR(30) = '1107';

                                 BEGIN TRY

                                     -- Get TaxRate (varchar to decimal)
                                     DECLARE @TaxRate DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'TAX_RATE'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get Fringe (varchar to decimal)
                                     DECLARE @Fringe DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'FRINGE'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get Benefit (varchar to decimal)
                                     DECLARE @Benefit DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'BENEFIT'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get Overhead (varchar to decimal)
                                     DECLARE @Overhead DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'OVERHEAD'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get NonProductiveAdjustment (varchar to decimal)
                                     DECLARE @NonProductiveAdj DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- MATERIAL COST CTE 
                              
			            WITH MaterialCost AS (

                                 SELECT 
                                     /* ============================================================
                                        SC PARTS MATERIAL COST (RebuiltPart = 'N', LinkType = 'RB')
                                        ============================================================ */
                                     (
                                         SELECT 
                                             SUM(
                                                 CASE 
                                                     WHEN SUS.RebuiltPart = 'N'
                                                          AND SUS.LinkType = 'MB'
                                                          AND SUS.LinkCode = @LinkCode
                                                     THEN TRY_CAST(
                                                             SBCES.FinalCost(
                                                                 CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)),
                                                                 CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)),
                                                                 ISNULL(SCP.MmsNewCost, 0),   
                                                                 0
                                                             ) AS DECIMAL(18,2)
                                                         )
                                                     ELSE 0 
                                                 END
                                             )
                                         FROM SBCES.ScPartsUsed SUS
                                         LEFT JOIN SBCES.StockCodedParts SCP 
                                             ON SUS.MMSStockCode = SCP.MMSStockCode
                                         WHERE SUS.LinkCode = @LinkCode
                                     ) AS SCPartsMaterialCost,

                                     /* ============================================================
                                        RB PARTS MATERIAL COST (RebuiltPart = 'Y', LinkType = 'RB')
                                        ============================================================ */
                                     (
                                         SELECT 
                                             SUM(
                                                 CASE 
                                                     WHEN SUS.RebuiltPart = 'Y'
                                                          AND SUS.LinkType = 'MB'
                                                          AND SUS.LinkCode = @LinkCode
                                                     THEN TRY_CAST(
                                                             SBCES.FinalCost(
                                                                 CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)),
                                                                 CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)),
                                                                 ISNULL(SUS.MmsCost, 0),   
                                                                 0
                                                             ) AS DECIMAL(18,2)
                                                         )
                                                     ELSE 0 
                                                 END
                                             )
                                         FROM SBCES.ScPartsUsed SUS
                                         LEFT JOIN SBCES.StockCodedParts SCP 
                                             ON SUS.MMSStockCode = SCP.MMSStockCode
                                         WHERE SUS.LinkType = 'MB'
                                           AND SUS.LinkCode = @LinkCode
                                     ) AS RBPartsMaterialCost,

                                     /* ============================================================
                                        NSC PARTS MATERIAL COST (LinkType = 'RB')
                                        ============================================================ */
                                     (
                                         SELECT 
                                             SUM(
                                                 CASE 
                                                     WHEN NSUS.LinkType = 'MB'
                                                          AND NSUS.LinkCode = @LinkCode
                                                     THEN TRY_CAST(
                                                             SBCES.FinalCost(
                                                                 CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)),
                                                                 CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)),
                                                                 ISNULL(NSUS.Cost, 0),
                                                                 0
                                                             ) AS DECIMAL(18,2)
                                                         )
                                                     ELSE 0 
                                                 END
                                             )
                                         FROM SBCES.NscPartsUsed NSUS
                                         WHERE 
					            --NSUS.LinkType = 'MB'
                                          -- AND 
					              NSUS.LinkCode = @LinkCode
                                     ) AS NSCSCPartsMaterialCost
                             ),

                                     -- Labour calculation broken into row level first
                                     LabourRows AS (
                                         SELECT
                                             -- Calculated Decimal Hrs
                                             (
                                                 CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                                 CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60
                                             ) AS DecimalHrs,

                                             -- Effective Hours
                                             (
                                                 (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                                  CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60)
                                                 * CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) / 100
                                             ) AS EffectiveHours,

                                             -- Labour Rate
                                             ISNULL((
                                                 SELECT TOP 1 ES.RatePerHour 
                                                 FROM CES.SBCES.EmployeeSalaries ES
                                                 WHERE ES.WageGroup = (
                                                     SELECT TOP 1 EC.WageGroup
                                                     FROM CES.SBCES.EmplClass EC
                                                     WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')
                                             ), 0) AS LabourRate,

                                             -- Labour Cost per row
                                             (
                                                 (
                                                     (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                                      CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60)
                                                     * CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) / 100
                                                 ) 
                                                 / @NonProductiveAdj
                                                 * ISNULL((
                                                     SELECT TOP 1 ES.RatePerHour 
                                                     FROM CES.SBCES.EmployeeSalaries ES
                                                     WHERE ES.WageGroup = (
                                                         SELECT TOP 1 EC.WageGroup
                                                         FROM CES.SBCES.EmplClass EC
                                                         WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')
                                                 ), 0)
                                             ) AS LabourCost

                                         FROM SBCES.EmployeeLabour EL
                                         WHERE 
                                          --EL.TypeId = 'MB' AND 
                                          EL.LinkNumber = @LinkCode
                                     ),

                                     LabourCost AS (
                                         SELECT
                                             SUM(LabourCost) AS TotalLabourCost
                                         FROM LabourRows
                                     ),

                                     FinalCalc AS (
                                         SELECT 
                                             MC.*,
                                             LC.TotalLabourCost,

                                             -- Calculate LabourFringe
                                             LC.TotalLabourCost * @Fringe AS LabourFringe,

                                             -- Calculate LabourBenefits
                                             (LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit AS LabourBenefits,

                                             -- Blended Fringe and Benefits %
                                             CASE WHEN LC.TotalLabourCost = 0 THEN 0 ELSE
                                             ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) / LC.TotalLabourCost
                                             END AS BlendedFringeBenefitPercent,

                                             -- Blended Fringe and Benefits Cost ($)
                                             ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) AS BlendedFringeBenefitCost,

                                             -- LabourOverhead
                                             LC.TotalLabourCost * @Overhead AS LabourOverhead,

                                             -- FinalLabourCost
                                             LC.TotalLabourCost 
                                             + ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) 
                                             + (LC.TotalLabourCost * @Overhead) AS FinalLabourCost

                                         FROM MaterialCost MC
                                         CROSS JOIN LabourCost LC
                                     )

                                     SELECT
                                         @LinkCode AS LinkCode,
								ISNULL(MC.SCPartsMaterialCost,0) as SCPartsMaterialCost,
								ISNULL(MC.NSCSCPartsMaterialCost,0) as NSCSCPartsMaterialCost,
								ISNULL(MC.RBPartsMaterialCost,0) as RBPartsMaterialCost,

                                         -- Materials:
                                         CAST(ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0) AS DECIMAL(18,2)) AS MaterialTotalCostNoTax,
                                         CAST((ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0)) * @TaxRate AS DECIMAL(18,2)) AS MaterialTotalTaxAmount,
                                         CAST((ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0)) * (1 + @TaxRate) AS DECIMAL(18,2)) AS MaterialTotalWithTax,

                                         -- Labour:
                                         CAST(FC.TotalLabourCost AS DECIMAL(18,2)) AS TotalLabourCost,
                                         CAST(FC.LabourFringe AS DECIMAL(18,2)) AS LabourFringe,
                                         CAST(FC.LabourBenefits AS DECIMAL(18,2)) AS LabourBenefits,
                                         CAST(FC.BlendedFringeBenefitPercent * 100 AS DECIMAL(18,2)) AS BlendedFringeBenefitPercent, -- percent format
                                         CAST(FC.BlendedFringeBenefitCost AS DECIMAL(18,2)) AS BlendedFringeBenefitCost,
                                         CAST(FC.LabourOverhead AS DECIMAL(18,2)) AS LabourOverhead,
                                         CAST(FC.FinalLabourCost AS DECIMAL(18,2)) AS FinalLabourCost,

                                         -- Core Cost:
                                         ISNULL((SELECT SUM(CoreCost) FROM SBCES.SCPartsUsed WHERE LinkCode = @LinkCode), 0) AS CoreCost,

                                         -- Total without Tax
                                         CAST(FC.FinalLabourCost + 
                                              (ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0))
                                         AS DECIMAL(18,2)) AS TotalWithoutTax,

                                         -- Total with Tax
                                         CAST(FC.FinalLabourCost + 
                                              ((ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0)) * (1 + @TaxRate))
                                         AS DECIMAL(18,2)) AS TotalWithTax

                                     FROM MaterialCost MC
                                     CROSS JOIN FinalCalc FC;

                                 END TRY
                                 BEGIN CATCH
                                     PRINT 'Error: ' + ERROR_MESSAGE();
                                 END CATCH;
                                  
                                  ";

                var result = await _dbConnection.QueryAsync<TotalCostInEstimates>(
                    query
                // new { id = id }
                );
                return await _dbConnection.QueryAsync<TotalCostInEstimates>(query);


            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                //throw;
                return null;
            }
        }

        private async Task<IEnumerable<TotalCostInEstimates>> GetTotalCostInArchVehicleEstimates(string id, string gridType)
        {
            try
            {
                string query = " DECLARE @ArchVehicleListId VARCHAR(30) = '" + id + "'" +
                               @"
                             --  DECLARE @LinkCode VARCHAR(30) = '4352';

BEGIN TRY

                                     -- Get TaxRate (varchar to decimal)
                                     DECLARE @TaxRate DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'TAX_RATE'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get Fringe (varchar to decimal)
                                     DECLARE @Fringe DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'FRINGE'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get Benefit (varchar to decimal)
                                     DECLARE @Benefit DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'BENEFIT'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get Overhead (varchar to decimal)
                                     DECLARE @Overhead DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'OVERHEAD'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get NonProductiveAdjustment (varchar to decimal)
                                     DECLARE @NonProductiveAdj DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- MATERIAL COST CTE (unchanged as per your request)
                                     WITH MaterialCost AS (
                                         SELECT 
                                             SUM(CASE WHEN SUS.RebuiltPart = 'N' AND SUS.LinkType = 'BUS' AND SUS.ArchVehicleListId = @ArchVehicleListId
                                                      THEN TRY_CAST(SBCES.FINALCOST(
                                                              CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)),
                                                              CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)),
                                                              ISNULL(SUS.MmsCost, 0), 0
                                                          ) AS DECIMAL(18,2))
                                                      ELSE 0 END) AS SCPartsMaterialCost,

                                             SUM(CASE WHEN SUS.RebuiltPart = 'Y' AND SUS.LinkType = 'BUS' AND SUS.ArchVehicleListId = @ArchVehicleListId
                                                      THEN TRY_CAST(SBCES.FINALCOST(
                                                              CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)),
                                                              CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)),
                                                              ISNULL(SUS.MmsCost, 0), 0
                                                          ) AS DECIMAL(18,2))
                                                      ELSE 0 END) AS RBPartsMaterialCost,

                                             SUM(CASE WHEN NSUS.LinkType = 'BUS' AND NSUS.ArchVehicleListId = @ArchVehicleListId
                                                      THEN TRY_CAST(SBCES.FINALCOST(
                                                              CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)),
                                                              CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)),
                                                              ISNULL(NSUS.Cost, 0), 0
                                                          ) AS DECIMAL(18,2))
                                                      ELSE 0 END) AS NSCSCPartsMaterialCost
                                         FROM SBCES.ArchVehScPartsUsed SUS
                                         FULL OUTER JOIN SBCES.ArchVehNscPartsUsed NSUS 
                                             ON ISNULL(SUS.CostCentre, '') = ISNULL(NSUS.CostCentre, '')
                                            AND ISNULL(SUS.LinkCode, '') = ISNULL(NSUS.LinkCode, '')
                                            AND ISNULL(SUS.LinkType, '') = ISNULL(NSUS.LinkType, '')
                                         WHERE 
                                             (SUS.LinkType = 'BUS' AND SUS.ArchVehicleListId = @ArchVehicleListId)
                                             OR (NSUS.LinkType = 'BUS' AND NSUS.ArchVehicleListId = @ArchVehicleListId)
                                     ),

                                     -- Labour calculation broken into row level first
                                     LabourRows AS (
                                         SELECT
                                             -- Calculated Decimal Hrs
                                             (
                                                 CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                                 CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60
                                             ) AS DecimalHrs,

                                             -- Effective Hours
                                             (
                                                 (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                                  CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60)
                                                 * CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) / 100
                                             ) AS EffectiveHours,

                                             -- Labour Rate
                                             ISNULL((
                                                 SELECT TOP 1 ES.RatePerHour 
                                                 FROM CES.SBCES.EmployeeSalaries ES
                                                 WHERE ES.WageGroup = (
                                                     SELECT TOP 1 EC.WageGroup
                                                     FROM CES.SBCES.EmplClass EC
                                                     WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')
                                             ), 0) AS LabourRate,

                                             -- Labour Cost per row
                                             (
                                                 (
                                                     (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                                      CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60)
                                                     * CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) / 100
                                                 ) 
                                                 / @NonProductiveAdj
                                                 * ISNULL((
                                                     SELECT TOP 1 ES.RatePerHour 
                                                     FROM CES.SBCES.EmployeeSalaries ES
                                                     WHERE ES.WageGroup = (
                                                         SELECT TOP 1 EC.WageGroup
                                                         FROM CES.SBCES.EmplClass EC
                                                         WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')
                                                 ), 0)
                                             ) AS LabourCost

                                         FROM SBCES.ArchVehEmployeeLabour EL
                                         WHERE EL.TypeId = 'BUS' AND EL.ArchVehicleListId = @ArchVehicleListId
                                     ),

                                     LabourCost AS (
                                         SELECT
                                             SUM(LabourCost) AS TotalLabourCost
                                         FROM LabourRows
                                     ),

                                     FinalCalc AS (
                                         SELECT 
                                             MC.*,
                                             LC.TotalLabourCost,

                                             -- Calculate LabourFringe
                                             LC.TotalLabourCost * @Fringe AS LabourFringe,

                                             -- Calculate LabourBenefits
                                             (LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit AS LabourBenefits,

                                             -- Blended Fringe and Benefits %
                                             CASE WHEN LC.TotalLabourCost = 0 THEN 0 ELSE
                                             ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) / LC.TotalLabourCost
                                             END AS BlendedFringeBenefitPercent,

                                             -- Blended Fringe and Benefits Cost ($)
                                             ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) AS BlendedFringeBenefitCost,

                                             -- LabourOverhead
                                             LC.TotalLabourCost * @Overhead AS LabourOverhead,

                                             -- FinalLabourCost
                                             LC.TotalLabourCost 
                                             + ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) 
                                             + (LC.TotalLabourCost * @Overhead) AS FinalLabourCost

                                         FROM MaterialCost MC
                                         CROSS JOIN LabourCost LC
                                     )

                                     SELECT
                                         @ArchVehicleListId AS ArchVehicleListId,

                                         -- Materials:
                                         CAST(MC.SCPartsMaterialCost + MC.RBPartsMaterialCost + MC.NSCSCPartsMaterialCost AS DECIMAL(18,2)) AS MaterialTotalCostNoTax,
                                         CAST((MC.SCPartsMaterialCost + MC.RBPartsMaterialCost + MC.NSCSCPartsMaterialCost) * @TaxRate AS DECIMAL(18,2)) AS MaterialTotalTaxAmount,
                                         CAST((MC.SCPartsMaterialCost + MC.RBPartsMaterialCost + MC.NSCSCPartsMaterialCost) * (1 + @TaxRate) AS DECIMAL(18,2)) AS MaterialTotalWithTax,

                                         -- Labour:
                                         CAST(FC.TotalLabourCost AS DECIMAL(18,2)) AS TotalLabourCost,
                                         CAST(FC.LabourFringe AS DECIMAL(18,2)) AS LabourFringe,
                                         CAST(FC.LabourBenefits AS DECIMAL(18,2)) AS LabourBenefits,
                                         CAST(FC.BlendedFringeBenefitPercent * 100 AS DECIMAL(18,2)) AS BlendedFringeBenefitPercent, -- percent format
                                         CAST(FC.BlendedFringeBenefitCost AS DECIMAL(18,2)) AS BlendedFringeBenefitCost,
                                         CAST(FC.LabourOverhead AS DECIMAL(18,2)) AS LabourOverhead,
                                         CAST(FC.FinalLabourCost AS DECIMAL(18,2)) AS FinalLabourCost,

                                         -- Core Cost:
                                         ISNULL((SELECT SUM(CoreCost) FROM SBCES.ArchVehScPartsUsed WHERE ArchVehicleListId = @ArchVehicleListId), 0) AS CoreCost,

                                         -- Total without Tax
                                         CAST(FC.FinalLabourCost + 
                                              (MC.SCPartsMaterialCost + MC.RBPartsMaterialCost + MC.NSCSCPartsMaterialCost)
                                         AS DECIMAL(18,2)) AS TotalWithoutTax,

                                         -- Total with Tax
                                         CAST(FC.FinalLabourCost + 
                                              ((MC.SCPartsMaterialCost + MC.RBPartsMaterialCost + MC.NSCSCPartsMaterialCost) * (1 + @TaxRate))
                                         AS DECIMAL(18,2)) AS TotalWithTax

                                     FROM MaterialCost MC
                                     CROSS JOIN FinalCalc FC;

                                 END TRY
                                 BEGIN CATCH
                                     PRINT 'Error: ' + ERROR_MESSAGE();
                                 END CATCH;
                              
                                  ";

                var result = await _dbConnection.QueryAsync<TotalCostInEstimates>(
                    query
                // new { id = id }
                );
                return await _dbConnection.QueryAsync<TotalCostInEstimates>(query);


            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                //throw;
                return null;
            }
        }

        private async Task<IEnumerable<TotalCostInEstimates>> GetTotalCostInRBEstimates(string id, string gridType)
        {
            try
            {
                var linkCode = id?.ToUpper();
                if (gridType == "RebuiltGrid")
                {
                    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                       "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                       new { Id = id }
                   );

                }

                string query = " DECLARE @LinkCode VARCHAR(30) = '" + linkCode + "'" +
                               @"
                            							--DECLARE @LinkCode VARCHAR(30) = 'MBH0096'
                           --    DECLARE @LinkCode VARCHAR(30) = '4352';
				 -- DECLARE @LinkCode VARCHAR(30) = '1107';
 							--DECLARE @LinkCode VARCHAR(30) = 'MBH0096'
                           --    DECLARE @LinkCode VARCHAR(30) = '4352';
				 -- DECLARE @LinkCode VARCHAR(30) = '1107';

                                 BEGIN TRY

                                     -- Get TaxRate (varchar to decimal)
                                     DECLARE @TaxRate DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'TAX_RATE'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get Fringe (varchar to decimal)
                                     DECLARE @Fringe DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'FRINGE'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get Benefit (varchar to decimal)
                                     DECLARE @Benefit DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'BENEFIT'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get Overhead (varchar to decimal)
                                     DECLARE @Overhead DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'OVERHEAD'), '0'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- Get NonProductiveAdjustment (varchar to decimal)
                                     DECLARE @NonProductiveAdj DECIMAL(18,6) =
                                         TRY_CAST(REPLACE(
                                             ISNULL(
                                                 (SELECT Value FROM SBCES.CESSETTINGS WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), '1'
                                             ), ',', '.') AS DECIMAL(18,6));

                                     -- MATERIAL COST CTE 
                              
			            WITH MaterialCost AS (

                                 SELECT 
                                     /* ============================================================
                                        SC PARTS MATERIAL COST (RebuiltPart = 'N', LinkType = 'RB')
                                        ============================================================ */
                                     (
                                         SELECT 
                                             SUM(
                                                 CASE 
                                                     WHEN SUS.RebuiltPart = 'N'
                                                          AND SUS.LinkType = 'RB'
                                                          AND SUS.LinkCode = @LinkCode
                                                     THEN TRY_CAST(
                                                             SBCES.FinalCost(
                                                                 CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)),
                                                                 CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)),
                                                                 ISNULL(SCP.MmsNewCost, 0),   -- << NEW COST SOURCE
                                                                 0
                                                             ) AS DECIMAL(18,2)
                                                         )
                                                     ELSE 0 
                                                 END
                                             )
                                         FROM SBCES.ScPartsUsed SUS
                                         LEFT JOIN SBCES.StockCodedParts SCP 
                                             ON SUS.MMSStockCode = SCP.MMSStockCode
                                         WHERE SUS.LinkCode = @LinkCode
                                     ) AS SCPartsMaterialCost,

                                     /* ============================================================
                                        RB PARTS MATERIAL COST (RebuiltPart = 'Y', LinkType = 'RB')
                                        ============================================================ */
                                     (
                                         SELECT 
                                             SUM(
                                                 CASE 
                                                     WHEN SUS.RebuiltPart = 'Y'
                                                          AND SUS.LinkType = 'RB'
                                                          AND SUS.LinkCode = @LinkCode
                                                     THEN TRY_CAST(
                                                             SBCES.FinalCost(
                                                                 CAST(ISNULL(SUS.PercentUsage,'0') AS VARCHAR(20)),
                                                                 CAST(ISNULL(SUS.QtyReqd,'0') AS VARCHAR(20)),
                                                                 ISNULL(SUS.MmsCost, 0),   
                                                                 0
                                                             ) AS DECIMAL(18,2)
                                                         )
                                                     ELSE 0 
                                                 END
                                             )
                                         FROM SBCES.ScPartsUsed SUS
                                         LEFT JOIN SBCES.StockCodedParts SCP 
                                             ON SUS.MMSStockCode = SCP.MMSStockCode
                                         WHERE SUS.LinkType = 'RB'
                                           AND SUS.LinkCode = @LinkCode
                                     ) AS RBPartsMaterialCost,

                                     /* ============================================================
                                        NSC PARTS MATERIAL COST (LinkType = 'RB')
                                        ============================================================ */
                                     (
                                         SELECT 
                                             SUM(
                                                 CASE 
                                                     WHEN NSUS.LinkType = 'RB'
                                                          AND NSUS.LinkCode = @LinkCode
                                                     THEN TRY_CAST(
                                                             SBCES.FinalCost(
                                                                 CAST(ISNULL(NSUS.PercentUsage,'0') AS VARCHAR(20)),
                                                                 CAST(ISNULL(NSUS.QtyReqd,'0') AS VARCHAR(20)),
                                                                 ISNULL(NSUS.Cost, 0),
                                                                 0
                                                             ) AS DECIMAL(18,2)
                                                         )
                                                     ELSE 0 
                                                 END
                                             )
                                         FROM SBCES.NscPartsUsed NSUS
                                         WHERE 
					            --NSUS.LinkType = 'RB'
                                          -- AND 
					              NSUS.LinkCode = @LinkCode
                                     ) AS NSCSCPartsMaterialCost
                             ),

                                     -- Labour calculation broken into row level first
                                     LabourRows AS (
                                         SELECT
                                             -- Calculated Decimal Hrs
                                             (
                                                 CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                                 CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60
                                             ) AS DecimalHrs,

                                             -- Effective Hours
                                             (
                                                 (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                                  CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60)
                                                 * CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) / 100
                                             ) AS EffectiveHours,

                                             -- Labour Rate
                                             ISNULL((
                                                 SELECT TOP 1 ES.RatePerHour 
                                                 FROM CES.SBCES.EmployeeSalaries ES
                                                 WHERE ES.WageGroup = (
                                                     SELECT TOP 1 EC.WageGroup
                                                     FROM CES.SBCES.EmplClass EC
                                                     WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')
                                             ), 0) AS LabourRate,

                                             -- Labour Cost per row
                                             (
                                                 (
                                                     (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), 0) AS DECIMAL(18,2)) + 
                                                      CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), 0) AS DECIMAL(18,2)) / 60)
                                                     * CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)) / 100
                                                 ) 
                                                 / @NonProductiveAdj
                                                 * ISNULL((
                                                     SELECT TOP 1 ES.RatePerHour 
                                                     FROM CES.SBCES.EmployeeSalaries ES
                                                     WHERE ES.WageGroup = (
                                                         SELECT TOP 1 EC.WageGroup
                                                         FROM CES.SBCES.EmplClass EC
                                                         WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')
                                                 ), 0)
                                             ) AS LabourCost

                                         FROM SBCES.EmployeeLabour EL
                                         WHERE 
                                          --EL.TypeId = 'MB' AND 
                                          EL.LinkNumber = @LinkCode
                                     ),

                                     LabourCost AS (
                                         SELECT
                                             SUM(LabourCost) AS TotalLabourCost
                                         FROM LabourRows
                                     ),

                                     FinalCalc AS (
                                         SELECT 
                                             MC.*,
                                             LC.TotalLabourCost,

                                             -- Calculate LabourFringe
                                             LC.TotalLabourCost * @Fringe AS LabourFringe,

                                             -- Calculate LabourBenefits
                                             (LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit AS LabourBenefits,

                                             -- Blended Fringe and Benefits %
                                             CASE WHEN LC.TotalLabourCost = 0 THEN 0 ELSE
                                             ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) / LC.TotalLabourCost
                                             END AS BlendedFringeBenefitPercent,

                                             -- Blended Fringe and Benefits Cost ($)
                                             ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) AS BlendedFringeBenefitCost,

                                             -- LabourOverhead
                                             LC.TotalLabourCost * @Overhead AS LabourOverhead,

                                             -- FinalLabourCost
                                             LC.TotalLabourCost 
                                             + ((LC.TotalLabourCost * @Fringe) + ((LC.TotalLabourCost + (LC.TotalLabourCost * @Fringe)) * @Benefit)) 
                                             + (LC.TotalLabourCost * @Overhead) AS FinalLabourCost

                                         FROM MaterialCost MC
                                         CROSS JOIN LabourCost LC
                                     )

                                     SELECT
                                         @LinkCode AS LinkCode,
								ISNULL(MC.SCPartsMaterialCost,0) as SCPartsMaterialCost,
								ISNULL(MC.NSCSCPartsMaterialCost,0) as NSCSCPartsMaterialCost,
								ISNULL(MC.RBPartsMaterialCost,0) as RBPartsMaterialCost,

                                         -- Materials:
                                         CAST(ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0) AS DECIMAL(18,2)) AS MaterialTotalCostNoTax,
                                         CAST((ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0)) * @TaxRate AS DECIMAL(18,2)) AS MaterialTotalTaxAmount,
                                         CAST((ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0)) * (1 + @TaxRate) AS DECIMAL(18,2)) AS MaterialTotalWithTax,

                                         -- Labour:
                                         CAST(FC.TotalLabourCost AS DECIMAL(18,2)) AS TotalLabourCost,
                                         CAST(FC.LabourFringe AS DECIMAL(18,2)) AS LabourFringe,
                                         CAST(FC.LabourBenefits AS DECIMAL(18,2)) AS LabourBenefits,
                                         CAST(FC.BlendedFringeBenefitPercent * 100 AS DECIMAL(18,2)) AS BlendedFringeBenefitPercent, -- percent format
                                         CAST(FC.BlendedFringeBenefitCost AS DECIMAL(18,2)) AS BlendedFringeBenefitCost,
                                         CAST(FC.LabourOverhead AS DECIMAL(18,2)) AS LabourOverhead,
                                         CAST(FC.FinalLabourCost AS DECIMAL(18,2)) AS FinalLabourCost,

                                         -- Core Cost:
                                         ISNULL((SELECT SUM(CoreCost) FROM SBCES.SCPartsUsed WHERE LinkCode = @LinkCode), 0) AS CoreCost,

                                         -- Total without Tax
                                         CAST(FC.FinalLabourCost + 
                                              (ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0))
                                         AS DECIMAL(18,2)) AS TotalWithoutTax,

                                         -- Total with Tax
                                         CAST(FC.FinalLabourCost + 
                                              ((ISNULL(MC.SCPartsMaterialCost,0) + ISNULL(MC.RBPartsMaterialCost,0) + ISNULL(MC.NSCSCPartsMaterialCost,0)) * (1 + @TaxRate))
                                         AS DECIMAL(18,2)) AS TotalWithTax

                                     FROM MaterialCost MC
                                     CROSS JOIN FinalCalc FC;

                                 END TRY
                                 BEGIN CATCH
                                     PRINT 'Error: ' + ERROR_MESSAGE();
                                 END CATCH;
                              
                                  ";

                var result = await _dbConnection.QueryAsync<TotalCostInEstimates>(
                    query
                //new { id = id }
                );
                return await _dbConnection.QueryAsync<TotalCostInEstimates>(query);

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                //throw;
                return null;
            }
        }
        //////////////////////////////////////////////////
        ///
        /// <summary>
        /// View a specific report type
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> ViewReport(string reportType, string id, [FromQuery] string gridType)
        {
            try
            {
               
                // Use your existing data method based on gridType
                IEnumerable<TotalCostInEstimates> data;

                if (gridType == "VehicleGrid")
                {
                    data = await GetTotalCostInVehicleEstimatesWithDetails(id, gridType);
                }
                else if (gridType == "MAKEVSBUY")
                {
                    data = await GetTotalCostInMakeVsBuyEstimatesWithDetails(id, gridType);
                }
                else
                {
                    return Content("Invalid grid type");
                }

                var costData = data?.FirstOrDefault();
                if (costData == null)
                {
                    return Content("No data found for the specified estimate.");
                }

                // Map data to ViewBag
                MapDataToViewBag(costData, id, gridType);

                // Return the appropriate view based on report type
                string viewName = GetReportViewName(reportType);
                return View(viewName);
            }
            catch (Exception ex)
            {
                return Content($"Error loading report: {ex.Message}");
            }
        }

        private void MapDataToViewBag(TotalCostInEstimates data, string id, string gridType)
        {
            // Vehicle/Estimate Details
            ViewBag.PartNum = id;
            ViewBag.GridType = gridType;
            ViewBag.VehicleDescription = data.VehicleDescription ?? data.Description ?? "-";
            ViewBag.VehicleSeries = data.VehicleSeries ?? "-";
            ViewBag.Make = data.Make ?? "-";
            ViewBag.Model = data.Model ?? "-";
            ViewBag.Year = data.Year.ToString() ?? "-";
            ViewBag.NumOfVehicles = data.NumOfVehicles.ToString() ?? "-";
            ViewBag.Engine = data.Engine ?? "-";
            ViewBag.Transmission = data.Transmission ?? "-";
            ViewBag.Differential = data.Differential ?? "-";
            ViewBag.ModifiedLastBy = data.ModifiedLastBy ?? "-";
            ViewBag.ModifiedLastDate = data.ModifiedLastDate.ToString("MM/dd/yyyy, hh:mm tt") ?? "-";

            // Material totals
            ViewBag.TotalParts = (data.TotalStockPartsCount) + (data.TotalNonStockPartsCount) + (data.TotalRebuiltPartsCount);
            ViewBag.TotalStockPartsCount = data.TotalStockPartsCount;
            ViewBag.TotalNonStockPartsCount = data.TotalNonStockPartsCount;
            ViewBag.TotalRebuiltPartsCount = data.TotalRebuiltPartsCount;
            ViewBag.SCPartsMaterialCost = data.SCPartsMaterialCost;
            ViewBag.NSCSCPartsMaterialCost = data.NSCSCPartsMaterialCost;
            ViewBag.RBPartsMaterialCost = data.RBPartsMaterialCost;
            ViewBag.MaterialTotalCostNoTax = data.MaterialTotalCostNoTax;
            ViewBag.MaterialTotalTaxAmount = data.MaterialTotalTaxAmount;
            ViewBag.MaterialTotalWithTax = data.MaterialTotalWithTax;

            // Labour totals
            ViewBag.TotalLabourHours = data.TotalLabourHours;
            ViewBag.TotalEffectiveHours = data.TotalEffectiveHours;
            ViewBag.TotalAdjustedHours = data.TotalAdjustedHours;
            ViewBag.LabourFringe = data.LabourFringe;
            ViewBag.LabourBenefits = data.LabourBenefits;
            ViewBag.BlendedFringeBenefitCost = data.BlendedFringeBenefitCost;
            ViewBag.LabourOverhead = data.LabourOverhead;
            ViewBag.FinalLabourCost = data.FinalLabourCost;

            // Lines
            ViewBag.MaterialLines = data.MaterialLines ?? new List<MaterialLineItem>();
            ViewBag.MaterialLinesCount = (data.MaterialLines as List<MaterialLineItem>)?.Count ?? 0;
            ViewBag.LabourTasks = data.LabourTasks ?? new List<LabourTaskSummary>();
            ViewBag.LabourTasksCount = (data.LabourTasks as List<LabourTaskSummary>)?.Count ?? 0;
        }

        private string GetReportViewName(string reportType)
        {
            switch (reportType?.ToLower())
            {
                case "full": return "~/Views/Shared/_Vehicle_FullEstimateReport.cshtml";
                case "vehicle": return "~/Views/Shared/_Vehicle_VehicleEstimateReport.cshtml";
                case "labour": return "~/Views/Shared/_Vehicle_LabourDetailsReport.cshtml";
                case "materials": return "~/Views/Shared/_Vehicle_MaterialsEstimateReport.cshtml";
                default: return "~/Views/Shared/_Vehicle_VehicleEstimateReport.cshtml";
            }
        }



        ////////////////////////
    }
}