﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Parts;
using BCES.Models.Common;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Humanizer;
using BCES.Controllers.Common;

namespace BCES.Controllers.Parts
{

    //[Route("NscPartsUsed")]
    public class NscPartsUsedController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public NscPartsUsedController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }
        // GET: NscPartsUsed/Index
        [HttpGet("NscPartsUsedIndex")]
        [AllowAnonymous]
        public IActionResult NscPartsUsedIndex()
        {
          // return View();
           return View("~/Views/Parts/NonStockCodedParts/Index.cshtml");
        }

        // POST: NscPartsUsed/GetNscPartsUsedView
        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> GetNscPartsUsedView([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid
            var model = await GetNscPartsUsedData();
           
            return Json(model.ToDataSourceResult(request));
        }

        // POST: NscPartsUsed/CreateNscPartsUsed
       [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateNscPartsUsed(NscPartsUsedViewModel nscPartsUsed)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage);

                return BadRequest(new { Errors = errors });
            }

            try
            {
                var getMaxId = @"SELECT MAX(Id) FROM CES.SBCES.NonStockCodedParts";
                int maxId = _dbConnection.QuerySingle<int>(getMaxId);

                var userName = ViewBag.UserName ?? "System";

                var insertQuery = @"
            INSERT INTO SBCES.NonStockCodedParts 
            (OrigSupplierNum, OrigSupplierName, OemPartCost, DetailedDesc, Keyword, 
             LastModifiedBy, LastModifiedDate, Id)
            VALUES 
            (@OrigSupplierNum, @OrigSupplierName, @OemPartCost, @DetailedDesc, @Keyword, 
             @LastModifiedBy, @LastModifiedDate, @Id);
        ";

                await ((IDbConnection)_dbConnection).ExecuteAsync(insertQuery, new
                {
                    OrigSupplierNum = nscPartsUsed.OrigSuppNum,
                    OrigSupplierName = nscPartsUsed.OrigSupplierName,
                    OemPartCost = nscPartsUsed.UnitCost,
                    DetailedDesc = nscPartsUsed.Description,
                    Keyword = nscPartsUsed.KeyWord,
                    LastModifiedBy = userName,
                    LastModifiedDate = DateTime.Now,
                    Id = maxId + 1
                });

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    success = false,
                    message = "An error occurred while saving the record.",
                    detail = ex.Message
                });
            }
        }

        //   public async Task<IActionResult> CreateNscPartsUsed([DataSourceRequest] DataSourceRequest request, [FromForm] NscPartsUsedViewModel nscPartsUsed)
        //public async Task<IActionResult> CreateNscPartsUsed(  NscPartsUsedViewModel nscPartsUsed)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        var errors = ModelState.Values
        //            .SelectMany(v => v.Errors)
        //            .Select(e => e.ErrorMessage);
        //        return BadRequest(new { Errors = errors });
        //    }


        //    try
        //    {
        //        var getMaxId = @"
        //                                select MAX(Id)  FROM [CES].[SBCES].[NonStockCodedParts]
        //                                ";
        //        int maxId =  _dbConnection.QuerySingle<int>(getMaxId);

        //        var userName = ViewBag.UserName ?? "System";

        //        //var insertQuery = String.Format(@"
        //        //INSERT INTO SBCES.[NonStockCodedParts] ([OrigSupplierNum], 
        //        //                 [OrigSupplierName],[OemPartCost], 
        //        //                 [DetailedDesc], [Keyword], [LastModifiedBy], LastModifiedDate, Id )
        //        //VALUES ('{0}', '{1}', {2}, '{3}', '{4}', '{5}','{6}', {7} )",
        //        //    nscPartsUsed.OrigSuppNum,
        //        //                  nscPartsUsed.OrigSupplierName,
        //        //                  nscPartsUsed.UnitCost,
        //        //                  nscPartsUsed.Description,
        //        //                   nscPartsUsed.KeyWord,
        //        //                   userName,
        //        //                   DateTime.Now,
        //        //                   maxId+1

        //        //     );

        //        var insertQuery = String.Format(@"
        //        INSERT INTO SBCES.[NonStockCodedParts] ([OrigSupplierNum], 
        //                         [OrigSupplierName],[OemPartCost], 
        //                         [DetailedDesc], [Keyword], [LastModifiedBy], LastModifiedDate, Id )
        //        VALUES ('" + nscPartsUsed.OrigSuppNum + "'," +
        //                      "'"  +  nscPartsUsed.OrigSupplierName + "'," +
        //                       "'" + nscPartsUsed.UnitCost + "'," +
        //                       "'" + nscPartsUsed.Description + "'," +
        //                       "'" + nscPartsUsed.KeyWord + "'," +
        //                        "'" + userName + "'," +
        //                       "'" + DateTime.Now + "'," +
        //                           maxId + 1

        //             );


        //        await _dbConnection.ExecuteAsync(insertQuery, nscPartsUsed);
        //        return Json(new { success = true });
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, "An error occurred while updating the Non Stock Coded Part.");
        //    }

        //}


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateNscPartsUsed( NscPartsUsedViewModel nscPartsUsed)
        {
            try
            {
                ////
                ///// Validate if OrigSupplierName exists in the database
                //bool isValid = _dbConnection.NonStockCodedParts
                //    .Any(p => p.OrigSupplierName == nscPartsUsed.OrigSupplierName);

                //if (!isValid)
                //{
                //    ModelState.AddModelError("OrigSupplierName", "Invalid selection.");
                //    return Json(ModelState.ToDataSourceResult());
                //}
                ///

                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values
                        .SelectMany(v => v.Errors)
                        .Select(e => e.ErrorMessage);
                    return BadRequest(new { Errors = errors });
                }

                string updateQuery = string.Format(@" UPDATE SBCES.[NonStockCodedParts] 
                   SET   
                   
                    [OemPartCost]= {0},
                    [DetailedDesc]='{1}',
                    [Keyword] = '{2}',                                 
                    LastModifiedBy = '{3}',
                     LastModifiedDate = '{4}'                    
                 
                     WHERE
                    [OrigSupplierNum] = '{5}'  AND
                    [OrigSupplierName] = '{6}'",
                             
                              nscPartsUsed.UnitCost,
                               nscPartsUsed.Description,
                               nscPartsUsed.KeyWord,
                              
                              ViewBag.UserName,
                              DateTime.Now,
                              nscPartsUsed.OrigSuppNum,
                              nscPartsUsed.OrigSupplierName
                              );
                
               

                await _dbConnection.ExecuteAsync(updateQuery, nscPartsUsed);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the Non Stock Coded Part.");
            }
            
        }

        [HttpPost]
        public async Task<IActionResult> DeleteNscPartsUsed(  string Id, string gridType)
        {
            try
            {


                string sql = @"DELETE FROM [CES].[SBCES].[NonStockCodedParts]
                         WHERE id =" + Id;
                 
                int affectedRows = await _dbConnection.ExecuteAsync(sql);

                if (gridType == "VehicleGrid")
                {
                    await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, Id);
                }

                 return Json(new { success = affectedRows > 0 });
                
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Delete failed: {ex.Message}");
            }
        }
        //  // DELETE: NscPartsUsed/DeleteNscPartsUsed/{id}
        ////  [HttpDelete("{id}")]
        //  [HttpPost]
        //  [AllowAnonymous]
        //  public async Task<IActionResult> DeleteNscPartsUsed([DataSourceRequest] DataSourceRequest request, NscPartsUsedViewModel nscPartsUsed)
        //  {
        //      try
        //      {
        //          var deleteQuery = String.Format(@"
        //          DELETE FROM SBCES.NscPartsUsed
        //          WHERE NscPartsUsedId  = {0}", nscPartsUsed.NscPartsUsedId);


        //          await _dbConnection.ExecuteAsync(deleteQuery, nscPartsUsed);
        //          return Json(new { success = true });
        //      }
        //      catch (Exception ex)
        //      {
        //          return StatusCode(500, "An error occurred while deleting the Non Stock Coded Part.");
        //      }

        //  }

        private async Task<IEnumerable<NscPartsUsedViewModel>> GetNscPartsUsedData()
        {
            try
            {
                var query = @"
                             
                            SELECT
                                    NSCP.Id,
                                    UPPER(NSCP.origSupplierNum) AS [OrigSuppNum],
                                    UPPER(NSCP.origSupplierName) AS [OrigSupplierName],
                                   UPPER(NSCP.[Keyword]) AS KeyWord,
                                    NSCP.oemPartCost AS [UnitCost],
                                    UPPER(NSCP.[DetailedDesc]) AS Description,
                                    [LastModifiedBy],
                                    [LastModifiedDate]
                                    
                                                                      
                                FROM
                                   
                                    SBCES.NONSTOCKCODEDPARTS NSCP 
                                   
                                    
                                Order by LastModifiedDate desc
                                                    
                                                    
                             ";

                return await _dbConnection.QueryAsync<NscPartsUsedViewModel>(query);
            }
            catch (Exception ex)
            {
                return null;
            }
            
        }

    }
}