﻿using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using BCES.Models.Parts;
using BCES.Controllers.Base;
using BCES.Data;
using System.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Data.SqlClient;
using BCES.Controllers.Common;
using static Org.BouncyCastle.Pqc.Crypto.Utilities.PqcOtherInfoGenerator;


namespace BCES.Controllers.Parts
{
    public class ScPartsUsedInEstimatesController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public ScPartsUsedInEstimatesController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> GetScPartsUsedInEstimates([DataSourceRequest] DataSourceRequest request, [FromQuery] string id, [FromQuery] string gridType)
        {
            // Fetch data for the grid
            ViewBag.ParentId = id;

            if (string.IsNullOrEmpty(id))
            {
                return BadRequest("id is required for :" + gridType);
            }
            ViewBag.ParentId = id;
            if (gridType == "RebuiltGrid")
            {
                var rbNscModel = await GetScPartsUsedInRBEstimates(id, gridType);
                return Json(rbNscModel.ToDataSourceResult(request));
            }
            if (gridType == "VehicleGrid")
            {
                var vehNscmodel = await GetScPartsUsedInVehicleEstimates(id, gridType);
                return Json(vehNscmodel.ToDataSourceResult(request));
            }
            if (gridType == "ArchivedVehicleGrid")
            {
                var vehNscmodel = await GetArchivedScPartsUsedInVehicleEstimates(id, gridType);
                return Json(vehNscmodel.ToDataSourceResult(request));
            }
            if (gridType == "MakeVsBuyGrid")
            {
                var vehNscmodel = await GetScPartsUsedInMbEstimates(id, gridType);
                return Json(vehNscmodel.ToDataSourceResult(request));
               // return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            if (gridType == "ArchivedMakeVsBuyGrid")
            {
                return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            if (gridType == "ArchivedRebuiltGrid")
            {
                return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            return StatusCode(500, "An error occurred while fetching data.");

           

        }

        private async Task<IEnumerable<StockCodedPartsViewModel>> GetArchivedScPartsUsedInVehicleEstimates(string partNum, string gridType)
        {
            try
            {
                var query = @"
                            SELECT 
                                ascp.MmsStockCode,
                                ascp.DateEntered AS LastModifiedDate,
                                ascp.RebPartCost,
                                ascp.UserEntered AS LastModifiedBy,
                                ascp.MmsCost AS UnitCost,
                                ascp.OemCost,
                                ascp.MmsRebuiltCode,
                                ascp.CostCentre,
                                ascp.QtyReqd AS Qty,
                                ascp.PercentUsage AS Percentage,
                                ascp.LinkCode,
                                ascp.RebuiltPart,
                                ascp.LinkType,
                                ascp.Corecost,
                                ascp.ArchVehicleListId,
                                ascp.TotalCost,
                                ascp.ScKeyword,
                                ascp.ScDescription,
                                scp.PartType,
                                scp.OrigSupplierName ,
                                scp.OrigSupplierNum ,
                                scp.DetailedDesc 
                            FROM 
                                CES.SBCES.ArchVehScPartsUsed AS ascp
                            JOIN 
                                SBCES.StockCodedParts AS scp ON ascp.MmsStockCode = scp.MmsStockCode
                            WHERE 
                                ascp.LinkType = 'BUS'
                                AND ascp.ArchVehicleListId = @id;";


                var parameters = new { id = partNum };

                var result = await _dbConnection.QueryAsync<StockCodedPartsViewModel>(query, parameters);


                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourDetailsData: {ex.Message}");
                throw; // Rethrow the exception for centralized handling
            }
        }
        private async Task<IEnumerable<StockCodedPartsViewModel>> GetScPartsUsedInVehicleEstimates(string id, string gridType)
        {

            try
            {
                ViewBag.ParentId = id;
                var query = @"
                             DECLARE @Id VARCHAR(30) = '" + id + "'" +
                             @"
                               
                                 SELECT 
                                SCP.Id as Id,
                                UPPER(SCP.MMSSTOCKCODE) AS MMSStockCode,
                                ISNULL(SCP.OemCost, 0) AS UnitCost,
                                ISNULL(SCP.CoreCost, 0) AS CoreCost,
                                UPPER(SCP.QTYREQD) AS Qty,
                                
                                REPLACE(SCP.PERCENTUSAGE, ',', '.') AS [Percentage],
                                ISNULL(SCP.CORECOST,0) AS CORECOST,
                                REPLACE(
                                    CAST(SBCES.FINALCOST(
                                        CAST(SCP.PERCENTUSAGE AS NUMERIC(18,2)), 
                                        CAST(SCP.QTYREQD AS NUMERIC(18,2)), 
                                        ISNULL(SCPARTS.[MmsNewCost], 0), 
                                        ISNULL(SCP.CORECOST,0)
                                    ) AS DECIMAL(18,2)), ',', '.'
                                ) AS TOTALCOST,
                                UPPER(SCP.COSTCENTRE) AS CC,
                                ISNULL(UPPER(SCPARTS.DETAILEDDESC), '') AS DetailedDesc,
                                ISNULL(UPPER(SCPARTS.PARTTYPE), '') AS PartType,
                                SCPARTS.[OrigSupplierNum] AS [OrigSupplierNum],
								 SCPARTS.[OrigSupplierName] AS [OrigSupplierName],
                                SCP.OEMCOST AS [OEM COST],
                                SCP.MMSREBUILTCODE AS MMSREBUILTCODE,
                                SCP.REBPARTCOST AS [RebuiltPartCost],
                                UPPER(SCP.REBUILTPART) AS REBUILTPART,
                                SCP.LinkCode,
                                 UPPER(SCP.LastModifiedBy) AS LastModifiedBy,
                                SCP.LastModifiedDate AS LastModifiedDate,
                                SCPARTS.OrigSupplierNum,
                                SCPARTS.OrigSupplierName
                            FROM 
                                SBCES.SCPARTSUSED SCP
                            LEFT JOIN 
                                SBCES.STOCKCODEDPARTS SCPARTS 
                                ON SCPARTS.MMSSTOCKCODE = SCP.MMSSTOCKCODE
                            WHERE 
                                SCP.LINKCODE = @Id 
                                AND SCP.LINKTYPE = 'BUS'
                                AND SCP.MMSSTOCKCODE is NOT NULL
                                AND SCP.RebuiltPart ='N'
                            ORDER BY 
                                SCP.MMSSTOCKCODE;

                                ";

                return await _dbConnection.QueryAsync<StockCodedPartsViewModel>(query);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private async Task<IEnumerable<StockCodedPartsViewModel>> GetScPartsUsedInRBEstimates(string parentId, string gridType)
        {


            try
            {
                var linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                    "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                    new { Id = parentId }

                );

                var query = @"
                             DECLARE @Id VARCHAR(30) = '" + parentId + "'" +
                             @"
                               
                                 SELECT 
                                SCP.ID as Id,
                                UPPER(SCP.MMSSTOCKCODE) AS MMSSTOCKCODE,
                                ISNULL(SCPARTS.[MmsNewCost], 0) AS UnitCost,
                                UPPER(SCP.QTYREQD) AS QTY,
                                REPLACE(SCP.PERCENTUSAGE, ',', '.') AS [Percentage],
                                ISNULL(SCP.CORECOST,0) AS CORECOST,
                                REPLACE(
                                    CAST(SBCES.FINALCOST(
                                        CAST(SCP.PERCENTUSAGE AS NUMERIC(18,2)), 
                                        CAST(SCP.QTYREQD AS NUMERIC(18,2)), 
                                        ISNULL(SCPARTS.[MmsNewCost], 0), 
                                        ISNULL(SCP.CORECOST,0)
                                    ) AS DECIMAL(18,2)), ',', '.'
                                ) AS TOTALCOST,
                                UPPER(SCP.COSTCENTRE) AS CC,
                                ISNULL(UPPER(SCPARTS.DETAILEDDESC), '') AS DetailedDesc,
                                ISNULL(UPPER(SCPARTS.PARTTYPE), '') AS PartType,
                                SCPARTS.[OrigSupplierNum] AS [OrigSupplierNum],
								 SCPARTS.[OrigSupplierName] AS [OrigSupplierName],
                                SCP.OEMCOST AS [OEM COST],
                                SCP.MMSREBUILTCODE AS MMSREBUILTCODE,
                                SCP.REBPARTCOST AS [RebuiltPartCost],
                                UPPER(SCP.REBUILTPART) AS REBUILTPART,
                                SCP.LinkCode,
                                SCP.LastModifiedBy,
								SCP.LastModifiedDate,
                                SCP.EnteredBy,
								SCP.DateEntered
                            FROM 
                                SBCES.SCPARTSUSED SCP
                            LEFT JOIN 
                                SBCES.STOCKCODEDPARTS SCPARTS 
                                ON SCPARTS.MMSSTOCKCODE = SCP.MMSSTOCKCODE
                            WHERE 
                                SCP.LINKCODE ='" + linkCode +"'" + 
                                @" 
                                AND SCP.LINKTYPE = 'RB'
                                AND SCP.RebuiltPart = 'N'
                            ORDER BY 
                                SCP.MMSSTOCKCODE;

                                ";

                return await _dbConnection.QueryAsync<StockCodedPartsViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }
        //GetScPartsUsedInMbEstimates
        private async Task<IEnumerable<StockCodedPartsViewModel>> GetScPartsUsedInMbEstimates(string id, string gridType)
        {


            try
            {

                var query = @"
                             DECLARE @Id VARCHAR(30) = '" + id + "'" +
                             @"
                               
                                 SELECT 
                                SCP.ID as Id,
                                UPPER(SCP.MMSSTOCKCODE) AS MMSSTOCKCODE,
                                ISNULL(SCPARTS.[MmsNewCost], 0) AS UnitCost,
                                UPPER(SCP.QTYREQD) AS QTY,
                                REPLACE(SCP.PERCENTUSAGE, ',', '.') AS [Percentage],
                                 ISNULL(SCP.CORECOST,0) AS CORECOST,
                                REPLACE(
                                    CAST(SBCES.FINALCOST(
                                        CAST(SCP.PERCENTUSAGE AS NUMERIC(18,2)), 
                                        CAST(SCP.QTYREQD AS NUMERIC(18,2)), 
                                        ISNULL(SCPARTS.[MmsNewCost], 0), 
                                        ISNULL(SCP.CORECOST,0)
                                    ) AS DECIMAL(18,2)), ',', '.'
                                ) AS TOTALCOST,
                                UPPER(SCP.COSTCENTRE) AS CC,
                                ISNULL(UPPER(SCPARTS.DETAILEDDESC), '') AS DESCRIPTION,
                                ISNULL(UPPER(SCPARTS.PARTTYPE), '') AS PARTTYPE,
                                SCPARTS.[OrigSupplierNum] AS [OrigSupplierNum],
								 SCPARTS.[OrigSupplierName] AS [OrigSupplierName],
                                SCP.OEMCOST AS [OEM COST],
                                SCP.MMSREBUILTCODE AS MMSREBUILTCODE,
                                SCP.REBPARTCOST AS [RebuiltPartCost],
                                UPPER(SCP.REBUILTPART) AS REBUILTPART,
                                SCP.LinkCode,
                                SCP.LastModifiedBy,
								SCP.LastModifiedDate
    
                            FROM 
                                SBCES.SCPARTSUSED SCP
                            LEFT JOIN 
                                SBCES.STOCKCODEDPARTS SCPARTS 
                                ON SCPARTS.MMSSTOCKCODE = SCP.MMSSTOCKCODE
                            WHERE 
                                SCP.LINKCODE = @Id 
                                AND SCP.LINKTYPE = 'MB'
                                AND SCP.RebuiltPart = 'N'
                               
                            ORDER BY 
                                SCP.MMSSTOCKCODE;

                                ";

                return await _dbConnection.QueryAsync<StockCodedPartsViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        //[HttpPost]
        //[AllowAnonymous]

        //public async Task<IActionResult> CreateScPartsUsedInEstimates(
        //    [FromForm] StockCodedPartsViewModel model,
        //      [FromQuery] string id,
        //      [FromQuery] string gridType)
        //{
        //    //if (!ModelState.IsValid)
        //    //{
        //    //    var errors = ModelState.Values
        //    //        .SelectMany(v => v.Errors)
        //    //        .Select(e => e.ErrorMessage);
        //    //    return BadRequest(new { Errors = errors });
        //    //}
        //    _dbConnection.Open();
        //    using var transaction = _dbConnection.BeginTransaction();

        //    try
        //    {
        //        var enteredBy = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM";
        //        var dateEntered = DateTime.Now;
        //        var linkCode = id;
        //        string linkType = ""; // gridType == "RebuiltGrid" ? "RB" : "BUS";
        //        if (gridType == "RebuiltGrid")
        //        {
        //            linkType = "RB";

        //        }
        //        if (gridType == "VehicleGrid")
        //        {
        //            linkType = "BUS";

        //        }
        //        if (gridType == "MakeVsBuyGrid")
        //        {
        //            linkType = "MB";

        //        }

        //        var isRebuiltPart = 'N';
        //        // Change in AJAX call parameters:
        //        var partData = new
        //        {
        //            id,
        //            gridType,
        //            model = new
        //            {
        //                MMSStockCode = model.MMSStockCode,
        //                CC = model.CC,
        //                Qty = model.Qty,
        //                Percentage = model.Percentage,
        //                UnitCost = model.UnitCost,
        //                CoreCost = model.CoreCost,
        //                LinkType = linkType,
        //                LinkCode = id
        //            }
        //        };

        //        //  var model = models.FirstOrDefault(); // only one model expected when Batch(false)
        //        if (model == null)
        //        {
        //            ModelState.AddModelError("", "No data submitted.");
        //            return null; ;
        //        }

        //        var mmsStockCode = model.MMSStockCode?.ToUpperInvariant();

        //        //  Duplicate check
        //        var duplicateCheckSql = @"
        //                        SELECT COUNT(*) 
        //                        FROM SBCES.SCPartsUsed 
        //                        WHERE UPPER(MMSStockCode) = @MMSStockCode
        //                          AND UPPER(LinkCode) = @LinkCode
        //                          AND UPPER(LinkType) = @LinkType";

        //        var duplicateCount = await _dbConnection.ExecuteScalarAsync<int>(
        //            duplicateCheckSql,
        //            new { MMSStockCode = mmsStockCode, LinkCode = linkCode.ToUpper(), LinkType = linkType },
        //            transaction
        //        );

        //        if (duplicateCount > 0)
        //        {
        //            //ModelState.AddModelError("MMSStockCode", $"MMSStockCode '{mmsStockCode}' already exists for this estimate.");
        //            //return BadRequest($"MMSStockCode '{mmsStockCode}' already exists for this estimate.");
        //            var msg = $"MMSStockCode '{model.MMSStockCode}' already exists for this estimate.";
        //            ModelState.AddModelError("MMSStockCode", msg);
        //            return BadRequest(msg); // triggers grid error event
        //        }

        //        var parameters = new DynamicParameters();
        //        parameters.Add("MMSStockCode", mmsStockCode);
        //        parameters.Add("CC", model.CC?.ToUpperInvariant() ?? " ");
        //        parameters.Add("CorePartNumber", model.CorePartNumber?.ToUpperInvariant() ?? " ");
        //        parameters.Add("EnteredBy", enteredBy);
        //        parameters.Add("DateEntered", dateEntered);
        //        parameters.Add("LinkCode", linkCode.ToUpper());
        //        parameters.Add("LinkType", linkType);
        //        parameters.Add("RebuiltPartNum", id);
        //        parameters.Add("IsRebuiltPart", isRebuiltPart);
        //        parameters.Add("UnitCost", model.UnitCost ?? 0m);
        //        parameters.Add("MmsNewCost", model.MmsNewCost ?? 0m);
        //        parameters.Add("CoreCost", model.CoreCost ?? 0m);
        //        parameters.Add("RebPartCost", model.PartCost ?? 0m);
        //        parameters.Add("LastModifiedBy", enteredBy);
        //        parameters.Add("LastModifiedDate", dateEntered);
        //        parameters.Add("Qty", (model.Qty));
        //        parameters.Add("Percentage", (model.Percentage));
        //        parameters.Add("OrigSupplierNum", (model.OrigSupplierNum ?? "0").ToUpperInvariant());
        //        parameters.Add("OrigSupplierName", (model.OrigSupplierName ?? "").ToUpperInvariant());
        //        parameters.Add("DetailedDesc", (model.DetailedDesc ?? "").ToUpperInvariant());
        //        parameters.Add("PartType", (model.PartType ?? "").ToUpperInvariant());

        //        var sql = @"
        //    INSERT INTO SBCES.SCPartsUsed (
        //        MMSStockCode, DateEntered, EnteredBy, MMSCost, OEMCost,
        //        LastModifiedBy, LastModifiedDate, CostCentre, QtyReqd,
        //        PercentUsage, LinkCode, RebuiltPart, LinkType, MMSRebuiltCode,
        //        CoreCost, RebPartCost, OrigSupplierName, OrigSupNum
        //    ) VALUES (
        //        UPPER(@MMSStockCode), 
        //        @LastModifiedDate, 
        //        UPPER(@LastModifiedBy),
        //        @UnitCost, 
        //        @MmsNewCost,
        //        UPPER(@LastModifiedBy), 
        //        @LastModifiedDate, 
        //        UPPER(@CC),
        //        UPPER(@Qty), 
        //        UPPER(@Percentage),
        //        UPPER(@LinkCode), 
        //        UPPER(@IsRebuiltPart), 
        //        UPPER(@LinkType),
        //        UPPER(@RebuiltPartNum), 
        //        @CoreCost,
        //        @RebPartCost,
        //        UPPER(@OrigSupplierName),
        //        UPPER(@OrigSupplierNum)                               
        //    )";

        //        await _dbConnection.ExecuteAsync(sql, parameters, transaction);
        //        transaction.Commit();

        //        if (gridType == "VehicleGrid")
        //        {
        //            await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
        //        }

        //        return StatusCode(200, $"success");
        //    }
        //    catch (SqlException sqlEx)
        //    {
        //        transaction.Rollback();
        //        ModelState.AddModelError("", $"Database error: {sqlEx.Message}");
        //        // return Json(models.ToDataSourceResult(request, ModelState));
        //        return StatusCode(500, $"failed");
        //    }
        //    catch (Exception ex)
        //    {
        //        transaction.Rollback();
        //        ModelState.AddModelError("", $"Unexpected error: {ex.Message}");
        //        //return Json(models.ToDataSourceResult(request, ModelState));
        //        return StatusCode(500, $"Action failed: {ex.Message}");
        //    }
        //}

        [HttpPost]
        public async Task<IActionResult> CreateScPartsUsedInEstimates(
    [DataSourceRequest] DataSourceRequest request,
    StockCodedPartsViewModel model,
    [FromQuery] string id,
    [FromQuery] string gridType)
        {
            if (model == null)
            {
                ModelState.AddModelError("", "No data submitted.");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
            }

            _dbConnection.Open();
            using var transaction = _dbConnection.BeginTransaction();

            try
            {
                var enteredBy = ViewBag.UserName;
                var dateEntered = DateTime.Now;
                var linkCode = id?.ToUpper(); ;

                if (gridType == "RebuiltGrid")
                {
                    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                       "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                       new { Id = id },
                       transaction
                   );
                    
                }
                


                    string linkType = gridType switch
                    {
                        "RebuiltGrid" => "RB",
                        "VehicleGrid" => "BUS",
                        "MakeVsBuyGrid" => "MB",
                        _ => ""
                    };

                var mmsStockCode = model.MMSStockCode?.ToUpperInvariant();

                // Duplicate check
                var duplicateCheckSql = @"
            SELECT COUNT(*) 
            FROM SBCES.ScPartsUsed 
            WHERE UPPER(MmsStockCode) = @MMSStockCode
              AND UPPER(LinkCode) = @LinkCode
              AND UPPER(LinkType) = @LinkType";

                var duplicateCount = await _dbConnection.ExecuteScalarAsync<int>(
                    duplicateCheckSql,
                    new { MMSStockCode = mmsStockCode, LinkCode = linkCode, LinkType = linkType },
                    transaction
                );

                if (duplicateCount > 0)
                {
                    // ModelState.AddModelError("MMSStockCode",
                    //     $"MMSStockCode '{model.MMSStockCode}' already exists for this estimate.");

                    //return Json(new[] { model }.ToDataSourceResult(request, ModelState));
                    //return Json(new { success = false, message = $"Stock code already exists for this estimate" });
                    var msg = $"Supplier Number '{model.MMSStockCode}' already exists for this estimate.";
                    ModelState.AddModelError("MMSStockCode", msg);
                    return BadRequest(msg); // triggers grid error event
                }

                var parameters = new DynamicParameters();
                parameters.Add("MMSStockCode", mmsStockCode);
                parameters.Add("LastModifiedDate", dateEntered);
                parameters.Add("LastModifiedBy", enteredBy);
                parameters.Add("UnitCost", model.UnitCost ?? 0m);
                parameters.Add("MmsNewCost", model.MmsNewCost ?? 0m);
                parameters.Add("CC", model.CC?.ToUpperInvariant());
                parameters.Add("Qty", model.Qty.ToString());
                parameters.Add("Percentage", model.Percentage.ToString());
                parameters.Add("LinkCode", linkCode); //linkCode
                parameters.Add("IsRebuiltPart", "N");
                parameters.Add("LinkType", linkType); //linkType
                parameters.Add("RebuiltPartNum", id);
                parameters.Add("CoreCost", model.CoreCost ?? 0m);
                parameters.Add("RebPartCost", model.PartCost ?? 0m);
                parameters.Add("OrigSupplierName", model.OrigSupplierName?.ToUpperInvariant());
                parameters.Add("OrigSupplierNum", model.OrigSupplierNum?.ToUpperInvariant());

                //  IMPORTANT: OUTPUT INSERTED.Id
                var sql = @"
            INSERT INTO SBCES.ScPartsUsed (
                MmsStockCode, DateEntered, EnteredBy, MmsCost, OemCost,
                LastModifiedBy, LastModifiedDate, CostCentre, QtyReqd,
                PercentUsage, LinkCode, RebuiltPart, LinkType, MmsRebuiltCode,
                CoreCost, RebPartCost, OrigSupplierName, OrigSupNum
            )
            OUTPUT INSERTED.Id
            VALUES (
                UPPER(@MMSStockCode), 
                @LastModifiedDate, 
                UPPER(@LastModifiedBy),
                @UnitCost,
                @UnitCost,                 
                UPPER(@LastModifiedBy), 
                @LastModifiedDate, 
                UPPER(@CC),
                @Qty, 
                @Percentage,
                @LinkCode,
                @IsRebuiltPart, 
                UPPER(@LinkType),
                UPPER(@RebuiltPartNum), 
                @CoreCost,
                @RebPartCost,
                UPPER(@OrigSupplierName),
                UPPER(@OrigSupplierNum)
            )";

                //  Get new Id
                var newId = await _dbConnection.ExecuteScalarAsync<int>(sql, parameters, transaction);

                model.Id = newId;
                transaction.Commit();

                //  Reload full record from DB
                var insertedItem = await _dbConnection.QueryFirstOrDefaultAsync<StockCodedPartsViewModel>(
                                    @"
                                                       SELECT 
                                SCP.ID as Id,
                                UPPER(SCP.MMSSTOCKCODE) AS MMSSTOCKCODE,
                                ISNULL(SCP.MMSCOST, 0) AS UnitCost,
                                UPPER(SCP.QTYREQD) AS QTY,
                                REPLACE(SCP.PERCENTUSAGE, ',', '.') AS [Percentage],
                                 ISNULL(SCP.CORECOST,0) AS CORECOST,
                                REPLACE(
                                    CAST(SBCES.FINALCOST(
                                        CAST(SCP.PERCENTUSAGE AS NUMERIC(18,2)), 
                                        CAST(SCP.QTYREQD AS NUMERIC(18,2)), 
                                        ISNULL(SCPARTS.[MmsNewCost], 0), 
                                        ISNULL(SCP.CORECOST,0)
                                    ) AS DECIMAL(18,2)), ',', '.'
                                ) AS TOTALCOST,
                                UPPER(SCP.COSTCENTRE) AS CC,
                                ISNULL(UPPER(SCPARTS.DETAILEDDESC), '') AS DetailedDesc,
                                ISNULL(UPPER(SCPARTS.PARTTYPE), '') AS PartType,
                                SCPARTS.[OrigSupplierNum] AS [OrigSupplierNum],
								 SCPARTS.[OrigSupplierName] AS [OrigSupplierName],
                                SCP.OEMCOST AS [OEM COST],
                                SCP.MMSREBUILTCODE AS MMSREBUILTCODE,
                                SCP.REBPARTCOST AS [RebuiltPartCost],
                                UPPER(SCP.REBUILTPART) AS REBUILTPART,
                                SCP.LinkCode,
                                SCP.LastModifiedBy,
								SCP.LastModifiedDate
                            FROM 
                                SBCES.SCPARTSUSED SCP
                            LEFT JOIN 
                                SBCES.STOCKCODEDPARTS SCPARTS 
                                ON SCPARTS.MMSSTOCKCODE = SCP.MMSSTOCKCODE
                            WHERE 
                                SCP.LINKCODE ='" +  linkCode + "'" + 
                                "  --AND SCP.LINKTYPE = 'RB'   ORDER BY           SCP.MMSSTOCKCODE; ",
                                    new { Id = newId }
                                );

                //update VehicleList table
                if (gridType == "VehicleGrid")
                {
                    await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                }

                return Json(new[] { insertedItem }.ToDataSourceResult(request, ModelState));
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                ModelState.AddModelError("", $"Error: {ex.Message}");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
            }
        }

        [AcceptVerbs("Post")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateScPartsUsedInEstimates(
    [FromForm] StockCodedPartsViewModel model,
    [FromQuery] string id,
    [FromQuery] string gridType)
        {

            var linkCode = "";

            if (gridType == "RebuiltGrid")
            {
                linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                   "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                   new { Id = id }
                   
               );
            }
            else
            {
                linkCode = id?.ToUpper();
            }

            string linkType = string.Empty;
            if (gridType == "RebuiltGrid")
            {
                linkType = "RB";
            }
            if (gridType == "VehicleGrid")
            {
                linkType = "BUS";
            }
            if (gridType == "MakeVsBuyGrid")
            {
                linkType = "MB";
            }
            //if (!ModelState.IsValid)
            //{
            //    return StatusCode(500, $"failed");
            //    // return Json(models.ToDataSourceResult(request, ModelState));
            //}
            _dbConnection.Open();
            using var transaction = _dbConnection.BeginTransaction();
            try
            {
                var enteredBy = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM";
                var dateModified = DateTime.Now.ToString();
                model.DateEntered = DateTime.Now.ToShortDateString();



                var sql = @"
                                UPDATE SBCES.SCPartsUsed 
                                SET 
                                    CostCentre ='" + model.CC + "'," +
                                "MMSCost ='" + model.UnitCost +
                                "', QtyReqd = '" + model.Qty +
                                "', PercentUsage = '" + model.Percentage +
                                "', CoreCost= '" + model.CoreCost +
                                "', LastModifiedBy = '" + model.LastModifiedBy +
                                "', LastModifiedDate = '" + dateModified +
                                "', EnteredBy ='" + model.EnteredBy +
                                "', DateEntered = '" + dateModified +
                           "' WHERE " +
                                " MMSStockCode ='" + model.MMSStockCode +
                                "' AND LinkCode ='" + linkCode +
                                "'  AND LinkType ='" + linkType + "'";
                                                 

                    await _dbConnection.ExecuteAsync(sql, null, transaction);
                


                transaction.Commit();

                if (gridType == "VehicleGrid")
                {
                    //update estimates
                    await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                }
                return StatusCode(200, $"success");
                // return Json(models.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                ModelState.AddModelError("", $"Error updating record: {ex.Message}");
                //return Json(models.ToDataSourceResult(request, ModelState));
                return StatusCode(500, $"failed");
            }
        }
        //[AcceptVerbs("Post")]
        //[AllowAnonymous]
        //public async Task<IActionResult> UpdateScPartsUsedInEstimates(
        //    [FromForm] StockCodedPartsViewModel model,
        //    [FromQuery] string id,
        //    [FromQuery] string gridType)
        //{

        //    string linkType = string.Empty;
        //    if (gridType == "RebuiltGrid")
        //    {
        //        linkType = "RB";
        //    }
        //    if (gridType == "VehicleGrid")
        //    {
        //        linkType = "BUS";
        //    }
        //    if (gridType == "MakeVsBuyGrid")
        //    {
        //        linkType = "MB";
        //    }
        //    //if (!ModelState.IsValid)
        //    //{
        //    //    return StatusCode(500, $"failed");
        //    //    // return Json(models.ToDataSourceResult(request, ModelState));
        //    //}
        //    _dbConnection.Open();
        //    using var transaction = _dbConnection.BeginTransaction();
        //    try
        //    {
        //        var enteredBy = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM";
        //        var dateModified = DateTime.Now;
        //        model.DateEntered = DateTime.Now.ToShortDateString();



        //        //foreach (var model in models)
        //        {
        //            var parameters = new DynamicParameters();
        //            parameters.Add("MMSStockCode", model.MMSStockCode?.ToUpperInvariant());
        //            parameters.Add("CC", model.CC?.ToUpperInvariant() ?? " ");
        //            parameters.Add("UnitCost", model.UnitCost ?? 0m);
        //            parameters.Add("Qty", (model.Qty));
        //            parameters.Add("Percentage", (model.Percentage));
        //            parameters.Add("CoreCost", model.CoreCost ?? 0m);
        //            parameters.Add("RebuiltPartNum", id?.ToUpperInvariant());
        //            parameters.Add("LastModifiedBy", ViewBag.UserName);
        //            parameters.Add("LastModifiedDate", DateTime.Now);
        //            parameters.Add("LinkType", linkType);
        //            parameters.Add("LinkCode", model.LinkCode);

        //            var sql = @"
        //                        UPDATE SBCES.SCPartsUsed 
        //                        SET 
        //                            CostCentre = UPPER(@CC),
        //                            MMSCost = @UnitCost,
        //                            QtyReqd = UPPER(@Qty),
        //                            PercentUsage = UPPER(@Percentage),
        //                            CoreCost = @CoreCost,
        //                            LastModifiedBy = @LastModifiedBy,
        //                            LastModifiedDate = @LastModifiedDate,
        //                            EnteredBy = @LastModifiedBy,
        //                            DateEntered = @LastModifiedDate
        //                        WHERE 
        //                            MMSStockCode = @MMSStockCode
        //                            AND LinkCode = @LinkCode
        //                            AND LinkType = @LinkType

        //                            ";

        //            await _dbConnection.ExecuteAsync(sql, parameters, transaction);
        //        }


        //        transaction.Commit();

        //        if (gridType == "VehicleGrid")
        //        {
        //            //update estimates
        //            await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
        //        }
        //        return StatusCode(200, $"success");
        //        // return Json(models.ToDataSourceResult(request));
        //    }
        //    catch (Exception ex)
        //    {
        //        transaction.Rollback();
        //        ModelState.AddModelError("", $"Error updating record: {ex.Message}");
        //        //return Json(models.ToDataSourceResult(request, ModelState));
        //        return StatusCode(500, $"failed");
        //    }
        //}


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteScPartsUsedInEstimates(
             string id,
             string partNum,
             string gridType)
        {
            try
            {
                string pid = ViewBag.PartNum;
                string pid2 = ViewBag.ParentId;
                string linkType = "";
                if (gridType == "VehicleGrid")
                    linkType = "BUS";
                else if (gridType == "RebuiltGrid")
                    linkType = "RB";
                else if (gridType == "MakeVsBuyGrid")
                    linkType = "MB";

                var linkCode = id?.ToUpper(); ;

                if (gridType == "RebuiltGrid")
                {
                    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                       "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                       new { Id = id }
                                          );

                }
                _dbConnection.Open();
                using var transaction = _dbConnection.BeginTransaction();


                string sql = @"DELETE FROM SBCES.SCPartsUsed 
                         WHERE MMSStockCode ='" + partNum + "'" +
                            " AND LinkCode = '" + linkCode + "'"  +
                            " AND LinkType ='" + linkType + "'";

                //var parameters = new 
                //{
                //    id,
                //    partNum,
                //    //linkType = gridType == "VehicleGrid" ? "BUS" : "RB"
                //};

                int affectedRows = await _dbConnection.ExecuteAsync(sql, param: null,  transaction:transaction);
                transaction.Commit();

                if (gridType == "VehicleGrid")
                {
                    await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                }

                return Json(new { success = affectedRows > 0 });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Delete failed: {ex.Message}");
            }
        }


        [AllowAnonymous]
        public async Task<IActionResult> GetScPartUsedDetail(string mmsStockCode, string vehicleListId)
        {
            try
            {
                var query = @"
            SELECT 
                scp.MMSStockCode,
                scp.PartType,
                scp.OrigSupplierNum,
                scp.OrigSupplierName,
                scp.DetailedDesc AS PartDescription,
                scp.MmsNewCost AS UnitCost,
                scp.CoreCost,
                scused.CostCentre,
                scused.QtyReqd AS Qty,
                scused.PercentUsage AS Percentage,
                scused.LastModifiedBy AS ModBy,
                scused.LastModifiedDate AS ModDate,
                dbo.FINALCOST(CAST(scused.PercentUsage AS NUMERIC(18,2)), 
                    CAST(scused.QtyReqd AS NUMERIC(18,2)), 
                    scp.MmsNewCost, 0) AS TotalCost
            FROM SBCES.SCPartsUsed scused
            INNER JOIN SBCES.StockCodedParts scp 
                ON scused.MMSStockCode = scp.MMSStockCode
            WHERE scused.MMSStockCode = @mmsStockCode 
                AND scused.LinkCode = @vehicleListId
                AND scused.LinkType = 'BUS'
                AND scused.RebuiltPart = 'N'";

                var part = await _dbConnection.QueryFirstOrDefaultAsync<StockCodedPartsViewModel>(
                    query,
                    new { mmsStockCode, vehicleListId });

                return part != null
                    ? Json(part)
                    : NotFound();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> GetScPartUsedDetail(
    [FromQuery] string mmsStockCode,
    [FromQuery] string vehicleListId,
    [FromQuery] string gridType)
        {
            try
            {
                var query = @"
            SELECT 
                scp.MMSStockCode,
                scp.PartType,
                scp.OrigSupplierNum,
                scp.OrigSupplierName,
                scp.DetailedDesc AS PartDescription,
                scp.MmsNewCost AS UnitCost,
                scused.CoreCost,  -- Changed to scused (SCPartsUsed table)
                scused.CostCentre,
                scused.QtyReqd AS Qty,
                scused.PercentUsage AS Percentage,
                scused.LastModifiedBy AS ModBy,
                scused.LastModifiedDate AS ModDate,
                dbo.FINALCOST(
                    CAST(scused.PercentUsage AS NUMERIC(18,2)), 
                    CAST(scused.QtyReqd AS NUMERIC(18,2)), 
                    scp.MmsNewCost, 0
                ) AS TotalCost
            FROM SBCES.SCPartsUsed scused
            INNER JOIN SBCES.StockCodedParts scp 
                ON scused.MMSStockCode = scp.MMSStockCode
            WHERE scused.MMSStockCode = @mmsStockCode 
                AND scused.LinkCode = @vehicleListId
                AND scused.LinkType = @linkType
                AND scused.RebuiltPart = 'N'";

                // Map gridType to database link type
                
                string linkType = "";
                if (gridType == "VehicleGrid")
                    linkType = "BUS";
                else if (gridType == "RebuiltGrid")
                    linkType = "RB";
                else if (gridType == "MakeVsBuyGrid")
                    linkType = "MB";

                var part = await _dbConnection.QueryFirstOrDefaultAsync<StockCodedPartsViewModel>(
                    query,
                    new
                    {
                        mmsStockCode,
                        vehicleListId,
                        linkType
                    });

                return part != null
                    ? Json(part)
                    : NotFound();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
