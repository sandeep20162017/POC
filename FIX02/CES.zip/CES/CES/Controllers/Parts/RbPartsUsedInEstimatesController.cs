﻿using BCES.Controllers.Base;
using BCES.Controllers.Common;
using BCES.Data;
using BCES.Models.Admin;
using BCES.Models.OEMKit;
using BCES.Models.Parts;
using Dapper;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Org.BouncyCastle.Utilities.Zlib;
using System.Data;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static Org.BouncyCastle.Pqc.Crypto.Utilities.PqcOtherInfoGenerator;
using static SQLite.SQLite3;


namespace BCES.Controllers.Parts
{
    public class RbPartsUsedInEstimatesController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public RbPartsUsedInEstimatesController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }


        [AllowAnonymous]
        [HttpPost]

        public async Task<IActionResult> CreateRbPartsUsedInEstimates(
                        [DataSourceRequest] DataSourceRequest request,
                        RebuiltPartsViewModel model,
                        [FromQuery] string id,
                        [FromQuery] string gridType

                    )
        {
            if (model == null)
            {
                ModelState.AddModelError("", "No data submitted.");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
            }

            _dbConnection.Open();
            using var transaction = _dbConnection.BeginTransaction();

            try
            {
                var enteredBy = ViewBag.UserName;
                var dateEntered = DateTime.Now;
                var linkCode = id?.ToUpper();

                if (gridType == "RebuiltGrid")
                {
                    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                       "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                       new { Id = id },
                       transaction
                   );
                    //linkCode = id?.ToUpper();
                }



                string linkType = gridType switch
                {
                    "RebuiltGrid" => "RB",
                    "VehicleGrid" => "BUS",
                    "MakeVsBuyGrid" => "MB",
                    _ => ""
                };

                //    var mmsStockCode = model.MmsStockCode?.ToUpperInvariant();

                //    // Duplicate check
                //    var duplicateCheckSql = @"
                //SELECT COUNT(*) 
                //FROM SBCES.ScPartsUsed 
                //WHERE UPPER(MmsStockCode) = @MMSStockCode
                //  AND UPPER(LinkCode) = @LinkCode
                //  AND UPPER(LinkType) = @LinkType"
                //   ;

                //    var duplicateCount = await _dbConnection.ExecuteScalarAsync<int>(
                //        duplicateCheckSql,
                //        new { MMSStockCode = mmsStockCode, LinkCode = linkCode, LinkType = linkType },
                //        transaction
                //    );

                //    if (duplicateCount > 0)
                //    {
                //        // ModelState.AddModelError("MMSStockCode",
                //        //     $"MMSStockCode '{model.MMSStockCode}' already exists for this estimate.");

                //        //return Json(new[] { model }.ToDataSourceResult(request, ModelState));
                //        //return Json(new { success = false, message = $"Stock code already exists for this estimate" });
                //        var msg = $"MmsStockCode '{model.MmsStockCode}' already exists for this estimate.";
                //        ModelState.AddModelError("MMSStockCode", msg);
                //        return BadRequest(msg); // triggers grid error event
                //    }
                var mmsStockCode = model.MmsStockCode;
                if (gridType == "VehicleGrid" || gridType == "MakeVsBuyGrid")
                {
                    mmsStockCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                      "SELECT MmsStockCode from SBCES.RbMasterlist where RebuiltStockNum = '" + model.RebuiltStockNum + "'",

                      new { Id = id },
                      transaction
                    );
                }

                var parameters = new DynamicParameters();
                parameters.Add("MMSStockCode", mmsStockCode);
                parameters.Add("LastModifiedDate", dateEntered);
                parameters.Add("DateEntered", dateEntered);
                parameters.Add("LastModifiedBy", enteredBy);
                parameters.Add("EnteredBy", enteredBy);
                parameters.Add("UnitCost", model.UnitCost ?? 0m);
                parameters.Add("MmsNewCost", model.SCMmsNewCost);
                parameters.Add("CC", model.CostCentre?.ToUpperInvariant());
                parameters.Add("Qty", model.Qty.ToString());
                parameters.Add("Percentage", model.Percentage.ToString());
                parameters.Add("LinkCode", linkCode); //linkCode
                parameters.Add("IsRebuiltPart", "Y");
                parameters.Add("LinkType", linkType); //linkType
                parameters.Add("MmsRebuiltCode", model.RebuiltStockNum); //linkCode
                parameters.Add("RebuiltPartNum", linkCode);
                parameters.Add("CoreCost", model.CoreCharge);
                parameters.Add("RebPartCost", model.SCOemPartCost);
                parameters.Add("OrigSupplierName", model.SCOrigSupplierName);
                parameters.Add("OrigSupplierNum", model.SCOrigSupplierNum);


                var sql = @"
                        INSERT INTO SBCES.SCPartsUsed (
                            MMSStockCode, DateEntered, EnteredBy, MMSCost, OEMCost,
                            LastModifiedBy, LastModifiedDate, CostCentre, QtyReqd,
                            PercentUsage, LinkCode, RebuiltPart, MmsRebuiltCode, LinkType, 
                            CoreCost, RebPartCost
                        ) VALUES (
                            UPPER(@MMSStockCode), 
                            @DateEntered, 
                            UPPER(@EnteredBy),
                            @UnitCost, 
                            @MmsNewCost,
                            UPPER(@EnteredBy), 
                            @DateEntered, 
                            UPPER(@CC),
                            UPPER(@Qty), 
                            UPPER(@Percentage),
                            UPPER(@LinkCode), 
                            UPPER(@IsRebuiltPart), 

                            UPPER(@MmsRebuiltCode),

                            UPPER(@LinkType),
    
                            @CoreCost,
                            @RebPartCost
                         )
                    ";
                //  Get new Id
                var newId = await _dbConnection.ExecuteScalarAsync<int>(sql, parameters, transaction);

                // model.id = newId;
                transaction.Commit();

                //  Reload full record from DB
                //var linkCode = "DECLARE @LinkCode VARCHAR(50) = '" + id + "';";
                if (gridType == "VehicleGrid")
                {
                    var insertedItem = "DECLARE @LinkCode VARCHAR(50) = '" + linkCode + "';" + @"


                        DECLARE @LinkType VARCHAR(50) = '" + linkType + "';" + @"

                        PRINT 'Starting Final Cost Calculation using CTEs...';

                        -- ============================
                        -- CTE: RBCost
                        -- ============================
                        WITH RBCost AS (
                            SELECT
                                scpu.MmsRebuiltCode,
                                SUM(
                                    (scpu.PercentUsage / 100.0) * scpu.QtyReqd * (scpu.MmsCost - ISNULL(scpu.CoreCost, 0))
                                ) AS TotalCost
                            FROM SBCES.ScPartsUsed scpu
                            WHERE scpu.LinkCode = @LinkCode
                              AND scpu.RebuiltPart = 'Y'
                              AND scpu.LinkType = @LinkType
                            GROUP BY scpu.MmsRebuiltCode
                        )

                        -- ============================
                        -- FINAL SELECT
                        -- ============================
                        SELECT
                            scpu.Id AS RebuiltId,
                            UPPER(rb.MmsStockCode) AS MmsStockCode,
                            UPPER(rb.RebuiltStockNum) AS RebuiltStockNum,
                            UPPER(rb.JobNumber) AS JobNumber,
                            UPPER(rb.Keyword) AS KeyWord,
                            UPPER(rb.DetailedDesc) AS Description,
                            UPPER(rb.CoreCharge) AS CoreCharge,
                            UPPER(rb.CorePartNum) AS CorePartNum,
                            UPPER(rb.SopNumber) AS SopNumber,

                            scpu.MmsCost AS UnitCost,
                            scpu.QtyReqd AS Qty,
                            scpu.PercentUsage AS Percentage,

                            -- Corrected: use RBCost CTE
                            ISNULL(rbc.TotalCost, 0) AS TotalCost,

                            UPPER(rb.RemanCost) AS RemanCost,
                            UPPER(rb.ExternalCost) AS ExternalCost,
                            rb.Active
                        FROM SBCES.ScPartsUsed scpu
                        LEFT JOIN SBCES.RBMasterlist rb
                            ON rb.RebuiltStockNum = scpu.MmsRebuiltCode
                        LEFT JOIN RBCost rbc
                            ON rbc.MmsRebuiltCode = scpu.MmsRebuiltCode
                        WHERE scpu.LinkCode = @LinkCode
                          AND scpu.RebuiltPart = 'Y'
                          AND scpu.LinkType = @LinkType
                        ORDER BY rb.RebuiltStockNum;

                        PRINT 'Query execution completed.';

                ";

                    //return Json(new[] { insertedItem }.ToDataSourceResult(request, ModelState));
                    var result = await _dbConnection.QueryAsync<RebuiltPartsViewModel>(insertedItem);
                    var json = Json(result);
                    return json;
                }

                if (gridType == "MakeVsBuyGrid")
                {
                    linkCode = "DECLARE @LinkCode VARCHAR(50) = '" + id + "';";
                    var insertedItem = linkCode + @"
                           
                        DECLARE @LinkType VARCHAR(50) = 'MB';

                        PRINT 'Starting Final Cost Calculation using CTEs...';

                        -- ============================
                        -- CTE: RBCost
                        -- ============================
                        WITH RBCost AS (
                            SELECT
                                scpu.MmsRebuiltCode,
                                SUM(
                                    (scpu.PercentUsage / 100.0) * scpu.QtyReqd * (scpu.MmsCost - ISNULL(scpu.CoreCost, 0))
                                ) AS TotalCost
                            FROM SBCES.ScPartsUsed scpu
                            WHERE scpu.LinkCode = @LinkCode
                              AND scpu.RebuiltPart = 'Y'
                              AND scpu.LinkType = @LinkType
                            GROUP BY scpu.MmsRebuiltCode
                        )

                        -- ============================
                        -- FINAL SELECT
                        -- ============================
                        SELECT
                            scpu.Id AS RebuiltId,
                            UPPER(rb.MmsStockCode) AS MmsStockCode,
                            UPPER(rb.RebuiltStockNum) AS RebuiltStockNum,
                            UPPER(rb.JobNumber) AS JobNumber,
                            UPPER(rb.Keyword) AS KeyWord,
                            UPPER(rb.DetailedDesc) AS Description,
                            UPPER(rb.CoreCharge) AS CoreCharge,
                            UPPER(rb.CorePartNum) AS CorePartNum,
                            UPPER(rb.SopNumber) AS SopNumber,

                            scpu.MmsCost AS UnitCost,
                            scpu.QtyReqd AS Qty,
                            scpu.PercentUsage AS Percentage,

                            -- Corrected: use RBCost CTE
                            ISNULL(rbc.TotalCost, 0) AS TotalCost,

                           UPPER(ISNULL(rb.RemanCost,0)) AS RemanCost,
                            UPPER(ISNULL(rb.ExternalCost,0)) AS ExternalCost,
                            rb.Active
                        FROM SBCES.ScPartsUsed scpu
                        LEFT JOIN SBCES.RBMasterlist rb
                            ON rb.RebuiltStockNum = scpu.MmsRebuiltCode
                        LEFT JOIN RBCost rbc
                            ON rbc.MmsRebuiltCode = scpu.MmsRebuiltCode
                        WHERE scpu.LinkCode = @LinkCode
                          AND scpu.RebuiltPart = 'Y'
                          AND scpu.LinkType = @LinkType
                        ORDER BY rb.RebuiltStockNum;

                        PRINT 'Query execution completed.';

                ";
                    //var result = new[] { insertedItem }.ToDataSourceResult(request, ModelState);

                    //var json = Json(result);

                    // 
                    //return json;
                    var result = await _dbConnection.QueryAsync<RebuiltPartsViewModel>(insertedItem);
                    var json = Json(result);
                    return json;

                    //    return Json(new[] { insertedItem }.ToDataSourceResult(request, ModelState));
                }
                //update VehicleList table
                if (gridType == "VehicleGrid")
                {
                    await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                }
                               

                    return Json(new { success = true });
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                ModelState.AddModelError("", $"Error: {ex.Message}");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
            }
        }



        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> GetRbPartsUsedInEstimates([DataSourceRequest] DataSourceRequest request, RebuiltPartsViewModel model, [FromQuery] string id, [FromQuery] string gridType)
        {
            // Fetch data for the grid

            if (string.IsNullOrEmpty(id))
            {
                return BadRequest("id is required for :" + gridType);
            }

            if (gridType == "RebuiltGrid")
            {
                var rbNscModel = await GetRbPartsUsedInRBEstimates(model, id, gridType);
                return Json(rbNscModel.ToDataSourceResult(request));
            }
            if (gridType == "VehicleGrid")
            {
                var vehNscmodel = await GetRbPartsUsedInVehicleEstimates(model, id, gridType);
                return Json(vehNscmodel.ToDataSourceResult(request));
            }
            if (gridType == "ArchivedVehicleGrid")
            {
                var vehNscmodel = await GetArchivedRbPartsUsedInVehicleEstimates(id, gridType);
                return Json(vehNscmodel.ToDataSourceResult(request));
            }
            if (gridType == "MakeVsBuyGrid")
            {
                var vehNscmodel = await GetRbPartsUsedInMbEstimates(model, id, gridType);
                return Json(vehNscmodel.ToDataSourceResult(request));
                //return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            if (gridType == "ArchivedMakeVsBuyGrid")
            {
                return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            if (gridType == "ArchivedRebuiltGrid")
            {
                return StatusCode(500, "An error occurred while fetching data. Implement this.");
            }
            return StatusCode(500, "An error occurred while fetching data.");


        }

        private async Task<IEnumerable<RebuiltPartsViewModel>> GetArchivedRbPartsUsedInVehicleEstimates(string partNum, string gridType)
        {
            try
            {
                var query = @"
                           SELECT 
                                ascp.MmsStockCode,
                                ascp.DateEntered AS LastModifiedDate,
                                ascp.RebPartCost,
                                ascp.UserEntered AS LastModifiedBy,
                                ascp.MmsCost AS UnitCost,
                                ascp.OemCost,
                                ascp.MmsRebuiltCode,
                                ascp.CostCentre,
                                ascp.QtyReqd AS Qty,
                                ascp.PercentUsage AS Percentage,
                                ascp.LinkCode,
                                ascp.RebuiltPart,
                                ascp.LinkType,
                                ascp.Corecost,
                                ascp.ArchVehicleListId,
                                ascp.TotalCost,
                                ascp.ScKeyword,
                                ascp.ScDescription,
                                scp.PartType,
                                scp.OrigSupplierName ,
                                scp.OrigSupplierNum ,
                                scp.DetailedDesc 
                            FROM 
                                CES.SBCES.ArchVehScPartsUsed AS ascp
                            JOIN 
                                SBCES.StockCodedParts AS scp ON ascp.MmsStockCode = scp.MmsStockCode
                            WHERE 
                                ascp.LinkType = 'BUS'
                                AND ascp.RebuiltPart = 'Y'
                                AND ascp.ArchVehicleListId = @id";


                var parameters = new { id = partNum };

                var result = await _dbConnection.QueryAsync<RebuiltPartsViewModel>(query, parameters);


                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetLabourDetailsData: {ex.Message}");
                throw; // Rethrow the exception for centralized handling
            }
        }

        [AllowAnonymous]
        private async Task<IEnumerable<RebuiltPartsViewModel>> GetRbPartsUsedInVehicleEstimates(RebuiltPartsViewModel model, string id, string gridType)
        {

            try
            {
                var linkCode = "DECLARE @LinkCode VARCHAR(50) = '" + id + "';";
                var query = linkCode + @"
                           
                        DECLARE @LinkType VARCHAR(50) = 'BUS';

                        PRINT 'Starting Final Cost Calculation using CTEs...';

                        -- ============================
                        -- CTE: RBCost
                        -- ============================
                        WITH RBCost AS (
                            SELECT
                                scpu.MmsRebuiltCode,
                                SUM(
                                    (scpu.PercentUsage / 100.0) * scpu.QtyReqd * (scpu.MmsCost - ISNULL(scpu.CoreCost, 0))
                                ) AS TotalCost
                            FROM SBCES.ScPartsUsed scpu
                            WHERE scpu.LinkCode = @LinkCode
                              AND scpu.RebuiltPart = 'Y'
                              AND scpu.LinkType = @LinkType
                            GROUP BY scpu.MmsRebuiltCode
                        )

                        -- ============================
                        -- FINAL SELECT
                        -- ============================
                        SELECT
                            scpu.Id AS RebuiltId,
                            UPPER(rb.MmsStockCode) AS MmsStockCode,
                            UPPER(rb.RebuiltStockNum) AS RebuiltStockNum,
                            UPPER(rb.JobNumber) AS JobNumber,
                            UPPER(rb.Keyword) AS KeyWord,
                            UPPER(rb.DetailedDesc) AS Description,
                            UPPER(rb.CoreCharge) AS CoreCharge,
                            UPPER(rb.CorePartNum) AS CorePartNum,
                            UPPER(rb.SopNumber) AS SopNumber,

                            scpu.MmsCost AS UnitCost,
                            scpu.QtyReqd AS Qty,
                            scpu.PercentUsage AS Percentage,

                            -- Corrected: use RBCost CTE
                            ISNULL(rbc.TotalCost, 0) AS TotalCost,

                            UPPER(rb.RemanCost) AS RemanCost,
                            UPPER(rb.ExternalCost) AS ExternalCost,
                            rb.Active,
                            scpu.LastModifiedBy  as LastModifiedBy,
							scpu.LastModifiedDate as LastModifiedDate
                        FROM SBCES.ScPartsUsed scpu
                        LEFT JOIN SBCES.RBMasterlist rb
                            ON rb.RebuiltStockNum = scpu.MmsRebuiltCode
                        LEFT JOIN RBCost rbc
                            ON rbc.MmsRebuiltCode = scpu.MmsRebuiltCode
                        WHERE scpu.LinkCode = @LinkCode
                          AND scpu.RebuiltPart = 'Y'
                          AND scpu.LinkType = @LinkType
                        ORDER BY rb.RebuiltStockNum;

                        PRINT 'Query execution completed.';

                ";

                return await _dbConnection.QueryAsync<RebuiltPartsViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        //GetRbPartsUsedInVehicleMbEstimates
        private async Task<IEnumerable<RebuiltPartsViewModel>> GetRbPartsUsedInMbEstimates(RebuiltPartsViewModel model, string id, string gridType)
        {

            try
            {
                var linkCode = "DECLARE @LinkCode VARCHAR(50) = '" + id + "';";
                var query = linkCode + @"
                           
                        DECLARE @LinkType VARCHAR(50) = 'MB';

                        PRINT 'Starting Final Cost Calculation using CTEs...';

                        -- ============================
                        -- CTE: RBCost
                        -- ============================
                        WITH RBCost AS (
                            SELECT
                                scpu.MmsRebuiltCode,
                                SUM(
                                    (scpu.PercentUsage / 100.0) * scpu.QtyReqd * (scpu.MmsCost - ISNULL(scpu.CoreCost, 0))
                                ) AS TotalCost
                            FROM SBCES.ScPartsUsed scpu
                            WHERE scpu.LinkCode = @LinkCode
                              AND scpu.RebuiltPart = 'Y'
                              AND scpu.LinkType = @LinkType
                            GROUP BY scpu.MmsRebuiltCode
                        )

                        -- ============================
                        -- FINAL SELECT
                        -- ============================
                        SELECT
                            scpu.Id AS RebuiltId,
                            UPPER(rb.MmsStockCode) AS MmsStockCode,
                            UPPER(rb.RebuiltStockNum) AS RebuiltStockNum,
                            UPPER(rb.JobNumber) AS JobNumber,
                            UPPER(rb.Keyword) AS KeyWord,
                            UPPER(rb.DetailedDesc) AS Description,
                            UPPER(rb.CoreCharge) AS CoreCharge,
                            UPPER(rb.CorePartNum) AS CorePartNum,
                            UPPER(rb.SopNumber) AS SopNumber,

                            scpu.MmsCost AS UnitCost,
                            scpu.QtyReqd AS Qty,
                            scpu.PercentUsage AS Percentage,

                            -- Corrected: use RBCost CTE
                            ISNULL(rbc.TotalCost, 0) AS TotalCost,

                            UPPER(rb.RemanCost) AS RemanCost,
                            UPPER(rb.ExternalCost) AS ExternalCost,
                            rb.Active,
                            	scpu.LastModifiedBy  as LastModifiedBy,
							scpu.LastModifiedDate as LastModifiedDate
                        FROM SBCES.ScPartsUsed scpu
                        LEFT JOIN SBCES.RBMasterlist rb
                            ON rb.RebuiltStockNum = scpu.MmsRebuiltCode
                        LEFT JOIN RBCost rbc
                            ON rbc.MmsRebuiltCode = scpu.MmsRebuiltCode
                        WHERE scpu.LinkCode = @LinkCode
                          AND scpu.RebuiltPart = 'Y'
                          AND scpu.LinkType = @LinkType
                        ORDER BY rb.RebuiltStockNum;

                        PRINT 'Query execution completed.';

                ";

                return await _dbConnection.QueryAsync<RebuiltPartsViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }
        [AllowAnonymous]
        private async Task<IEnumerable<RebuiltPartsViewModel>> GetRbPartsUsedInRBEstimates(RebuiltPartsViewModel model, string id, string gridType)
        {

            try
            {
                //link to actual rbid
                var linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                    "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                    new { Id = id }

                );

                var query = @"DECLARE @LinkCode VARCHAR(50) ='" + linkCode + "';" +


                    @"
                            DECLARE @LinkType VARCHAR(50) = 'RB';

                            PRINT 'Starting Final Cost Calculation using CTEs...';

                            -- ============================
                            -- CTE: RBCost
                            -- ============================
                            WITH RBCost AS (
                                SELECT
                                    scpu.MmsRebuiltCode,
                                    SUM(
                                        (scpu.PercentUsage / 100.0) * scpu.QtyReqd * (scpu.MmsCost - ISNULL(scpu.CoreCost, 0))
                                    ) AS TotalCost
                                FROM SBCES.ScPartsUsed scpu
                                WHERE scpu.LinkCode = @LinkCode
                                  AND scpu.RebuiltPart = 'Y'
                                  AND scpu.LinkType = 'RB'
                                GROUP BY scpu.MmsRebuiltCode
                            )

                            -- ============================
                            -- FINAL SELECT
                            -- ============================
                            SELECT
                                scpu.Id AS RebuiltId,
                                UPPER(rb.MmsStockCode) AS MmsStockCode,
                                UPPER(rb.RebuiltStockNum) AS RebuiltStockNum,
                                UPPER(rb.JobNumber) AS JobNumber,
                                UPPER(rb.Keyword) AS KeyWord,
                                UPPER(rb.DetailedDesc) AS Description,
                                UPPER(rb.CoreCharge) AS CoreCharge,
                                UPPER(rb.CorePartNum) AS CorePartNum,
                                UPPER(rb.SopNumber) AS SopNumber,

                                scpu.MmsCost AS UnitCost,
                                scpu.QtyReqd AS Qty,
                                scpu.PercentUsage AS Percentage,

                                -- Corrected: use RBCost CTE
                                ISNULL(rbc.TotalCost, 0) AS TotalCost,

                                UPPER(rb.RemanCost) AS RemanCost,
                                UPPER(rb.ExternalCost) AS ExternalCost,
                                rb.Active
                            FROM SBCES.ScPartsUsed scpu
                            LEFT JOIN SBCES.RBMasterlist rb
                                ON rb.RebuiltStockNum = scpu.MmsRebuiltCode
                            LEFT JOIN RBCost rbc
                                ON rbc.MmsRebuiltCode = scpu.MmsRebuiltCode
                            WHERE scpu.LinkCode = @LinkCode
                              AND scpu.RebuiltPart = 'Y'
                              AND scpu.LinkType = 'RB'
                            ORDER BY rb.RebuiltStockNum;

                            PRINT 'Query execution completed.';

                             
                             
                             ";

                return await _dbConnection.QueryAsync<RebuiltPartsViewModel>(query);

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateRbPartsUsedInRbEstimates(
           [DataSourceRequest] DataSourceRequest request,
           RebuiltPartsViewModel model,
           // RebuiltPartsViewModel model,
           [FromQuery] string id,
           [FromQuery] string gridType)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage);
                return BadRequest(new { Errors = errors });
            }

            _dbConnection.Open();

            using var transaction = _dbConnection.BeginTransaction();
            try
            {
                // Get values from ViewBag and system
                var enteredBy = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM";
                var dateEntered = DateTime.Now;
                var linkCode = id;// ViewBag.MMsCode?.ToString().ToUpper() ?? "DEFAULT_CODE";

                var isRebuiltPart = "Y";

                string linkType = ""; // gridType == "RebuiltGrid" ? "RB" : "BUS";
                if (gridType == "RebuiltGrid")
                {
                    linkType = "RB";
                    linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                       "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                       new { Id = id }

                        );

                }
                if (gridType == "VehicleGrid")
                {
                    linkType = "BUS";

                }
                if (gridType == "MakeVsBuyGrid")
                {
                    linkType = "MB";

                }
                //////////////////////


                //  Duplicate check
                var duplicateCheckSql = @"
                                SELECT COUNT(*) 
                                FROM SBCES.SCPartsUsed 
                                WHERE UPPER(MMSStockCode) = @MMSStockCode
                                  AND UPPER(LinkCode) = @LinkCode
                                  AND UPPER(LinkType) = @LinkType";

                var duplicateCount = await _dbConnection.ExecuteScalarAsync<int>(
                    duplicateCheckSql,
                    new { MMSStockCode = model.MmsStockCode, LinkCode = linkCode.ToUpper(), LinkType = linkType },
                    transaction
                );

                if (duplicateCount > 0)
                {
                    //ModelState.AddModelError("MMSStockCode", $"MMSStockCode '{mmsStockCode}' already exists for this estimate.");
                    //return BadRequest($"MMSStockCode '{mmsStockCode}' already exists for this estimate.");
                    var msg = $"Rebuilt Stock Number '{model.RebuiltStockNum}' already exists for this estimate.";
                    ModelState.AddModelError("RebuiltStockNum", msg);
                    return BadRequest(msg); // triggers grid error event
                }


                /////////////////////

                //foreach (var model in models)
                {
                    var parameters = new DynamicParameters();

                    // Convert all string values to uppercase
                    parameters.Add("MMSStockCode", model.MmsStockCode);

                    parameters.Add("CorePartNumber", model.CorePartNum?.ToUpperInvariant() ?? " ");
                    parameters.Add("EnteredBy", enteredBy);
                    parameters.Add("DateEntered", dateEntered);
                    parameters.Add("LinkCode", linkCode);
                    parameters.Add("LinkType", linkType);
                    parameters.Add("RebuiltPartNum", model.RebuiltStockNum);
                    parameters.Add("IsRebuiltPart", isRebuiltPart);
                    parameters.Add("MmsRebuiltCode", model.MmsRebuiltCode);

                    // Decimal values with defaults
                    parameters.Add("UnitCost", model.UnitCost);
                    parameters.Add("MmsNewCost", model.BuyNewCost);
                    parameters.Add("CoreCost", model.CoreCharge);
                    parameters.Add("RebPartCost", model.UnitCost);
                    parameters.Add("CC", model.CostCentre);



                    parameters.Add("Qty", model.Qty);
                    parameters.Add("Percentage", model.Percentage);

                    var sql = @"
                            INSERT INTO SBCES.SCPartsUsed (
                                MMSStockCode, DateEntered, EnteredBy, MMSCost, OEMCost,
                                LastModifiedBy, LastModifiedDate, CostCentre, QtyReqd,
                                PercentUsage, LinkCode, RebuiltPart, MmsRebuiltCode, LinkType, MMSRebuiltCode,
                                CoreCost, RebPartCost
                            ) VALUES (
                                UPPER(@MMSStockCode), 
                                @DateEntered, 
                                UPPER(@EnteredBy),
                                @UnitCost, 
                                @MmsNewCost,
                                UPPER(@EnteredBy), 
                                @DateEntered, 
                                UPPER(@CC),
                                UPPER(@Qty), 
                                UPPER(@Percentage),
                                UPPER(@LinkCode), 
                                UPPER(@IsRebuiltPart), 

                                UPPER(@MmsRebuiltCode),

                                UPPER(@LinkType),
                                UPPER(@RebuiltPartNum), 
                                @CoreCost,
                                @RebPartCost
                            )";

                    var result = await _dbConnection.ExecuteAsync(sql, parameters, transaction);



                    transaction.Commit();

                    if (gridType == "VehicleGrid")
                    {
                        //update estimates
                        await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                    }



                }
                return Json(new[] { model }.ToDataSourceResult(request));

            }
            catch (SqlException sqlEx)
            {
                transaction.Rollback();
                ModelState.AddModelError("", $"Database error: {sqlEx.Message}");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
                // return Json(models.ToDataSourceResult(request, ModelState));
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                ModelState.AddModelError("", $"Unexpected error: {ex.Message}");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
                //  return Json(models.ToDataSourceResult(request, ModelState));
            }
        }

        [AcceptVerbs("Post")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateRbPartsUsedInEstimates(
                                                    [DataSourceRequest] DataSourceRequest request,
                                                    RebuiltPartsViewModel model,
                                                    [FromQuery] string id,
                                                    [FromQuery] string gridType)
        {
            //if (!ModelState.IsValid)
            //{
            //    return Json(models.ToDataSourceResult(request, ModelState));
            //}
            var isRebuiltPart = 'Y';

            string linkType = "";
            var linkCode = "";
            if (gridType == "RebuiltGrid")
            {
                linkType = "RB";
                linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                   "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                   new { Id = id }

                    );

            }
            if (gridType == "VehicleGrid")
            {
                linkType = "BUS";
                linkCode = id?.ToUpper();
            }
            _dbConnection.Open();
            using var transaction = _dbConnection.BeginTransaction();
            try
            {
                var enteredBy = ViewBag.UserName?.ToString().ToUpper() ?? "SYSTEM";
                var dateModified = DateTime.Now;

                // foreach (var model in models)
                {
                    var parameters = new DynamicParameters();
                    //  parameters.Add("MMSStockCode", model.MMSStockCode?.ToUpperInvariant());
                    // parameters.Add("CC", model.CC?.ToUpperInvariant() ?? " ");
                    parameters.Add("Id", model.RebuiltId);
                    parameters.Add("UnitCost", model.UnitCost ?? 0m);
                    parameters.Add("Qty", model.Qty);
                    parameters.Add("Percentage", model.Percentage);
                    parameters.Add("CoreCost", model.CoreCharge);
                    parameters.Add("LinkCode", linkCode);
                    parameters.Add("LinkType", linkType);
                    parameters.Add("LastModifiedBy", enteredBy);

                    parameters.Add("LastModifiedDate", dateModified);

                    var sql = @"
                                UPDATE SBCES.SCPartsUsed 
                                SET 
                                    --CostCentre = UPPER(@CC),
                                    --MMSStockCode = @MMSStockCode
                                    MMSCost = @UnitCost,
                                    QtyReqd = @Qty,
                                    PercentUsage = @Percentage,
                                    CoreCost = @CoreCost,
                                    LastModifiedBy = @LastModifiedBy,
                                    LastModifiedDate = @LastModifiedDate
                                     
                                WHERE 
                                    --LinkCode = @LinkCode
                                    --AND
                                    --LinkType = @LinkType
                                   -- AND 
                                   ID = @Id
                                   ";

                    await _dbConnection.ExecuteAsync(sql, parameters, transaction);
                }


                transaction.Commit();

                if (gridType == "VehicleGrid")
                {
                    //update estimates
                    await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                }

                // return Json(models.ToDataSourceResult(request));
                return Json(new[] { model }.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                ModelState.AddModelError("", $"Error updating record: {ex.Message}");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
                //return Json(models.ToDataSourceResult(request, ModelState));
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteRbPartsUsedInEstimates(
                                                         [DataSourceRequest] DataSourceRequest request,
                                                         RebuiltPartsViewModel model,
                                                         string id,
                                                         string partNum,
                                                          string gridType)
        {
            string linkType = ""; // gridType == "RebuiltGrid" ? "RB" : "BUS";
            var linkCode = id?.ToUpper();
            if (gridType == "RebuiltGrid")
            {
                linkType = "RB";
                linkCode = await _dbConnection.QueryFirstOrDefaultAsync<string>(
                   "SELECT RebuiltStockNum FROM sbces.RbMasterlist WHERE RbMasterlistId = @Id",
                   new { Id = id }
                   );
            }
            if (gridType == "VehicleGrid")
            {
                linkType = "BUS";


            }
            if (gridType == "MakeVsBuyGrid")
            {
                linkType = "MB";

            }

            if (!ModelState.IsValid)
            {
                // return Json(model.ToDataSourceResult(request, ModelState));
            }

            _dbConnection.Open();
            using var transaction = _dbConnection.BeginTransaction();
            try
            {

                var sql = @"
                                DELETE FROM SBCES.SCPartsUsed 
                                WHERE                                  
                                     LinkCode = '" + linkCode + "'" + " and LinkType ='" + linkType + "' and MmsRebuiltCode ='" + partNum + "'";

                await _dbConnection.ExecuteAsync(sql, null, transaction);

                transaction.Commit();

                if (gridType == "VehicleGrid")
                {
                    //update estimates
                    await VehicleListEstimatesUpdater.UpdateVehicleCostsAsync(_dbConnection, id);
                }

                return Json(new[] { model }.ToDataSourceResult(request, ModelState));


            }
            catch (Exception ex)
            {
                transaction.Rollback();
                ModelState.AddModelError("", $"Error deleting record: {ex.Message}");
                return Json(new[] { model }.ToDataSourceResult(request, ModelState));
            }
        }

        [HttpGet]
        public async Task<IActionResult> RefreshRbPartDetails(string rebuiltStockNum)
        {
            if (string.IsNullOrEmpty(rebuiltStockNum))
            {
                return BadRequest(new { Message = "RebuiltStock Number is required." });
            }

            try
            {
                var query = @"
                            SELECT  [RbMasterlistId]
                              ,[MmsStockCode]      
                              ,[DetailedDesc]
                              ,[Keyword]      
                              ,[RebuiltStockNum]
                              ,[CoreCharge]      
                          FROM [CES].[SBCES].[RbMasterlist] where RebuiltStockNum = @rebuiltStockNum";

                using (var connection = _db.CreateConnection())
                {
                    var result = await connection.QueryFirstOrDefaultAsync(query, new { rebuiltStockNum });

                    if (result == null)
                    {
                        return NotFound(new { Message = "Rebuilt Stock Number not found." });
                    }

                    // Validate OemPartCost
                    //if (result.OemPartCost < 0)
                    //{
                    //    return Ok(new
                    //    {
                    //        Message = "Invalid Part Cost - must be greater than 0",
                    //        Data = result // Send data anyway if needed
                    //    });
                    //}

                    return Ok(new
                    {
                        //  RebuiltStockNum = result.RebuiltPartNum,
                        KeyWord = result.Keyword,
                        Description = result.DetailedDesc,
                        OemPartCost = result.CoreCharge
                    });
                }
            }
            catch (Exception ex)
            {
                // _logger.LogError(ex, "Error refreshing NSC part details");
                return StatusCode(500, new { Message = "An error occurred while refreshing part details." });
            }
        }
    }
}
