﻿// NonStockCodedPartsController.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using BCES.Models.Parts;
using BCES.Controllers.Base;
using NuGet.Protocol;
using Microsoft.AspNetCore.Authorization;


namespace BCES.Controllers.Parts
{
    [Route("StockCodedParts")]
    public class StockCodedPartsController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public StockCodedPartsController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper; 
            _httpContextAccessor = httpContextAccessor;
            _dbConnection = _db.CreateConnection();
        }

        [HttpGet("Index")]
        [AllowAnonymous]
        public IActionResult Index()
        {
            
            return View("~/Views/Parts/StockCodedParts/Index.cshtml");
        }

        
        [AllowAnonymous]
        public async Task<IActionResult> ReadStockCodedParts([DataSourceRequest] DataSourceRequest request)
        {
            try
            {
                var users = await GetStockCodedParts(); ;
                return Json(users.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while fetching users.");
            }
        }

        [AllowAnonymous]
        private async Task<IEnumerable<StockCodedPartsViewModel>> GetStockCodedParts()
        {
            
            string query = @"
                    SELECT 
                       
                        *
                    FROM 
                      
                        SBCES.[StockCodedParts] ";
            return await _dbConnection.QueryAsync<StockCodedPartsViewModel>(query);


        }

    }
}