﻿// NonStockCodedPartsController.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using BCES.Models.Parts;
using NuGet.Protocol;


namespace BCES.Controllers
{
    [Route("NonStockCodedParts")]
    public class NonStockCodedPartsController : Controller
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;

        public NonStockCodedPartsController(DapperContext dapper)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
        }

        [HttpGet("Index")]
        public IActionResult Index()
        {
            ViewBag.UserName = HttpContext.Session.GetString("username");
            ViewBag.RoleId = HttpContext.Session.GetInt32("roleId");
            ViewBag.RoleName = HttpContext.Session.GetString("roleName");
            return View("~/Views/Parts/NonStockCodedParts/Index.cshtml");
        }

        // GET: NonStockCodedParts/Read
        // Returns a JSON result of NonStockCodedParts
        //[HttpGet("ReadNonStockCodedParts")]
        public async Task<IActionResult> ReadNonStockCodedParts([DataSourceRequest] DataSourceRequest request)
        {
            try
            {
                var users = await GetNonStockCodedParts(); ;
                return Json(users.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while fetching users.");
            }
        }

        // GET: NonStockCodedParts/GetNonStockCodedParts
        // Makes a Dapper SQL call to retrieve NonStockCodedParts
        private async Task<IEnumerable<NonStockCodedPartsModel>> GetNonStockCodedParts()
        {
            //string query = @"select PartID, SupplierName from BCES.NonStockCodedParts";
            //return await _dbConnection.QueryAsync<NonStockCodedPartsModel>(query);

            string query = @"
                    SELECT 
                        NSCP.*,
                        AP.*
                    FROM 
                        BCES.NonStockCodedParts NSCP
                    INNER JOIN 
                        BCES.AllParts AP ON NSCP.PartID = AP.PartID";
            return await _dbConnection.QueryAsync<NonStockCodedPartsModel, AllPartsModel, NonStockCodedPartsModel>(query, (nscp, ap) =>
            {
                nscp.AllPartsModel = ap;
                return nscp;
            }, splitOn: "PartID");


        }

        // POST: NonStockCodedParts/Add
        // Adds a new NonStockCodedPart
        [HttpPost]
        public JsonResult AddNonStockCodedPart(NonStockCodedPartsModel nonStockCodedPart)
        {
            try
            {
               
                // Insert into AllParts table
                string allPartsQuery = @"
                    INSERT INTO BCES.AllParts (DetailedDesc, DateEntered, PartCost, AddedBy, OrigSupplierNum, OrigSupplierName, LastModifiedBy, LastModifiedDate)
                    VALUES (@DetailedDesc, @DateEntered, @PartCost, @AddedBy, @SupplierNumber, @SupplierName, @LastModifiedBy, @LastModifiedDate);
                    SELECT CAST(SCOPE_IDENTITY() as int)";
                int partID = _dbConnection.Query<int>(allPartsQuery, nonStockCodedPart).Single();

                // Insert into NonStockCodedParts table
                string nonStockCodedPartsQuery = @"
                    INSERT INTO BCES.NonStockCodedParts (PartID, SupplierName, SupplierNumber, PartUnitCost)
                    VALUES (@PartID, @SupplierName, @SupplierNumber, @PartUnitCost)";
                _dbConnection.Execute(nonStockCodedPartsQuery, new { PartID = partID, nonStockCodedPart.SupplierName, nonStockCodedPart.SupplierNumber, nonStockCodedPart.PartUnitCost });
                
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Log the exception
                return Json(new { error = ex.Message });
            }
        }

        // POST: NonStockCodedParts/Update
        // Updates an existing NonStockCodedPart
        [HttpPost]
        public JsonResult UpdateNonStockCodedPart(NonStockCodedPartsModel nonStockCodedPart)
        {
            try
            {
                
                // Update AllParts table
                string allPartsQuery = @"
                    UPDATE BCES.AllParts
                    SET DetailedDesc = @DetailedDesc, DateEntered = @DateEntered, PartCost = @PartCost, AddedBy = @AddedBy, OrigSupplierNum = @SupplierNumber, OrigSupplierName = @SupplierName, LastModifiedBy = @LastModifiedBy, LastModifiedDate = @LastModifiedDate
                    WHERE PartID = @PartID";
                _dbConnection.Execute(allPartsQuery, nonStockCodedPart);

                // Update NonStockCodedParts table
                string nonStockCodedPartsQuery = @"
                    UPDATE BCES.NonStockCodedParts
                    SET SupplierName = @SupplierName, SupplierNumber = @SupplierNumber, PartUnitCost = @PartUnitCost
                    WHERE PartID = @PartID";
                _dbConnection.Execute(nonStockCodedPartsQuery, nonStockCodedPart);
                
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Log the exception
                return Json(new { error = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateNonStockCodedPart([DataSourceRequest] DataSourceRequest request, NonStockCodedPartsModel nonStockCodedPartsModel)
        {
            try
            {
                if (nonStockCodedPartsModel != null && ModelState.IsValid)
                {
                    //productService.Create(product);
                    await UpdateNonStockCodedPartsAsync(nonStockCodedPartsModel);
                }

                return Json(new[] { nonStockCodedPartsModel }.ToDataSourceResult(request, ModelState));
               
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the user.");
            }
        }

        private async Task UpdateNonStockCodedPartsAsync(NonStockCodedPartsModel nonStockCodedPartsModel)
        {
            var query = "UPDATE BCES.Users SET UserName = @UserName, RoleId = @RoleId WHERE UserId = @UserId;";
          //  await _dbConnection.ExecuteAsync(query, new { UserId = userId, UserName = userName, RoleId = roleId });
        }
        // POST: NonStockCodedParts/Delete
        // Deletes an existing NonStockCodedPart
        [HttpPost]
        public JsonResult DeleteNonStockCodedPart(int partID)
        {
            try
            {
                
                // Delete from NonStockCodedParts table
                string nonStockCodedPartsQuery = "DELETE FROM BCES.NonStockCodedParts WHERE PartID = @PartID";
                _dbConnection.Execute(nonStockCodedPartsQuery, new { PartID = partID });

                // Delete from AllParts table
                string allPartsQuery = "DELETE FROM BCES.AllParts WHERE PartID = @PartID";
                _dbConnection.Execute(allPartsQuery, new { PartID = partID });
                
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Log the exception
                return Json(new { error = ex.Message });
            }
        }
    }
}