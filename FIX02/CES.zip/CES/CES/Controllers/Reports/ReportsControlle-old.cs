﻿using BCES.Controllers.Base;
using BCES.Data;
using Microsoft.AspNetCore.Mvc;

namespace BCES.Controllers.Reports
{
    public class ReportsControllerOld : BaseController
    {
        public ReportsControllerOld(DapperContext dapper, IHttpContextAccessor httpContextAccessor)
            : base(dapper, httpContextAccessor)
        {
        }

        //[Route("Reports/{reportName}")] 
        //[Route("Reports/DynamicReportViewer")]
        public IActionResult ReportViewer(string reportName)
        {
            // Pass the report name to the view
            ViewData["ReportName"] = reportName;
            return View("DynamicReportViewer");
        }
    }
}