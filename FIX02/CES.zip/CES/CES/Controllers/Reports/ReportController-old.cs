﻿using System.Web;
using Microsoft.AspNetCore.Mvc;
using Telerik.Reporting.Services.AspNetCore;
using Telerik.Reporting.Services;
using Telerik.Reporting;
//using Telerik.ReportViewer.Mvc;

//using Telerik.ReportViewer.Mvc;
namespace BCES.Controllers.Reports
{
    [Route("api/report")]
    [ApiController]
    public class ReportControllerOld : ReportsControllerBase
    {
        
        public ReportControllerOld(IReportServiceConfiguration reportServiceConfiguration)
            : base(reportServiceConfiguration)
        {
            var uriReportSource = new Telerik.Reporting.UriReportSource();

           


            // Adding the initial parameter values
            //uriReportSource.Parameters.Add(new Telerik.Reporting.Parameter("OrderNumber", "SO43659"));
        }
    }
}