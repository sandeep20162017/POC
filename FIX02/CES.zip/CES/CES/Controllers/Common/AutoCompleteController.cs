﻿using BCES.Controllers.Base;
using BCES.Data;
using BCES.Models.Parts;
using Dapper;
using Humanizer;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Utilities.Zlib;
using System.Data;


namespace BCES.Controllers.Common
{
    public class AutoCompleteController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public AutoCompleteController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        public IActionResult GetAutoCompleteData(string columnName, string searchText)
        {
            try
            {
                // 1. Validate parameters
              if (string.IsNullOrEmpty(columnName))
                    return BadRequest("Column name is required.");

                // 2. Column whitelist
                var columnMappings = new Dictionary<string, (string SqlColumn, string Table)>
            {
                //Admin Labour Tasks
                { "TaskDescription", ("TaskDescription", "[SBCES].[LabourTaskDescriptions]") },
                //NSC Parts 
                { "OrigSuppNum", ("OrigSupplierNum", "[SBCES].[NonStockCodedParts]") },
                { "OrigSupplierName", ("OrigSupplierName", "[SBCES].[NonStockCodedParts]") },
                { "Description", ("DetailedDesc", "[SBCES].[NonStockCodedParts]") },
                { "KeyWord", ("KeyWord", "[SBCES].[NonStockCodedParts]") },
                 { "Keyword", ("Keyword", "[SBCES].[NonStockCodedParts]") },
                //RB Parts
                { "DetailedDesc", ("DetailedDesc", "[SBCES].[RbMasterlist]") },
                { "LabourDefn", ("LabourDefn", "[SBCES].[EMPLCLASS]") },
                { "CC", ("COSTCENTRE", "[SBCES].[COSTCENTRES]") },
                { "CostCentre", ("COSTCENTRE", "[SBCES].[COSTCENTRES]") },
                { "Task", ("TaskDescription", "[SBCES].[LabourTaskDescriptions]") },
                { "MMSStockCode", ("MMSSTOCKCODE", "[SBCES].[STOCKCODEDPARTS]") },
                { "MmsStockCode", ("MMSSTOCKCODE", "[SBCES].[STOCKCODEDPARTS]") },

                { "RebuiltStockNum", ("RebuiltStockNum", "[SBCES].[RbMasterlist]") },
                //LabourType
                 { "WAGEGROUP", ("WAGEGROUP", "[SBCES].[EMPLCLASS]") },
                //user management
                {"RoleName", ("RoleName", "[SBCES].Roles") },
                //Vehicle
                {"VehSeriesCode", ("[VehSeriesCode]", "[SBCES].[VehicleList]") },
                {"ProjDesc", ("[ProjDesc]", "[SBCES].[VehicleList]") },
                {"Make", ("[Make]", "[SBCES].[TYPEOFVEHICLE]") },
                {"VehModel", ("[Model]", "[SBCES].[TYPEOFVEHICLE]") },
                  {"Model", ("[Model]", "[SBCES].[TYPEOFVEHICLE]") },
                {"Year", ("[Year]", "[SBCES].[TYPEOFVEHICLE]") },
              
                {"Engine", ("[Name]", "[SBCES].[Engines]") },
                {"Transmission", ("[Name]", "[SBCES].[TRANSMISSIONS]") },
                {"Differential", ("[Name]", "[SBCES].[Differential]") },
                

                //{ "KeyWord", ("KeyWord", "[SBCES].[RbMasterlist]") }
            };

                if (!columnMappings.TryGetValue(columnName, out var mapping))
                    return BadRequest("Invalid column name, in AutoComplete.");

                // 3. Parameterized query
                using (var connection = _dbConnection)
                {
                    var sql = "";
                    if (columnName == "RebuiltStockNum")
                    {
                        sql = $@"
                                        SELECT                                       
                                        UPPER(RebuiltStockNum) AS RebuiltStockNum                                        
                                        FROM SBCES.RBMasterlist
                                       WHERE  RebuiltStockNum LIKE '" + searchText + "%'" +
                                        @" --AND Active is not null
                                       order by [RebuiltStockNum] 
                                                                   ";
                    }
                    else

                        sql = $@"
                                SELECT DISTINCT {mapping.SqlColumn} AS Text
                                FROM {mapping.Table}";
                             //  WHERE {mapping.SqlColumn} LIKE @SearchText + '%'";
                 

                    var results = connection.Query<string>(sql, new { SearchText = searchText ?? "" });

                    // Wrap results in objects with "Text" property
                    var data = results.Select(x => new { Text = x }).ToList();
                   // Thread.Sleep(2000);
                    return Json(data);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return Json(null);
            }


        }
        //[HttpGet]
        //public IActionResult GetSupplierDetails(string supplierNumber)
        //{
        //    if (string.IsNullOrEmpty(supplierNumber))
        //        return BadRequest("Supplier number is required.");

        //    var sql = @"
        //                SELECT 
        //                    OrigSupplierName AS SupplierName
        //                    -- KeyWord,
        //                   -- DetailedDesc AS Description,
        //                    -- OemPartCost AS PartCost
        //                FROM [SBCES].[NonStockCodedParts]
        //                WHERE OrigSupplierNum = @SupplierNumber
        //            ";

        //    var result = _dbConnection.QueryFirstOrDefault(sql, new { SupplierNumber = supplierNumber });

        //    if (result == null)
        //        return NotFound("Supplier not found.");

        //    return Json(result);
        //} 

        [HttpGet]
        public IActionResult GetVehSeries()
        {
            
            //var sql = @"
            //    select distinct VehSeriesCode from [SBCES].[VehicleList]";

            var sql = "SELECT [Description] as VehSeriesCode  FROM [CES].[SBCES].[ListOfBuses]";

            var result = _dbConnection.Query(sql);
            return Json(result);
        }

        [HttpGet]
        public IActionResult GetSupplierNames(string supplierNumber)
        {
            if (string.IsNullOrEmpty(supplierNumber))
                return BadRequest("Supplier number is required.");

            var sql = @"
                SELECT DISTINCT OrigSupplierName  AS Text
                FROM [SBCES].[NonStockCodedParts]
                WHERE OrigSupplierNum = @SupplierNumber";

            var result = _dbConnection.Query(sql, new { SupplierNumber = supplierNumber });
return Json(result);
        }
       

        [HttpGet]
        public IActionResult GetSupplierDetailsByName(string supplierNumber, string supplierName)
        {
            if (string.IsNullOrEmpty(supplierNumber) || string.IsNullOrEmpty(supplierName))
                return BadRequest("Supplier number and name are required.");

            var sql = @"
                        SELECT 
                            OrigSupplierName AS SupplierName,
                            KeyWord,
                            DetailedDesc AS Description,
                            OemPartCost AS UnitCost
                        FROM [SBCES].[NonStockCodedParts]
                        WHERE OrigSupplierNum = @SupplierNumber
                          AND OrigSupplierName = @SupplierName";

            var result = _dbConnection.QueryFirstOrDefault(sql, new { SupplierNumber = supplierNumber, SupplierName = supplierName });
            return Json(result);
        }

        [HttpGet]
        public IActionResult GetRbPartDetails(string rebuiltStockNum, string gridType)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(rebuiltStockNum))
                    return BadRequest("RebuiltStockNum is required.");

                // STEP 1 — Get RbMasterListId first
                //var rbMasterListId = _dbConnection.QueryFirstOrDefault<int?>(@"
                //                    SELECT RbMasterListId 
                //                    FROM SBCES.RbMasterlist 
                //                    WHERE RebuiltStockNum = @RebuiltStockNum",
                //                            new { RebuiltStockNum = rebuiltStockNum });

                //if (rbMasterListId == null)
                //    return NotFound("RbMasterListId not found for this RebuiltStockNum.");
                  


                var sql = @"
                        DECLARE @LinkCode VARCHAR(50) ='" + rebuiltStockNum + "';" + 

                        " DECLARE @LinkType VARCHAR(50) = 'RB';"  +
                        @"
                        
                    
                       -- DECLARE @LinkCode VARCHAR(50) ='SW0815'; 
                      --  DECLARE @LinkType VARCHAR(50) = 'RB';
                        
                    PRINT 'Starting Final Cost Calculation using CTEs...';

                        WITH MaterialCosts AS (
                            SELECT
                                ISNULL(cc.Name, 'NONE') AS AssemblyArea,
                                ISNULL(spu.CostCentre, '0') AS CostCentre,
                                SUM(
                                    (spu.PercentUsage / 100.0) * spu.QtyReqd * (spu.MmsCost - ISNULL(spu.CoreCost, 0))
                                ) AS TotalCost,
                                SUM(
                                    (spu.PercentUsage / 100.0) * spu.QtyReqd * spu.MmsCost
                                ) AS TaxableCost
                            FROM
                                SBCES.ScPartsUsed spu
                                LEFT JOIN SBCES.CostCentres cc ON spu.CostCentre = cc.CostCentre
                            WHERE
                                spu.LinkCode = UPPER(@LinkCode)
                                AND spu.LinkType = UPPER(@LinkType)
                               -- AND spu.RebuiltPart = 'N'
                            GROUP BY
                                cc.Name,
                                spu.CostCentre
                        ),
                        NscMaterialCosts AS (
                            SELECT
                                ISNULL(cc.Name, 'NONE') AS AssemblyArea,
                                ISNULL(nscpu.CostCentre, '0') AS CostCentre,
                                SUM(
                                    (nscpu.PercentUsage / 100.0) * nscpu.QtyReqd * (nscp.OemPartCost - ISNULL(nscpu.CoreCost, 0))
                                ) AS TotalCost,
                                SUM(
                                    (nscpu.PercentUsage / 100.0) * nscpu.QtyReqd * nscp.OemPartCost
                                ) AS TaxableCost
                            FROM
                                SBCES.NscPartsUsed nscpu
                                INNER JOIN SBCES.NonStockCodedParts nscp ON nscpu.Id = nscp.Id
                                LEFT JOIN SBCES.CostCentres cc ON nscpu.CostCentre = cc.CostCentre
                            WHERE
                                nscpu.LinkCode = UPPER(@LinkCode)
                                AND nscpu.LinkType = UPPER(@LinkType)
                            GROUP BY
                                cc.Name,
                                nscpu.CostCentre
                        ),
                        CombinedMaterials AS (
                            SELECT * FROM MaterialCosts
                            UNION ALL
                            SELECT * FROM NscMaterialCosts
                        ),
                        TotalMaterialCost AS (
                            SELECT
                                ROUND(SUM(ISNULL(TotalCost, 0)), 2) AS RbCost
                            FROM
                                CombinedMaterials
                        ),
                        
                        FinalTotal AS (
                            SELECT
                                ISNULL(tm.RbCost, 0)  AS FinalPrice,
                                UPPER(@LinkCode) AS LinkCode
                            FROM
                                TotalMaterialCost tm
                        )

                        --PRINT 'Fetching RBMasterlist with computed UnitCost...';
						
                        SELECT  top 1
                            UPPER(rb.MmsStockCode) AS MmsStockCode,
                           
							
                            UPPER(rb.RebuiltStockNum) AS RebuiltStockNum,
                            UPPER(rb.JobNumber) AS JobNumber,
                            UPPER(rb.Keyword) AS KeyWord,
                            UPPER(rb.DetailedDesc) AS Description,
                            UPPER(rb.CoreCharge) AS CoreCharge,
                            UPPER(rb.CorePartNum) AS CorePartNum,
                            UPPER(rb.SopNumber) AS SopNumber,
                            UPPER(CAST(ft.FinalPrice AS VARCHAR)) AS UnitCost, 
                            UPPER(rb.RemanCost) AS RemanCost,
                            UPPER(rb.ExternalCost) AS ExternalCost,
							--sc.OrigSupplierName AS SCOrigSupplierName,
							--sc.OrigSupplierNum AS  SCOrigSupplierNum,
							--sc.MmsStockCode AS SCMMsStockCode,
							--sc.DetailedDesc AS SCDetailedDesc,
							--sc.JobNumber as SCJobNumber,
							--sc.OemPartCost as SCOemPartCost,
							--sc.MmsNewCost as SCMmsnewCost,

                            rb.Active
                       FROM SBCES.RBMasterlist rb
							LEFT JOIN FinalTotal ft 
								ON UPPER(rb.RebuiltStockNum) = ft.LinkCode
							LEFT JOIN SBCES.RBMasterlist rb2
								ON rb2.RebuiltStockNum = @LinkCode
							LEFT JOIN SBCES.ScPartsUsed scpu
								ON rb2.RebuiltStockNum = scpu.MmsRebuiltCode
						   --JOIN SBCES.StockCodedParts scp
							  -- ON rb2.MmsStockCode = scpu.MmsStockCode

                        WHERE
                            rb.RebuiltStockNum = @LinkCode
                        --    AND rb.Active IS NOT NULL
                        ORDER BY
                            rb.RebuiltStockNum;

                        PRINT 'Query execution completed.';
                           
                           ";

                var result = _dbConnection.QueryFirstOrDefault(sql, new { RebuiltStockNum = rebuiltStockNum });

                if (result == null)
                    return NotFound("Part not found.");

                return Json(result);
            }
            catch (Exception ex)
            {
                //  log the exception
                return StatusCode(500, "An error occurred while retrieving the data.");
            }
        }

        [HttpGet]
        public IActionResult GetScPartDetails(string mmsStockCode)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(mmsStockCode))
                    return BadRequest("mmsStockCode is required.");

                var sql = @"
                            SELECT [MmsStockCode]
                          ,[CorePartNumber]
                          ,[PartType]
                          ,[JobNumber]
                          ,[DetailedDesc]
                          ,[DateEntered]
                          ,[ItemRefNumber]
                          ,[OverheadType]
                          ,[CoreCharge]
                          ,[PartCost]
                          ,[LastModifiedDate]
                          ,[LastModifiedBy]
                          ,[AddedBy]
                          ,[MmsNewCost] as UnitCost
                          ,[OemPartCost]
                          ,[MmsSyncDate]
                          ,[OrigSupplierNum]
                          ,[OrigSupplierName]
                      FROM [CES].[SBCES].[StockCodedParts]
                        WHERE  MmsStockCode = '" + mmsStockCode + "'" +
                       @"Order By MmsStockCode
                                                    ";

                var result = _dbConnection.QueryFirstOrDefault(sql, new { MmsStockCode = mmsStockCode });

                if (result == null)
                    return NotFound("Part not found.");

                return Json(result);
            }
            catch (Exception ex)
            {
                //  log the exception
                return StatusCode(500, "An error occurred while retrieving the data.");
            }
        }
    }
}

    
