﻿using Microsoft.AspNetCore.Mvc;
using BCES.Controllers.Base;
using BCES.Data;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Common
{
    [Route("Common/[controller]/[action]")]
    public class PartialViewTestController : BaseController
    {
        public PartialViewTestController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {

        }
        //public IActionResult Index()
        //{
        //    return View();
        //}
        [HttpGet]
        [AllowAnonymous]
        public IActionResult PartialTest1()
        {
            return PartialView("~/Views/Parts/RebuiltParts/PartialViewTest1.cshtml");
        }
        [HttpGet]
        [AllowAnonymous]
        public IActionResult PartialTest2()
        {
            return PartialView("~/Views/Parts/RebuiltParts/PartialViewTest2.cshtml");
        }

    }
}
