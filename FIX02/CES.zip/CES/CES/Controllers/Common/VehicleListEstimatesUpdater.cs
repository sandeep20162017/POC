﻿using System;
using System.Data;
using System.Threading.Tasks;
using Dapper;
using Microsoft.AspNetCore.Mvc;

namespace BCES.Controllers.Common
{
    public static class VehicleListEstimatesUpdater
    {
        public static async Task UpdateVehicleCostsAsync(IDbConnection db, string id)
        {
            const string sql = @"
                        -- DECLARE @id VARCHAR(30) = @RebuiltPartNum;
                       -- DECLARE @id VARCHAR(30) = '4489';

                        BEGIN TRY
                            PRINT '================ LABOUR + MATERIALS DEBUG START ================';

                            --------------------------------------------------------------------
                            -- TEMP TABLE FOR LABOUR
                            --------------------------------------------------------------------
                            CREATE TABLE #TempLabourDetails
                            (
                                Id INT,
                                DecimalHrs DECIMAL(18, 2),
                                EffectiveHours DECIMAL(18, 2),
                                AdjHrs VARCHAR(10),
                                LabourRate DECIMAL(18, 2),
                                LabourCost DECIMAL(18, 2),
                                LabourOverheadTotal DECIMAL(18, 2)
                            );

                            --------------------------------------------------------------------
                            -- INSERT LABOUR DETAILS
                            --------------------------------------------------------------------
                            PRINT 'DEBUG: Loading labour rows from EmployeeLabour...';

                            INSERT INTO #TempLabourDetails
                            SELECT 
                                EL.Id,

                                -- DecimalHrs
                                CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), '0') AS DECIMAL(18,2)) + 
                                CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), '0') AS DECIMAL(18,2)) / 60.0,

                                -- EffectiveHours
                                (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), '0') AS DECIMAL(18,2)) + 
                                 CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), '0') AS DECIMAL(18,2)) / 60.0)
                                 * ISNULL(CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)), 0) / 100.0,

                                -- AdjHrs
                                CAST((
                                    (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), '0') AS DECIMAL(18,2)) + 
                                     CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), '0') AS DECIMAL(18,2)) / 60.0)
                                     * ISNULL(CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)), 0) / 100.0
                                ) /
                                ISNULL(
                                    (SELECT TOP 1 CAST(Value AS DECIMAL(18,2)) 
                                     FROM CES.SBCES.CesSettings
                                     WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), 1
                                ) AS VARCHAR(10)),

                                -- LabourRate
                                (SELECT TOP 1 ES.RatePerHour 
                                 FROM CES.SBCES.EmployeeSalaries ES
                                 WHERE ES.WageGroup = 
                                    (SELECT TOP 1 EC.WageGroup
                                     FROM CES.SBCES.EmplClass EC
                                     WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')),

                                -- LabourCost
                                ISNULL((
                                    (
                                        (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), '0') AS DECIMAL(18,2)) + 
                                         CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), '0') AS DECIMAL(18,2)) / 60.0)
                                         * ISNULL(CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)), 0) / 100.0
                                    ) /
                                    ISNULL(
                                        (SELECT TOP 1 CAST(Value AS DECIMAL(18,2)) 
                                         FROM CES.SBCES.CesSettings
                                         WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), 1
                                    )
                                    * ISNULL((
                                        SELECT TOP 1 ES.RatePerHour 
                                        FROM CES.SBCES.EmployeeSalaries ES
                                        WHERE ES.WageGroup = 
                                            (SELECT TOP 1 EC.WageGroup
                                             FROM CES.SBCES.EmplClass EC
                                             WHERE EC.LabourDefn LIKE '%' + EL.LabourDefn + '%')
                                    ), 0)
                                ), 0),

                                -- LabourOverheadTotal
                                ISNULL((
                                    (
                                        (CAST(ISNULL(LEFT(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) - 1), '0') AS DECIMAL(18,2)) + 
                                         CAST(ISNULL(SUBSTRING(EL.HrsReqd, CHARINDEX(':', EL.HrsReqd) + 1, LEN(EL.HrsReqd)), '0') AS DECIMAL(18,2)) / 60.0)
                                         * ISNULL(CAST(NULLIF(EL.Usage, '') AS DECIMAL(18,2)), 0) / 100.0
                                    ) /
                                    ISNULL(
                                        (SELECT TOP 1 CAST(Value AS DECIMAL(18,2)) 
                                         FROM CES.SBCES.CesSettings
                                         WHERE Parameter = 'NON_PRODUCTIVE_ADJUSTMENT'), 1
                                    )
                                    * ISNULL((
                                        SELECT TOP 1 CAST(Value AS DECIMAL(18,2)) 
                                        FROM CES.SBCES.CesSettings
                                        WHERE Parameter = 'OVERHEAD'
                                    ), 0)
                                ), 0)

                            FROM CES.SBCES.EmployeeLabour EL
                            WHERE EL.TypeId = 'BUS' AND EL.LinkNumber = @id;

                            PRINT 'DEBUG: Labour rows inserted = ' + CAST(@@ROWCOUNT AS VARCHAR(10));

                            --------------------------------------------------------------------
                            -- LABOUR TOTALS
                            --------------------------------------------------------------------
                            DECLARE @LabourCost DECIMAL(18,2) = ISNULL((SELECT SUM(LabourCost) FROM #TempLabourDetails), 0);
                            DECLARE @LabourOverheadAmount DECIMAL(18,2) = ISNULL((SELECT SUM(LabourOverheadTotal) FROM #TempLabourDetails), 0);
                            DECLARE @LabourBenefits DECIMAL(18,2) = ISNULL((SELECT CAST(Value AS DECIMAL(18,2)) FROM CES.SBCES.CesSettings WHERE Parameter = 'BENEFIT'), 0);
                            DECLARE @LabourFringe DECIMAL(18,2) = ISNULL((SELECT CAST(Value AS DECIMAL(18,2)) FROM CES.SBCES.CesSettings WHERE Parameter = 'FRINGE'), 0);

                            DECLARE @LabourTotal DECIMAL(18,2) =
                                @LabourCost + @LabourOverheadAmount + @LabourBenefits + @LabourFringe;

                            PRINT 'DEBUG: LabourCost = ' + CAST(@LabourCost AS VARCHAR(50));
                            PRINT 'DEBUG: LabourOverheadAmount = ' + CAST(@LabourOverheadAmount AS VARCHAR(50));
                            PRINT 'DEBUG: LabourBenefits = ' + CAST(@LabourBenefits AS VARCHAR(50));
                            PRINT 'DEBUG: LabourFringe = ' + CAST(@LabourFringe AS VARCHAR(50));
                            PRINT 'DEBUG: LabourTotal = ' + CAST(@LabourTotal AS VARCHAR(50));

                            --------------------------------------------------------------------
                            -- MATERIALS (SCPartsUsed + NscPartsUsed)
                            --------------------------------------------------------------------
                            PRINT 'DEBUG: Loading SCPartsUsed rows...';

                            SELECT *
                            FROM CES.SBCES.SCPartsUsed
                            WHERE LinkCode = @id;

                            PRINT 'DEBUG: SCPartsUsed per-row material calculation (Formula B):';

                            SELECT 
                                MmsStockCode,
                                MMSCost,
                                QtyReqd,
                                PercentUsage,
                                CoreCost,
                                (MMSCost * QtyReqd * (PercentUsage / 100.0)) - ISNULL(CoreCost, 0) AS MaterialLine
                            FROM CES.SBCES.SCPartsUsed
                            WHERE LinkCode = @id;

                            PRINT 'DEBUG: Loading NscPartsUsed rows...';

                            SELECT *
                            FROM CES.SBCES.NscPartsUsed
                            WHERE LinkCode = @id;

                            PRINT 'DEBUG: NscPartsUsed per-row material calculation (Formula B):';

                            SELECT 
                                Cost,
                                QtyReqd,
                                PercentUsage,
                                CoreCost,
                                (Cost * QtyReqd * (PercentUsage / 100.0)) - ISNULL(CoreCost, 0) AS MaterialLine
                            FROM CES.SBCES.NscPartsUsed
                            WHERE LinkCode = @id;

                            --------------------------------------------------------------------
                            -- MATERIAL TOTALS
                            --------------------------------------------------------------------
                            DECLARE @MaterialsTotal DECIMAL(18,2) =
                            (
                                SELECT 
                                    ISNULL(SUM(
                                        (MMSCost * QtyReqd * (PercentUsage / 100.0)) - ISNULL(CoreCost, 0)
                                    ), 0)
                                FROM CES.SBCES.SCPartsUsed
                                WHERE LinkCode = @id
                            )
                            +
                            (
                                SELECT 
                                    ISNULL(SUM(
                                        (Cost * QtyReqd * (PercentUsage / 100.0)) - ISNULL(CoreCost, 0)
                                    ), 0)
                                FROM CES.SBCES.NscPartsUsed
                                WHERE LinkCode = @id
                            );

                            PRINT 'DEBUG: Combined MaterialsTotal = ' + CAST(@MaterialsTotal AS VARCHAR(50));

                            --------------------------------------------------------------------
                            -- TAX
                            --------------------------------------------------------------------
                            DECLARE @TaxRate DECIMAL(18,4) =
                            (
                                SELECT ISNULL(CAST(Value AS DECIMAL(18,4)), 0)
                                FROM CES.SBCES.CesSettings
                                WHERE Parameter = 'TAX_RATE'
                            );

                            DECLARE @TotalTax DECIMAL(18,2) = @MaterialsTotal * @TaxRate;

                            PRINT 'DEBUG: TaxRate = ' + CAST(@TaxRate AS VARCHAR(50));
                            PRINT 'DEBUG: TotalTax = ' + CAST(@TotalTax AS VARCHAR(50));

                            --------------------------------------------------------------------
                            -- FINAL TOTALS
                            --------------------------------------------------------------------
                            DECLARE @TotalBusEstimateCost DECIMAL(18,2) =
                                @LabourCost + @MaterialsTotal;

                            DECLARE @TotalCostTax DECIMAL(18,2) =
                                @TotalBusEstimateCost + @TotalTax;

                            PRINT 'DEBUG: TotalBusEstimateCost = ' + CAST(@TotalBusEstimateCost AS VARCHAR(50));
                            PRINT 'DEBUG: TotalCostTax = ' + CAST(@TotalCostTax AS VARCHAR(50));

                            --------------------------------------------------------------------
                            -- UPDATE VEHICLE LIST
                            --------------------------------------------------------------------
                            PRINT 'DEBUG: Updating VehicleList...';

                            UPDATE CES.SBCES.VehicleList
                            SET 
                                LabourCost = @LabourCost,
                                LabourOverheadAmount = @LabourOverheadAmount,
                                LabourBenefits = @LabourBenefits,
                                LabourFringe = @LabourFringe,
                                LabourTotal = @LabourTotal,
                                MaterialsTotal = @MaterialsTotal,
                                TotalBusEstimateCost = @TotalBusEstimateCost,
                                TotalTax = @TotalTax,
                                TotalCostTax = @TotalCostTax,
                                OemKitsTotal = 0
                            WHERE VehicleListId = @id;

                            PRINT 'DEBUG: VehicleList updated successfully.';

                            DROP TABLE #TempLabourDetails;

                            PRINT '================ LABOUR + MATERIALS DEBUG END =================';

                        END TRY
                        BEGIN CATCH
                            PRINT 'ERROR: ' + ERROR_MESSAGE();
                            THROW;
                        END CATCH;

        ";

            try
            {
                await db.ExecuteAsync(sql, new { id = id });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating VehicleList for VehicleList {id}: {ex.Message}");
                throw;
            }
        }
    }
}
