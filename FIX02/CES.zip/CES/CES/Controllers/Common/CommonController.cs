﻿using Microsoft.AspNetCore.Mvc;
using BCES.Controllers.Base;
using BCES.Data;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Common
{
    public class CommonController : BaseController
    {

        public CommonController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
           
        }
        [AllowAnonymous]
        public IActionResult Index()
        {
            return View("~/Views/Common/Index.cshtml");
        }
    }
}
