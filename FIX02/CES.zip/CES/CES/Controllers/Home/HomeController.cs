﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BCES.Models.Home;
using BCES.Controllers.Base;
using BCES.Data;
using Microsoft.AspNetCore.Authorization;
using BCES.Models.Admin;
using System.Data;
using Dapper;
using Telerik.SvgIcons;
using System.Net;
using Microsoft.AspNetCore.Authentication;

namespace BCES.Controllers.Home
{
    public class HomeController : BaseController
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;

        public HomeController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            var roleName = _httpContextAccessor.HttpContext.Session.GetString("roleName");
        }

        [AllowAnonymous]

        public IActionResult SessionExpired()
        {
            try
            {
                HttpContext.SignOutAsync();
                HttpContext.Session.Clear();
                return View("~/Views/Shared/SessionExpired.cshtml");
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            try
            {
                // Get the latest content from database
                var content = await _dbConnection.QueryFirstAsync<string>(
                    "SELECT TOP 1 Content FROM SBCES.AdminHtmlContent ORDER BY Id DESC");

                var model = new EditorModel
                {
                    Content = content ?? "<p>No content found</p>"
                };

                // Decode if needed
                var decodedContent = WebUtility.HtmlDecode(content ?? string.Empty);

                return View(new EditorModel { Content = decodedContent });
            }
            catch (Exception ex)
            {
                return HandleError(ex);
            }
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
