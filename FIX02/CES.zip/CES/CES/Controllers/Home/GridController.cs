﻿using BCES.Models.Home;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BCES.Controllers.Home
{

    public class GridController : Controller
    {
        public ActionResult Editing_Custom()
        {
            var categories = Enumerable.Range(0, 50).Select(i => new ShipCityModel
            {
                CityID = i,
                CityName = "Amazing City " + i
            });
            ViewData["cities"] = categories.ToList();
            ViewData["defaultCity"] = categories.First();
            return View();
        }
        public ActionResult Orders_Read([DataSourceRequest] DataSourceRequest request)
        {
            var result = Enumerable.Range(0, 50).Select(i => new OrderViewModel
            {
                OrderID = i,
                Freight = i * 10,
                OrderDate = new DateTime(2016, 9, 15).AddDays(i % 7),
                ShipName = "ShipName " + i,
                ShipCity = new ShipCityModel()
                {
                    CityID = i,
                    CityName = "Amazing City " + i
                }
            });

            var dsResult = result.ToDataSourceResult(request);
            return Json(dsResult);
        }
    }
}
