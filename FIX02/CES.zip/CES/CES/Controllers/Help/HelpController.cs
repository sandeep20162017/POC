﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using BCES.Data;   

namespace BCES.Controllers.Help
{
    public class HelpController : Controller
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;

        public HelpController(
            IHttpContextAccessor httpContextAccessor,
            DapperContext db)
        {
            _httpContextAccessor = httpContextAccessor;
            _db = db;
            _dbConnection = _db.CreateConnection();
        }

        // ---------------------------------------------------------
        // DOWNLOAD: User Guide
        // ---------------------------------------------------------
        public IActionResult UserGuide()
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/files/CESUserGuide.pdf");

            if (!System.IO.File.Exists(filePath))
                return NotFound("User Guide PDF not found.");

            var bytes = System.IO.File.ReadAllBytes(filePath);
            return File(bytes, "application/pdf", "CESUserGuide.pdf");
        }

        // ---------------------------------------------------------
        // DOWNLOAD: Training Guide
        // ---------------------------------------------------------
        public IActionResult TrainingGuide()
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/files/CESTrainingGuide.pdf");

            if (!System.IO.File.Exists(filePath))
                return NotFound("Training Guide PDF not found.");

            var bytes = System.IO.File.ReadAllBytes(filePath);
            return File(bytes, "application/pdf", "CESTrainingGuide.pdf");
        }
    }
}
