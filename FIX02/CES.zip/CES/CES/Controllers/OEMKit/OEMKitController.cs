﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.OEMKit;

using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.OEMKit
{

   // [Route("OEMKit")]
    [AllowAnonymous]
    public class OEMKitController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public OEMKitController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
        }
        // GET: NscPartsUsed/Index
        [HttpGet("OEMKitIndex")]
        [AllowAnonymous]
        public IActionResult OEMKitIndex()
        {
            // return View();
            return View("~/Views/OEMKit/Index.cshtml");
        }

       
        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> GetOEMKitView([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid
            var model = await GetOEMKitData();
            return Json(model.ToDataSourceResult(request));
        }

      
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateOEMKit([DataSourceRequest] DataSourceRequest request, [FromForm] OEMKitModel oemModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var countQuery = @"
                                        SELECT count(*)
                                        FROM SBCES.KitsMasterList
                                        where PartNumber = '" + oemModel.PartNumber + "'";
                var fetchedList = await _dbConnection.QuerySingleOrDefaultAsync<int>(countQuery, new { PartNumber = oemModel.PartNumber });
                if (fetchedList > 0)
                {
                    
                    // Handle or log the exception
                    throw new Exception("Failed to add OEM Kit. Part Number exists.");
                    
                }
                string insertQuery = String.Format(@"
                                                    INSERT INTO SBCES.KitsMasterList ([PartNumber] ,[EstimatedCost] ,[Keyword] ,[DetailedDesc],[LastModifiedBy] ,[LastModifiedDate] ,[DateEntered])
                                                    VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}')",
                                                        oemModel.PartNumber,
                                                        oemModel.EstimatedCost,
                                                        oemModel.Keyword,
                                                        oemModel.DetailedDesc,
                                                        ViewBag.UserName,
                                                        DateTime.Now,
                                                        DateTime.Now
                                                         );

                
                var tt = insertQuery;
                await _dbConnection.ExecuteAsync(insertQuery, oemModel);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the OEM Kit.");
            }

        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateOEMKit([DataSourceRequest] DataSourceRequest request, [FromForm] OEMKitModel oemModel)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                string updateQuery = @"DELETE FOM SBCES.KitsMasterList WHERE [PartNumber]= '" + oemModel.PartNumber + "'";
                                                       

                await _dbConnection.ExecuteAsync(updateQuery, oemModel);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the OEM Kit.");
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteOEMKit([DataSourceRequest] DataSourceRequest request, OEMKitModel oemModel)
        {
            try
            {
                var deleteQuery = @"DELETE FROM SBCES.KitsMasterList WHERE [PartNumber]= '" + oemModel.PartNumber + "'";

                await _dbConnection.ExecuteAsync(deleteQuery, oemModel);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while deleting the OEM Kit.");
            }

        }

        private async Task<IEnumerable<OEMKitModel>> GetOEMKitData()
        {
            try
            {
                var query = @"
                            SELECT  [PartNumber]
                                  ,[EstimatedCost]
                                  ,[Keyword]
                                  ,[DetailedDesc]
     
                              FROM [CES].[SBCES].[KitsMasterlist]
                             ";
                
                return await _dbConnection.QueryAsync<OEMKitModel>(query);
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        
    }
}