﻿using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using BCES.Models.Parts;
using BCES.Controllers.Base;
using BCES.Data;
using System.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using BCES.Models.Admin;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Authorization;
using System.Security.Policy;
using System.Threading.Tasks;

namespace BCES.Controllers.Admin
{
    public class BusController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public BusController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }

        //[HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Index([DataSourceRequest] DataSourceRequest request)
        {



            // Fetch data for the grid

            //if (string.IsNullOrEmpty(taskId))
            //{
            //    return BadRequest("TaskId is required.");
            //}

            // Fetch data for the grid using the rebuiltPartNum
            GetBusData();
            //return Json(model.ToDataSourceResult(request));

            return View("~/Views/Admin/bus.cshtml");


        }

        [AllowAnonymous]
        private async Task<IEnumerable<BusModel>> GetBusData()
        {
            try
            {

                var query = @" SELECT [ListId], [Description]  
                               FROM [SBCES].[ListOfBuses] 
                               order by [Description]                       

                                ";

                var buses = await _dbConnection.QueryAsync<BusModel>(query);
                return buses.Distinct().ToList();

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ReadBus([DataSourceRequest] DataSourceRequest request)
        {
            try
            {
                var tasks = await GetBusData();
                return Json(tasks.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while fetching vehicles.");
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateBus([DataSourceRequest] DataSourceRequest request, BusModel busModel)
        {
            try
            {
                await UpdateBusAsync(busModel);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the task.");
            }
        }

        [AllowAnonymous]
        private async Task UpdateBusAsync(BusModel busModel)
        {
            try
            {
                string updateQuery = string.Format(@" UPDATE SBCES.ListOfBuses 
                                                           SET   
                                                            Description = '{0}' 
                                                             where [ListId] = {1}", busModel.Description,
                                                         busModel.ListId
                                                  );

                var tt = updateQuery;

                await _dbConnection.ExecuteAsync(updateQuery, busModel);

            }
            catch (Exception ex)
            {
                // Log the exception (consider using a logging framework)
                Console.WriteLine($"Error updating vehicle: {ex.Message}");

                // Rethrow the exception to propagate it to the caller
                throw;
            }
        }

        [HttpPost]
        [AllowAnonymous]

        public async Task<IActionResult> CreateBus([DataSourceRequest] DataSourceRequest request, [FromForm] BusModel busModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                //Avoid duplicate
                //check if ListId Exits in database
                var listQuery = @"
                                        SELECT count(*)
                                        FROM SBCES.ListOfBuses
                                        where Description = '" + busModel.Description + "'";
                var fetchedVehicle = await _dbConnection.QuerySingleOrDefaultAsync<int>(listQuery, new { listId = busModel.Description });
                if (fetchedVehicle > 0)
                {                    
                    // Handle or log the exception

                    throw new Exception("An error occurred while updating the Vehicle. Vehicle exists or you are trying to add the same vehicle in batch mode. ");
                   
                }
                var insertQuery = String.Format(@" 
                INSERT INTO SBCES.ListOfBuses (ListID, Description)
                VALUES ((select MAX(ListID) + 1 from SBCES.ListOfBuses) , '{0}'); ",

                    busModel.Description
                    );

                //INSERT INTO SBCES.LabourTaskDescriptions (TaskID, TaskDescription)
                // VALUES((select MAX(TaskID) + 1 from SBCES.LabourTaskDescriptions) , '01 A') 

                var tt = insertQuery;
                await _dbConnection.ExecuteAsync(insertQuery, busModel);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the Vehicle. Vehicle exists or you are trying to add the same vehicle in batch mode.  ");
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteBus([DataSourceRequest] DataSourceRequest request, BusModel busModel)
        {
            try
            {
                await DeleteBusAsync(busModel);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the task.");
            }
        }

        [AllowAnonymous]
        [HttpPost]
        private async Task DeleteBusAsync([FromForm] BusModel busModel)
        {
            try
            {
                string deleteQuery = string.Format(@" Delete  from  SBCES.ListOfBuses                                                            
                                                             where [ListId] = {0}", 
                                                         busModel.ListId
                                                  );

                var tt = deleteQuery;
                await _dbConnection.ExecuteAsync(deleteQuery, busModel);
            }
            catch (Exception ex)
            {
                // Log the exception (consider using a logging framework)
                Console.WriteLine($"Error deleting vehicle: {ex.Message}");

                // Rethrow the exception to propagate it to the caller
                throw;
            }
        }

    }
}
