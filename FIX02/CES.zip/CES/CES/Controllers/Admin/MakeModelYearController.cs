﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Parts;
using BCES.Models.Common;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Admin
{
    public class MakeModelYearController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public MakeModelYearController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet("MakeModelYearIndex")]
        [AllowAnonymous]
        public IActionResult MakeModelYearIndex()
        {
            // return View();
            return View("~/Views/Admin/MakeModelYear.cshtml");
        }


        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> ReadMakeModelYear([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid
            var model = await GetMakeModelYearData();
            return Json(model.ToDataSourceResult(request));
        }


        private async Task<IEnumerable<MakeModelYearModel>> GetMakeModelYearData()
        {
            try
            {
                var query = @"
                           SELECT Make, Model as VehicleModel, Year FROM SBCES.TYPEOFVEHICLE order by Make
                        ";
                return await _dbConnection.QueryAsync<MakeModelYearModel>(query);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateMakeModelYear([DataSourceRequest] DataSourceRequest request, [FromForm] MakeModelYearModel model)
        {

            try
            {
                //check if model and year are not null
                if (model.VehicleModel == null || model.Year == 0)
                {
                    return StatusCode(500, "Model and Year are required fields. Insert failed.");
                }
                var insertQuery = @"INSERT INTO [SBCES].[TypeOfVehicle] ([Make] ,[Model],[Year])    VALUES     ('" + model.Make + "', '" + model.VehicleModel + "', '" + model.Year + "')";                    
                                   
                await _dbConnection.ExecuteAsync(insertQuery, model);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the transmission.");
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateMakeModelYear([DataSourceRequest] DataSourceRequest request, [FromForm] MakeModelYearModel model)
        {
            
            try
            {
                //check if model and year are not null
                if (model.VehicleModel == null || model.Year == 0)
                {
                    return StatusCode(500, "An error occurred while updating the make model year.");
                }

                var deleteQuery = "DELETE  FROM SBCES.TypeOfVehicle WHERE Make = '" + model.Make + "' OR Model = '" + model.VehicleModel + "' OR Year = '" + model.Year + "'";
                await _dbConnection.ExecuteAsync(deleteQuery, model);

                var insertQuery = @"INSERT INTO [SBCES].[TypeOfVehicle]
                                   ([Make]
                                   ,[Model]
                                   ,[Year])
                                    VALUES
                                   ('" + model.Make + "', '" + model.VehicleModel + "', '" + model.Year + "')";
                await _dbConnection.ExecuteAsync(insertQuery, model);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the make model year.");
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteMakeModelYear([DataSourceRequest] DataSourceRequest request, [FromForm] MakeModelYearModel model)
        {
            //TO DO revisit SQL queries
            try
            {
                var deleteQuery = "DELETE  FROM SBCES.TypeOfVehicle WHERE Make = '" + model.Make + "' AND Model = '" + model.VehicleModel + "' AND Year = '" + model.Year + "'";
                await _dbConnection.ExecuteAsync(deleteQuery, model);

               
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the transmission.");
            }

        }
    }
}
