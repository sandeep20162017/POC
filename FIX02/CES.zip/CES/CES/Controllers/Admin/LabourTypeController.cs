﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Parts;
using BCES.Models.Common;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Admin
{

    //[Route("NscPartsUsed")]
    public class LabourTypeController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public LabourTypeController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
        }
        // GET: NscPartsUsed/Index
        [HttpGet("LabourTypeIndex")]
        [AllowAnonymous]
        public IActionResult LabourTypeIndex()
        {
            // return View();
            return View("~/Views/Admin/LabourType.cshtml");
        }

        // POST: NscPartsUsed/GetNscPartsUsedView
        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> GetLabourType([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid
            var model = await GetLabourTypeData();
            return Json(model.ToDataSourceResult(request));
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateLabourType([DataSourceRequest] DataSourceRequest request, [FromForm] LabourTypeModel model)
        {
            try
            {
                // Validate required fields
                var errors = new List<string>();

                if (model.WageGroup == 0)
                {
                    errors.Add("Wage Group is required");
                }

                if (model.LabourDefn == null || model.HrsPerWeek <= 0)
                {
                    errors.Add("Labour Definition and Hours per week are required. Isert failed.");
                }

                if (errors.Any())
                {
                    return BadRequest(new { errors });
                }

                //// Get WageGroup with proper null handling
                //var wageGroupQuery = @"
                //                    SELECT TOP 1 WAGEGROUP 
                //                    FROM SBCES.EMPLOYEESALARIES 
                //                    WHERE RATEPERHOUR = @RatePerHr
                //                    ORDER BY WAGEGROUP DESC"; // Get highest wage group if multiple exist

                //var wageGroup = await _dbConnection.QueryFirstOrDefaultAsync<int?>(
                //    wageGroupQuery,
                //    new { RatePerHr = model.RatePerHr }
                //);

                //if (!wageGroup.HasValue)
                //{
                //    return BadRequest(new
                //    {
                //        errors = new[] { $"No Wage Group found for Rate {model.RatePerHr}" }
                //    });
                //}

                var insertQuery = @"INSERT INTO [SBCES].[EmplClass] 
                          ([LabourType], [LabourDefn], [WageGroup], [HrsPerWeek], [DateEntered], [OverheadType]) 
                          VALUES 
                          ((SELECT ISNULL(MAX(LabourType), 0) + 1 FROM [SBCES].[EmplClass]), 
                          @LabourDefn, @WageGroup, @HrsPerWeek, @DateEntered, @OverheadType)";

                var parameters = new
                {
                    LabourDefn = model.LabourDefn ,
                    WageGroup = model.WageGroup,
                    HrsPerWeek = model.HrsPerWeek ,
                    DateEntered = DateTime.Now,
                    OverheadType = 1.2 //hardcoded for insert TODO - revisit
                };

                await _dbConnection.ExecuteAsync(insertQuery, parameters);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Log error here
                return StatusCode(500, new { errors = new[] { $"Create failed: {ex.Message}" } });
            }
        }



        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateLabourType([DataSourceRequest] DataSourceRequest request, LabourTypeModel model)
        {
            try
            {
                //if (!ModelState.IsValid)
                //{
                //    var errors = ModelState.Values
                //        .SelectMany(v => v.Errors)
                //        .Select(e => e.ErrorMessage)
                //        .ToList();
                //    return BadRequest(new { errors });
                //}

                if (model.LabourType <= 0)
                {
                    return BadRequest(new { errors = new[] { "Invalid Labour Type ID" } });
                }

                // Validate RatePerHr
                if (model.RatePerHr <= 0)
                {
                    return BadRequest(new { errors = new[] { "Rate Per Hour is required" } });
                }

                //// Get WageGroup
                //var wageGroupQuery = @"SELECT TOP 1 WAGEGROUP 
                //             FROM SBCES.EMPLOYEESALARIES 
                //             WHERE RATEPERHOUR = @RatePerHr
                //             ORDER BY WAGEGROUP";

                //var wageGroup = await _dbConnection.QueryFirstOrDefaultAsync<int?>(
                //    wageGroupQuery,
                //    new { RatePerHr = model.RatePerHr }
                //);

                //if (!wageGroup.HasValue)
                //{
                //    return BadRequest(new { errors = new[] { "Invalid Rate Per Hour selected" } });
                //}

                var updateQuery = @"UPDATE [SBCES].[EmplClass] SET
                          LabourDefn = @LabourDefn,
                          WageGroup = @WageGroup,
                          HrsPerWeek = @HrsPerWeek,
                          DateEntered = @DateEntered,
                          OverheadType = @OverheadType
                          WHERE LabourType = @LabourType";

                var parameters = new
                {
                    LabourType = model.LabourType,
                    LabourDefn = model.LabourDefn ?? (object)DBNull.Value,
                    WageGroup = model.WageGroup,
                    HrsPerWeek = model.HrsPerWeek,
                    DateEntered = DateTime.Now,
                    OverheadType = model.OverheadType
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(updateQuery, parameters);

                return rowsAffected > 0
                    ? Json(new { success = true })
                    : NotFound(new { errors = new[] { "Record not found" } });
            }
            catch (Exception ex)
            {
                // Log error here
                return StatusCode(500, new { errors = new[] { $"Update failed: {ex.Message}" } });
            }
        }



        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteLabourType([DataSourceRequest] DataSourceRequest request, LabourTypeModel labourTypeModel)
        {
            if (labourTypeModel == null || labourTypeModel.LabourType <= 0)
                return BadRequest("Invalid LabourType value.");

            try
            {
                var deleteQuery = @"
                                DELETE FROM [SBCES].[EmplClass] 
                                WHERE LabourType = @LabourType";

                var parameters = new
                {
                    LabourType = labourTypeModel.LabourType
                };

                var rowsAffected = await _dbConnection.ExecuteAsync(deleteQuery, parameters);

                if (rowsAffected > 0)
                {
                    return Json(new { success = true });
                }
                else
                {
                    return NotFound("LabourType not found.");
                }
            }
            catch (Exception ex)
            {
               // _logger.LogError(ex, "An error occurred while deleting LabourType with ID {LabourType}", labourTypeModel.LabourType);
                return StatusCode(500, $"An error occurred while deleting the LabourType: {ex.Message}");
            }
        }

        private async Task<IEnumerable<LabourTypeModel>> GetLabourTypeData()
        {
            try
            {
                var query = @"
                            SELECT 
                                ec.LABOURTYPE as LabourType,
                                ec.LABOURDEFN as LabourDefn,
                                ec.WAGEGROUP AS WageGroup,
                                es.RATEPERHOUR AS RatePerHr,
                                ec.HRSPERWEEK AS HrsPerWeek,
                                ec.OVERHEADTYPE AS OverheadType
                            FROM SBCES.EMPLCLASS ec
                            INNER JOIN SBCES.EMPLOYEESALARIES es 
                                ON ec.WAGEGROUP = es.WAGEGROUP";

                return await _dbConnection.QueryAsync<LabourTypeModel>(query);
            }
            catch (Exception ex)
            {
                // Log error here
                return Enumerable.Empty<LabourTypeModel>();
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetRatePerHrOptions()
        {
            try
            {
                var query = @"SELECT 
                    CAST(RATEPERHOUR AS DECIMAL(18,2)) AS RatePerHr,
                    WAGEGROUP 
                 FROM SBCES.EMPLOYEESALARIES";

                var options = await _dbConnection.QueryAsync(query);
                return Json(options);
            }
            catch (Exception ex)
            {
                // Log error here
                return StatusCode(500, new { error = $"Failed to load Rate Per Hour options: {ex.Message}" });
            }
        }


        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetWageGroupOptions()
        {
            try
            {
                var query = @"SELECT   WageGroup   FROM SBCES.EMPLOYEESALARIES";

                var options = await _dbConnection.QueryAsync(query);
                return Json(options);
            }
            catch (Exception ex)
            {
                // Log error here
                return StatusCode(500, new { error = $"Failed to load Rate Per Hour options: {ex.Message}" });
            }
        }

    }
}