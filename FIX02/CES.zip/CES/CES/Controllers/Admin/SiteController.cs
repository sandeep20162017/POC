﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Admin;
using BCES.Models.Common;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Admin
{

    //[Route("Site")]
    public class SiteController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public SiteController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }
        // GET: NscPartsUsed/Index
        [HttpGet("SiteIndex")]
        [AllowAnonymous]
        public IActionResult Index()
        {
            // return View();
            return View("~/Views/Admin/Site.cshtml");
        }

        // POST: NscPartsUsed/GetNscPartsUsedView
        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> GetSiteView([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid (you can use Dapper or any other method)
            var model = await GetSiteData();
            return Json(model.ToDataSourceResult(request));
        }

        // POST: NscPartsUsed/CreateNscPartsUsed
        [HttpPost]
        [AllowAnonymous]

        public async Task<IActionResult> CreateSite([DataSourceRequest] DataSourceRequest request, [FromForm] SiteModel siteModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var insertQuery = String.Format(@"
                INSERT INTO SBCES.Sites (SiteName)
                VALUES ('{0}'); SELECT SCOPE_IDENTITY();",
               
                    siteModel.SiteName                   
                    );

                var tt = insertQuery;
                await _dbConnection.ExecuteAsync(insertQuery, siteModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the Sites.");
            }

        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateSite([DataSourceRequest] DataSourceRequest request, [FromForm] SiteModel site)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var tt = site.SiteName;
               
                string updateQuery = string.Format(@" UPDATE SBCES.Sites 
                   SET   
                    SiteName = '{0}' where siteid= {1}
                    " ,site.SiteName, site.SiteId
                              );
                tt = updateQuery;
                
                await _dbConnection.ExecuteAsync(updateQuery, site);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating site.");
            }

        }

        
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteSite([DataSourceRequest] DataSourceRequest request, SiteModel site)
        {
            try
            {
                var deleteQuery = String.Format(@"
                DELETE FROM SBCES.Sites
                WHERE SiteName  = '{0}'", site.SiteName);


                await _dbConnection.ExecuteAsync(deleteQuery, site);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while deleting the Site.");
            }

        }

        private async Task<IEnumerable<SiteModel>> GetSiteData()
        {
            try
            {
                var query = @"
                SELECT 
                    site.SiteId,
                    site.SiteName
                   
                FROM 
                    SBCES.Sites site;";


                return await _dbConnection.QueryAsync<SiteModel>(query);
            }
            catch (Exception ex)
            {
                return null;
            }

        }

 
    }
}