﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Parts;
using BCES.Models.Common;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Admin
{

    //[Route("NscPartsUsed")]
    public class EmpSalaryController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public EmpSalaryController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
        }
        // GET: NscPartsUsed/Index
        [HttpGet("EmpSalaryIndex")]
        [AllowAnonymous]
        public IActionResult EmpSalaryIndex()
        {
            // return View();
            return View("~/Views/Admin/EmpSalary.cshtml");
        }


        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> GetEmpSalary([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid
            var model = await GetEmpSalaryData();
            return Json(model.ToDataSourceResult(request));
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateEmpSalary([DataSourceRequest] DataSourceRequest request, [FromForm] EmpSalaryModel empSalaryModel)
        {

            try
            {
                var insertQuery = "INSERT INTO SBCES.EMPLOYEESALARIES (WAGEGROUP, RATEPERHOUR, DATEENTERED) VALUES (" + empSalaryModel.WageGroup + "," + empSalaryModel.RatePerHour + "," + DateTime.Now.ToString("d") + ")";


                await _dbConnection.ExecuteAsync(insertQuery, empSalaryModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Wage Group exits. Insert failed.");
            }

        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateEmpSalary([DataSourceRequest] DataSourceRequest request, [FromForm] EmpSalaryModel empSalaryModel)
        {
            try
            {


                // UPSERT operation using MERGE statement
                var sql = @"
                            MERGE INTO SBCES.EMPLOYEESALARIES AS target
                            USING (VALUES (@WageGroup, @RatePerHour, @DateEntered)) 
                                AS source (WageGroup, RatePerHour, DateEntered)
                            ON target.WageGroup = source.WageGroup
                            WHEN MATCHED THEN
                                UPDATE SET 
                                    RatePerHour = source.RatePerHour,
                                    DateEntered = source.DateEntered
                            WHEN NOT MATCHED THEN
                                INSERT (WageGroup, RatePerHour, DateEntered)
                                VALUES (source.WageGroup, source.RatePerHour, source.DateEntered);";

                var parameters = new
                {
                    empSalaryModel.WageGroup,
                    empSalaryModel.RatePerHour,
                    DateEntered = DateTime.Now
                };

                await _dbConnection.ExecuteAsync(sql, parameters);

                return Json(new[] { empSalaryModel }.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error updating salary: {ex.Message}" });
            }
        }


        //  [HttpDelete("{id}")]
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteEmpSalary([DataSourceRequest] DataSourceRequest request, EmpSalaryModel empSalaryModel)
        {
            try
            {
                var deleteQuery = "DELETE FROM SBCES.EMPLOYEESALARIES where WAGEGROUP = " + empSalaryModel.WageGroup;


                await _dbConnection.ExecuteAsync(deleteQuery, empSalaryModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while deleting salary.");
            }

        }

        private async Task<IEnumerable<EmpSalaryModel>> GetEmpSalaryData()
        {
            try
            {
                var query = @"
                           SELECT WageGroup , RatePerHour  FROM SBCES.EMPLOYEESALARIES
                        ";
                return await _dbConnection.QueryAsync<EmpSalaryModel>(query);
            }
            catch (Exception ex)
            {
                return null;
            }

        }

    }
}