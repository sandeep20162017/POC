﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Parts;
using BCES.Models.Common;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Admin
{
    public class DifferentialController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public DifferentialController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
        }
       
        [HttpGet("DifferentialIndex")]
        [AllowAnonymous]
        public IActionResult DifferentialIndex()
        {
            // return View();
            return View("~/Views/Admin/Differential.cshtml");
        }


        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> ReadDifferential([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid
            var model = await GetDifferentialData();
            ViewBag.DifferentialName = model;
            return Json(model.ToDataSourceResult(request));
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateDifferential([DataSourceRequest] DataSourceRequest request, [FromForm] DifferentialModel differentialModel)
        {
           
            try
            {
                var insertQuery = "INSERT INTO SBCES.Differential (NAME) VALUES ('" + differentialModel.Name + "')";
                await _dbConnection.ExecuteAsync(insertQuery, differentialModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the transmission.");
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateDifferential([DataSourceRequest] DataSourceRequest request, [FromForm] DifferentialModel differentialModel)
        {

            try
            {
                var deleteQuery = "DELETE FROM SBCES.Differential WHERE NAME = '" + differentialModel.Name + "'";
                await _dbConnection.ExecuteAsync(deleteQuery, differentialModel);

                var insertQuery = "INSERT INTO SBCES.Differential (NAME) VALUES ('" + differentialModel.Name + "')";
                await _dbConnection.ExecuteAsync(insertQuery, differentialModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the transmission.");
            }

        }

        private async Task<IEnumerable<TransmissionModel>> GetDifferentialData()
        {
            try
            {
                var query = @"
                           SELECT Name  FROM [SBCES].[Differential] order by name
                        ";
                return await _dbConnection.QueryAsync<TransmissionModel>(query);

               
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteDifferential([DataSourceRequest] DataSourceRequest request, [FromForm] DifferentialModel differentialModel)
        {

            try
            {
                var deleteQuery = "DELETE FROM SBCES.Differential WHERE NAME = '" + differentialModel.Name + "'";
                await _dbConnection.ExecuteAsync(deleteQuery, differentialModel);

               
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the transmission.");
            }

        }
    }
}