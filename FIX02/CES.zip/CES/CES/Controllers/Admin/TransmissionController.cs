﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Parts;
using BCES.Models.Common;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Admin
{
    public class TransmissionController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public TransmissionController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
        }
        // GET: NscPartsUsed/Index
        [HttpGet("TransmissionIndex")]
        [AllowAnonymous]
        public IActionResult TransmissionIndex()
        {
            // return View();
            return View("~/Views/Admin/Transmission.cshtml");
        }


        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> ReadTransmission([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid
            var model = await GetTransmissionData();
            return Json(model.ToDataSourceResult(request));
        }


        private async Task<IEnumerable<TransmissionModel>> GetTransmissionData()
        {
            try
            {
                var query = @"
                           SELECT Name  FROM SBCES.TRANSMISSIONS order by name
                        ";
                return await _dbConnection.QueryAsync<TransmissionModel>(query);
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateTransmission([DataSourceRequest] DataSourceRequest request, [FromForm] TransmissionModel transmissionModel)
        {

            try
            {
                var insertQuery = "INSERT INTO SBCES.Transmissions (NAME) VALUES ('" + transmissionModel.Name + "')";
                await _dbConnection.ExecuteAsync(insertQuery, transmissionModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the transmission.");
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateTransmission([DataSourceRequest] DataSourceRequest request, [FromForm] TransmissionModel transmissionModel)
        {

            try
            {
                var deleteQuery = "DELETE FROM SBCES.Transmissions WHERE NAME = '%" + transmissionModel.Name + "%'";
                await _dbConnection.ExecuteAsync(deleteQuery, transmissionModel);

                var insertQuery = "INSERT INTO SBCES.Transmissions (NAME) VALUES ('" + transmissionModel.Name + "')";
                await _dbConnection.ExecuteAsync(insertQuery, transmissionModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the transmission.");
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteTransmission([DataSourceRequest] DataSourceRequest request, [FromForm] TransmissionModel transmissionModel)
        {

            try
            {
                var insertQuery = "Delete from SBCES.Transmissions  where NAME = '" + transmissionModel.Name + "'";
                await _dbConnection.ExecuteAsync(insertQuery, transmissionModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the transmission.");
            }

        }

    }
}