﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Parts;
using BCES.Models.Common;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Admin
{
    public class EngineController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public EngineController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
        }
       
        [HttpGet("EngineIndex")]
        [AllowAnonymous]
        public IActionResult EngineIndex()
        {
            // return View();
            return View("~/Views/Admin/Engine.cshtml");
        }


        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> ReadEngine([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid
            var model = await GetEnginelData();
            return Json(model.ToDataSourceResult(request));
        }
                

        private async Task<IEnumerable<EnginesModel>> GetEnginelData()
        {
            try
            {
                var query = @"
                           SELECT Name  FROM [SBCES].[Engines] order by name
                        ";
                return await _dbConnection.QueryAsync<EnginesModel>(query);
            }
            catch (Exception ex)
            {
                HandleError(ex);
               
                return null;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateEngine([DataSourceRequest] DataSourceRequest request, [FromForm] EnginesModel enginesModel)
        {

            try
            {
                var insertQuery = "INSERT INTO SBCES.Engines (NAME) VALUES ('" + enginesModel.Name + "')";
                await _dbConnection.ExecuteAsync(insertQuery, enginesModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the engine. Duplicate record found. ");
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateEngine([DataSourceRequest] DataSourceRequest request, [FromForm] EnginesModel enginesModel)
        {

            try
            {
                var deleteQuery = "DELETE FROM  SBCES.Engines WHERE NAME = '" + enginesModel.Name + "'";
                await _dbConnection.ExecuteAsync(deleteQuery, enginesModel);

                var insertQuery = "INSERT INTO SBCES.Engines (NAME) VALUES ('" + enginesModel.Name + "')";
                await _dbConnection.ExecuteAsync(insertQuery, enginesModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the engines.");
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteEngine([DataSourceRequest] DataSourceRequest request, [FromForm] EnginesModel enginesModel)
        {

            try
            {
                var deleteQuery = "DELETE FROM SBCES.Engines WHERE NAME = '" + enginesModel.Name + "'";
                await _dbConnection.ExecuteAsync(deleteQuery, enginesModel);

                
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the engines.");
            }

        }
    }
}