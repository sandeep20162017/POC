﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using BCES.Controllers.Base;
using HttpGetAttribute = Microsoft.AspNetCore.Mvc.HttpGetAttribute;
using HttpPostAttribute = Microsoft.AspNetCore.Mvc.HttpPostAttribute;
using Microsoft.AspNetCore.Authorization;
using System.Security.Policy;

namespace BCES.Controllers.Admin
{

    public class UserManagementGridController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private static List<string> _selectedSites = new List<string>();


        public UserManagementGridController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }

        #region Index Action

        // Index action to return the main view and load roles
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            try
            {

                //role
                var roles = await GetRoles();
                ViewData["Roles"] = roles;

                ////sites 
                var sites = await GetSites();
                ViewData["Sites"] = sites;


                // Fetch users and sites
                var users = await GetUsers();

                return View("~/Views/Admin/Index.cshtml"); // Return the main grid view
            }
            catch (Exception ex)
            {
                // Log the exception if necessary
                return BadRequest("Error loading roles or sites.");
            }
        }
        #endregion

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ReadUsers([DataSourceRequest] DataSourceRequest request)
        {
            try
            {

                var users = await GetUsers();
                return Json(users.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while fetching users.");
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> AddUser([DataSourceRequest] DataSourceRequest request, [FromForm] UserViewModel userViewModel)
        {
            try
            {
                //if (!ModelState.IsValid)
                //{
                //    var errors = ModelState.Values
                //        .SelectMany(v => v.Errors)
                //        .Select(e => e.ErrorMessage);
                //    return BadRequest(new { Errors = errors });
                //}

                if (userViewModel.RoleName == null || userViewModel.UserName == null)
                {
                    //  ModelState.AddModelError("RoleId", "User Name and Role are required");
                    // return Json(new[] { userViewModel }.ToDataSourceResult(request, ModelState));
                    return StatusCode(500, "User Name and Role are required fields. Insert failed.");
                }
                //get roleid and update model
                var roleId = @"
                                        SELECT RoleId
                                        FROM [SBCES].[Roles]
                                        where RoleName = '" + userViewModel.RoleName + "'";
                userViewModel.RoleId =   await _dbConnection.QuerySingleOrDefaultAsync<int>(roleId, new { RoleName = userViewModel.RoleName });


                var tt = userViewModel.RoleName;
                // TODO - Undo when site association is enabled
                //if (_selectedSites.Count == 0)
                //{
                //    ModelState.AddModelError("RoleId", "Please select site.");
                //    return Json(new[] { userViewModel }.ToDataSourceResult(request, ModelState));
                //}
                if (_selectedSites.Count == 0)
                {
                    var sites = _selectedSites;
                    userViewModel.SelectedSites = _selectedSites;

                    //names for display
                    string selectedSiteIds = string.Join(",", _selectedSites);
                    //update model
                    userViewModel.SiteId = selectedSiteIds;

                    //convert to it to pass to query
                    var siteIds = sites.Select(int.Parse).ToList();
                    //list of all the SiteNames for binding
                    string selectedSiteNames = GetUserSelectedSiteNames(siteIds);
                    //update model for binding
                    userViewModel.SiteName = selectedSiteNames;

                    //site related
                    // Split the comma-separated strings into lists
                    var siteIdsList = _selectedSites;
                    var siteNamesList = selectedSiteNames.Split(',').ToList();
                    var updatedUserView = UserManagementGridController.UpdateSiteInModel(userViewModel, siteIdsList, siteNamesList);
                }

                var userId = await AddUserAsync(userViewModel);              


                // return Json(new[] { user }.ToDataSourceResult(request, ModelState));
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while adding the user.");
            }
        }
              

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateUser([DataSourceRequest] DataSourceRequest request,  UserViewModel userViewModel)
        {                       
            try
            {
                //if (!ModelState.IsValid)
                //{
                //    var errors = ModelState.Values
                //        .SelectMany(v => v.Errors)
                //        .Select(e => e.ErrorMessage);
                //    return BadRequest(new { Errors = errors });
                //}

                if (userViewModel != null) // && ModelState.IsValid)
                {
                    //get roleid and update model
                    var roleId = @"
                                    SELECT RoleId
                                    FROM [SBCES].[Roles]
                                    where RoleName = '" + userViewModel.RoleName + "'";
                    userViewModel.RoleId = await _dbConnection.QuerySingleOrDefaultAsync<int>(roleId, new { RoleName = userViewModel.RoleName });
                    
                    //site
                    userViewModel.SelectedSites = _selectedSites;
                    // convert to it to pass to query
                    var siteIds = _selectedSites.Select(int.Parse).ToList();

                    //list of all the SiteNames for binding
                    string selectedSiteNames = GetUserSelectedSiteNames(siteIds);
                    //update model for binding
                    userViewModel.SiteName = selectedSiteNames;

                    //Update SiteModel
                    // Split the comma-separated strings into lists
                    var siteIdsList = _selectedSites;
                    var siteNamesList = selectedSiteNames.Split(',').ToList();
                    var updatedUserView = UserManagementGridController.UpdateSiteInModel(userViewModel, siteIdsList, siteNamesList);

                    await UpdateUserAsync(userViewModel);
                }

                return RedirectToAction("Index");
               // return Json(new[] { userViewModel }.ToDataSourceResult(request, ModelState));
               
                
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the user.");
            }
        }

        [AllowAnonymous]
        [HttpPost]
        
        public async Task<IActionResult> DeleteUser([DataSourceRequest] DataSourceRequest request, int userID)
        {
            try
            {
                await DeleteUserAsync(userID);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while deleting the user.");
            }
        }

        [AllowAnonymous]
        private async Task<IEnumerable<UserViewModel>> GetUsers()
        {
            try
            {
                const string query = @"SELECT u.UserId, u.UserName, u.userADId, u.RoleId, r.RoleName,
                                     STRING_AGG(CAST(us.SiteId AS VARCHAR), ',') AS SiteId,
                                     STRING_AGG(s.SiteName, ',') AS SiteName
                                      FROM SBCES.[Users] u
                                      INNER JOIN SBCES.[Roles] r ON u.RoleId = r.RoleId
                                      LEFT JOIN SBCES.UserSites us ON u.UserId = us.UserId
                                      LEFT JOIN SBCES.Sites s ON us.SiteId = s.SiteId
                                      
                                      GROUP BY u.userADId, u.UserId, u.UserName, u.RoleId, r.RoleName
                                       order by  u.userADId 
                                        ";

                var users =  _dbConnection.Query<UserViewModel>(query).ToList();

                // Parse SiteIdsString into SiteIds
                foreach (var user in users)
                {
                    if (user.SiteIds.Count > 0)
                    {
                        user.SiteIds = string.IsNullOrEmpty(user.SiteId)
                            ? new List<int>()
                            : user.SiteId.Split(',').Select(int.Parse).ToList();

                        user.SiteNames = string.IsNullOrEmpty(user.SiteName)
                            ? new List<string>()
                            : user.SiteName.Split(',').ToList();

                        List<int> siteIdList = user.SiteId.Split(',').Select(int.Parse).ToList();
                        List<string> siteNameList = user.SiteName.Split(',').ToList();


                        var siteModelList = siteIdList.Zip(siteNameList, (id, name) => new SiteModel
                        {
                            SiteId = id,
                            SiteName = name
                        }).ToList();
                        user.Sites = siteModelList;
                    }
                }
                return users.Distinct().ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [AllowAnonymous]
        private async Task<int> AddUserAsync(UserViewModel userViewModel)
        {
            
            // Start a transaction
            _dbConnection.Open();
            using (var transaction = _dbConnection.BeginTransaction())
            {
                try
                {
                    //check if useADId Exits in database
                    var useADQuery = @"
                                        SELECT count(*)
                                        FROM SBCES.Users
                                        where UserADId = '" + userViewModel.UserADId + "'";
                    var fetchedUserAD = await _dbConnection.QuerySingleOrDefaultAsync<int>(useADQuery, new { UserId = userViewModel.UserID }, transaction);
                    if (fetchedUserAD > 0)
                    {
                        transaction.Rollback();
                        // Handle or log the exception
                        throw new Exception("Failed to add user. User exists.");
                    }
                    // Insert into Users table
                    var insertUserQuery = @"
                                            INSERT INTO SBCES.Users (UserADId, UserName, RoleId)
                                            VALUES (@UserADId, @UserName,  @RoleId);
                                            SELECT CAST(SCOPE_IDENTITY() as int);";

                    var userId = await _dbConnection.QuerySingleAsync<int>(insertUserQuery, new
                    {
                        UserName = userViewModel.UserName,
                        UserADId = userViewModel.UserADId, 
                        RoleId = userViewModel.RoleId,
                    }, transaction);

                    // Insert into UserSites table
                    var insertUserSitesQuery = @"
                                                INSERT INTO SBCES.UserSites (UserId, SiteId)
                                                VALUES (@UserId, 1);"; //TODO when Site logic is confirmed add @SiteId

                    //foreach (var site in userViewModel.Sites)
                    //{
                        await _dbConnection.ExecuteAsync(insertUserSitesQuery, new
                        {
                            UserId = userId
                        }, transaction);
                    //}

                    // Commit the transaction
                    transaction.Commit();

                    return userId;
                }
                catch (Exception ex)
                {
                    // Rollback the transaction in case of any error
                    transaction.Rollback();
                    // Handle or log the exception
                    throw new Exception("Failed to add user.", ex);
                }
            }
        }
        [AllowAnonymous]
        private async Task UpdateUserAsync(UserViewModel userViewModel)
        {
            // Start a transaction
            _dbConnection.Open();
            using (var transaction = _dbConnection.BeginTransaction())
            {
                try
                {

                    //if userid already exits, throw
                    // Fetch the UserADId for the given UserName
                    var userADIdQuery = @"
                                        SELECT UserADId
                                        FROM SBCES.Users
                                        WHERE UserId =" + userViewModel.UserID;
                    var fetchedUserADId = await _dbConnection.QuerySingleOrDefaultAsync<string>(userADIdQuery, new { UserId = userViewModel.UserID }, transaction);
                    var userNameQuery = @"
                                        SELECT UserName
                                        FROM SBCES.Users
                                        WHERE UserId =" + userViewModel.UserID;
                    var fetchedUserName = await _dbConnection.QuerySingleOrDefaultAsync<string>(userNameQuery, new { UserId = userViewModel.UserID }, transaction);
                    var userRoleQuery = @"
                                        SELECT RoleID
                                        FROM SBCES.Users
                                        WHERE UserId =" + userViewModel.UserID;
                    var fetchedUserRole = await _dbConnection.QuerySingleOrDefaultAsync<int>(userRoleQuery, new { UserId = userViewModel.UserID }, transaction);
                    
                    ////if user ID is same, but admin wants to update Role or name, allow
                    //if (fetchedUserADId == userViewModel.UserADId && ( fetchedUserName != userViewModel.UserName || fetchedUserRole != userViewModel.RoleId))
                    //{
                    //    //do nothing
                    //}
                    if (fetchedUserADId != userViewModel.UserADId && (fetchedUserName == userViewModel.UserName || fetchedUserRole == userViewModel.RoleId))
                    {
                        //check if useADId Exits in database
                        var useADQuery = @"
                                        SELECT count(*)
                                        FROM SBCES.Users
                                        where UserADId = '" + userViewModel.UserADId + "'";
                        var fetchedUserAD = await _dbConnection.QuerySingleOrDefaultAsync<int>(useADQuery, new { UserId = userViewModel.UserID }, transaction);
                        if (fetchedUserAD > 0)
                        {
                            transaction.Rollback();
                            // Handle or log the exception
                            throw new Exception("Failed to add user.");
                        }
                    }
                    var userIdQuery = @"
                                        SELECT UserId
                                        FROM SBCES.Users
                                        WHERE UserId =" + userViewModel.UserID ;
                    var fetchedUserId = await _dbConnection.QuerySingleOrDefaultAsync<int>(userIdQuery, new { UserId = userViewModel.UserID }, transaction);
                    
                        // Update the user's role in the Users table
                    var updateUserQuery = @"
                                            UPDATE SBCES.Users
                                             SET RoleId =" +  userViewModel.RoleId +
                                            "  ,UserName = '" + userViewModel.UserName + "'" +
                                            " ,UserADId ='" + userViewModel.UserADId + "'" +
                                            " WHERE UserId =" + userViewModel.UserID;
                                        

                    
                        await _dbConnection.ExecuteAsync(updateUserQuery, new { RoleId = userViewModel.RoleId, UserADId = userViewModel.UserADId, UserName = userViewModel.UserName }, transaction);



                    //Default siteid for a user
                    // delete al values and then Insert new UserSites entries
                    var deleteUserSitesQuery = @"
                                                DELETE from SBCES.UserSites where userid = " + userViewModel.UserID;
                    await _dbConnection.ExecuteAsync(deleteUserSitesQuery, new { UserId = userViewModel.UserID, SiteId = userViewModel.SiteId }, transaction);
                    var insertUserSitesQuery = @"
                                                INSERT INTO SBCES.UserSites (UserId, SiteId)
                                                VALUES (@UserId, 1 )";
                    await _dbConnection.ExecuteAsync(insertUserSitesQuery, new { UserId = userViewModel.UserID, SiteId = 1 }, transaction);

                    //TODO : revisit whe Site logic is finalized
                    //if (_selectedSites.Count >= 0)

                    //{
                    //    // Delete existing UserSites entries for the user
                    //    var deleteUserSitesQuery = @"
                    //                            DELETE FROM SBCES.UserSites
                    //                            WHERE UserId =" + userViewModel.UserID;

                    //    await _dbConnection.ExecuteAsync(deleteUserSitesQuery, new { UserId = userViewModel.UserID }, transaction);

                    //    // Insert new UserSites entries
                    //    var insertUserSitesQuery = @"
                    //                            INSERT INTO SBCES.UserSites (UserId, SiteId)
                    //                            VALUES (@UserId, @SiteId);
                    //                        ";

                    //    foreach (var site in userViewModel.Sites)
                    //    {
                    //        await _dbConnection.ExecuteAsync(insertUserSitesQuery, new { UserId = userViewModel.UserID, SiteId = site.SiteId }, transaction);
                    //    }

                    //}

                    // Commit the transaction
                    transaction.Commit();

                    // return userId;
                }
                catch (Exception ex)
                {
                    // Rollback the transaction in case of any error
                    transaction.Rollback();

                    // Log the exception (consider using a logging framework)
                    Console.WriteLine($"Error updating user: {ex.Message}");

                    // Rethrow the exception to propagate it to the caller
                    throw;
                }
            }
        }

        [AllowAnonymous]
        private async Task DeleteUserAsync(int userId)
        {
           
            _dbConnection.Open();
            using (var transaction = _dbConnection.BeginTransaction())
            {
                try
                {
                    // Delete from UserSites table
                    var deleteUserSitesQuery = @"
                                                DELETE FROM SBCES.UserSites
                                                WHERE UserId = @UserId;";

                    await _dbConnection.ExecuteAsync(deleteUserSitesQuery, new
                    {
                        UserId = userId
                    }, transaction);

                    // Delete from Users table
                    var deleteUserQuery = @"
                                            DELETE FROM SBCES.Users
                                            WHERE UserId = @UserId;";

                    await _dbConnection.ExecuteAsync(deleteUserQuery, new
                    {
                        UserId = userId
                    }, transaction);

                    // Commit the transaction
                    transaction.Commit();

                   // return true;
                }
                catch (Exception ex)
                {
                    // Rollback the transaction in case of any error
                    transaction.Rollback();
                    // Handle or log the exception
                    throw new Exception("Failed to delete user.", ex);
                }
            }
        }
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetRoleOptions()
        {
            try
            {
                var query = @"SELECT   [RoleId]   ,[RoleName]   FROM [SBCES].[Roles]";

                var options = await _dbConnection.QueryAsync(query);
                return Json(options);
            }
            catch (Exception ex)
            {
                // Log error here
                return StatusCode(500, new { error = $"Failed to load Role: {ex.Message}" });
            }
        }
        [AllowAnonymous]
        private async Task<IEnumerable<RoleModel>> GetRoles()
        {
            var query = "SELECT RoleId, RoleName FROM SBCES.Roles";
            return await _dbConnection.QueryAsync<RoleModel>(query);
        }


        //site related 
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> GetSelectedSites([FromBody] dynamic data)
        {
            var sites = data?.sites?.ToObject<List<string>>() ?? Enumerable.Empty<string>();
            _selectedSites = sites;
            var viewModel = new UserViewModel { SelectedSites = sites };
            return Json(viewModel);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ReadSites([DataSourceRequest] DataSourceRequest request)
        {
            var sites = await GetSites(); 
            return Json(sites);
        }

        [AllowAnonymous]
        private async Task<IEnumerable<SiteModel>> GetSites()
        {
            var query = "SELECT SiteId, SiteName FROM SBCES.Sites";
            var sites = await _dbConnection.QueryAsync<SiteModel>(query);
            return sites.ToList();

        }

        [AllowAnonymous]
        private string GetUserSelectedSiteNames(List<int> selectedSiteIds)
        {
            // Ensure the list of selected site IDs is not empty
            if (selectedSiteIds == null || !selectedSiteIds.Any())
            {
                return string.Empty;
            }

            try
            {
                // Create the SQL query with placeholders for the site IDs
                var query = "SELECT SiteName FROM SBCES.Sites WHERE SiteId IN @SelectedSiteIds";

                // Execute the query using Dapper
                var siteNames =  _dbConnection.Query<string>(query, new { SelectedSiteIds = selectedSiteIds });

                // Concatenate the site names into a single string
                return string.Join(", ", siteNames);
            }
            catch (Exception ex)
            {
                // Log the exception 
                Console.WriteLine($"An error occurred: {ex.Message}");

                // Rethrow the exception or return a default value
                throw; // or return string.Empty;
            }
        }
        // Function to update the Sites list based on selectedSiteIds and selectedSiteNames
        [AllowAnonymous]
        public static UserViewModel UpdateSiteInModel(UserViewModel userView, List<string> selectedSiteIds, List<string> selectedSiteNames)
        {
            // Clear the existing Sites list to avoid duplicates
           // userView.Sites.Clear();

            // Iterate through the selectedSiteIds and selectedSiteNames
            for (int i = 0; i < selectedSiteIds.Count; i++)
            {
                try
                {
                    // Parse the SiteId from string to int
                    if (int.TryParse(selectedSiteIds[i], out int siteId))
                    {
                        // Create a new SiteModel instance
                        var site = new SiteModel
                        {
                            SiteId = siteId,
                            SiteName = selectedSiteNames[i]
                        };

                        // Add the new SiteModel to the Sites list
                        userView.Sites.Add(site);
                    }
                    else
                    {
                        // Handle the case where the SiteId cannot be parsed
                        throw new FormatException($"Invalid SiteId format: {selectedSiteIds[i]}");
                    }
                }
                catch (Exception ex)
                {
                    // Log the exception or handle it as needed
                    Console.WriteLine($"Error updating site: {ex.Message}");
                }
            }

            // Return the updated UserViewModel
            return userView;
        }

    }
}