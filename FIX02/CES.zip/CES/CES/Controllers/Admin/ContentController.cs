﻿using Kendo.Mvc.UI;
using BCES.Models.Parts;
using BCES.Controllers.Base;
using BCES.Data;
using System.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using BCES.Models.Admin;
using Microsoft.AspNetCore.Authorization;
using System.Net;

namespace BCES.Controllers.Admin
{
    public class ContentController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public ContentController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index([DataSourceRequest] DataSourceRequest request)
        {

            return View("~/Views/Admin/Editor.cshtml");

        }

        [HttpPost]
        public IActionResult SaveContent(EditorModel model)
        {
            try
            {
                // Save to DB using Dapper
                _dbConnection.Execute(
                                    @"INSERT INTO SBCES.AdminHtmlContent 
                                        (Content) 
                                        VALUES 
                                        (@Content)",
                                        new { model.Content });

                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                return HandleError(ex);
            }
        }

    }
}
