﻿using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using BCES.Models.Parts;
using BCES.Controllers.Base;
using BCES.Data;
using System.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using BCES.Models.Admin;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Authorization;
using System.Security.Policy;
using System.Threading.Tasks;
using System.Data.Common;

namespace BCES.Controllers.Admin
{
    public class TaskController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public TaskController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }

        //[HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Index([DataSourceRequest] DataSourceRequest request)
        {

            // Fetch data for the grid using the rebuiltPartNum
            GetTaskData();
            //return Json(model.ToDataSourceResult(request));

            return View("~/Views/Admin/LabourTask.cshtml");

        }

        [AllowAnonymous]
        private async Task<IEnumerable<TaskModel>> GetTaskData()
        {
            try
            {

                var query = @" SELECT [TaskId], [TaskDescription]  
                               FROM [SBCES].[LabourTaskDescriptions] 
                               order by [TaskDescription]                        

                                ";

                 var tasks = await _dbConnection.QueryAsync<TaskModel>(query);
                return tasks.Distinct().ToList();

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ReadTasks([DataSourceRequest] DataSourceRequest request)
        {
            try
            {

                var tasks = await GetTaskData();
                
                return Json(tasks.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while fetching tasks.");
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateTask([DataSourceRequest] DataSourceRequest request, TaskModel taskModel)
        {
            try
            {

                await UpdateTasksAsync(taskModel);

                return RedirectToAction("Index");
             
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the task.");
            }
        }

        [AllowAnonymous]
        private async Task UpdateTasksAsync(TaskModel taskModel)
        {
                           
                try
                {
                    string updateQuery = string.Format(@" UPDATE SBCES.LabourTaskDescriptions 
                                                           SET   
                                                            TaskDescription = '{0}' 
                                                             where [TaskId] = {1}", taskModel.TaskDescription,  
                                                             taskModel.TaskId
                                                      );
                  //  var tt = updateQuery;
                    await _dbConnection.ExecuteAsync(updateQuery, taskModel);                   
                                }
                catch (Exception ex)
                {                   
                    // Log the exception (consider using a logging framework)
                    Console.WriteLine($"Error updating tasks: {ex.Message}");

                    // Rethrow the exception to propagate it to the caller
                    throw;
                }            
        }

        [HttpPost]
        [AllowAnonymous]

        public async Task<IActionResult> CreateTask([DataSourceRequest] DataSourceRequest request,  TaskModel taskModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            _dbConnection.Open();
            using (var transaction = _dbConnection.BeginTransaction())
            {

                try
                {
                    
                    //check if useADId Exits in database
                    var checkiftaskExistsQuery = @"
                                        SELECT count(*)
                                        FROM  SBCES.LabourTaskDescriptions
                                        where TaskDescription = '" + taskModel.TaskDescription + "'";
                    var taskCount = await _dbConnection.QuerySingleOrDefaultAsync<int>(checkiftaskExistsQuery, new { TaskDescription = taskModel.TaskDescription }, transaction);
                    if (taskCount > 0)
                    {
                        transaction.Rollback();
                        // Handle or log the exception
                        HandleError(new Exception("Failed to add task. Task exists."));
                        throw new Exception("Failed to add task. Task exists.");
                    }
                    ///
                    var getMaxTaskId = @"
                                        SELECT Max(TaskId)
                                        FROM  SBCES.LabourTaskDescriptions
                                        ";
                    var maxTaskId = await _dbConnection.QuerySingleAsync<int>(getMaxTaskId, new { TaskDescription = taskModel.TaskDescription }, transaction);
                    taskModel.TaskId = maxTaskId + 1;

                    //
                    var insertQuery = String.Format(@" 
                                            INSERT INTO SBCES.LabourTaskDescriptions (TaskID, TaskDescription)
                                            VALUES ((select MAX(TaskID) + 1 from SBCES.LabourTaskDescriptions) , '{0}'); ",

                        taskModel.TaskDescription
                        );


                    await _dbConnection.ExecuteAsync(insertQuery, taskModel,  transaction);

                    // Commit the transaction
                    transaction.Commit();
                    return Json(new [] {taskModel });
                }
                catch (Exception ex)
                {
                    HandleError(ex);
                    return StatusCode(500, "An error occurred while updating the Task.");
                }
            }

        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteTask([DataSourceRequest] DataSourceRequest request, TaskModel model)
        {
            try
            {
                var deleteQuery = String.Format(@"
                DELETE FROM SBCES.LabourTaskDescriptions
                WHERE TaskId  = '{0}'", model.TaskId);


                await _dbConnection.ExecuteAsync(deleteQuery, model);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while deleting the Task.");
            }

        }

    }
}
