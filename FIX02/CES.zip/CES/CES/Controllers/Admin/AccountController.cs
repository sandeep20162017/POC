﻿using BCES.Controllers.Base;
using BCES.Data;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace BCES.Controllers.Admin
{

    public class AccountController : Controller
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;

        //public AccountController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        //{
        //    _httpContextAccessor = httpContextAccessor;
        //    _db = dapper;
        //    _dbConnection = _db.CreateConnection();

        //    var roleName = _httpContextAccessor.HttpContext.Session.GetString("roleName");
        //}
        public AccountController()
        {
            ViewBag.UserName = "Session Expired";
            ViewBag.RoleName = "Session Expired";
        }
        [AllowAnonymous]
        public IActionResult Logout(bool timeout = false)
        {
            HttpContext.SignOutAsync();
            HttpContext.Session.Clear();
            ViewBag.UserName = "Session Expired";
            ViewBag.RoleName = "Session Expired";
            return RedirectToAction("SessionExpired", "Home");
        }
        [HttpPost]
        [Authorize]
        public IActionResult KeepAlive()
        {
            HttpContext.Session.SetString("LastActivity", DateTime.UtcNow.ToString());
            return Json(new { success = true });
        }

       

    }
}
