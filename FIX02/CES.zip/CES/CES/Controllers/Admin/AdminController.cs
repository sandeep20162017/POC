﻿using BCES.Data;
using BCES.Models.Admin;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using NuGet.Protocol;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Admin
{

    public class AdminController : Controller
    {
        public readonly ContextApplicationDB _db;
        private static List<BCES.Models.Admin.RoleModel> roles = new List<BCES.Models.Admin.RoleModel>();

        public AdminController(ContextApplicationDB db)
        {
            _db = db;
        }
        [AllowAnonymous]
        public ActionResult Index()
        {
            

            var roles = _db.Roles.FromSqlInterpolated($"SELECT RoleId, RoleName From SCES.Roles").ToList();
            ViewData["roles"] = roles.ToList();

            ViewBag.UserName = HttpContext.Session.GetString("username");
            ViewBag.RoleId = HttpContext.Session.GetInt32("roleId");
            ViewBag.RoleName = HttpContext.Session.GetString("roleName");
            ////HttpContext.Items["defaultRole"] = categories.First();
            ////HttpContext.Items["roles"] = categories.ToList();
            //ViewData["defaultRole"] = roles.Last();


            return View();
        }
       

    }
}
