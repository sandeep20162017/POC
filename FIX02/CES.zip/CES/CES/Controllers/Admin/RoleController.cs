﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Admin;
using BCES.Models.Common;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Admin
{

    //[Route("Site")]
    public class RoleController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public RoleController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();

            _httpContextAccessor = httpContextAccessor;
        }
        
        [HttpGet("RoleIndex")]
        [AllowAnonymous]
        public IActionResult Index()
        {
            // return View();
            return View("~/Views/Admin/Role.cshtml");
        }

        // POST: NscPartsUsed/GetNscPartsUsedView
        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> GetRoleView([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid (you can use Dapper or any other method)
            var model = await GetRoleData();
            return Json(model.ToDataSourceResult(request));
        }

        
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateRole([DataSourceRequest] DataSourceRequest request, [FromForm] RoleModel roleModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var insertQuery = String.Format(@"
                INSERT INTO SBCES.Roles (RoleName)
                VALUES ('{0}'); ",roleModel.RoleName  );

                var tt = insertQuery;
                await _dbConnection.ExecuteAsync(insertQuery, roleModel);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the Roles.");
            }

        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateRole([DataSourceRequest] DataSourceRequest request, [FromForm] RoleModel role)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var tt = role.RoleName;

                string updateQuery = string.Format(@" UPDATE SBCES.Roles  
                   SET   
                    RoleName = '{0}'  
                   Where RoleId = {1} ", role.RoleName, role.RoleId
                              );

                await _dbConnection.ExecuteAsync(updateQuery, role);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the Roles.");
            }

        }

        
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteRole([DataSourceRequest] DataSourceRequest request,  RoleModel role)
        {
            try
            {
               // var deleteQuery = "";
                var deleteQuery = String.Format(@"
                DELETE FROM SBCES.Roles
                WHERE RoleId  = '{0}' ", role.RoleId);

                await _dbConnection.ExecuteAsync(deleteQuery, role);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while deleting the Role.");
            }

        }

        private async Task<IEnumerable<RoleModel>> GetRoleData()
        {
            try
            {
                var query = @"
                SELECT 
                    role.RoleId,
                    role.RoleName
                   
                FROM 
                    SBCES.Roles role;";


                return await _dbConnection.QueryAsync<RoleModel>(query);
            }
            catch (Exception ex)
            {
                return null;
            }

        }


    }
}