﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using BCES.Data;
using Telerik.SvgIcons;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using BCES.Controllers.Base;
using BCES.Models.Parts;
using BCES.Models.Common;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authorization;

namespace BCES.Controllers.Admin
{

    //[Route("NscPartsUsed")]
    public class SettingController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public SettingController(DapperContext dapper, IHttpContextAccessor httpContextAccessor) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
        }
        // GET: NscPartsUsed/Index
        [HttpGet("SettingIndex")]
        [AllowAnonymous]
        public IActionResult SettingIndex()
        {
            // return View();
            return View("~/Views/Admin/Setting.cshtml");
        }


        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult> GetSetting([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid
            var model = await GetSettingData();
            return Json(model.ToDataSourceResult(request));
        }


       

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateSetting([DataSourceRequest] DataSourceRequest request, [FromForm] SettingModel model)
        {
            try
            {

                string updateQuery = "UPDATE SBCES.CESSETTINGS SET VALUE = '" + model.Value + "' WHERE PARAMETER = '" + model.Parameter + "'";
                await _dbConnection.ExecuteAsync(updateQuery, model);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating the salary.");
            }

        }
             
        private async Task<IEnumerable<SettingModel>> GetSettingData()
        {
            try
            {
                var query = @"
                           SELECT CESSETTINGSID, PARAMETER, VALUE FROM SBCES.CESSETTINGS WHERE PARAMETER IN ('TAX_RATE', 'FRINGE', 'BENEFIT', 'NON_PRODUCTIVE_ADJUSTMENT', 'OVERHEAD', 'SESSIONTIMEOUTMINUTES', 'SESSIONTIMEOUTWARNINGMINUTES')
                        ";
                return await _dbConnection.QueryAsync<SettingModel>(query);
            }
            catch (Exception ex)
            {
                return null;
            }

        }

    }
}