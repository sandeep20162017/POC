﻿using Azure.Core;
using BCES.Controllers.Admin;
using BCES.Controllers.Base;
using BCES.Data;
using BCES.Models.Admin;
using BCES.Models.ArchVehicle;
using BCES.Models.Common;
using BCES.Models.MakeVsBuy;
using BCES.Models.Parts;
using BCES.Models.Parts;
using BCES.Models.Vehicle;
using CES.Models.MakevsBuy;
using Dapper;
using Dapper;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.Blazor;
using MimeKit;
using Newtonsoft.Json.Linq;
using OfficeOpenXml;
using Org.BouncyCastle.Utilities.Zlib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Telerik.DataSource;
using Telerik.DataSource.Extensions;
using Telerik.SvgIcons;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static System.Net.Mime.MediaTypeNames;
using CommandType = System.Data.CommandType;
using DataSourceRequest = Kendo.Mvc.UI.DataSourceRequest;
using Multipart = MimeKit.Multipart;
using SmtpClient = MailKit.Net.Smtp.SmtpClient;

//using System.Net.Mime;
//using CES.Views.Shared;
namespace BCES.Controllers.Parts
{
    // [Route("api/[controller]")]
    public class MakeVsBuyController : BaseController
    {
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IServiceProvider _serviceProvider;
        private readonly BusesController _busesController;
        private readonly LabourDetailsController _labourDetailsController;
        private static List<string> _selectedBuses = new List<string>();


        public MakeVsBuyController(DapperContext dapper, IHttpContextAccessor httpContextAccessor,
                                      IServiceProvider serviceProvider, BusesController busesController,
                                      LabourDetailsController labourDetailsController
                                    ) : base(dapper, httpContextAccessor)
        {
            _db = dapper;
            _dbConnection = _db.CreateConnection();
            _httpContextAccessor = httpContextAccessor;
            _serviceProvider = serviceProvider;
            _busesController = busesController;
            _labourDetailsController = labourDetailsController;
        }

        [HttpGet("MakeVsBuyIndex")]
        [AllowAnonymous]
        public IActionResult MakeVsBuyIndex()
        {
            // return View();
            //GetRebuiltPartsData();
            return View("~/Views/MakeVsBuy/Index.cshtml");
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult ArchivedIndex()
        {
            // return View();
            //GetRebuiltPartsData();
            return View("~/Views/MakeVsBuy/_ArchivedMakeVsBuyIndex.cshtml");
            // return View("~/Views/Vehicles/ArchivedIndex.cshtml");
        }

        //[AllowAnonymous]
        //public IActionResult ArchivedIndex()
        //{
        //    // return View();
        //    return View("~/Views/Vehicles/ArchivedIndex.cshtml");
        //}

        [HttpGet]
        [AllowAnonymous]
        public async Task<JsonResult> GetMakeVsBuyView([DataSourceRequest] DataSourceRequest request)
        {
            try
            {
                var model = await GetMakeVsBuyData();
                return Json(model.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                return Json(new { error = ex.Message });
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<JsonResult> GetArchivedMakeVsBuyView([DataSourceRequest] DataSourceRequest request)
        {
            // Fetch data for the grid 
            try
            {
                var model = await GetArchivedMakeVsBuyData();

                return Json(model.ToDataSourceResult(request));
            }
            catch (Exception ex)
            {
                return Json(ex);
            }
        }


        public async Task<IActionResult> GetMakeVsBuyById(string id, bool readOnly = false)
        {
            if (string.IsNullOrEmpty(id) || id == "0" )
            {
                
                // ADD mode
                var vm = new MakeVsBuyViewModel
                {
                    MbNumber = null
                };

                return PartialView("~/Views/Shared/_MakeVsBuyPopUp.cshtml", vm);
            }

            // EDIT mode
            const string sql = @"
                                SELECT mb.[MbPrefix] as PrefixCode
                                       ,mb.[MbNumber]
                                      ,mb.[Keyword]
                                      ,mb.[Description]
                                      ,mb.[BusType]
                                      ,mb.[NumBusComp]
                                      ,mb.[VendorPartNum]
                                      ,mb.[BuyCode]
                                      ,mb.[RebuildCode]
                                      ,mb.[CoreCode]
                                      ,mb.[AnnualUsage]
                                      ,mb.[BenchNumber]
                                      ,mb.[SampleProvided]
                                      ,mb.[Recommendation]
                                      ,mb.[RemanCost]
                                      ,mb.[ExternalCost]
                                      ,mb.[BuyNewCost]
                                      ,mb.[InternalCost]
                                      ,mb.[SopNumber]
                                      ,mb.[CoreCost]
                                      ,mb.[JobNumber]
                                      ,mb.[DateOpened]
                                      ,mb.[Readmanualnewprice]
                                      ,mb.[MbPrefix]
	                                 ,STRING_AGG(CAST(mblb.listid AS VARCHAR), ',') AS BusId
                                      , STRING_AGG(lb.description, ',') AS BusName
                                  FROM [CES].[SBCES].[MbList] mb
   
                                 LEFT JOIN 
                                     SBCES.MBLISTOFBUSES mblb ON mb.MbNumber = mblb.MbNumber
                                 LEFT JOIN 
                                     SBCES.LISTOFBUSES lb ON lb.listid = mblb.listid
                                     WHERE  --rbl.listid is not null and 
                                      mb.MbNumber =  @MbNumber
	                                GROUP BY
                                       mb.[MbNumber]
                                      ,mb.[Keyword]
                                      ,mb.[Description]
                                      ,mb.[BusType]
                                      ,mb.[NumBusComp]
                                      ,mb.[VendorPartNum]
                                      ,mb.[BuyCode]
                                      ,mb.[RebuildCode]
                                      ,mb.[CoreCode]
                                      ,mb.[AnnualUsage]
                                      ,mb.[BenchNumber]
                                      ,mb.[SampleProvided]
                                      ,mb.[Recommendation]
                                      ,mb.[RemanCost]
                                      ,mb.[ExternalCost]
                                      ,mb.[BuyNewCost]
                                      ,mb.[InternalCost]
                                      ,mb.[SopNumber]
                                      ,mb.[CoreCost]
                                      ,mb.[JobNumber]
                                      ,mb.[DateOpened]
                                      ,mb.[Readmanualnewprice]
                                      ,mb.[MbPrefix]
                                Order by  DateOpened desc";

            var model = await _dbConnection.QueryFirstOrDefaultAsync<MakeVsBuyViewModel>(
                sql,
                new { MbNumber = id }
            );

            if (model == null)
                return NotFound();

            ViewBag.ReadOnly = readOnly;
            ViewBag.ParentId = id;

            return PartialView("~/Views/Shared/_MakeVsBuyPopUp.cshtml", model);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ReadBuses([DataSourceRequest] DataSourceRequest request)
        {
            var buses = await GetVehicleSeries();
            return Json(buses);
        }

        [AllowAnonymous]
        private async Task<IEnumerable<BusesModel>> GetVehicleSeries() //multiselect
        {
            try
            {
                var query = @"
                         SELECT distinct [ListId] as BusId
                          ,[Description] as BusName
                          FROM [CES].[SBCES].[ListOfBuses]";
                var buses = await _dbConnection.QueryAsync<BusesModel>(query);
                return buses.ToList();
            }
            catch (Exception ex)
            {
               
                return null;
            }
        }

        [AllowAnonymous]
        private string GetUserSelectedBusNames(List<int> selectedBusIds)
        {
            // Ensure the list of selected site IDs is not empty
            if (selectedBusIds == null || !selectedBusIds.Any())
            {
                return string.Empty;
            }

            try
            {
                // Create the SQL query with placeholders for the site IDs
                var query = "SELECT   Description FROM [SBCES].[ListOfBuses] WHERE ListId IN @SelectedBusIds";

                // Execute the query using Dapper
                var busNames = _dbConnection.Query<string>(query, new { SelectedBusIds = selectedBusIds });

                // Concatenate the site names into a single string
                return string.Join(", ", busNames);
            }
            catch (Exception ex)
            {
                // Log the exception 
                Console.WriteLine($"An error occurred: {ex.Message}");

                // Rethrow the exception or return a default value
                throw; // or return string.Empty;
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddMakeVsBuyView(  [DataSourceRequest] DataSourceRequest request,
            [FromBody] MakeVsBuyViewModel makevsbuyViewModel)
        {
            try
            {
                //Add buses
                var buses = _selectedBuses;
                makevsbuyViewModel.SelectedBuses = _selectedBuses;
                
                makevsbuyViewModel.DateOpened = DateTime.Now;
                makevsbuyViewModel.DateEntered = DateTime.Now;
                
                //names for display
                string selectedBusIds = string.Join(",", _selectedBuses);
                //update model
                makevsbuyViewModel.BusId = selectedBusIds;

                //convert to it to pass to query
                var busIds = buses.Select(int.Parse).ToList();
                //list of all the SiteNames for binding
                string selectedBusNames = GetUserSelectedBusNames(busIds);
                //update model for binding
                makevsbuyViewModel.BusName = selectedBusNames;

                //site related
                // Split the comma-separated strings into lists
                var busIdsList = _selectedBuses;
                var busNamesList = selectedBusNames.Split(',').ToList();
                var updatedMakeVsBuyView = MakeVsBuyController.UpdateBusInModel(makevsbuyViewModel, busIdsList, busNamesList);

                ////////////////////////////
                if (makevsbuyViewModel == null)
                    return BadRequest("Unable to save. Model data is missing.");

                //if (!ModelState.IsValid)
                //    return BadRequest("Unable to save. Required fields are missing.");

                // ADD mode: MbNumber not set yet
                if (string.IsNullOrEmpty(makevsbuyViewModel.MbNumber))
                {
                    if (string.IsNullOrEmpty(makevsbuyViewModel.MbPrefix))
                        return BadRequest("Prefix is required for new estimates.");
                    _dbConnection.Open();
                    using (var tran = _dbConnection.BeginTransaction())
                    {
                        // 1) increment sequence for this prefix
                        const string updateSql = @"
                UPDATE CES.SBCES.MBPrefixSequence
                SET LastNumber = LastNumber + 1
                WHERE PrefixCode = @Prefix;

                IF @@ROWCOUNT = 0
                BEGIN
                    INSERT INTO CES.SBCES.MBPrefixSequence (PrefixCode, LastNumber)
                    VALUES (@Prefix, 1);
                END;

                SELECT LastNumber
                FROM CES.SBCES.MBPrefixSequence
                WHERE PrefixCode = @Prefix;";

                        var nextNumber = await _dbConnection.ExecuteScalarAsync<int>(
                            updateSql,
                            new { Prefix = makevsbuyViewModel.MbPrefix },
                            tran
                        );

                        // 2) build MbNumber = PREFIX + 6‑digit padded number
                        makevsbuyViewModel.MbNumber =
                            makevsbuyViewModel.MbPrefix + nextNumber.ToString("D6");

                        // 3) insert into main table
                        const string insertSql = @"
                INSERT INTO CES.SBCES.MBLIST
                    (MbPrefix, MbNumber, Keyword, Description, BusType, NumBusComp,
                     VendorPartNum, BuyCode, RebuildCode, CoreCode, AnnualUsage,
                     BenchNumber, SampleProvided,Recommendation, DateOpened, CoreCost,
                     SopNumber,JobNumber,InternalCost,BuyNewCost,RemanCost
                     )
                VALUES
                    (@MbPrefix, @MbNumber, @Keyword, @Description, @BusType, @NumBusComp,
                     @VendorPartNum, @BuyCode, @RebuildCode, @CoreCode, @AnnualUsage,
                     @BenchNumber, @SampleProvided, @Recommendation, GETDATE(), @CoreCost,
                     @SopNumber, @JobNumber,@InternalCost,@BuyNewCost,@RemanCost
                    );";

                        await _dbConnection.ExecuteAsync(insertSql, makevsbuyViewModel, tran);

                        // Insert bus associations
                        var insertBusesQuery = @"
                                            INSERT INTO SBCES.MBLISTOFBUSES (MbNumber, listid)
                                            VALUES (@MbNumber,@BusId)";

                       
                        foreach (var bus in makevsbuyViewModel.Buses)
                        {
                            await _dbConnection.ExecuteAsync(insertBusesQuery, new
                            {
                                makevsbuyViewModel.MbNumber,
                                BusId = bus.BusId
                            }, tran);
                        }

                        tran.Commit();
                    }
                }
                else
                {
                    // EDIT mode: update existing
                    const string updateSql = @"
                            UPDATE CES.SBCES.MBLIST
                            SET Keyword = @Keyword,
                                Description = @Description,
                                BusType = @BusType,
                                NumBusComp = @NumBusComp,
                                VendorPartNum = @VendorPartNum,
                                BuyCode = @BuyCode,
                                RebuildCode = @RebuildCode,
                                CoreCode = @CoreCode,
                                AnnualUsage = @AnnualUsage,
                                BenchNumber = @BenchNumber,
                                SampleProvided = @SampleProvided,
                                Recommendation = @Recommendation,
                                CoreCost = @CoreCost,
                                SopNumber = @SopNumber,
                                JobNumber = @JobNumber,
                                InternalCost = @InternalCost,
                                BuyNewCost = @BuyNewCost, 
                                RemanCost = @RemanCost

                            WHERE MbNumber = @MbNumber;";

                    await _dbConnection.ExecuteAsync(updateSql, makevsbuyViewModel);
                }

                // return MbNumber so client can update title, etc.
                return Json(makevsbuyViewModel);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [AllowAnonymous]
        private async Task<IEnumerable<MakeVsBuyViewModel>> GetMakeVsBuyData()
        {
            try
            {
                var vehiclesQuery = @"
                           SELECT 
                       mb.[MbNumber]
                      ,mb.[Keyword]
                      ,mb.[Description]
                      ,mb.[BusType]
                      ,mb.[NumBusComp]
                      ,mb.[VendorPartNum]
                      ,mb.[BuyCode]
                      ,mb.[RebuildCode]
                      ,mb.[CoreCode]
                      ,mb.[AnnualUsage]
                      ,mb.[BenchNumber]
                      ,mb.[SampleProvided]
                      ,mb.[Recommendation]
                      ,mb.[RemanCost]
                      ,mb.[ExternalCost]
                      ,mb.[BuyNewCost]
                      ,mb.[InternalCost]
                      ,mb.[SopNumber]
                      ,mb.[CoreCost]
                      ,mb.[JobNumber]
                      ,mb.[DateOpened]
                      ,mb.[Readmanualnewprice]
                      ,mb.[MbPrefix]
	                 ,STRING_AGG(CAST(mblb.listid AS VARCHAR), ',') AS BusId
                      , STRING_AGG(lb.description, ',') AS BusName
                  FROM [CES].[SBCES].[MbList] mb
   
                 LEFT JOIN 
                     SBCES.MBLISTOFBUSES mblb ON mb.MbNumber = mblb.MbNumber
                 LEFT JOIN 
                     SBCES.LISTOFBUSES lb ON lb.listid = mblb.listid
                     --WHERE  --rbl.listid is not null and 
                     -- mb.MbNumber = 'MBH0097' -- @Id
	                GROUP BY
                       mb.[MbNumber]
                      ,mb.[Keyword]
                      ,mb.[Description]
                      ,mb.[BusType]
                      ,mb.[NumBusComp]
                      ,mb.[VendorPartNum]
                      ,mb.[BuyCode]
                      ,mb.[RebuildCode]
                      ,mb.[CoreCode]
                      ,mb.[AnnualUsage]
                      ,mb.[BenchNumber]
                      ,mb.[SampleProvided]
                      ,mb.[Recommendation]
                      ,mb.[RemanCost]
                      ,mb.[ExternalCost]
                      ,mb.[BuyNewCost]
                      ,mb.[InternalCost]
                      ,mb.[SopNumber]
                      ,mb.[CoreCost]
                      ,mb.[JobNumber]
                      ,mb.[DateOpened]
                      ,mb.[Readmanualnewprice]
                      ,mb.[MbPrefix]
                Order by mb.DateOpened desc  
                                                                    ";


                var vehicles = _dbConnection.Query<MakeVsBuyViewModel>(vehiclesQuery).ToList();


                return vehicles.Distinct().ToList();

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching MB data: {ex.Message}");
                return Enumerable.Empty<MakeVsBuyViewModel>();
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ReadMbPrefix([DataSourceRequest] DataSourceRequest request)
        {
            var mbPrefix = await GetMbPrefix();
            return Json(mbPrefix);
        }

        [AllowAnonymous]
        private async Task<IEnumerable<MbPrefixModel>> GetMbPrefix() //multiselect
        {
            try
            {
                var query = @"
                         SELECT distinct [PrefixCode] 
                          FROM [CES].[SBCES].[MBPrefixSequence]";
                var mbPrefix = await _dbConnection.QueryAsync<MbPrefixModel>(query);
                return mbPrefix.ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> GetSelectedBuses([FromBody] dynamic data)
        {
            var buses = data?.buses?.ToObject<List<string>>() ?? Enumerable.Empty<string>();
            _selectedBuses = buses;
            var viewModel = new MakeVsBuyViewModel { SelectedBuses = buses };
            return Json(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateMakeVsBuyView([FromBody] MakeVsBuyViewModel vehicleViewModel)
        {
            //if (!ModelState.IsValid)
            //{
            //    var errors = ModelState.Values
            //        .SelectMany(v => v.Errors)
            //        .Select(e => e.ErrorMessage);
            //    return BadRequest(new { Errors = errors });
            //}

            try
            {
                vehicleViewModel.SelectedBuses = _selectedBuses;
                // convert to it to pass to query
                var busIds = _selectedBuses.Select(int.Parse).ToList();

                //list of all the SiteNames for binding
                string selectedBusNames = GetUserSelectedBusNames(busIds);
                //update model for binding
                vehicleViewModel.BusName = selectedBusNames;

                //Update SiteModel
                // Split the comma-separated strings into lists
                var busIdsList = _selectedBuses;
                var busNamesList = selectedBusNames.Split(',').ToList();
                var updatedPartView = MakeVsBuyController.UpdateBusInModel(vehicleViewModel, busIdsList, busNamesList);

                await UpdateMakeVsBuyAsync(vehicleViewModel);

                var updated = await GetMakeVsBuyJsonByIdAsync(vehicleViewModel.MbNumber);

                // return Ok(updated);
                return Ok(new { VehicleListId = vehicleViewModel.MbNumber, Success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Update failed: " + ex.Message);
            }
        }

        public static MakeVsBuyViewModel UpdateBusInModel(MakeVsBuyViewModel busView, List<string> selectedBusIds, List<string> selectedBusNames)
        {
            // Clear the existing Sites list to avoid duplicates
            // busView.Buses.Clear();
            // busView.BusNames.Clear();

            // Iterate through the selectedSiteIds and selectedSiteNames
            for (int i = 0; i < selectedBusIds.Count; i++)
            {
                try
                {
                    // Parse the SiteId from string to int
                    if (int.TryParse(selectedBusIds[i], out int busId))
                    {
                        // Create a new SiteModel instance
                        var bus = new BusesModel
                        {
                            BusId = busId,
                            BusName = selectedBusNames[i]
                        };

                        // Add the new SiteModel to the Sites list
                        busView.Buses.Add(bus);
                    }
                    else
                    {
                        // Handle the case where the SiteId cannot be parsed
                        throw new FormatException($"Invalid SiteId format: {selectedBusIds[i]}");
                    }
                }
                catch (Exception ex)
                {
                    // Log the exception or handle it as needed
                    Console.WriteLine($"Error updating bus: {ex.Message}");
                }
            }
            // Return the updated UserViewModel
            return busView;
        }

        [AllowAnonymous]
        private async Task UpdateMakeVsBuyAsync(MakeVsBuyViewModel makevsbuyViewModel)
        {
            var userName = ViewBag.UserName;
            _dbConnection.Open();
            using (var transaction = _dbConnection.BeginTransaction())
            {
                try
                {
                    // Update the [MBList] table
                    var updateMakeVsBuylistQuery = @"
                                            UPDATE SBCES.[MbList]
                                            SET 

                                                Keyword= @Keyword,
                                                Description =@Description,
                                                BusType= @BusType,
                                                
                                                NumBusComp = @NumBusComp,
                                                
                                                VendorPartNum = @VendorPartNum,
                                                BuyCode = @BuyCode,
                                                RebuildCode = @RebuildCode,
                                                CoreCode = @CoreCode,
                                                AnnualUsage = @AnnualUsage,
                                               
                                                

                                                BenchNumber = @BenchNumber,

 						                        SampleProvided= @SampleProvided,
                                                Recommendation= @Recommendation,
                                                RemanCost = @RemanCost,
                                                ExternalCost = @ExternalCost,
                                                BuyNewCost = @BuyNewCost,

                                               InternalCost = @InternalCost,
                                                SopNumber= @SopNumber,
                                                CoreCost = @CoreCost,
                                                JobNumber = @JobNumber,
                                                DateOpened = @DateOpened                                             
                                               
            
                                            WHERE MbNumber = @MbNumber;
                                        ";

                    await _dbConnection.ExecuteAsync(updateMakeVsBuylistQuery, new
                    {
                        makevsbuyViewModel.Keyword,
                        makevsbuyViewModel.Description,
                        makevsbuyViewModel.BusType,
                       
                        makevsbuyViewModel.NumBusComp,
                        makevsbuyViewModel.VendorPartNum,
                        makevsbuyViewModel.BuyCode,
                        makevsbuyViewModel.RebuildCode,
                        makevsbuyViewModel.CoreCode,
                        makevsbuyViewModel.AnnualUsage,
                        makevsbuyViewModel.BenchNumber,
                        makevsbuyViewModel.SampleProvided,
                        makevsbuyViewModel.Recommendation,
                        makevsbuyViewModel.RemanCost,
                        makevsbuyViewModel.ExternalCost,
                        makevsbuyViewModel.BuyNewCost,
                        makevsbuyViewModel.InternalCost,
                        makevsbuyViewModel.SopNumber,
                        makevsbuyViewModel.CoreCost,
                        makevsbuyViewModel.JobNumber,
                        makevsbuyViewModel.DateOpened,
                        makevsbuyViewModel.MbNumber


                    }, transaction);

                    // -----------------------------
                    // UPDATE BUS LIST
                    // -----------------------------
                    if (_selectedBuses.Count > 0)
                    {
                        // DELETE old buses
                        var deleteSql = @"
                    DELETE FROM SBCES.MBLISTOFBUSES
                    WHERE MbNumber = @MbNumber;
                ";

                        await _dbConnection.ExecuteAsync(deleteSql,
                            new { makevsbuyViewModel.MbNumber },
                            transaction);   // transaction passed


                        // INSERT new buses
                        var insertSql = @"
                            INSERT INTO SBCES.MBLISTOFBUSES (MbNumber, listid)
                            VALUES (@MbNumber, @BusId);
                        ";

                        foreach (var bus in makevsbuyViewModel.Buses)
                        {
                            await _dbConnection.ExecuteAsync(insertSql, new
                            {
                                MbNumber = makevsbuyViewModel.MbNumber,
                                BusId = bus.BusId
                            }, transaction);   // transaction passed
                        }
                    }

                    // Commit the transaction
                    transaction.Commit();

                }
                catch (Exception ex)
                {
                    // Rollback the transaction in case of an error
                    transaction.Rollback();
                    Console.WriteLine($"Error updating makevsbuy: {ex.Message}");
                    throw; // Re-throw the exception to propagate it
                }
            }
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteMakeVsBuy(string MbNumber)
        {

            try
            {
                if (string.IsNullOrEmpty(MbNumber))
                {
                    return BadRequest("Invalid data.");
                }

                var deletePartSql = "DELETE FROM SBCES.[MbList] WHERE MbNumber = '" + MbNumber + "'";

                await _dbConnection.ExecuteAsync(deletePartSql, new { MbNumber });

                //Delete Labour
                string deleteLabourQuery = @"
                    DELETE FROM SBCES.EmployeeLabour 
                    WHERE LINKNUMBER = '" + MbNumber + "' AND TypeId = 'MB'";

                await _dbConnection.ExecuteAsync(deleteLabourQuery, new { MbNumber });

                //Delete SC Parts
                string deleteScPartsQuery = @"DELETE FROM SBCES.SCPartsUsed
                                            WHERE
                                                LINKTYPE = 'BUS'
                                                AND RebuiltPart = 'N'
                                                AND LinkCode = '" + MbNumber + "'";
                await _dbConnection.ExecuteAsync(deleteScPartsQuery, new { MbNumber });

                //Delete NSC Parts
                string deleteNscPartsQuery = @"
                              DELETE FROM SBCES.NSCPartsUsed 
                              WHERE  LINKTYPE = 'MB'                                                
                             AND LinkCode = '" + MbNumber + "'";
                await _dbConnection.ExecuteAsync(deleteNscPartsQuery, new { MbNumber });

                //Delete SC Parts
                string deleteRbPartsQuery = @"DELETE FROM SBCES.SCPartsUsed
                                            WHERE
                                                LINKTYPE = 'MB'
                                                AND RebuiltPart = 'Y'
                                                AND LinkCode = '" + MbNumber + "'";
                await _dbConnection.ExecuteAsync(deleteRbPartsQuery, new { MbNumber });


                return Json(new { success = true });
                //return RedirectToAction("VehiclesIndex");
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Internal server error: {ex.Message}" });
            }
        }


        [AllowAnonymous]
        private async Task<IEnumerable<MakeVsBuyViewModel>> GetArchivedMakeVsBuyData()
        {
            try
            {
                //TODO
                // Base query for rebuilt parts data
                var vehQuery = @"            
                                SELECT  [ArchMbMasterlistId],
									ROW_NUMBER() OVER (
							        PARTITION BY [MbNumber]
							        ORDER BY DateEntered ASC
					          ) AS VersionNo
                                  ,[MbNumber]
                                  ,[Keyword]
                                  ,[Description]
                                  ,[BusType]
                                  ,[NumBusComp]
                                  ,[VendorPartNum]
                                  ,[BuyCode]
                                  ,[RebuildCode]
                                  ,[CoreCode]
                                  ,[AnnualUsage]
                                  ,[BenchNumber]
                                  ,[SampleProvided]
                                  ,[Recommendation]
                                  ,[RemanCost]
                                  ,[ExternalCost]
                                  ,[BuyNewCost]
                                  ,[InternalCost]
                                  ,[SopNumber]
                                  ,[CoreCost]
                                  ,[JobNumber]
                                  ,[LabourCost]
                                  ,[LabourOverheadAmount]
                                  ,[LabourTotal]
                                  ,[MaterialsTotal]
                                  ,[TotalMbEstimateCost]
                                  ,[DateEntered]
                                  ,[TotalTax]
                                  ,[TotalCostTax]
                              FROM [CES].[SBCES].[ArchMbMasterlist]
                              order by [MbNumber] desc, VersionNo desc;
                                            ";

                var vehArchived = (await _dbConnection.QueryAsync<MakeVsBuyViewModel>(vehQuery)).ToList();


                return vehArchived;
            }
            catch (Exception ex)
            {
                // Handle errors gracefully
                return null;
            }
        }

        //[HttpPost]
        //public async Task<IActionResult> AddMakeVsBuyView([DataSourceRequest] DataSourceRequest request,[FromBody] MakeVsBuyViewModel makevsbuyViewModel)
        //{
        //    if (makevsbuyViewModel == null)
        //        return BadRequest("Unable to save. Model data is missing.");

        //    //if (!ModelState.IsValid)
        //    //{
        //    //    return BadRequest("Unable to save. Required fields are missing.");
        //    //}

        //    try
        //    {
        //        var newId = await AddMakeVsBuyAsync(makevsbuyViewModel);

        //        // Re-fetch full model from DB
        //        var updated = await GetMakeVsBuyJsonByIdAsync(newId);

        //        // return Ok(updated);
        //        return Ok(new { MbNumber = newId, Success = true });
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, "Add failed: " + ex.Message);
        //    }
        //}


        [HttpGet]
        private async Task<MakeVsBuyViewModel> GetMakeVsBuyJsonByIdAsync(string id)
        {
            var model = new List<BCES.Models.Parts.StockCodedPartsViewModel> { };
            return await _dbConnection.QueryFirstOrDefaultAsync<MakeVsBuyViewModel>(
           @"
                        SELECT  [MbNumber]
                  ,[Keyword]
                  ,[Description]
                  ,[BusType]
                  ,[NumBusComp]
                  ,[VendorPartNum]
                  ,[BuyCode]
                  ,[RebuildCode]
                  ,[CoreCode]
                  ,[AnnualUsage]
                  ,[BenchNumber]
                  ,[SampleProvided]
                  ,[Recommendation]
                  ,[RemanCost]
                  ,[ExternalCost]
                  ,[BuyNewCost]
                  ,[InternalCost]
                  ,[SopNumber]
                  ,[CoreCost]
                  ,[JobNumber]
                  ,[DateOpened]
                  ,[Readmanualnewprice]
              FROM [CES].[SBCES].[MbList]
                        WHERE MbNumber = @id", new { id });
        }

        [HttpGet]
        public ActionResult GetMakeVsBuyEstimatePopup(int id)
        {
            try
            {
                if (id == 0)
                {
                    // Create a new vehicle for add mode
                    var newVehicle = new MakeVsBuyViewModel();
                    ViewBag.ParentId = 0;
                    ViewBag.FormattedDate = "System Generated";
                    return PartialView("_VehEstimatePopUp", newVehicle);
                }

                // Get existing vehicle data using Dapper
                var vehicle = _dbConnection.QueryFirstOrDefault<MakeVsBuyViewModel>(@"
                SELECT  [MbNumber]
                      ,[Keyword]
                      ,[Description]
                      ,[BusType]
                      ,[NumBusComp]
                      ,[VendorPartNum]
                      ,[BuyCode]
                      ,[RebuildCode]
                      ,[CoreCode]
                      ,[AnnualUsage]
                      ,[BenchNumber]
                      ,[SampleProvided]
                      ,[Recommendation]
                      ,[RemanCost]
                      ,[ExternalCost]
                      ,[BuyNewCost]
                      ,[InternalCost]
                      ,[SopNumber]
                      ,[CoreCost]
                      ,[JobNumber]
                      ,[DateOpened]
                     
                  FROM [CES].[SBCES].[MbList]
                                WHERE MbNumber = @Id",
                            new { Id = id });

                if (vehicle == null)
                {
                    return Content("MakeVsBuy not found");
                }

                ViewBag.ParentId = id;
                ViewBag.FormattedDate = vehicle.DateOpened;

                return PartialView("_VehPopUp", vehicle);
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        private async Task<string> AddMakeVsBuyAsync([FromBody] MakeVsBuyViewModel makevsbuyViewModel)
        {

            //TODO

            //if (!ModelState.IsValid)
            //{
            //    var errors = ModelState.Values
            //        .SelectMany(v => v.Errors)
            //        .Select(e => e.ErrorMessage);
            //    return BadRequest(new { Errors = errors }); <---- How to send errors to user
            //}
            var userName = ViewBag.UserName;
            var maxVehicleListId =
                        _dbConnection.QueryFirstOrDefault<int>(@"SELECT MAX(VehicleListId) + 1  FROM SBCES.VehicleList");

            _dbConnection.Open();
            using (var transaction = _dbConnection.BeginTransaction())
            {
                try
                {
                    // Insert into the main RbMasterlist table
                    var insertVehlistQuery = @"
                                                        INSERT INTO SBCES.VehicleList ( VehicleListId,NumOfVehicles,
                                                            Sopnumber, ProjDesc, Differential, Engine, 
                                                             Make, Model, VehSeriesCode, Year, Transmission,  EnteredBy,
                                                            DateEntered, ModifiedLastBy, ModifiedLastDate
                                                        )
                                                        VALUES (
                                                            @VehicleListId,@NumOfVehicles, @Sopnumber, @ProjDesc, @Differential, @Engine, 
                                                             @Make, @VehModel, @VehSeriesCode, @Year, @Transmission, @EnteredBy,
                                                            @DateEntered, @ModifiedLastBy, @ModifiedLastDate
                                                        );
                                                        
                                                    ";

                    await _dbConnection.ExecuteAsync(insertVehlistQuery, new
                    {
                        VehicleListId = maxVehicleListId,



                        EnteredBy = userName,
                        DateEntered = DateTime.Now,
                        ModifiedLastBy = userName,
                        ModifiedLastDate = DateTime.Now

                    }, transaction);



                    // Commit the transaction
                    transaction.Commit();

                    return "Success"; //TODO

                }
                catch (Exception ex)
                {
                    // Rollback the transaction in case of an error
                    // transaction.Rollback();
                    Console.WriteLine($"Error creating MakeVsBuy data: {ex.Message}");
                    throw; // Re-throw the exception to propagate it
                }
            }

        }

        [HttpGet]
        public ActionResult GetLabourDetailsTabContent(int vehicleId)
        {
            // Fetch data for labour details
            var labourDetails = _dbConnection.Query<LabourDetailsRebuiltPartsViewModel>(
                "SELECT * FROM LabourDetails WHERE VehicleId = @VehicleId",
                new { VehicleId = vehicleId });

            return PartialView("_LabourDetails", labourDetails);
        }

        [AllowAnonymous]
        public IActionResult LabourDetailsPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParenId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_LabourDetails", new List<LabourDetailsRebuiltPartsViewModel>());
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult ScDetailsPartial([FromForm] string id, string gridType)
        {
            ViewBag.ParentId = id;
            ViewBag.PartNum = id;
            if (gridType == null)
            {
                ViewBag.GridType = "VehicleGrid";
            }
            else
            {
                ViewBag.GridType = gridType;

            }

            var model = new List<BCES.Models.Parts.StockCodedPartsViewModel> { };

            return PartialView("_ScPartsUsed", model);

        }

        [AllowAnonymous]
        public IActionResult LabourHourSummaryPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParentId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_LabourHourSummary", new List<LabourDetailsRebuiltPartsViewModel>());
        }

        [AllowAnonymous]
        public IActionResult AllLabourInRBPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParentId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_AllLabour", new List<LabourDetailsRebuiltPartsViewModel>());
        }


        [AllowAnonymous]
        public IActionResult MaterialCostSummaryPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParentId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_MaterialCostSummary", new List<MaterialCostSummaryInRbViewModel>());
        }

        [AllowAnonymous]
        public IActionResult NonStockPartsPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParentId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_NscPartsUsed", new List<NscPartsUsedViewModel>());

        }


        [AllowAnonymous]
        public IActionResult RebuiltPartsPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParenId = id;
            ViewBag.GridType = gridType ?? "VehicleGrid";
            return PartialView("_RbPartsUsed", new List<RebuiltPartsViewModel>());
        }

        [AllowAnonymous]
        public IActionResult TotalCostPartial(string id, string gridType)
        {
            ViewBag.PartNum = id;
            ViewBag.ParenId = id;
            if (gridType == null)
            {
                ViewBag.GridType = "VehicleGrid";
            }
            else
            {
                ViewBag.GridType = gridType;

            }
            var model = new List<BCES.Models.Parts.TotalCostInEstimates> { };
            return PartialView("_TotalCost", model);
            //san return PartialView("_MakeVsBuyTotalCost", model);
        }

        private async Task<IEnumerable<NscPartsUsedViewModel>> GetNonStockParts(string id)
        {
            try
            {
                return await _dbConnection.QueryAsync<NscPartsUsedViewModel>(@"
            SELECT * 
            FROM SBCES.NSCPartsUsed 
            WHERE LinkCode = @Id AND LinkType = 'MB'",
                    new { Id = id });
            }
            catch
            {
                return new List<NscPartsUsedViewModel>();
            }
        }

        private async Task<IEnumerable<RebuiltPartsViewModel>> GetRebuiltParts(string id)
        {
            try
            {
                return await _dbConnection.QueryAsync<RebuiltPartsViewModel>(@"
            SELECT * 
            FROM SBCES.SCPartsUsed 
            WHERE LinkCode = @Id AND LinkType = 'MB' AND RebuiltPart = 'Y'",
                    new { Id = id });
            }
            catch
            {
                return new List<RebuiltPartsViewModel>();
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public IActionResult SaveDetails()
        {
            // Save logic here
            return Json(new { success = true, message = "Saved Details successfully." });
        }


        [HttpPost]
        [AllowAnonymous]
        public IActionResult CancelDetails(int vehicleListId)
        {
            try
            {
                // Return a success response
                return Json(new { success = true, message = "Changes discarded successfully." });
            }
            catch (Exception ex)
            {

                return Json(new { success = false, message = "An error occurred while discarding changes. Please try again." });
            }
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ArchiveMakeVsBuyDetails([FromBody] ArchiveMakeVsBuyRequestModel payload)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@MbId", payload.MbId);
                parameters.Add("@ReturnValue", dbType: DbType.Int32, direction: ParameterDirection.ReturnValue);

                await _dbConnection.ExecuteAsync(
                    "[SBCES].[ArchiveMb]",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                var retVal = parameters.Get<int>("@ReturnValue");

                return Json(new
                {
                    success = retVal == 0,
                    message = retVal == 0
                        ? $"Archived Vehicle List Id: {payload.MbId}"
                        : $"Archive failed with return value: {retVal}"
                });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    message = $"Archive failed: {ex.Message}"
                });
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> SendEmail(string to, string subject, string body, string rebuiltPartNum)
        {
            try
            {
                // Resolve the ExportController from the service provider
                var exportController = _serviceProvider.GetRequiredService<ExportController>();

                // Generate the Excel file in memory by calling SaveToExcel
                var memoryStream = await exportController.SaveToExcel(rebuiltPartNum);


                // Send the email with the attached Excel file
                var message = new MimeMessage();
                message.From.Add(new MailboxAddress("Sandeep Kanao", "sandeep.kanao@ttc.ca"));
                message.To.Add(new MailboxAddress("Sandeep.Kanao@ttc.ca", to));
                message.Subject = subject;
                message.Body = new TextPart("plain") { Text = body };

                var attachment = new MimePart("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                {
                    Content = new MimeContent((Stream)memoryStream),
                    ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                    ContentTransferEncoding = ContentEncoding.Base64,
                    FileName = $"{rebuiltPartNum}_Vehicle_Estimate.xlsx"
                };

                var multipart = new Multipart("mixed");
                multipart.Add(message.Body);
                multipart.Add(attachment);
                message.Body = multipart;

                using (var client = new SmtpClient())
                {
                    await client.ConnectAsync("smtp.freesmtpservers.com", 25, SecureSocketOptions.StartTls);
                    // await client.AuthenticateAsync("sandeep.kanao@gmail.com", "Perf4you@");
                    await client.SendAsync(message);
                    await client.DisconnectAsync(true);
                }

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                // Log the exception 
                Console.WriteLine($"Error sending email: {ex.Message}");

                return Json(new { success = false, message = ex.Message });
            }
        }

        [AllowAnonymous]
        public IActionResult DownloadExcel(string filePath)
        {
            var fileBytes = System.IO.File.ReadAllBytes(filePath);
            return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", Path.GetFileName(filePath));
        }


        [HttpPost]
        [AllowAnonymous]
        public IActionResult CopyEstimate(
        [FromBody] CopyEstimateRequest request) // Create this DTO class
        {
            try
            {
                //              @viMbNumber = N'MBH0097',
                //@viNewMbNumber = N'TEST0001',
                //@viKeyword = N'TEST',
                //@viRebuildNumber = N'TEST',
                //@viEnteredBy = N'System',
                //@voRetVal = @voRetVal OUTPUT
                var parameters = new DynamicParameters();
                parameters.Add("@viMbNumber", request.oldMbNumber, DbType.String);
              //  parameters.Add("@viNewMbNumber", request.newMbNumber, DbType.String);
                parameters.Add("@viKeyword", request.newKeyword, DbType.String);
                parameters.Add("@viRebuildNumber", request.newRebuiltStockNum, DbType.String);
                parameters.Add("@viEnteredBy", "System", DbType.String);
              
                parameters.Add("@voRetVal", dbType: DbType.Int32, direction: ParameterDirection.Output);

                _dbConnection.Execute("SBCES.CopyMbEstimate", parameters, commandType: CommandType.StoredProcedure);

             //   int newVehicleListId = parameters.Get<int>("@viNewMbNumber");
                return Json(new { success = true});
                //throw new NotImplementedException();
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public class CopyEstimateRequest
        {
            public string oldMbNumber { get; set; }
            public string newMbNumber { get; set; }
            public string oldKeyword { get; set; }
            public string oldRebuiltStockNum { get; set; }
            
            public string newKeyword { get; set; }
            public string newRebuiltStockNum { get; set; }
            public string EnteredBy { get; set; }
        }

        /// ///////////////////////
        [AllowAnonymous]
        public IActionResult ConvertMbToRB(
         [FromBody] ConvertMbToRBRequest request) // Create this DTO class
        {
            try
            {
                //check if RebuiltStockNum Exits in database
                var listQuery = @"DECLARE @MbNumber VARCHAR(50)= '" + request.mbNumber + "'" +
                    "\n DECLARE @RebuiltStockNum VARCHAR(50)= '" + request.rbNumber + "'" +
                    "\n DECLARE @MmsStockcode VARCHAR(50)= '" + request.stockNumber + "'" +
                 @"
               

                --RBMasterlist
                --1. RB MasterList
                INSERT INTO SBCES.RbMasterlist
                (
                    MmsStockCode,
                    DetailedDesc,
                    Keyword,
                    CorePartNum,
                    RebuiltStockNum,
                    JobNumber,
                    EstimatedCost,
                    DateEntered,
                    LastModifiedBy,
                    SopNumber,
                    CoreCharge,
                    BuyNewCost,
                    RemanCost,
                    ExternalCost
  
                )
                SELECT
   
	                @MmsStockcode as MmsStockCode,
                    UPPER(MbList.Description)       AS DetailedDesc,
                    UPPER(MbList.Keyword)           AS Keyword,
                    UPPER(MbList.CoreCode)          AS CorePartNum,
                    @RebuiltStockNum    AS RebuiltStockNum,
                    UPPER(MbList.JobNumber)         AS JobNumber,
                    1                               AS EstimatedCost,
                    GETDATE()                       AS DateModified,
                    'System'                       AS LastModifiedBy,
                    UPPER(MbList.SopNumber)         AS SopNumber,
                    ISNULL(UPPER(MbList.CoreCost), ' ') AS CoreCharge,
                    UPPER(MbList.BuyNewCost)        AS BuyNewCost,
                    UPPER(MbList.RemanCost)         AS RemanCost,
                    UPPER(MbList.ExternalCost)      AS ExternalCost
   
                FROM
                    SBCES.MbList AS MbList
                WHERE
                    MbList.MbNumber =  @MbNumber
	                --and MbList.MmsStockCode = @MmsStockcode


                --SCPARTUSED
                INSERT INTO SBCES.ScPartsUsed
                (
                    MmsStockCode,
                    DateEntered,
                    MmsCost,
                    OemCost,
                    LastModifiedBy,
                    LastModifiedDate,
                    CostCentre,
                    QtyReqd,
                    PercentUsage,
                    LinkCode,
                    RebuiltPart,
                    LinkType,
                    MmsRebuiltCode,
                    CoreCost,
                    RebPartCost
                )
                SELECT
                  UPPER(SCPU.MmsStockCode)                                   AS MmsStockCode,
                    GETDATE()                                                  AS DateEntered,
    
                    ISNULL(SCPU.MmsCost, 0)                                    AS MmsCost,
                    ISNULL(SCPU.OemCost, 0)                                    AS OemCost,
                    UPPER('System')                                        AS LastModifiedBy,
                    GETDATE()                                                  AS LastModifiedDate,
                    ISNULL(UPPER(SCPU.CostCentre), ' ')                        AS CostCentre,
                    ISNULL(SCPU.QtyReqd, '0')                                  AS QtyReqd,
                    ISNULL(SCPU.PercentUsage, '0')                             AS PercentUsage,
                    @RebuiltStockNum                                                AS LinkCode,
                    'Y'                                                  AS RebuiltPart,
                   'RB'                                                 AS LinkType,
                    ISNULL(SCPU.MmsRebuiltCode, ' ')                           AS MmsRebuiltCode,
                    ISNULL(SCPU.CoreCost, 0)                                   AS CoreCost,
                    ISNULL(SCPU.RebPartCost, 0)                                AS RebPartCost
                FROM
                    SBCES.ScPartsUsed AS SCPU
                LEFT JOIN
                    SBCES.StockCodedParts AS SCP
                        ON SCP.MmsStockCode = SCPU.MmsStockCode
                WHERE
                   SCPU.LinkCode     =  @MbNumber
                   AND 
	                SCPU.RebuiltPart ='Y'
                    AND SCPU.LinkType = 'MB'
                ORDER BY
                    SCPU.MmsStockCode;   

                --NSCPartsUsed
                INSERT INTO SBCES.NscPartsUsed
                (
                    OrigSuppNum,
                    OrigSupplierName,
                    CostCentre,
                    PercentUsage,
                    EnteredBy,
                    DateEntered,
                    LastModifiedBy,
                    LastModifiedDate,
                    LinkCode,
                    QtyReqd,
                    Cost,
                    LinkType,
                    CoreCost,
                    Id
                )
                SELECT
                    ISNULL(UPPER(NSCPU.OrigSuppNum), ' ')                         AS OrigSuppNum,
                    ISNULL(UPPER(NSCP.OrigSupplierName), ' ')                     AS OrigSupplierName,
                    ISNULL(UPPER(NSCPU.CostCentre), ' ')                          AS CostCentre,
                    ISNULL(NSCPU.PercentUsage, '0')                               AS PercentUsage,
                    EnteredBy                                           AS EnteredBy,
                    GETDATE()                                                     AS DateEntered,
                    NSCPU.LastModifiedBy                                          AS LastModifiedBy,
                    GETDATE()                                                     AS LastModifiedDate,
                    @RebuiltStockNum                                                      AS LinkCode,
                    ISNULL(NSCPU.QtyReqd, '0')                                    AS QtyReqd,
                    ISNULL(NSCPU.Cost, 0)                                         AS Cost,
                    'RB'                                          AS LinkType,
                    ISNULL(NSCPU.CoreCost, 1)                                     AS CoreCost,
                    NSCPU.Id                                                      AS Id
                FROM
                    SBCES.NscPartsUsed AS NSCPU
                LEFT JOIN
                    SBCES.NonStockCodedParts AS NSCP
                        ON NSCP.Id = NSCPU.Id
                WHERE
                    NSCPU.LinkCode = @MBNumber
                    AND NSCPU.LinkType = 'MB'
                ORDER BY
                    NSCPU.OrigSuppNum;

                --EmployeeLabour 
                INSERT INTO SBCES.EmployeeLabour
                (
                    LabourDefn,
                    DateEntered,
                    LinkNumber,
                    TypeId,
                    CostCentre,
                    Task,
                    LabourType,
                    Usage,
                    HrsReqd,
                    AdjHrs,
                    DateRevised,
                    TimeAddition,
                    RebuiltPartNum,
                    LastModifiedBy
                )
                SELECT
                    UPPER(ISNULL(EL.LabourDefn, ' '))                 AS LabourDefn,
                    GETDATE()                                         AS DateEntered,
                    @RebuiltStockNum                AS LinkNumber,
                    'RB'                    AS TypeId,
                    UPPER(ISNULL(EL.CostCentre, ' '))                 AS CostCentre,
                    UPPER(ISNULL(EL.Task, ' '))                       AS Task,
                    UPPER(ISNULL(EL.LabourType, ' '))                 AS LabourType,
                    UPPER(ISNULL(EL.Usage, ' '))                      AS Usage,
                    ISNULL(EL.HrsReqd, 0)                             AS HrsReqd,
                    ISNULL(EL.AdjHrs, 0)                              AS AdjHrs,
                    GETDATE()                                         AS DateRevised,
                    ISNULL(EL.TimeAddition, 0)                        AS TimeAddition,
                    UPPER(ISNULL(EL.RebuiltPartNum, ' '))             AS RebuiltPartNum,
                    LastModifiedBy                                    AS LastModifiedBy
                FROM
                    SBCES.EmployeeLabour AS EL
                WHERE
                    EL.LinkNumber = @MBNumber
                    AND EL.TypeId = 'MB';

                --ListOfBuses

                INSERT INTO SBCES.RbListOfBuses
                (
                    RebuiltStockNum,
                    ListId
                )
                SELECT
                    @RebuiltStockNum,
                    MBLB.ListId
                FROM
                    SBCES.MbListOfBuses AS MBLB
                INNER JOIN
                    SBCES.ListOfBuses AS LOB
                        ON LOB.ListId = MBLB.ListId
                WHERE
                    MBLB.MbNumber = @MbNumber;


                  
                ";

               _dbConnection.ExecuteAsync(listQuery);


                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public class ConvertMbToRBRequest
        {
            public string mbNumber { get; set; }
            public string rbNumber { get; set; }
            public string stockNumber { get; set; }
            
        }
        //////////////////////////////////////////////////

        // === Popup Details Action ===
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ArchiveDetails(int id)
        {
            try
            {
                var vm = await GetArchMakeVsBuyPopup(id);
                return PartialView("_ArchMakeVsBuyPopup", vm);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        private async Task<MakeVsBuyViewModel> GetArchMakeVsBuyPopup(int id)
        {
            try
            {
                // Master
                var masterSql = @"
                  /****** Script for SelectTopNRows command from SSMS  ******/
                    SELECT  [ArchMbMasterlistId]
                          ,[MbNumber]
                          ,[Keyword]
                          ,[Description]
                          ,[BusType]
                          ,[NumBusComp]
                          ,[VendorPartNum]
                          ,[BuyCode]
                          ,[RebuildCode]
                          ,[CoreCode]
                          ,[AnnualUsage]
                          ,[BenchNumber]
                          ,[SampleProvided]
                          ,[Recommendation]
                          ,[RemanCost]
                          ,[ExternalCost]
                          ,[BuyNewCost]
                          ,[InternalCost]
                          ,[SopNumber]
                          ,[CoreCost]
                          ,[JobNumber]
                          ,[LabourCost]
                          ,[LabourOverheadAmount]
                          ,[LabourTotal]
                          ,[MaterialsTotal]
                          ,[TotalMbEstimateCost]
                          ,[DateEntered]
                          ,[TotalTax]
                          ,[TotalCostTax]
                      FROM [CES].[SBCES].[ArchMbMasterlist]
 

                                       WHERE ArchMbMasterlistId =" + id;
                var master = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(masterSql, new { id });

                // SC Parts
                var scSql = @"SELECT MMSSTOCKCODE, SCDESCRIPTION, QTYREQD, TOTALCOST, REBUILTPART, LINKTYPE, LINKCODE
                              FROM SBCES.ARCHMBSCPARTSUSED
                              WHERE REBUILTPART = 'N' and ArchMbMasterlistId =" + id;
                var scParts = await _dbConnection.QueryAsync<ScPartUsedViewModel>(scSql, new { id });

                // NSC Parts
                var nscSql = @"SELECT ORIGSUPPNUM, ORIGSUPPLIERNAME, QTYREQD, TOTALCOST, LINKTYPE, LINKCODE
                               FROM [SBCES].[ArchMBNscPartsUsed]
                               WHERE [ArchMbMasterlistId] =" + id;
                var nscParts = await _dbConnection.QueryAsync<NscPartUsedViewModel>(nscSql, new { id });

                var rbSql = @"SELECT MMSSTOCKCODE, SCDESCRIPTION, QTYREQD, TOTALCOST, REBUILTPART, LINKTYPE, LINKCODE
                              FROM SBCES.ARCHMBSCPARTSUSE
                              WHERE REBUILTPART ='Y' and ArchMbMasterlistId =" + id;
                var rbParts = await _dbConnection.QueryAsync<ScPartUsedViewModel>(scSql, new { id });

                // Employee Labour
                var labourSql = @"SELECT LABOURDEFN, TASK, HRSREQD, ADJHRS, TIMEADDITION
                                  FROM SBCES.ARCHMBEMPLOYEELABOUR
                                  WHERE ArchMbMasterlist =" + id;
                var labour = await _dbConnection.QueryAsync<EmployeeLabourViewModel>(labourSql, new { id });

                // Labour Totals
                var labourTotalsSql = @"SELECT COSTCENTRE, TOTALHOURS
                                        FROM SBCES.ARCHMBLABOURCCTOTAL
                                        WHERE ArchMbMasterlistId =" + id;
                var labourTotals = await _dbConnection.QueryAsync<LabourCcTotalViewModel>(labourTotalsSql, new { id });

                MakeVsBuyViewModel archVehiclePopupViewModel = new MakeVsBuyViewModel
                {
                    ArchMbMasterlistId = master.ArchMbMasterlistId,
                    Keyword = master.Keyword,
                    Description = master.Description,
                    BuyNewCost = master.BuyNewCost,
                    InternalCost = master.InternalCost
                   
                };

                return new MakeVsBuyViewModel
                {
                    ArchMbMasterlistId = master.ArchMbMasterlistId,
                    Keyword = master.Keyword,
                    Description = master.Description,
                    BuyNewCost = master.BuyNewCost,
                    InternalCost = master.InternalCost
                    
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching archive details: {ex.Message}");
                return new MakeVsBuyViewModel();
            }
        }

        ///////////////////////////////////////////////////
    }

}