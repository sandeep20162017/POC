﻿using Microsoft.EntityFrameworkCore;
using BCES.Models;
using System.Reflection;
using Dapper;
using BCES.Models.Admin;



namespace BCES.Data
{
    public class ContextApplicationDB : DbContext
    {
        private readonly IConfiguration? _configuration = null;

        public ContextApplicationDB(IConfiguration configuration)
        {
            this._configuration = configuration;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("DefaultConnection"),
                sqlServerOptionsAction: SqlOperation =>
                {
                    SqlOperation.MigrationsAssembly(typeof(Program).GetTypeInfo().Assembly.GetName().Name);
                    //Configuring Connection Resiliency:
                    ////پیکربندی انعطاف پذیری اتصال:
                    SqlOperation
                    .EnableRetryOnFailure(maxRetryCount: 5,
                     maxRetryDelay: TimeSpan.FromSeconds(30),
                     errorNumbersToAdd: null);

                    //////////// Changing default behavior when client evaluation occurs to throw.// تغییر رفتار پیش‌فرض زمانی که ارزیابی مشتری رخ می‌دهد. 
                    //////////// Default in EFCore would be to log warning when client evaluation is done. // پیش‌فرض در EFCore این است که وقتی ارزیابی مشتری انجام می‌شود، هشدار ثبت شود.
                    //////////options.ConfigureWarnings(warnings => warnings.Throw(RelationalEventId.QueryPossibleUnintendedUseOfEqualsWarning));
                });

        }

        public virtual DbSet<UserModel> Users { get; set; }
        public virtual DbSet<RoleModel> Roles { get; set; }
        public virtual DbSet<UserRoleModel> UserRoles { get; set; }
       
        public virtual DbSet<VehicleDelete> Vehicles { get; set; }
        public virtual DbSet<UserViewModel> UserView { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<UserRole>()
        //        .HasKey(ur => new { ur.UserId, ur.RoleId });

        //    modelBuilder.Entity<UserRole>()
        //        .HasOne(ur => ur.User);

        //    modelBuilder.Entity<UserRole>()
        //        .HasOne(ur => ur.Role)
        //        .WithMany(r => r.UserRoles)
        //        .HasForeignKey(ur => ur.RoleId);
        //}
    }
}
