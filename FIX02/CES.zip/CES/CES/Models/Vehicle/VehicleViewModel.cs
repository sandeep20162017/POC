﻿using BCES.Models.Parts;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Configuration;

namespace BCES.Models.Vehicle
{
   // [Table("VehicleList", Schema = "SBCES")]
    public class VehicleViewModel
    {
        public VehicleViewModel() {
            StockCodedParts = new List<StockCodedPartsViewModel>();
            NonStockParts = new List<NscPartsUsedViewModel>();
            RebuiltParts = new List<RebuiltPartsViewModel>();
        }
        // [Key]

        // [Display(Name = "Vehicle List ID")]
        [Required(ErrorMessage = "Vehicle List Id is required")]
        public int VehicleListId { get; set; }

        public int VersionNo { get; set; }

        public int ArchVehicleListId { get; set; }

        public int OldId { get; set; }

        [Required(ErrorMessage = "Vehicle Series Code is required")]
        [StringLength(50)]
      //  [Display(Name = "Vehicle Series Code")]
        public string VehSeriesCode { get; set; }

       [Required(ErrorMessage = "Num Of Vehicles is required")]
      //  [IntegerValidator]
      //  [Display(Name = "Number of Vehicles")]
        public int NumOfVehicles { get; set; }

        [Required(ErrorMessage = "Description is required")]
        [StringLength(200)]
      //  [Display(Name = "Project Description")]
        public string ProjDesc { get; set; }

      //  [Required]
      //  [Display(Name = "Date Entered")]
        public DateTime? DateEntered { get; set; } = DateTime.Now;

      //  [Required(ErrorMessage = "Entered By is required")]
        //[StringLength(25)]
       // [Display(Name = "Entered By")]
        public string? EnteredBy { get; set; }

       // [Required(ErrorMessage = "Last Modified By is required")]
        //[StringLength(25)]
       // [Display(Name = "Last Modified By")]
        public string? ModifiedLastBy { get; set; }

       // [Required]
       // [Display(Name = "Last Modified Date")]
        public DateTime? ModifiedLastDate { get; set; }

        //[StringLength(25)]
        //[Required(ErrorMessage = "Field is required")]
        public string? Make { get; set; }

        //[StringLength(25)]
        
        public string? VehModel { get; set; }

                
       // [Range(1900, 2100, ErrorMessage = "Year must be 4 digits")]
       // [Required(ErrorMessage = "Field is required")]
        public int? Year { get; set; }

        [StringLength(25)]
       // [Required(ErrorMessage = "Field is required")]
        public string? Engine { get; set; }

        [StringLength(25)]
        //[Required(ErrorMessage = "Field is required")]
        public string? Transmission { get; set; }

        [StringLength(25)]
       // [Required(ErrorMessage = "Field is required")]
        public string? Differential { get; set; }

        [StringLength(30)]
      //  [Display(Name = "SOP Number")]
        public string? Sopnumber { get; set; }

        public decimal? LabourCost { get; set; }

        public decimal? LabourOverheadAmount { get; set; }
        public decimal? LabourTotal { get; set; }
        public decimal? MaterialsTotal { get; set; }
       public decimal? TotalBusEstimateCost { get; set; }

        public List<StockCodedPartsViewModel> StockCodedParts { get; set; }
        public List<NscPartsUsedViewModel> NonStockParts { get; set; }
        public List<RebuiltPartsViewModel> RebuiltParts { get; set; }

        internal object? ToDataSourceResult(object request, ModelStateDictionary modelState)
        {
            throw new NotImplementedException();
        }
    }
}