﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Configuration;

namespace BCES.Models.MakeVsBuy
{
    public class ArchiveMakeVsBuyRequestModel
    {
        public string MbId { get; set; }
        public string VehSeriesCode { get; set; }
        public string TypeId { get; set; }
        public string Username { get; set; }
        public decimal? LabourCost { get; set; }
        public decimal? LabourOverheadAmount { get; set; }
        public decimal? LabourTotal { get; set; }
        public decimal? MaterialsTotal { get; set; }
        public decimal? TotalBusEstimateCost { get; set; }
        public decimal? TaxTotal { get; set; }
        public decimal? TotalCostTax { get; set; }
        public decimal? OemKitsTotal { get; set; }
    }
}