﻿namespace CES.Models.MakevsBuy
{
    public class MbPrefixModel
    {
        public string? PrefixCode { get; set; }
        public int? LastNumber { get; set; }
    }
}
