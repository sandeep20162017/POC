﻿using BCES.Models.Common;
using BCES.Models.Parts;

namespace BCES.Models.MakeVsBuy
{
    public class MakeVsBuyViewModel
    {
        public int ArchMbMasterlistId { get; set; }
        public int VersionNo { get; set; }
        public string MbId { get; set; }

        public string MbNumber { get; set; }
        public string? MbPrefix { get; set; }   // from dropdown

        public string? Keyword { get; set; }
        public string? Description { get; set; }
        public string? BusType { get; set; }
        public string? NumBusComp { get; set; }
        public string? VendorPartNum { get; set; }
        public string? BuyCode { get; set; }
        public string? RebuildCode { get; set; }

        public string? MmsBuyCode { get; set; }
        public string? CoreCode { get; set; }
        public string? AnnualUsage { get; set; }
        public string? BenchNumber { get; set; }
        public string? SampleProvided { get; set; }
        public string? Recommendation { get; set; }
        public string? RemanCost { get; set; }
        public string? ExternalCost { get; set; }
        public string? BuyNewCost { get; set; }
        public string? InternalCost { get; set; }
        public string? SopNumber { get; set; }
        public string? CoreCost { get; set; }
        public string? JobNumber { get; set; }
        public decimal? ManualPrice { get; set; }
        public int? RowId { get; set; }
        public DateTime? DateOpened { get; set; }
        public DateTime? DateEntered { get; set; }


        public List<LabourDetailsRebuiltPartsViewModel>? LabourDetailsRebuiltParts { get; set; } = [];

        public List<BusesModel>? Buses { get; set; } = new List<BusesModel>();

        public List<int>? BusIds { get; set; } = new();// Parsed Site IDs
        public List<string>? BusNames { get; set; } = new();
        public List<string>? SelectedBuses { get; set; }
        public string? BusId { get; set; } // Comma-separated Site IDs from SQL
        public string? BusName { get; set; } // Comma-separated Site Names from SQL

        public string VehicleSeries { get; set; }
        public string VehSeriesCode { get; set; }
        public List<int>? BusIdsList =>
            string.IsNullOrWhiteSpace(BusId)
                ? new List<int>()
                : BusId.Split(',')
                       .Select(int.Parse)
                       .ToList();

        ////TODO 
        //public List<LabourDetailsRebuiltPartsViewModel> LabourDetailsRebuiltParts { get; set; } = [];

        //// Full list of bus objects (for display)
        //public List<BusesModel> ListOfBus { get; set; } = new List<BusesModel>();

        //// List of IDs for editor binding
        //public List<int?> ListOfBusIds { get; set; } = new List<int?>();


    }
}