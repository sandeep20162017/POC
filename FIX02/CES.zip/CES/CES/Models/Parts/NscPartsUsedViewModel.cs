﻿
using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Parts
{
    public class NscPartsUsedViewModel
    {
        // NScPartsUsed Table Columns
       
        //[Required(ErrorMessage = "This field is required.")]
        public int Oid { get; set; }

        [Required(ErrorMessage = "Required.")]
        public string OrigSuppNum { get; set; }

        //[RegularExpression(@"^[a-zA-Z0-9-&\s()]*$", ErrorMessage = "Invalid Supplier Name, check for special characters")]
        [Required(ErrorMessage = "Select supplier name.")]
        public string OrigSupplierName { get; set; }

        [Required(ErrorMessage = "Required.")]
        public int Percentage { get; set; }

        //[Required(ErrorMessage = "Required.")]
        public decimal? UnitCost { get; set; }

        
         public decimal? OemPartCost { get; set; }

        [Required(ErrorMessage = "Required.")]
        public int Qty {  get; set; }

        public int NscPartsUsedId { get; set; }


        //[Required(ErrorMessage = "Required.")]
        public string? CC { get; set; }

        public decimal TotalCost { get; set; }
        public decimal? CoreCost { get; set; }

       // [Required(ErrorMessage = "Required.")]
        public string? Description { get; set; }

        
        public string? KeyWord { get; set; }

        public int Id { get; set; }

        public string? OId { get; set; }

        public String? LastModifiedDate { get; set; }
        public String? LastModifiedBy { get; set; }
    }
}