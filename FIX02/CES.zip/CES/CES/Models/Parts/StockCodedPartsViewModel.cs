﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BCES.Models.Parts
{
    public class StockCodedPartsViewModel
    {
        public int Id { get; set; }
        public decimal? UnitCost { get; set; }

        [Required(ErrorMessage = "Qty field is required.")]
        public decimal Qty { get; set; }

        [Required(ErrorMessage = "Percentage field is required.")]
        public decimal Percentage { get; set; }
            public decimal? CoreCost { get; set; }
        public decimal? TotalCost { get; set; }

        [Required(ErrorMessage = "Cost Centre field is required.")]
        public string CC { get; set; }
   
        public string? Keyword { get; set; }

        [Required(ErrorMessage = "Stock Code field is required.")]
        [StringLength(30)]
        public string MMSStockCode { get; set; }

        [StringLength(30)]
        public string? CorePartNumber { get; set; }

        [StringLength(30)]
        public decimal? MmsCost { get; set; }

        [StringLength(50)]
        public string? PartType { get; set; }

        [StringLength(30)]
        public string? JobNumber { get; set; }

        [StringLength(500)]
        public string? DetailedDesc { get; set; }

        [StringLength(8)]
        public string? DateEntered { get; set; }

        
        public decimal? CoreCharge { get; set; }

        public decimal? PartCost { get; set; }

       
        public decimal? MmsNewCost { get; set; }


        public string? OrigSupplierNum { get; set; }

        [StringLength(40)]
       
        public string? OrigSupplierName { get; set; }

        [NotMapped]
        public string? CostSavingPerUnitDummy { get; set; }

        [NotMapped]
        public string? PercentageSavingPerUnitDummy { get; set; }

        public string? LinkCode { get; set; }

        public string? LastModifiedBy { get; set; }
        public string? EnteredBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }


    }
}