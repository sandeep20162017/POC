﻿namespace BCES.Models.Parts
{
    public class MaterialCostSummaryInRbViewModel
    {
        public string AssemblyArea { get; set; }
        public string  CostCentre {  get; set; }
        public decimal TotalCost { get; set; }
        public decimal Tax { get; set; }
        public decimal TotalWithTax { get; set; }
    }
}
