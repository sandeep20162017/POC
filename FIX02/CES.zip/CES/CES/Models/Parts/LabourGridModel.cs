﻿namespace BCES.Models.Parts
{
    public class LabourGridModel
    {
        public int Id { get; set; }
        public string LabourCode { get; set; }
        public string Description { get; set; }
        public decimal Hours { get; set; }
        public decimal Rate { get; set; }
        public decimal TotalCost { get; set; }
    }

  
}