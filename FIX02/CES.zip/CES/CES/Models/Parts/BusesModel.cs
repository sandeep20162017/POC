﻿namespace BCES.Models.Parts
{
    public class BusesModel
    {
        public int BusId { get; set; }
        public string BusName { get; set; }
       
    }
}
