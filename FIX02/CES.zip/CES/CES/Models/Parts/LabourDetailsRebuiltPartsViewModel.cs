﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Parts
{
    public class LabourDetailsRebuiltPartsViewModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [StringLength(50)]
        [Required(ErrorMessage = "Labour Type field is required.")]
        public string? LabourDefn { get; set; }

        public DateTime? DateEntered { get; set; }


        [StringLength(25)]
        public string? LinkNumber { get; set; }

        [StringLength(5)]
        public string? TypeId { get; set; }

        [StringLength(5)]
        [Required(ErrorMessage = "Cost Centre field is required.")]
        public string? CostCentre { get; set; }

        public string? CostCentreTotalHrs { get; set; }

        [StringLength(50)]

        
        public string? Task { get; set; }

       
        public string? LabourType { get; set; }

        // [Range(0, 100, ErrorMessage = "Usage % must be between 0 and 100.")]

        [Required(ErrorMessage = "Labour Usage field is required.")]
        public int? Usage { get; set; }

        /// <summary> additinal columns for calcuations
        public decimal? DecimalHrs { get; set; }
        public decimal? EffectiveHours { get; set; }
        public string? AdjHrs { get; set; } //make sure to cast this when used
        public decimal LabourCost { get; set; }
        public decimal LabourOverheadTotal { get; set; }
        /// </summary>

        public decimal? AdjustedHours { get; set; }
       

        public int LabourHrs { get; set; }

       // [Range(0, 59, ErrorMessage = "Minutes must be between 0 and 59.")]
        public int LabourMins { get; set; }

        [StringLength(25)]
        public string? HrsReqd { get; set; }

        
        // Change DateOnly to DateTime
        public DateTime? DateRevised { get; set; }

        [Column(TypeName = "numeric(18,2)")]
        public decimal? TimeAddition { get; set; }

       // [StringLength(30)]
       // public string RebuiltPartNum { get; set; }

        [StringLength(25)]
        public string? LastModifiedBy { get; set; }
        ///////////////////////
        ///
       
        public string? Cc { get; set; }        
        public decimal? Time { get; set; }
        public decimal? RatePerHour { get; set; }
        public decimal? TotalCost { get; set; }
        public string? ExtendedTime { get; set; }
        public string? EstimateType { get; set; }
        public string? EstimateNumber { get; set; }
        public decimal? WrenchTime { get; set; }
    }


}


