﻿using System.Collections.Generic;

namespace BCES.Models.Parts
{
    public class TotalCostInEstimates
    {
        //RB --start
     
        
        public string? MmsStockCode { get; set; }
        public string? ItemRefNumber { get; set; }
        public string? CorePartNum { get; set; }
        public string? CoreCharge { get; set; }
        public string? RebuiltStockNum { get; set; }
        


        public decimal? EstimatedCost { get; set; }

        //public string? BuyNewCost { get; set; }
        //public string? RemanCost { get; set; }
        //public string? ExternalCost { get; set; }
        //public string? SopNumber { get; set; }

        public int? Active { get; set; }

        public string? RBListOfBuses { get; set; }

        public DateTime DateEntered { get; set; }

        public string? LastModifiedBy { get; set; }


        //RB --End

        //MakeVsBuy -- start
        public string? Keyword { get; set; }
        public string? Description { get; set; }
        public string? BusType { get; set; }
        public string? NumBusComp { get; set; }
        public string? VendorPartNum { get; set; }
        public string? BuyCode { get; set; }
        public string? RebuildCode { get; set; }
        public string? CoreCode { get; set; }
        public string? AnnualUsage { get; set; }
        public string? BenchNumber { get; set; }
        public string? SampleProvided { get; set; }
        public string? Recommendation { get; set; }
        public string? RemanCost { get; set; }
        public string? ExternalCost { get; set; }
        public string? BuyNewCost { get; set; }
        public string? InternalCost { get; set; }
        public string? SopNumber { get; set; }
        public decimal? CoreCost { get; set; }
        public string? JobNumber { get; set; }
        public DateTime? DateOpened { get; set; }
        public string? Readmanualnewprice { get; set; }
        public string? MbPrefix { get; set; }


        //MakeVsBuy --End
        // Existing properties
        public string LinkCode { get; set; }
      
        public decimal TotalLabourOverheadCost { get; set; }
        public decimal TotalLabourCost { get; set; }
        public decimal MaterialTotalCostNoTax { get; set; }
        public decimal MaterialTotalTaxAmount { get; set; }
        public decimal MaterialTotalWithTax { get; set; }
        public decimal LabourFringe { get; set; }
        public decimal LabourBenefits { get; set; }
        public decimal BlendedFringeBenefitPercent { get; set; }
        public decimal BlendedFringeBenefitCost { get; set; }
        public decimal LabourOverhead { get; set; }
        public decimal FinalLabourCost { get; set; }
        public decimal TotalWithoutTax { get; set; }
        public decimal TotalWithTax { get; set; }
        public decimal SCPartsMaterialCost { get; set; }
        public decimal NSCSCPartsMaterialCost { get; set; }
        public decimal RBPartsMaterialCost { get; set; }

        // NEW: Vehicle Details
        public string VehicleDescription { get; set; }  // ProjDesc
        public string VehicleSeries { get; set; }       // VehSeriesCode

        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int NumOfVehicles { get; set; }
        public string Engine { get; set; }
        public string Transmission { get; set; }
        public string Differential { get; set; }
        public string ModifiedLastBy { get; set; }
        public DateTime ModifiedLastDate { get; set; }
        public string EnteredBy { get; set; }
      
        public string Sopnumber { get; set; }


        // NEW: Labour Hours Summary
        public decimal TotalLabourHours { get; set; }
        public decimal TotalEffectiveHours { get; set; }
        public decimal TotalAdjustedHours { get; set; }

        // NEW: Material Summary Details
        public int TotalStockPartsCount { get; set; }
        public int TotalNonStockPartsCount { get; set; }
        public int TotalRebuiltPartsCount { get; set; }
        public decimal AverageStockPartCost { get; set; }
        public decimal AverageNonStockPartCost { get; set; }
        public decimal AverageRebuiltPartCost { get; set; }

        // NEW: Labour Task Summary (individual lines)
        public List<LabourTaskSummary> LabourTasks { get; set; }

        // NEW: Material Lines (individual part lines)
        public List<MaterialLineItem> MaterialLines { get; set; }
    }

    public class LabourTaskSummary
    {
        public string Task { get; set; }
        public string LabourDefinition { get; set; }
        public string CC { get; set; }
        public decimal Hours { get; set; }
        public decimal EffectiveHours { get; set; }
        public decimal AdjustedHours { get; set; }
        public decimal RatePerHour { get; set; }
        public decimal TotalCost { get; set; }
        public int Count { get; set; }
    }

    public class MaterialLineItem
    {
        public string Type { get; set; }  // "Stock", "Rebuilt", "Non-Stock"
        public string CC { get; set; }
        public string StockCode { get; set; }
        public string Description { get; set; }
        public decimal Quantity { get; set; }
        public decimal UnitCost { get; set; }
        public decimal PercentUsage { get; set; }
        public decimal TotalCost { get; set; }
        public string Supplier { get; set; }  // For NSC parts
    }
}