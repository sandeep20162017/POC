﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Parts
{
    public class AllPartsViewModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PartID { get; set; }

        public string MMSStockCode { get; set; }
        public string CorePartNumber { get; set; }
        public string PartType { get; set; }
        public string JobNumber { get; set; }
        public string DetailedDesc { get; set; }
        public DateTime DateEntered { get; set; }
        public string ItemRefNumber { get; set; }
        public decimal OverheadType { get; set; }
        public decimal CoreCharge { get; set; }
        public decimal PartCost { get; set; }
        public string AddedBy { get; set; }
        public decimal MMSNewCost { get; set; }
        public DateTime MSSyncDate { get; set; }
        public string OrigSupplierNum { get; set; }
        public string OrigSupplierName { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public string Description { get; set; }
        public string Keyword { get; set; }
      
        public decimal MMSBuyCode { get; set; }
       
        public string SOPNumber { get; set; }

        public string CostCentre { get; set; }
        public string QtyReqd { get; set; }
        public string PercentUsage { get; set; }
       
        public string EnteredBy { get; set; }
        public string LinkCode { get; set; }
        public decimal Cost { get; set; }
        public string LinkType { get; set; }
        public decimal CoreCost { get; set; }
        public string OrigSupNum { get; set; }
        public string OrigSupplierName { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime LastModifiedDate { get; set; }



    }
}
