﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Parts
{
    public class AllLabourDetailsModel
    {
        public string LabourType { get; set; }
        public string Cc { get; set; }
        public string Task { get; set; }
        public decimal? Usage { get; set; }
        public decimal? Time { get; set; }
        public decimal? RatePerHour { get; set; }
        public decimal? TotalCost { get; set; }
        public string ExtendedTime { get; set; }
        public string EstimateType { get; set; }
        public string EstimateNumber { get; set; }
        public string WrenchTime { get; set; }
    }


}


