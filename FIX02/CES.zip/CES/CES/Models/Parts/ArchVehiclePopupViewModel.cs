﻿using System;
using System.Collections.Generic;

namespace BCES.Models.ArchVehicle
{
    public class ArchVehiclePopupViewModel
    {
        // Master
        public int? ArchVehicleListId { get; set; }
        public int? OldId { get; set; }
    public string VehSeriesCode { get; set; }
        public string NumOfVehicles { get; set; }
        public string ProjDesc { get; set; }
        public string LinkType { get; set; }
        public string LinkCode { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Year { get; set; }
        public string Engine { get; set; }
        public string Transmission { get; set; }
        public string Differential { get; set; }
        public string ArchivedBy { get; set; }
        public DateTime ArchivedDate { get; set; }

        // Costs
        public decimal? LabourCost { get; set; }
        public decimal? LabourOverheadAmount { get; set; }
        public decimal? LabourTotal { get; set; }
        public decimal? MaterialsTotal { get; set; }
        public decimal? TotalBusEstimateCost { get; set; }
        public decimal? TotalTax { get; set; }
        public decimal? TotalCostTax { get; set; }
       

        // Collections
        public IEnumerable<ScPartUsedViewModel> ScPartsUsed { get; set; } = new List<ScPartUsedViewModel>();
        public IEnumerable<NscPartUsedViewModel> NscPartsUsed { get; set; } = new List<NscPartUsedViewModel>();
        public IEnumerable<ScPartUsedViewModel> RbPartsUsed { get; set; } = new List<ScPartUsedViewModel>();
        public IEnumerable<EmployeeLabourViewModel> EmployeeLabours { get; set; } = new List<EmployeeLabourViewModel>();
        public IEnumerable<LabourCcTotalViewModel> LabourCcTotals { get; set; } = new List<LabourCcTotalViewModel>();
    }

    public class ScPartUsedViewModel
    {
        public string MmsStockCode { get; set; }
        public string ScDescription { get; set; }
        public string QtyReqd { get; set; }
        public decimal? TotalCost { get; set; }
        public string RebuiltPart { get; set; }
    }

    public class NscPartUsedViewModel
    {
        public string OrigSuppNum { get; set; }
        public string OrigSupplierName { get; set; }
        public string QtyReqd { get; set; }
        public decimal? TotalCost { get; set; }
    }

    public class EmployeeLabourViewModel
    {
        public string LabourDefn { get; set; }
        public string Task { get; set; }
        public string HrsReqd { get; set; }
        public string AdjHrs { get; set; }
        public decimal? TimeAddition { get; set; }
    }

    public class LabourCcTotalViewModel
    {
        public string CostCentre { get; set; }
        public decimal? TotalHours { get; set; }
    }
}