﻿namespace CES.Models.Parts
{
    public class RbPartsinRbParts
    {
        public string MmsStockCode { get; set; }
        public string DetailedDesc { get; set; }
        public string Keyword { get; set; }
        public string JobNumber { get; set; }
        public string RebuiltStockNum { get; set; }
        public string? CoreCharge { get; set; }
        public string? CorePartNum { get; set; }
        public string Qty { get; set; }
        public string Percentage { get; set; }
        public string? TotalCost { get; set; }
    }
}
