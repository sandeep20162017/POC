﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BCES.Models.Parts
{
    public class RebuiltPartsViewModel
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]

        public int RbId { get; set; }
        public int RebuiltId { get; set; }
        public string? MmsBuyCode { get; set; }
        public string? MmsRebuiltCode { get; set; }
        public string? MmsStockCode { get; set; }
        public string? CostCentre { get; set; }
        public string? CoreCode { get; set; }


        public string? KeyWord { get; set; }

        
        public string? JobNumber { get; set; }

       
        public string? RebuiltStockNum { get; set; }
        public string? CoreCharge { get; set; }
        public string? CorePartNum { get; set; }

        [Required(ErrorMessage = "Qty field is required.")]
        public int Qty {  get; set; }

        [Required(ErrorMessage = "Percentage field is required.")]
        public int Percentage { get; set; }


        public decimal? TotalCost { get; set; }

        public List<LabourDetailsRebuiltPartsViewModel>? LabourDetailsRebuiltParts { get; set; } = [];

        public List<BusesModel>? Buses { get; set; } = new List<BusesModel>();
       
        public List<int>? BusIds { get; set; } = new();// Parsed Site IDs
        public List<string>? BusNames { get; set; } = new();
        public List<string>? SelectedBuses { get; set; }
        public string? BusId { get; set; } // Comma-separated Site IDs from SQL
        public string? BusName { get; set; } // Comma-separated Site Names from SQL

        public string? Description { get; set; }              

        public string? LastModifiedBy { get; set; }
        public string? LastModifiedDate { get; set; }
        public string? SopNumber { get; set; }
        public string? BuyNewCost { get; set; }
        public string? RemanCost { get; set; }
        public decimal? UnitCost { get; set; }
        public bool IsActive { get; set; }

        public string? MaterialsTotal { get; set; }
        public string? LabourTotal { get; set; }
        public string? TotalRebuiltPartCost { get; set; }
        public string? TotalCostTax { get; set; }
        public string? EnteredBy { get; set; }
        public DateTime? DateEntered { get; set; }

        public List<int> BusIdsList =>
            string.IsNullOrWhiteSpace(BusId)
                ? new List<int>()
                : BusId.Split(',')
                       .Select(int.Parse)
                       .ToList();

        [NotMapped]
        public string? CostSavingPerUnitDummy { get; set; }

        [NotMapped]
        public string? PercentageSavingPerUnitDummy { get; set; }

        public string? ExternalCost { get; set; }

        public string? SCOrigSupplierName { get; set; }
        public string? SCOrigSupplierNum { get; set; }
        public string? SCMMsStockCode { get; set; }
        public string? SCDetailedDesc { get; set; }
        public string? SCJobNumber { get; set; }
        public string? SCOemPartCost { get; set; }
        public string? SCMmsNewCost { get; set; }


    }
}