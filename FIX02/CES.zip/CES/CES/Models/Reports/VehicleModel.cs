﻿using System;

namespace BCES.Models.Reports
{
    public class VehicleModel
    {
        public int VehicleListId { get; set; }
        public string VehSeriesCode { get; set; }
        public int NumOfVehicles { get; set; }
        public string ProjDesc { get; set; }
        public DateTime DateEntered { get; set; }
        public string EnteredBy { get; set; }
        public string ModifiedLastBy { get; set; }
        public DateTime? ModifiedLastDate { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string Engine { get; set; }
        public string Transmission { get; set; }
        public string Differential { get; set; }
        public string SopNumber { get; set; }
    }
}
