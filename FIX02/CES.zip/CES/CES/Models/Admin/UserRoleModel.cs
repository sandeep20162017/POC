﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BCES.Models.Admin
{
    [Table("UserRoles", Schema = "BCES")]
    public class UserRoleModel
    {

        [Column(Order = 1)]
        public int UserId { get; set; }

        [Key]
        [Column(Order = 2)]
        public int RoleId { get; set; }

        // Navigation properties
        [ForeignKey("UserId")]
        public UserModel User { get; set; }

        [ForeignKey("RoleId")]
        public RoleModel Role { get; set; } 

        // Other user-role-related fields
    }
}