﻿using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Admin
{
    public class LabourTypeModel
    {
        public int LabourType { get; set; }
        [Required(ErrorMessage = "Labour Definition is required")]
        public string LabourDefn { get; set; }

        [Required(ErrorMessage = "Wage Group is required")]
        public int WageGroup { get; set; }

       // [Required(ErrorMessage = "Rate Per Hour is required")]
       // [Range(0.01, 200.0, ErrorMessage = "Rate must be positive, between 0.01-200.00")]
        public decimal RatePerHr { get; set; }

        [Required(ErrorMessage = "Hours per week is required")]
        [Range(0, 168, ErrorMessage = "Hours must be between 0-168")]
        public decimal HrsPerWeek { get; set; }

        [Required(ErrorMessage = "Overhead Type is required")]
        [Range(0, double.MaxValue, ErrorMessage = "Cannot be negative.")]
        public decimal? OverheadType { get; set; }
        public string CC { get; set; }

        public string? TotalCost { get; set; }
    }
}
