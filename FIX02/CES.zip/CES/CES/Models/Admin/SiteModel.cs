﻿using Kendo.Mvc.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
//using System.Web.Mvc;
namespace BCES.Models.Admin
{
    public class SiteModel
    {
        /// <summary>
        /// 
        /// </summary>
        [Required]
        public int SiteId { get; set; }
        [Required]
        public string SiteName { get; set; }
        public bool? Checked { get; set; } = false;
       
    }
}
