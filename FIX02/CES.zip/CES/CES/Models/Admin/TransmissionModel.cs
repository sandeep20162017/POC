﻿
using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Admin
{
    public class TransmissionModel
    {
        [Required(ErrorMessage = "This field is required.")]

        [RegularExpression(@"^[^a-z]+$", ErrorMessage = "Lowercase letters are not allowed.")]
        public string Name { get; set; }
    }
}
