﻿namespace BCES.Models.Admin
{
    public class EditorModel
    {
        public int Id { get; set; }
        public string Content { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
