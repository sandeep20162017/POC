﻿using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Admin
{
    public class DifferentialModel
    {
        [Required(ErrorMessage = "This field is required.")]
        
        public string Name { get; set; }
    }
}
