﻿using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Admin
{
    public class BusModel
    {
        /// <summary>
        /// 
        /// </summary>
        public int ListId { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        //[RegularExpression(@"^[^<>\;:""'{}\*\^%#@\]\[}{&/+\!?#]*$", ErrorMessage = "Invalid characters used.")]
        public string Description { get; set; }


    }
}
