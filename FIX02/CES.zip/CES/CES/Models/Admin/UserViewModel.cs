﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BCES.Models.Admin;
using Kendo.Mvc.UI;
using Kendo.Mvc.UI;
using System.Collections.Generic;
//using System.Web.Mvc;

namespace BCES.Models.Admin
{
    public class UserViewModel 
    {
            public int UserID { get; set; }

            [Required(ErrorMessage = "This field is required.")]
            [RegularExpression(@"^[^<>\;:""'{}\*\^%#@\]\[}{&/+\-!?$=#]*$", ErrorMessage = "Invalid characters used.")]
            
            public string UserADId { get; set; }

            [Required(ErrorMessage = "This field is required.")]
            [RegularExpression(@"^[^<>\;:""'{}\*\^%#@\]\[}{&/+\()!$?#]*$", ErrorMessage = "Invalid characters used.")]

            public string UserName { get; set; }
            public string? UserEmail { get; set; }
            public string? UserContactNo { get; set; }
            public string? Location { get; set; }

         
            [Required(ErrorMessage = "This field is required.")]
            public int  RoleId { get; set; }

            public string RoleName { get; set; }

           
            public List<SiteModel>? Sites { get; set; } = new List<SiteModel>();

            public List<string>? SelectedSites { get; set; }

            /////
            public string? SiteId { get; set; } // Comma-separated Site IDs from SQL
            public string? SiteName { get; set; } // Comma-separated Site Names from SQL

            public List<int>? SiteIds { get; set; } = new();// Parsed Site IDs
            public List<string>? SiteNames { get; set; } = new();// Parsed Site Names

    }
}
