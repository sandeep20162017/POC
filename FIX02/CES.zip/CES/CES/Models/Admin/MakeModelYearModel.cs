﻿using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Admin
{
    public class MakeModelYearModel
    {
        [Required(ErrorMessage = "This field is required.")]
        [RegularExpression(@"^[^<>\;:""'{}\*\^%#@\]\[}{&/+\()!?#]*$", ErrorMessage = "Invalid characters used.")]
        public string Make { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        [RegularExpression(@"^[^<>\;:""'{}\*\^%#@\]\[}{&/+\()!?#]*$", ErrorMessage = "Invalid characters used.")]
        
        
        public string VehicleModel { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [RegularExpression(@"^[^<>\;:""'{}\*\^%#@\]\[}{&/+\()!?#]*$", ErrorMessage = "Invalid characters used.")]
        [Range(1960, 2045, ErrorMessage = "Must be positive, between 1900-2199")]
        public int Year { get; set; }
    }
}
