﻿using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Admin
{
    public class TaskModel
    {
        public int TaskId { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        // [RegularExpression(@"^[^<>\;:""'{}\*\^%#@\]\[}{&/+\()!?#]*$", ErrorMessage = "Invalid characters used.")]
        // [RegularExpression(@"^[A-Z\s]+$", ErrorMessage = "Must be uppercase.")]
       // [RegularExpression(@"^[A-Z\s]+$",            ErrorMessage = "Must be uppercase and cannot contain invalid characters.")]
        [RegularExpression(@"^[A-Z0-9_/ \-]+$",
            ErrorMessage = "Must be uppercase and cannot contain invalid characters.")]
        public string TaskDescription { get; set; }
    }
}
