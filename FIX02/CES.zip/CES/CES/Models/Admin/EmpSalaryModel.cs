﻿using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Admin
{
    public class EmpSalaryModel
    {
        [Required(ErrorMessage = "This field is required.")]
        [RegularExpression(@"^[^<>\;""'{}\*\^%#@\]\[}{&/+\()!?#]*$", ErrorMessage = "Invalid characters used.")]
        [Range(1, 100, ErrorMessage = "Cannot be negative, and must be in the range 1-100.")]
        public int WageGroup { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [RegularExpression(@"^[^<>\;""'{}\*\^%#@\]\[}{&/+\()!?#]*$", ErrorMessage = "Invalid characters used.")]
        [Range(0.01, 500.0, ErrorMessage = "Rate must be positive, between 0.01-500.00")]
        public decimal RatePerHour { get; set; }
      
        public DateTime DateEntered { get; set; }
    }
}
