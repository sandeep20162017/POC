﻿using System.ComponentModel.DataAnnotations;

namespace BCES.Models.Admin
{
    public class SettingModel
    {
        public string CesSettingId { get; set; }        
        public string Parameter { get; set; }

        [Required(ErrorMessage = "Value field is required.")]
        [RegularExpression(@"^\d+(?:\.\d+)?$", ErrorMessage = "Non Numeric characters used.")]
        public string Value { get; set; }
       
    }
}
