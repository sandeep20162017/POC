﻿namespace BCES.Models.OEMKit
{
    public class OEMKitModel
    {
        public string PartNumber { get; set; }
        public string DetailedDesc { get; set; }
        public string Keyword { get; set; }
        public string EstimatedCost { get; set; }

    }



}