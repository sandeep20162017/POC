﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BCES.Models.Home
{
    public class ShipCityModel
    {
        public int CityID { get; set; }
        public string CityName { get; set; }

    }
}
