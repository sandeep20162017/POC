﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BCES.Models
{
  
    [Table("VEHICLE_LIST", Schema = "CES")]
    public class VehicleDelete
    {
     
        [Key]
        public Decimal VEHICLE_LIST_ID { get; set; }
        public string VEH_SERIES_CODE { get; set; }
        public string NUM_OF_VEHICLES { get; set; }
        public string PROJ_DESC { get; set; }
        public string MAKE { get; set; }
        public string MODEL { get; set; }
        public string YEAR { get; set; }
        public string ENGINE { get; set; }




    }
}
