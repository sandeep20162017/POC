﻿namespace BCES.Models.Common
{
    public class ListOfBusesModel
    {
        public string RebuiltStockNum { get; set; }
        public string ListId { get; set; }
        public string Description { get; set; }
    }
}
