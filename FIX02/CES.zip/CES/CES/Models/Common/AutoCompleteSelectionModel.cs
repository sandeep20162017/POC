﻿namespace BCES.Models.Common
{
    public class AutoCompleteSelectionModel
    {
       public  string Value { get; set; }
        public string Text { get; set; }

    }
}
