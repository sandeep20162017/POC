﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using System.Threading.Tasks;
using BCES.Data;
using System.Data;
using Dapper;
//using System.Web.Mvc;

public class RoleSessionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IWebHostEnvironment _env;
    private readonly DapperContext _db;
    private readonly IDbConnection _dbConnection;

    public RoleSessionMiddleware(RequestDelegate next, DapperContext dapper)
    {
        _next = next;
       // _env = env;
        _db = dapper;
        _dbConnection = _db.CreateConnection();
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Check if the session variable is already set
       // if (context.Session.GetString("RoleId") == null)
        {
            var userName = Environment.UserName;
            //context.Session.SetString("username", userName);
           context.Items["userName"] = userName;

            var roleId =
                    _dbConnection.QueryFirstOrDefault<int>(@"SELECT r.RoleId FROM BCES.Users u JOIN BCES.Roles r ON u.RoleId = r.RoleId WHERE u.UserName = '" + userName + "'");
            context.Items["roleId"] = (int)roleId;
           // context.Session.SetInt32("roleId", roleId);

            var roleName =
                _dbConnection.QueryFirstOrDefault<string>(@"SELECT r.RoleName FROM BCES.Users u JOIN BCES.Roles r ON u.RoleId = r.RoleId WHERE u.UserName = '" + userName + "'");
            context.Items["roleName"] = roleName;

            // Set the role ID in the session
            context.Session.SetInt32("roleId", roleId);
            context.Session.SetString("roleName", roleName.ToString());
            context.Session.SetString("userName", userName.ToString());
            System.Diagnostics.Debug.WriteLine($"RoleId, RoleName, UserName are set in session: {roleId}, {roleName}, {userName}");
        }

        // Call the next middleware in the pipeline
        await _next(context);
    }

}