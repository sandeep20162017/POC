﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Security.Claims;
using System.Threading.Tasks;
using BCES.Models.Admin;
using BCES.Data;
using System.Data;
using Dapper;
using Telerik.SvgIcons;
//using System.Web.Mvc;

namespace BCES.MiddleWare
{
    public class RoleMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly DapperContext _db;
        private readonly IDbConnection _dbConnection;
        //private readonly DapperHelper _dapperHelper;

        public RoleMiddleware(RequestDelegate next, DapperContext dapper)
        {
            _next = next;
            _db = dapper;
            _dbConnection = _db.CreateConnection();
        }

        public async Task InvokeAsync(HttpContext context)
        {
            
            var userName = Environment.UserName;
          //  context.Session.SetString("username", userName);
            context.Items["userName"] = userName;
            
            var roleId =
                    _dbConnection.QueryFirstOrDefault<int>(@"SELECT r.RoleId FROM BCES.Users u JOIN BCES.Roles r ON u.RoleId = r.RoleId WHERE u.UserName = '" + userName + "'");
            context.Items["roleId"] = roleId;
           // context.Session.SetInt32("roleId", roleId);
            
            var roleName =
                _dbConnection.QueryFirstOrDefault<string>(@"SELECT r.RoleName FROM BCES.Users u JOIN BCES.Roles r ON u.RoleId = r.RoleId WHERE u.UserName = '" + userName + "'");
            context.Items["roleName"] = roleName;
            //context.Session.SetString("roleName", roleName);



            await _next(context);
        }
    }

    public static class RoleMiddlewareExtensions
    {
        public static IApplicationBuilder UseRoleMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RoleMiddleware>();
        }
    }
}
