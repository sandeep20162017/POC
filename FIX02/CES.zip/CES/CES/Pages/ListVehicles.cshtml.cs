using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BCES.Data;
using BCES.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;
using Microsoft.Data.SqlClient;

namespace BCES.Pages
{

    [BindProperties]

    public class ListVehicleModel : PageModel
    {
        public DataSet VehiclesDS { get; set; }
        public  IList<Vehicle>? Vehicles;
        public readonly ContextApplicationDB _db;

        public ListVehicleModel(ContextApplicationDB db)
        {
            _db = db;
        }
        // public List<Vehicle> Vehicles = new List<Vehicle>();
        public void OnGet()
        {
            if (Vehicles != null)
            {
               
             }
            //Vehicles = new List<Vehicle>();
            // Populate the collection with data.
            //Enumerable.Range(1, 50).ToList().ForEach(i => Vehicles.Add(new Vehicle
            //{
            //    VEHICLE_LIST_ID = i+1,
            //    VEH_SERIES_CODE = "Test code - " + (i + 1).ToString(),
            //    NUM_OF_VEHICLES = "44" + (i+1).ToString(),      
            //    PROJ_DESC = "Test Desc - " + (i + 1).ToString()                

            //}));

            Vehicles = GetVehicles();
          //  PopulateVechileDS();
            // Vehicles = _db.Vehicles.OrderByDescending(f => f.VEHICLE_LIST_ID).ToList();
            //Vehicles = _db.Vehicles.FromSqlInterpolated($"SELECT * FROM CES.VEHICLE_LIST").OrderByDescending(f => f.VEHICLE_LIST_ID).ToList();

        }
        public IList<Vehicle> GetVehicles()
        {
            Vehicles = _db.Vehicles.FromSqlInterpolated($"SELECT  [VEHICLE_LIST_ID]      ,[VEH_SERIES_CODE]       ,[NUM_OF_VEHICLES]       ,[PROJ_DESC]       ,[DATE_ENTERED]       ,[ENTERED_BY]       ,[MODIFIED_LAST_BY]       ,[MODIFIED_LAST_DATE]       ,[MAKE]       ,[MODEL]       ,[YEAR]       ,[ENGINE]       ,[TRANSMISSION]       ,[DIFFERENTIAL]       ,[SOPNUMBER] FROM CES.VEHICLE_LIST")
                .OrderByDescending(f => f.VEHICLE_LIST_ID).ToList();
            return Vehicles;
        }

        private void PopulateVechileDS()
        {
            string constr = "server=AppCESDB_DEV ;user=CESUser;password=CESUser#Dev;database=CES";
            using (SqlConnection con = new SqlConnection(constr))
            {
                string query = "SELECT  [VEHICLE_LIST_ID]      ,[VEH_SERIES_CODE]       ,[NUM_OF_VEHICLES]       ,[PROJ_DESC]       ,[DATE_ENTERED]       ,[ENTERED_BY]       ,[MODIFIED_LAST_BY]       ,[MODIFIED_LAST_DATE]       ,[MAKE]       ,[MODEL]       ,[YEAR]       ,[ENGINE]       ,[TRANSMISSION]       ,[DIFFERENTIAL]       ,[SOPNUMBER] FROM CES.VEHICLE_LIST";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        using (DataSet ds = new DataSet())
                        {
                            VehiclesDS = new DataSet();
                            sda.Fill(VehiclesDS);
                        }
                    }
                }
            }
        }

                
        public JsonResult OnPostList([DataSourceRequest] DataSourceRequest request, string additionalParameter)
        {
           // Vehicles = _db.Vehicles.OrderByDescending(f => f.VEHICLE_LIST_ID).ToList();
            Vehicles = _db.Vehicles.FromSqlInterpolated($"SELECT * FROM CES.VEHICLE_LIST").OrderByDescending(f => f.VEHICLE_LIST_ID).ToList();

            return new JsonResult(Vehicles.ToDataSourceResult(request));
        }

        public void OnPostDestroy([DataSourceRequest] DataSourceRequest request, Vehicle vehicle)
        {
            var entity = _db.Vehicles.FromSqlInterpolated($"SELECT * FROM CES.VEHICLE_LIST").OrderByDescending(f => f.VEHICLE_LIST_ID).ToList();
            if (entity != null)
            {
                String deleteQuery = "$(DELETE * FROM CES.VEHICLE_LIST WHERE VEHICLE_LIST_ID = }" +  vehicle.VEHICLE_LIST_ID;
                //_db.Vehicles.FromSqlInterpolated($"DELETE * FROM CES.VEHICLE_LIST WHERE ").OrderByDescending(f => f.VEHICLE_LIST_ID);
                //_db.SaveChanges();
            }

        //    var entity = _db.Vehicles.FirstOrDefault(f => f.VEHICLE_LIST_ID == vehicle.VEHICLE_LIST_ID);
        //    if (entity != null)
        //    {
        //        _db.Vehicles.Remove(entity);
        //        _db.SaveChanges();
        //    }
        //    return new JsonResult(new[] { vehicle }.ToDataSourceResult(request, ModelState));
        }

        public JsonResult OnPostUpdate([DataSourceRequest] DataSourceRequest request, Vehicle vehicle)
        {
            _db.Vehicles.Where(x => x.VEHICLE_LIST_ID == vehicle.VEHICLE_LIST_ID).Select(x => vehicle);

            return new JsonResult(new[] { vehicle }.ToDataSourceResult(request, ModelState));
        }

    }
}
