using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BCES.Data;
using BCES.Models;

namespace BCES.Pages
{
    [BindProperties]
    public class AddModel : PageModel
    {
        public UserModel User { get; set; }
        private readonly  ContextApplicationDB? _db =null;

        public AddModel(ContextApplicationDB db)
        {
            _db= db;    
        }
        public void OnGet()
        {

        }

        public async  Task<IActionResult> OnPostAdd(UserModel user)
        {
            
               await _db.Users.AddAsync(user);
               await _db.SaveChangesAsync();
               return RedirectToPage("ListUsers");
            
            
        }
    }
}
