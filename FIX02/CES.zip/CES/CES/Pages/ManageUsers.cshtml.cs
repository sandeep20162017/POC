using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BCES.Data;
using BCES.Models;
using BCES.Pages.Shared.EditorTemplates;
using BCES.Pages.Shared;
using Microsoft.EntityFrameworkCore;
using System.Data;
using Microsoft.Data.SqlClient;
using Dapper;
using CommandType = System.Data.CommandType;

namespace BCES.Pages
{
    [BindProperties]
    public class ManageUsers : PageModel
    {
        public readonly ContextApplicationDB _db;
        private readonly IConfiguration _configuration;
        public List<UserViewModel> UserViews { get; set; }

        public ManageUsers(ContextApplicationDB db)
        {
            _db = db;
        }
        public void OnGet()
        {

            UserViews = GetUsers();
        }
        public List<UserViewModel> GetUsers()
        {
            UserViews = _db.UserView.FromSqlInterpolated($"EXEC [BCES].[GetAllUsersWithRoles]").ToList();
            // Populate ViewData with roles
            ViewData["Roles"] = _roles;
            return UserViews;

        }

        
        // Sample data for demonstration purposes
        private static List<UserModel> _users = new List<UserModel>
    {
        new UserModel { UserId = 1, UserName = "User1" },
        new UserModel { UserId = 2, UserName = "User2" }
    };

        private static List<RoleModel> _roles = new List<RoleModel>
    {
        new RoleModel { RoleId = 1, RoleName = "Admin" },
        new RoleModel { RoleId = 2, RoleName = "User" },
        new RoleModel { RoleId = 3, RoleName = "Guest" }
    };

        private static List<UserRoleModel> _userRoles = new List<UserRoleModel>
    {
        new UserRoleModel { UserId = 1, RoleId = 1 },
        new UserRoleModel { UserId = 2, RoleId = 2 }
    };


        public JsonResult OnPostGetUsers([DataSourceRequest] DataSourceRequest request)
        {
            var users = _db.Users.Select(u => new UserViewModel
            {
                UserId = u.UserId,
                UserName = u.UserName
            }).ToList();

            return new JsonResult(users.ToDataSourceResult(request));
        }

        public JsonResult OnPostCreateUser([DataSourceRequest] DataSourceRequest request, UserViewModel user)
        {
            if (ModelState.IsValid)
            {
                var newUser = new UserModel
                {
                    UserName = user.UserName
                };

                _db.Users.Add(newUser);
                _db.SaveChanges();

                user.UserId = newUser.UserId;
            }

            return new JsonResult(new[] { user }.ToDataSourceResult(request, ModelState));
        }

        public JsonResult OnPostUpdateUser([DataSourceRequest] DataSourceRequest request, UserViewModel user)
        {
            if (ModelState.IsValid)
            {
                var existingUser = _db.Users.FirstOrDefault(u => u.UserId == user.UserId);
                if (existingUser != null)
                {
                    existingUser.UserName = user.UserName;
                    _db.SaveChanges();
                }
            }

            return new JsonResult(new[] { user }.ToDataSourceResult(request, ModelState));
        }

        public JsonResult OnPostDeleteUser([DataSourceRequest] DataSourceRequest request, UserViewModel user)
        {
            var existingUser = _db.Users.FirstOrDefault(u => u.UserId == user.UserId);
            if (existingUser != null)
            {
                _db.Users.Remove(existingUser);
                _db.SaveChanges();
            }

            return new JsonResult(new[] { user }.ToDataSourceResult(request, ModelState));
        }

        //public async Task<IActionResult> OnPostUpdateUserAsync([FromBody] UserViewModel user)
        //{
        //    using (IDbConnection db = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
        //    {
        //        var parameters = new DynamicParameters();
        //        parameters.Add("@UserId", user.UserId);
        //        parameters.Add("@UserName", user.UserName);
        //        parameters.Add("@RoleId", user.RoleId);

        //        await db.ExecuteAsync("BCES.UpdateUser", parameters, commandType: CommandType.StoredProcedure);
        //        return new JsonResult(new { success = true });
        //    }
        //}

        //public async Task<IActionResult> OnPostDeleteUserAsync([FromBody] int userId)
        //{
        //    using (IDbConnection db = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
        //    {
        //        var parameters = new DynamicParameters();
        //        parameters.Add("@UserId", userId);

        //        await db.ExecuteAsync("BCES.DeleteUser", parameters, commandType: CommandType.StoredProcedure);
        //        return new JsonResult(new { success = true });
        //    }
        //}
    }


}