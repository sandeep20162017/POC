using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BCES.Data;
using BCES.Models;


namespace BCES.Pages
{
    [BindProperties]
    public class UpdateModel : PageModel
    {
        public static IList<UserModel> users;
        public readonly ContextApplicationDB _db;
        public UpdateModel(ContextApplicationDB db)
        {
            _db = db;
        }
        public void OnGet()
        {

        }
        public JsonResult OnPostUpdate([DataSourceRequest] DataSourceRequest request, UserModel user)
        {
            try
            {
                
                if (users != null)
                {
                    users.Clear();
                }
                users = _db.Users.ToList();
                users.Where(x => x.UserId == user.UserId).Select(x => user);

                //Update Row
                var entity = _db.Users.FirstOrDefault(item => item.UserId == user.UserId);
                if (entity != null)
                {
                    entity.UserName = user.UserName;
                   
                    _db.SaveChanges();
                }




                return new JsonResult(new[] { user }.ToDataSourceResult(request, ModelState));
            }
            catch (Exception ex)
            {
                string s = ex.Message.ToString();
                return null;
            }

        }

        public async Task<IActionResult> OnPostUpdateNew(UserModel user)
        {
            try
            {
                if (users != null)
                {
                    users.Clear();
                }
                users = _db.Users.ToList();
                users.Where(x => x.UserId == user.UserId).Select(x => user);

                //Update Row
                var entity = _db.Users.FirstOrDefault(item => item.UserId == user.UserId);
                if (entity != null)
                {
                    entity.UserName = user.UserName;
                    
                    await _db.SaveChangesAsync();
                }

                return RedirectToPage("ListUsers");



            }
            catch (Exception ex)
            {
                string s = ex.Message.ToString();
                return null;
            }
        }
    }
}
