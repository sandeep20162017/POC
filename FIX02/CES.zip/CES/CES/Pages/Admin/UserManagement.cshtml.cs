//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Mvc.RazorPages;
//using System.Collections.Generic;
//using System.Linq;
//using Microsoft.Extensions.Configuration;
//using Microsoft.EntityFrameworkCore;
//using System;
//using BCES.Models;
//using BCES.Data;

//namespace BCES.Pages.Admin
//{
   
//    [BindProperties]
//    public class UserManagement : PageModel
//    {
//        private readonly ContextApplicationDB _db;
//        [BindProperty]
//        public List<UserViewModel> UserViews { get; set; }

//        public UserManagement(ContextApplicationDB db)
//        {
//            _db = db;
//        }

//        public void OnGet()
//        {
//            try
//            {

//               //GetUsersFromDatabase();
                
//                // Get roles from the database
//                var roles = GetRolesFromDatabase();
//                ViewData["Roles"] = roles;
//            }
//            catch (Exception ex)
//            {
//                // Handle exception
//                ViewData["ErrorMessage"] = "An error occurred while fetching roles from the database: " + ex.Message;
//            }
//        }

//        public JsonResult OnPostGetUsers()
//        {
//            try
//            {
//                var users = GetUsersFromDatabase();
//                var results =  new JsonResult(users);
//                return results;
//            }
//            catch (Exception ex)
//            {
//                // Handle exception
//                return new JsonResult(new { error = "An error occurred while fetching users from the database: " + ex.Message });
//            }
//        }

//        public JsonResult OnPostUpdateUser([FromBody] UserViewModel user)
//        {
//            try
//            {
//                var roleId = GetRoleIdByName(user.RoleName);
//                UpdateUserRoleInDatabase(user.UserId, roleId);
//                return new JsonResult(new { success = true });
//            }
//            catch (Exception ex)
//            {
//                // Handle exception
//                return new JsonResult(new { error = "An error occurred while updating the user role in the database: " + ex.Message });
//            }
//        }

//        private List<RoleModel> GetRolesFromDatabase()
//        {
//            return _db.Roles.ToList();
//        }

//        private List<UserViewModel> GetUsersFromDatabase()
//        {
//            return (from u in _db.Users
//                    join ur in _db.UserRoles on u.UserId equals ur.UserId
//                    join r in _db.Roles on ur.RoleId equals r.RoleId
//                    select new UserViewModel
//                    {
//                        UserId = u.UserId,
//                        UserName = u.UserName,
//                        RoleName = r.RoleName
//                    }).ToList();
//        }

//        private int GetRoleIdByName(string roleName)
//        {
//            var role = _db.Roles.FirstOrDefault(r => r.RoleName == roleName);
//            return role?.RoleId ?? 0;
//        }

//        private void UpdateUserRoleInDatabase(int userId, int roleId)
//        {
//            var userRole = _db.UserRoles.FirstOrDefault(ur => ur.UserId == userId);
//            if (userRole != null)
//            {
//                userRole.RoleId = roleId;
//                _db.SaveChanges();
//            }
//        }
//    }

  
//}