
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BCES.Data;
using BCES.Models;

namespace BCES.Pages
{
    [BindProperties]
    public class AddVehicleModel : PageModel
    {
        public Vehicle Vechile { get; set; }
        private readonly ContextApplicationDB? _db = null;

        public AddVehicleModel(ContextApplicationDB db)
        {
            _db = db;
        }
        public void OnGet()
        {

        }

        public async Task<IActionResult> OnPostAdd(Vehicle vehicle)
        {

            await _db.Vehicles.AddAsync(vehicle);
            await _db.SaveChangesAsync();
            return RedirectToPage("ListVehicle");


        }
    }
}

