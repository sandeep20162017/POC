using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BCES.Data;
using BCES.Models;

namespace BCES.Pages
{
    [BindProperties]
    public class ListUserModel : PageModel
    {
        public static IList<UserModel>? Users;
        public readonly ContextApplicationDB _db;

        public ListUserModel(ContextApplicationDB db)
        {
            _db=db;
        }
        public void OnGet()
        {
            if (Users !=null)
            {
                Users.Clear();
            } 
            Users = _db.Users.OrderByDescending(f=> f.UserId).ToList();
        }

        public JsonResult OnPostList([DataSourceRequest] DataSourceRequest request ,string additionalParameter)
        {
            Users = _db.Users.OrderByDescending(f => f.UserId).ToList();

            return new JsonResult(Users.ToDataSourceResult(request));
        }
       
        public JsonResult OnPostDestroy([DataSourceRequest] DataSourceRequest request, UserModel user)
        {
            var entity = _db.Users.FirstOrDefault(f => f.UserId == user.UserId);
            if (entity != null)
            {
                _db.Users.Remove(entity);
                _db.SaveChanges();  
            }
            return new JsonResult(new[] { user }.ToDataSourceResult(request, ModelState));
        }

        public JsonResult OnPostUpdate([DataSourceRequest] DataSourceRequest request, UserModel user)
        {
            _db.Users.Where(x => x.UserId == user.UserId).Select(x => user);

            return new JsonResult(new[] { user }.ToDataSourceResult(request, ModelState));
        }

    }
}
