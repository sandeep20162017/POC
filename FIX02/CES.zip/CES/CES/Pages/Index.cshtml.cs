﻿using BCES.Data;
using BCES.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BCES.Pages
{
    public class IndexModel : PageModel
    {
        private readonly DbContext _db;

        public IndexModel(ContextApplicationDB db)
        {
            _db = db;
        }

       
        public string UserRole { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                // Get the username from the machine the user is logged into
                string username = Environment.UserName;

                // Get the user's role
                UserRole = await GetUserRoleAsync(username);
                //set session
               
                TempData["UserRole"] = UserRole;



                return Page();
            }
            catch (Exception ex)
            {
                // Log the exception
                string exp = ex.InnerException.ToString();
                return RedirectToPage("/Error");
            }
        }

        private async Task<string> GetUserRoleAsync(string username)
        {
            try
            {
                var userRole = await _db.Set<UserRoleModel>()
                    .FromSqlInterpolated($"SELECT * FROM BCES.UserRoles WHERE UserId = (SELECT UserId FROM BCES.Users WHERE Username = {username})")
                    .Join(_db.Set<RoleModel>(), ur => ur.RoleId, r => r.RoleId, (ur, r) => r.RoleName)
                    .FirstOrDefaultAsync();

                return userRole;
            }
            catch (Exception ex)
            {
                // Log the exception
                throw new Exception("Error retrieving user role", ex);
            }
        }
    }
}