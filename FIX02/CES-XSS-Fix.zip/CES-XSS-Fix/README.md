# CES: Fix for the 7 High findings (Cross-site Scripting)

Source: Invicti OWASP Top 10 2021 scan of `ces.uat.int.ttc.ca`, 14 Oct 2026.
The 7 High findings are all Cross-site Scripting on these Rebuilt Parts partial pages,
through the `id` and `gridType` query-string values:

- `/RebuiltParts/LabourDetailsPartial`
- `/RebuiltParts/ScDetailsPartial`
- `/RebuiltParts/RebuiltPartsPartial`
- `/RebuiltParts/NonStockPartsPartial`

## What this fix does

A small middleware checks `id` and `gridType` on those four endpoints **before** any view or
controller runs:

- `id` must be letters, digits, `-` or `_` (1 to 64 characters). Examples that pass:
  `1234`, `abcd123`, `123abcd`, `abcd_123`, `abcd-123`. Missing or empty values pass through unchanged.
- `gridType` must be one of the allowed grid names (list in the middleware file).
- Anything else gets HTTP 400, and the user sees a Kendo dialog ("Invalid ID" or "Invalid Request").

No view or controller changes are needed.

## Contents

| File | What to do |
|---|---|
| `Middleware/InputValidationMiddleware.cs` | Add to the project (new file) |
| `Startup.cs` | Two changes: `using BCES.Middleware;` and one `app.UseMiddleware<...>()` line. A full patched copy is included; **compare with your own before overwriting** |
| `wwwroot/js/site.append.js` | **Append** the contents to the end of your existing `wwwroot/js/site.js` (do not replace the file) |
| `Tests/Test-XssFix.ps1` | Optional PowerShell smoke test using the scan's payload shapes |
| `README.md` | This file |

`Program.cs` is unchanged.

## Install

1. Copy `Middleware/InputValidationMiddleware.cs` into the project (keep the `Middleware` folder).
2. In `Startup.cs`:
   - add `using BCES.Middleware;` at the top
   - in `Configure`, add this right after `app.UseStaticFiles();` and before the session validation middleware:
     ```csharp
     app.UseMiddleware<InputValidationMiddleware>();
     ```
3. Append `wwwroot/js/site.append.js` to the end of `wwwroot/js/site.js`.
   `site.js` is loaded after jQuery and Kendo in the layout, so no view change is needed.
4. Build and deploy to UAT.

## Verify

1. Run `Tests/Test-XssFix.ps1` (adjust `-Base` if needed). Attack lines should return 400; valid lines should not.
2. Open the Rebuilt Parts screens and confirm the grids load normally.
3. Re-run the Invicti scan. All seven High findings should be gone.

## Grid names

All grid names from the application inventory are enabled in `AllowedGridTypes`. Only `RebuiltGrid`
appears in the scan report; the others are likely names and may not match the real strings in code.
If a screen shows the "Invalid Request" dialog, find the real `gridType` value
(search the solution for `gridType` / `ViewBag.GridType`) and add it to the list.

## Notes and limits

- **Scope:** only the four partial actions above are checked. If a future scan flags similar partials
  elsewhere, add their action names to `ProtectedActions` (and the controller prefix if it differs).
- **Root cause is not removed.** The views still write `id` / `gridType` into script blocks without
  encoding. This fix blocks the attack at the entry point. For a lasting fix, encode output in the
  views (for example `Url.Action(...)` or `Json.Serialize(...)` instead of string concatenation) and
  add a Content Security Policy with script nonces. Add this to the backlog.
- **Dialog:** relies on jQuery AJAX (`ajaxError`). If a partial is loaded another way, such as `fetch`,
  the 400 still happens but the dialog will not show.
- **Out of scope:** the Medium and Low findings (HSTS, cookie Secure flag, CORS `AllowAll`, header and
  version disclosure, stack trace, autocomplete) are not addressed here.
- **Logging:** blocked requests are logged as warnings (parameter name, action, client IP; not the value).
