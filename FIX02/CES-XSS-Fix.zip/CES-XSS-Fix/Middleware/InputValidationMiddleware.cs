using System.Text.RegularExpressions;

namespace BCES.Middleware
{
    /// <summary>
    /// Rejects unsafe 'id' / 'gridType' values on the four Rebuilt Parts partial endpoints
    /// (the pages flagged as Cross-site Scripting in the Invicti scan).
    /// </summary>
    public class InputValidationMiddleware
    {
        private static readonly HashSet<string> ProtectedActions = new(StringComparer.OrdinalIgnoreCase)
        {
            "LabourDetailsPartial",
            "ScDetailsPartial",
            "RebuiltPartsPartial",
            "NonStockPartsPartial"
        };

        private static readonly HashSet<string> AllowedGridTypes = new(StringComparer.Ordinal)
        {
            // Seen in the Invicti scan report
            "RebuiltGrid",

            // Vehicles
            "VehicleGrid", "VehiclesGrid", "VehicleListGrid",

            // Rebuilt Parts
            "RebuiltPartsGrid", "RbMasterlistGrid",

            // Make vs Buy
            "MakeVsBuyGrid",

            // Stock Coded Parts
            "StockCodedPartsGrid",

            // Non-Stock Coded Parts
            "NscPartsGrid", "NonStockCodedPartsGrid",

            // Admin - Tasks
            "TaskGrid", "LabourTaskGrid",

            // Admin - Labour Types
            "LabourTypeGrid", "EmplClassGrid",

            // Admin - Cost Centres
            "CostCentreGrid",

            // Admin - Roles
            "RoleGrid", "UserManagementGrid",

            // Admin - Make/Model/Year
            "MakeModelYearGrid", "TypeOfVehicleGrid",

            // Admin - Engines, Transmissions, Differentials
            "EngineGrid", "TransmissionGrid", "DifferentialGrid",

            // Admin - Buses
            "BusGrid", "ListOfBusesGrid",

            // Admin - Settings, Content, Employee Salary
            "SettingGrid", "ContentGrid", "EmpSalaryGrid"
        };

        // Letters, digits, hyphen, underscore. \z (not $) so a trailing newline cannot slip through.
        private static readonly Regex SafeId =
            new(@"\A[A-Za-z0-9_-]{1,64}\z", RegexOptions.Compiled | RegexOptions.CultureInvariant);

        private readonly RequestDelegate _next;
        private readonly ILogger<InputValidationMiddleware> _logger;

        public InputValidationMiddleware(
            RequestDelegate next,
            ILogger<InputValidationMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var segments = (context.Request.Path.Value ?? string.Empty)
                .Split('/', StringSplitOptions.RemoveEmptyEntries);

            if (segments.Length >= 2 &&
                segments[0].Equals("RebuiltParts", StringComparison.OrdinalIgnoreCase) &&
                ProtectedActions.Contains(segments[1]))
            {
                string? invalid = null;

                // id supplied in the URL path: /RebuiltParts/Action/{id}
                if (segments.Length > 2 && !SafeId.IsMatch(segments[2]))
                    invalid = "id";

                // id / gridType supplied in the query string
                if (invalid == null && !AllValid(context.Request.Query["id"], v => SafeId.IsMatch(v)))
                    invalid = "id";

                if (invalid == null && !AllValid(context.Request.Query["gridType"], v => AllowedGridTypes.Contains(v)))
                    invalid = "gridType";

                if (invalid != null)
                {
                    _logger.LogWarning(
                        "Blocked request: invalid '{Param}' on RebuiltParts/{Action} from {RemoteIp}",
                        invalid, segments[1], context.Connection.RemoteIpAddress);

                    context.Response.StatusCode = StatusCodes.Status400BadRequest;
                    context.Response.Headers["X-CES-Validation"] = "InvalidParameter";
                    context.Response.Headers["X-CES-Invalid-Param"] = invalid;
                    context.Response.ContentType = "text/plain; charset=utf-8";
                    await context.Response.WriteAsync("Invalid request parameter.");
                    return;
                }
            }

            await _next(context);
        }

        // Missing or empty values pass through unchanged; anything else must match.
        private static bool AllValid(Microsoft.Extensions.Primitives.StringValues values, Func<string, bool> isValid)
        {
            foreach (var v in values)
            {
                if (string.IsNullOrEmpty(v)) continue;
                if (!isValid(v)) return false;
            }
            return true;
        }
    }
}
