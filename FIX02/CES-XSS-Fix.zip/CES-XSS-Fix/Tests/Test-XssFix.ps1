# Quick check of the XSS fix using the payload shapes from the Invicti scan.
# Run from a Windows machine that can reach the site. Uses your Windows credentials.
# Expected: every "attack" line prints 400, every "valid" line prints something other than 400.

param(
    [string]$Base = "https://ces.uat.int.ttc.ca/RebuiltParts"
)

$actions  = "LabourDetailsPartial","ScDetailsPartial","RebuiltPartsPartial","NonStockPartsPartial"
$payloads = @(
    "'`"--></style></scRipt><scRipt>netsparker(0x00568A)</scRipt>",
    "<scRipt>ns(0x005DDE)</scRipt>"
)

function Try-Get($url) {
    try   { [int](Invoke-WebRequest $url -UseDefaultCredentials -UseBasicParsing).StatusCode }
    catch { [int]$_.Exception.Response.StatusCode }
}

foreach ($a in $actions) {
    foreach ($p in $payloads) {
        $e = [uri]::EscapeDataString($p)
        "{0,-22} id-attack        -> {1}   (expect 400)" -f $a, (Try-Get "$Base/$a`?gridType=RebuiltGrid&id=$e")
        "{0,-22} gridType-attack  -> {1}   (expect 400)" -f $a, (Try-Get "$Base/$a`?gridType=$e&id=3")
    }
    foreach ($id in "1234","abcd123","123abcd","abcd_123","abcd-123") {
        "{0,-22} valid id {1,-9} -> {2}   (expect not 400)" -f $a, $id, (Try-Get "$Base/$a`?gridType=RebuiltGrid&id=$id")
    }
}
