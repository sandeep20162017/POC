import re
import ast
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
errors = []

for path in sorted(BASE_DIR.glob("ces_refresh_*.py")):
    try:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except SyntaxError as exc:
        errors.append(f"{path.name}: {exc}")

for path in sorted(BASE_DIR.glob("ces_refresh_*.py")):
    text = path.read_text(encoding="utf-8")
    if "sys.exit(" in text:
        errors.append(f"{path.name}: contains sys.exit()")
    if re.search(r"(?m)^\s*return\s+[012]\s*(?:#.*)?$", text):
        errors.append(f"{path.name}: contains return 0/1/2")

# The known broken literal connection-string construction must not exist.
for path in sorted(BASE_DIR.glob("ces_refresh_*.py")):
    text = path.read_text(encoding="utf-8")
    if 'DRIVER= + driver + ;SERVER=' in text:
        errors.append(f"{path.name}: contains broken ODBC connection-string expression")

if errors:
    print("VALIDATION FAILED")
    for e in errors:
        print(e)
else:
    print("VALIDATION PASSED")
    print("All migration Python files are syntactically valid.")
    print("No sys.exit() or main-level return 0/1/2 process exits found.")
    print("ODBC connection-string defect is absent.")

# No process exit codes are used by this validator.
