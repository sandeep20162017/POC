@echo off
setlocal
cd /d "%~dp0"
if not exist logs mkdir logs
echo CES Oracle to SQL Server refresh v3 > logs\ces_refresh_all.log
echo.
echo Oracle is READ ONLY. All DELETE operations target SQL Server only.
echo.
echo ===== PHASE 1: DELETE SQL TARGETS =====
echo DELETE SBCES.ArchMbEmployeeLabour
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchMbEmployeeLabour.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchMbListBuses
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchMbListBuses.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchMbmaterielsCcTotal
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchMbmaterielsCcTotal.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchMbNscPartsUsed
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchMbNscPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchMbScPartsUsed
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchMbScPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchRbEmployeeLabour
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchRbEmployeeLabour.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchRbLabourCcTotal
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchRbLabourCcTotal.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchRbListBuses
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchRbListBuses.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchRbMaterialsCcTotal
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchRbMaterialsCcTotal.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchRbNscPartsUsed
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchRbNscPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchRbScPartsUsed
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchRbScPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchVehEmployeeLabour
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchVehEmployeeLabour.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchVehKits
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchVehKits.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchVehLabourCcTotal
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchVehLabourCcTotal.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchVehMaterialsCcTotal
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchVehMaterialsCcTotal.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchVehNscPartsUsed
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchVehNscPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchVehScPartsUsed
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchVehScPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchMbMasterlist
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchMbMasterlist.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchRbMasterlist
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchRbMasterlist.py" >> logs\ces_refresh_all.log 2>&1
echo DELETE SBCES.ArchVehicleList
set CES_REFRESH_MODE=DELETE
python "ces_refresh_ArchVehicleList.py" >> logs\ces_refresh_all.log 2>&1
echo ===== PHASE 2: INSERT SQL PARENTS =====
echo INSERT SBCES.ArchMbMasterlist
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchMbMasterlist.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchRbMasterlist
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchRbMasterlist.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchVehicleList
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchVehicleList.py" >> logs\ces_refresh_all.log 2>&1
echo ===== PHASE 3: INSERT SQL CHILDREN =====
echo INSERT SBCES.ArchMbEmployeeLabour
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchMbEmployeeLabour.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchMbListBuses
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchMbListBuses.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchMbmaterielsCcTotal
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchMbmaterielsCcTotal.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchMbNscPartsUsed
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchMbNscPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchMbScPartsUsed
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchMbScPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchRbEmployeeLabour
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchRbEmployeeLabour.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchRbLabourCcTotal
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchRbLabourCcTotal.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchRbListBuses
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchRbListBuses.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchRbMaterialsCcTotal
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchRbMaterialsCcTotal.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchRbNscPartsUsed
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchRbNscPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchRbScPartsUsed
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchRbScPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchVehEmployeeLabour
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchVehEmployeeLabour.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchVehKits
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchVehKits.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchVehLabourCcTotal
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchVehLabourCcTotal.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchVehMaterialsCcTotal
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchVehMaterialsCcTotal.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchVehNscPartsUsed
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchVehNscPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo INSERT SBCES.ArchVehScPartsUsed
set CES_REFRESH_MODE=INSERT
python "ces_refresh_ArchVehScPartsUsed.py" >> logs\ces_refresh_all.log 2>&1
echo.
echo REFRESH COMPLETE - review logs\ces_refresh_all.log
pause
endlocal
