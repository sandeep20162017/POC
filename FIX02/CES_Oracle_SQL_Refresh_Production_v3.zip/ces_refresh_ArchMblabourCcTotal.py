# CES Oracle -> SQL Server
# REVIEW-ONLY mapping notice.
#
# The supplied DDL contains a mismatch:
#   Oracle ARCH_RB_LABOUR_CC_TOTAL
#   SQL    SBCES.ArchMblabourCcTotal (expects ArchMbMasterlistId)
#
# A second SQL table exists with the logically matching RB mapping:
#   SBCES.ArchRbLabourCcTotal
#
# This script intentionally performs NO database operation.
# It contains no process exit codes.

import logging
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

logger = logging.getLogger("ArchMblabourCcTotal")
logger.setLevel(logging.INFO)
logger.handlers.clear()

fh = logging.FileHandler(LOG_DIR / "ArchMblabourCcTotal_review.log", mode="a", encoding="utf-8")
sh = logging.StreamHandler()
fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
fh.setFormatter(fmt)
sh.setFormatter(fmt)
logger.addHandler(fh)
logger.addHandler(sh)

logger.info("=" * 90)
logger.info("REVIEW REQUIRED | ArchMblabourCcTotal")
logger.info("No Oracle connection was opened.")
logger.info("No SQL Server connection was opened.")
logger.info("No data was read, inserted, updated, or deleted.")
logger.info(
    "DDL mismatch: Oracle ARCH_RB_LABOUR_CC_TOTAL contains "
    "ARCH_RB_MASTERLIST_ID, while SBCES.ArchMblabourCcTotal "
    "expects ArchMbMasterlistId."
)
logger.info("Use SBCES.ArchRbLabourCcTotal for the RB source mapping.")
logger.info("=" * 90)

if __name__ == "__main__":
    logger.info("Review-only script completed.")
