CES Oracle -> SQL Server Refresh Package v3
===============================================

FIXES IN V3
-----------
1. Fixed the SQL Server ODBC connection-string bug that produced:
   IM002 - Data source name not found and no default driver specified.

2. SQL ODBC driver is now "auto" in ces_refresh_config.json.
   Each script checks pyodbc.drivers() and selects the newest installed
   Microsoft SQL Server ODBC driver. If none is installed, the error lists
   the installed drivers.

3. No sys.exit(), return 0, return 1, or return 2 process-exit logic is used.
   Normal Python helper return statements are retained where they are required
   to pass values between functions.

4. Oracle is READ ONLY.
   Oracle operations are SELECT/COUNT only. No Oracle DELETE/UPDATE/INSERT/
   MERGE/TRUNCATE/DROP statements are present.

5. SQL Server is the only database where refresh DELETE/INSERT operations occur.

6. FULL mode keeps the SQL delete and insert in one transaction for each
   individual table. If insertion does not completely succeed, that table's
   SQL transaction is rolled back.

7. Explicit Oracle-to-SQL column lists are used. Identity columns are excluded.

8. ArchMblabourCcTotal remains review-only because the supplied DDL has a real
   Oracle/SQL parent-key mismatch. It performs no database operation.

CONFIGURATION
-------------
Edit ces_refresh_config.json if the SQL Server or Oracle connection details
need to change.

The current SQL Server driver setting is:
    "driver": "auto"

This avoids depending on ODBC Driver 17 specifically.

MODES
-----
Default:
    FULL

Environment variable:
    set CES_REFRESH_MODE=FULL
    set CES_REFRESH_MODE=INSERT
    set CES_REFRESH_MODE=DELETE

FULL:
    Read Oracle -> delete SQL target -> insert SQL target.
    Delete + insert are committed only when all rows insert successfully.

INSERT:
    Read Oracle -> insert into SQL target without deleting existing SQL rows.

DELETE:
    Delete SQL target only.

INDIVIDUAL SCRIPT EXAMPLE
-------------------------
    python ces_refresh_ArchMbMasterlist.py

ALL TABLES
----------
Use:
    ces_refresh_all.bat

The BAT file does SQL Server delete phase followed by SQL Server insert phase.
Oracle is never a delete target.

VALIDATION
----------
Run:
    python validate_package.py

REQUIRED PYTHON PACKAGES
------------------------
    pip install oracledb pyodbc

SQL SERVER ODBC
---------------
At least one Microsoft SQL Server ODBC driver must be installed on Windows.
The scripts automatically select an installed SQL Server driver.

If no driver is installed, install a supported Microsoft ODBC Driver for SQL
Server and rerun.

IMPORTANT
---------
Do not modify Oracle production tables with these scripts. Oracle is intended
as the source and is accessed read-only.
