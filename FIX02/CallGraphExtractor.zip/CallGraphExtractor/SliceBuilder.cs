using System.Text.RegularExpressions;

namespace CallGraph;

public sealed class SliceOptions
{
    public int Depth { get; init; } = 6;
    public int CallersDepth { get; init; } = 1;
    public int MaxNodes { get; init; } = 400;
    /// Target token budget per emitted slice file.
    public int TokenBudget { get; init; } = 6000;
    public bool IncludePaths { get; init; } = true;
}

/// Turns the graph into retrieval-sized units: one slice per entry point,
/// split into parts when it exceeds the token budget.
public sealed class SliceBuilder
{
    private readonly Graph _graph;
    private readonly SchemaIndex _schema;
    private readonly SliceOptions _opt;
    private readonly PathAnalyzer _paths;

    public SliceBuilder(Graph graph, SchemaIndex schema, SliceOptions? options = null)
    {
        _graph = graph;
        _schema = schema;
        _opt = options ?? new SliceOptions();
        _paths = new PathAnalyzer(graph, new PathOptions { MaxDepth = _opt.Depth + 2 });
    }

    /// Closure around a root: downstream calls + N levels of callers + SQL leaves.
    public (HashSet<string> Ids, List<Edge> Edges) Neighborhood(string root, int? depth = null)
    {
        var d = depth ?? _opt.Depth;
        var ids = new HashSet<string>(StringComparer.Ordinal) { root };
        var edges = new List<Edge>();
        var queue = new Queue<(string Id, int Depth)>();
        queue.Enqueue((root, 0));

        while (queue.Count > 0)
        {
            var (cur, cd) = queue.Dequeue();
            if (cd >= d || ids.Count >= _opt.MaxNodes) continue;

            foreach (var e in _graph.Out(cur))
            {
                switch (e.Kind)
                {
                    case EdgeKind.SqlRead:
                    case EdgeKind.SqlWrite:
                    case EdgeKind.SqlProc:
                        ids.Add(e.To);
                        edges.Add(e);
                        break;
                    case EdgeKind.Call:
                    case EdgeKind.Ctor:
                    case EdgeKind.Implements:
                    // Client side: an action's slice should carry the view it
                    // renders and the JS that lives in it.
                    case EdgeKind.Renders:
                    case EdgeKind.Includes:
                    case EdgeKind.ScriptRef:
                    case EdgeKind.Defines:
                    case EdgeKind.JsCall:
                    case EdgeKind.HttpCall:
                    case EdgeKind.FormPost:
                        edges.Add(e);
                        if (ids.Add(e.To)) queue.Enqueue((e.To, cd + 1));
                        break;
                }
            }
        }

        // callers, so the model can see who else is affected by a change
        var upQueue = new Queue<(string Id, int Depth)>();
        upQueue.Enqueue((root, 0));
        while (upQueue.Count > 0)
        {
            var (cur, cd) = upQueue.Dequeue();
            if (cd >= _opt.CallersDepth) continue;
            foreach (var e in _graph.In(cur))
            {
                // HttpCall/FormPost upward answers "which page calls this action?"
                if (e.Kind is not (EdgeKind.Call or EdgeKind.Ctor or EdgeKind.Implements
                                   or EdgeKind.HttpCall or EdgeKind.FormPost
                                   or EdgeKind.Defines or EdgeKind.ScriptRef or EdgeKind.Renders))
                    continue;
                edges.Add(e);
                if (ids.Add(e.From)) upQueue.Enqueue((e.From, cd + 1));
            }
        }

        var filtered = edges
            .Where(e => ids.Contains(e.From) && ids.Contains(e.To))
            .GroupBy(e => e.Key).Select(g => g.First()).ToList();

        return (ids, filtered);
    }

    public List<Slice> BuildAll(Action<string>? log = null)
    {
        var result = new List<Slice>();
        foreach (var entry in _graph.EntryPoints().OrderBy(n => n.Id, StringComparer.Ordinal))
            result.AddRange(Build(entry.Id));
        log?.Invoke($"slices: {result.Count}");
        return result;
    }

    public List<Slice> Build(string rootId)
    {
        var (ids, edges) = Neighborhood(rootId);
        var root = _graph.Get(rootId);
        var nodes = ids.Select(_graph.Get).Where(n => n is not null).Cast<Node>()
                       .OrderBy(n => n.Id, StringComparer.Ordinal).ToList();

        var tables = nodes.Where(n => n.IsSql).Select(n => n.Name!).Distinct()
                          .OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();

        var full = new Slice
        {
            Id = Stem(rootId),
            Entry = rootId,
            Route = root?.Route,
            Nodes = nodes,
            Edges = edges,
            Tables = tables,
            Schema = _schema.For(tables),
            Paths = _opt.IncludePaths ? _paths.From(rootId) : new List<CallPath>()
        };

        return SplitToBudget(full, _opt.TokenBudget);
    }

    /// Splits an oversized slice into parts. The entry, route, tables and schema
    /// are repeated in every part so each part stands alone in a prompt.
    public static List<Slice> SplitToBudget(Slice slice, int budget)
    {
        slice.EstTokens = TokenCounter.Estimate(slice);
        if (slice.EstTokens <= budget) return new List<Slice> { slice };

        var header = new Slice
        {
            Id = slice.Id, Entry = slice.Entry, Route = slice.Route,
            Nodes = new List<Node>(), Edges = new List<Edge>(),
            Tables = slice.Tables, Schema = slice.Schema
        };
        var headerCost = TokenCounter.Estimate(header);

        var buckets = new List<List<Node>>();
        var current = new List<Node>();
        var cost = headerCost;

        foreach (var n in slice.Nodes)
        {
            var c = TokenCounter.Estimate(n);
            if (current.Count > 0 && cost + c > budget)
            {
                buckets.Add(current);
                current = new List<Node>();
                cost = headerCost;
            }
            current.Add(n);
            cost += c;
        }
        if (current.Count > 0) buckets.Add(current);

        var parts = new List<Slice>();
        for (var i = 0; i < buckets.Count; i++)
        {
            var set = buckets[i].Select(n => n.Id).ToHashSet(StringComparer.Ordinal);
            var partEdges = slice.Edges.Where(e => set.Contains(e.From) || set.Contains(e.To)).ToList();
            var partPaths = slice.Paths.Where(p => p.Steps.Any(s => set.Contains(s.Id))).ToList();

            var part = new Slice
            {
                Id = $"{slice.Id}#p{i + 1}",
                Entry = slice.Entry,
                Route = slice.Route,
                Part = i + 1,
                PartsTotal = buckets.Count,
                Nodes = buckets[i],
                Edges = partEdges,
                Paths = partPaths,
                Tables = slice.Tables,
                Schema = slice.Schema,
                OmittedBranches = slice.Nodes.Where(n => !set.Contains(n.Id))
                                             .Select(n => n.Id).Take(50).ToArray()
            };
            part.EstTokens = TokenCounter.Estimate(part);
            parts.Add(part);
        }
        return parts;
    }

    public static SliceIndexEntry Index(Slice s, string fileName)
    {
        var files = s.Nodes.Select(n => n.File).Where(f => f is not null)
                           .Cast<string>().Distinct().ToArray();

        var text = string.Join(" ", new[]
            {
                s.Route ?? "",
                s.Entry,
                string.Join(" ", s.Nodes.Select(n => n.DeclaringType is null
                    ? n.Name ?? n.Id
                    : $"{n.DeclaringType.Split('.').Last()}.{n.Name}")),
                string.Join(" ", s.Nodes.Select(n => n.Summary).Where(x => x is not null)!),
                string.Join(" ", files),
                string.Join(" ", s.Tables)
            }.Where(x => x.Length > 0));

        return new SliceIndexEntry
        {
            Id = s.Id,
            File = fileName,
            Entry = s.Entry,
            Route = s.Route,
            Part = s.Part,
            PartsTotal = s.PartsTotal,
            NodeCount = s.Nodes.Count,
            PathCount = s.Paths.Count,
            Tables = s.Tables.ToArray(),
            Files = files,
            EstTokens = s.EstTokens,
            Text = Regex.Replace(text, @"\s+", " ").Trim()
        };
    }

    public static string Stem(string id)
    {
        var s = Regex.Replace(id, @"[^\w.]+", "_");
        return s.Length <= 150 ? s : s[..150] + "_" + Math.Abs(id.GetHashCode());
    }
}
