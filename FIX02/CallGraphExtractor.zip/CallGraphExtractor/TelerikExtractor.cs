using System.Text.RegularExpressions;

namespace CallGraph;

/// Telerik UI for ASP.NET Core / MVC (and Kendo UI) server-side widgets are
/// configured as a fluent C# chain inside a Razor code block, e.g.:
///
///   @(Html.Kendo().Grid<OrderDto>()
///       .Name("grid")
///       .DataSource(ds => ds.Ajax()
///           .Read(r => r.Action("GetOrders", "Order"))
///           .Update(u => u.Action("UpdateOrder", "Order"))
///           .Create(c => c.Action("CreateOrder", "Order"))
///           .Destroy(d => d.Action("DeleteOrder", "Order"))))
///
///   @(Html.Kendo().Window()
///       .Name("editWindow")
///       .LoadContentFrom("Edit", "Order", new { id = 0 }))
///
/// This is real C# and, if the project has RazorCompileOnBuild, Roslyn *could*
/// see it via the generated obj/**/*.cshtml.g.cs files. That path is brittle
/// across SDK versions, so instead this does a targeted regex sweep over the
/// raw .cshtml text for the handful of method names that carry action
/// references. It only needs `.Action("name", "controller")` and
/// `.LoadContentFrom(...)` shapes, which are stable across Telerik/Kendo
/// versions.
public static class TelerikExtractor
{
    // .Read(r => r.Action("GetOrders", "Order"))  — captures the DataSource verb
    // (Read/Update/Create/Destroy) and the Action(...) call inside its lambda.
    private static readonly Regex DataSourceOp = new(
        @"\.(?<op>Read|Update|Create|Destroy|Insert)\s*\(\s*\w+\s*=>\s*\w+\.Action\s*\(\s*""(?<action>[^""]+)""\s*(?:,\s*""(?<controller>[^""]+)"")?",
        RegexOptions.Compiled | RegexOptions.Singleline);

    // .LoadContentFrom("Edit", "Order", ...) — Window / PopupEditor content source
    private static readonly Regex LoadContentFrom = new(
        @"\.LoadContentFrom\s*\(\s*""(?<action>[^""]+)""\s*(?:,\s*""(?<controller>[^""]+)"")?",
        RegexOptions.Compiled);

    // .Content(@<text>@Html.Partial("_Foo")</text>) or .Content(() => { ... })
    // is usually a partial, not an action — handled separately, see ContentPartial.
    private static readonly Regex ContentPartial = new(
        @"\.Content\s*\([^)]*Html\.Partial\w*\s*\(\s*""(?<name>[^""]+)""",
        RegexOptions.Compiled | RegexOptions.Singleline);

    // Identifies which widget a chain belongs to, for tagging only.
    private static readonly Regex WidgetStart = new(
        @"Html\.(?:Kendo|Telerik)\(\)\.(?<widget>\w+)\s*(?:<[^>]*>)?\s*\(\)",
        RegexOptions.Compiled);

    // .Name("grid") — used to make readable node/edge labels
    private static readonly Regex NameCall = new(
        @"\.Name\s*\(\s*""(?<name>[^""]+)""", RegexOptions.Compiled);

    public static void Scan(Graph graph, string viewId, string relFile, string text)
    {
        // Work chain-by-chain: split on "Html.Kendo()" / "Html.Telerik()" so
        // .Action() calls get attributed to the right widget, not the whole file.
        var starts = WidgetStart.Matches(text).Cast<Match>().ToList();
        if (starts.Count == 0) return;

        for (var i = 0; i < starts.Count; i++)
        {
            var start = starts[i].Index;
            var end = i + 1 < starts.Count ? starts[i + 1].Index : text.Length;
            var chain = text[start..end];
            var widget = starts[i].Groups["widget"].Value;
            var widgetName = NameCall.Match(chain) is { Success: true } nm
                ? nm.Groups["name"].Value : $"{widget}@{LineAt(text, start)}";

            var widgetId = $"widget:{relFile}#{widgetName}";
            if (!graph.Nodes.ContainsKey(widgetId))
                graph.Nodes[widgetId] = new Node
                {
                    Id = widgetId,
                    Kind = NodeKind.JsFunction,          // treated as a client-ish node for slicing
                    Name = $"{widget}({widgetName})",
                    File = relFile,
                    Line = LineAt(text, start),
                    Language = "razor",
                    Tags = new[] { "telerik-widget", widget.ToLowerInvariant() }
                };
            graph.Edges.Add(new Edge
            {
                From = viewId, To = widgetId, Kind = EdgeKind.Defines, Line = LineAt(text, start)
            });

            foreach (Match m in DataSourceOp.Matches(chain))
            {
                var action = m.Groups["action"].Value;
                var controller = m.Groups["controller"].Success ? m.Groups["controller"].Value : null;
                var op = m.Groups["op"].Value;
                var line = LineAt(text, start + m.Index);

                graph.Edges.Add(new Edge
                {
                    From = widgetId,
                    To = EndpointResolver.PendingId(controller, action),
                    Kind = EdgeKind.HttpCall,
                    Line = line,
                    Resolution = $"kendo-datasource-{op.ToLowerInvariant()}"
                });
            }

            foreach (Match m in LoadContentFrom.Matches(chain))
            {
                var action = m.Groups["action"].Value;
                var controller = m.Groups["controller"].Success ? m.Groups["controller"].Value : null;
                var line = LineAt(text, start + m.Index);

                graph.Edges.Add(new Edge
                {
                    From = widgetId,
                    To = EndpointResolver.PendingId(controller, action),
                    Kind = EdgeKind.HttpCall,
                    Line = line,
                    Resolution = "kendo-window-content"
                });
            }

            foreach (Match m in ContentPartial.Matches(chain))
            {
                var line = LineAt(text, start + m.Index);
                graph.Warnings.Add($"telerik-partial-content\t{relFile}:{line}\t{m.Groups["name"].Value}");
                // Left as a warning rather than an edge: resolving the partial
                // name to a view id here would duplicate RazorScanner's partial
                // resolution logic. If this shows up often, move ContentPartial
                // matching into RazorScanner.ResolvePartial instead.
            }
        }
    }

    private static int LineAt(string text, int index)
    {
        var n = 1;
        for (var i = 0; i < index && i < text.Length; i++)
            if (text[i] == '\n') n++;
        return n;
    }
}
