using System.Text.Json;
using CallGraph;
using Microsoft.Build.Locator;

// callgraph build   <solution.sln> --out ./graph [--schema schema.sql] [--budget 6000] [--depth 6]
// callgraph paths   <solution.sln> --out ./graph [--max-depth 12] [--all-terminals]
// callgraph context <./graph> --query "GET /orders/{id}" --src /repo [--budget 12000]
//
// build   -> nodes.jsonl, edges.jsonl, paths.jsonl, slices/*.json, slices/index.json, manifest.json
// context -> a single JSON blob ready to be templated into an OpenAI request

if (args.Length < 2)
{
    Console.Error.WriteLine("""
        usage:
          callgraph build   <solution.sln> --out <dir> [--schema <schema.sql>] [--budget 6000] [--depth 6]
                            [--repo <repoRoot>] [--js-root <wwwroot/js>] [--no-client]
          callgraph paths   <solution.sln> --out <dir> [--max-depth 12] [--all-terminals]
          callgraph context <graphDir> --query "<text>" --src <repoRoot> [--schema <schema.sql>] [--budget 12000]

        client-side flags:
          --repo      root used to locate .cshtml and wwwroot (defaults to the .sln folder)
          --js-root   explicit JS folder; otherwise any *.js under a wwwroot/ directory
          --no-client skip Razor/JS scanning entirely
        """);
    return 1;
}

var command = args[0];
var positional = args[1];
var flags = ParseFlags(args.Skip(2));

int Int(string name, int fallback) =>
    flags.TryGetValue(name, out var v) && int.TryParse(v, out var i) ? i : fallback;

string? Str(string name) => flags.TryGetValue(name, out var v) ? v : null;
bool Has(string name) => flags.ContainsKey(name);

void Log(string m) => Console.Error.WriteLine(m);

switch (command)
{
    case "build":
    case "paths":
    {
        MSBuildLocator.RegisterDefaults();

        var outDir = Path.GetFullPath(Str("out") ?? "./graph");
        Directory.CreateDirectory(outDir);

        var graph = await new RoslynGraphBuilder().BuildAsync(Path.GetFullPath(positional), Log);
        var schema = SchemaIndex.Load(Str("schema"));
        Log($"schema: {schema.Count} tables");

        // ---- client side: Razor views, embedded and standalone JavaScript ----
        if (!Has("no-client"))
        {
            var repoRoot = Path.GetFullPath(Str("repo") ?? Path.GetDirectoryName(Path.GetFullPath(positional))!);
            var scanner = new RazorScanner(graph, repoRoot);

            var cshtml = EnumerateFiles(repoRoot, "*.cshtml");
            scanner.ScanViews(cshtml, Log);

            var jsRoot = Str("js-root");
            var jsFiles = jsRoot is not null
                ? EnumerateFiles(Path.GetFullPath(jsRoot), "*.js")
                : EnumerateFiles(repoRoot, "*.js").Where(f =>
                    f.Replace('\\', '/').Contains("/wwwroot/", StringComparison.OrdinalIgnoreCase));
            scanner.ScanJsFiles(jsFiles, Log);

            var js = new JsAnalyzer(graph);
            foreach (var block in scanner.Scripts) js.Analyze(block, Log);

            scanner.LinkActionsToViews();
            EndpointResolver.Resolve(graph, Log);
            graph.Invalidate();
            Log($"graph with client: {graph.Nodes.Count} nodes, {graph.Edges.Count} edges");
        }

        var pathOpts = new PathOptions
        {
            MaxDepth = Int("max-depth", 12),
            MaxPathsPerEntry = Int("max-paths", 60),
            SqlTerminalsOnly = !Has("all-terminals")
        };
        var paths = new PathAnalyzer(graph, pathOpts).Analyze(Log);

        await WriteJsonl(Path.Combine(outDir, "nodes.jsonl"),
            graph.Nodes.Values.OrderBy(n => n.Id, StringComparer.Ordinal));

        await WriteJsonl(Path.Combine(outDir, "edges.jsonl"),
            graph.Edges.GroupBy(e => e.Key).Select(g => g.First()));

        await WriteJsonl(Path.Combine(outDir, "paths.jsonl"), paths);

        await File.WriteAllLinesAsync(Path.Combine(outDir, "warnings.txt"),
            graph.Warnings.Distinct().OrderBy(x => x, StringComparer.Ordinal));

        var index = new List<SliceIndexEntry>();
        if (command == "build")
        {
            var sliceDir = Path.Combine(outDir, "slices");
            Directory.CreateDirectory(sliceDir);

            var builder = new SliceBuilder(graph, schema, new SliceOptions
            {
                Depth = Int("depth", 6),
                CallersDepth = Int("callers", 1),
                TokenBudget = Int("budget", 6000)
            });

            foreach (var slice in builder.BuildAll(Log))
            {
                var name = slice.PartsTotal > 1
                    ? $"{SliceBuilder.Stem(slice.Entry)}.p{slice.Part}.json"
                    : $"{SliceBuilder.Stem(slice.Entry)}.json";
                await File.WriteAllTextAsync(Path.Combine(sliceDir, name),
                    JsonSerializer.Serialize(slice, Json.Options));
                index.Add(SliceBuilder.Index(slice, name));
            }

            await File.WriteAllTextAsync(Path.Combine(sliceDir, "index.json"),
                JsonSerializer.Serialize(index, Json.Pretty));
        }

        var manifest = new
        {
            generatedAt = DateTimeOffset.UtcNow,
            solution = Path.GetFileName(positional),
            nodes = graph.Nodes.Count,
            methods = graph.Nodes.Values.Count(n => n.Kind == NodeKind.Method),
            tables = graph.Nodes.Values.Count(n => n.Kind == NodeKind.Table),
            procs = graph.Nodes.Values.Count(n => n.Kind == NodeKind.Proc),
            views = graph.Nodes.Values.Count(n => n.Kind == NodeKind.View),
            scripts = graph.Nodes.Values.Count(n => n.Kind == NodeKind.ScriptFile),
            jsFunctions = graph.Nodes.Values.Count(n => n.Kind == NodeKind.JsFunction),
            clientEntryPoints = graph.ClientEntryPoints().Count(),
            edges = graph.Edges.GroupBy(e => e.Kind).ToDictionary(g => g.Key.ToString(), g => g.Count()),
            entryPoints = graph.EntryPoints().Count(),
            paths = paths.Count,
            slices = index.Count,
            sliceTokens = new
            {
                total = index.Sum(i => i.EstTokens),
                max = index.Count == 0 ? 0 : index.Max(i => i.EstTokens),
                mean = index.Count == 0 ? 0 : (int)index.Average(i => i.EstTokens)
            },
            warnings = graph.Warnings.Count
        };
        await File.WriteAllTextAsync(Path.Combine(outDir, "manifest.json"),
            JsonSerializer.Serialize(manifest, Json.Pretty));

        Log(JsonSerializer.Serialize(manifest, Json.Pretty));
        return 0;
    }

    case "context":
    {
        var graphDir = Path.GetFullPath(positional);
        var query = Str("query") ?? throw new ArgumentException("--query is required");
        var src = Path.GetFullPath(Str("src") ?? ".");

        var graph = new Graph();
        foreach (var line in await File.ReadAllLinesAsync(Path.Combine(graphDir, "nodes.jsonl")))
        {
            var n = JsonSerializer.Deserialize<Node>(line, Json.Options)!;
            graph.Nodes[n.Id] = n;
        }
        foreach (var line in await File.ReadAllLinesAsync(Path.Combine(graphDir, "edges.jsonl")))
            graph.Edges.Add(JsonSerializer.Deserialize<Edge>(line, Json.Options)!);
        graph.Invalidate();

        var schema = SchemaIndex.Load(Str("schema"));
        var assembler = new ContextAssembler(graph, schema, src);
        var ctx = assembler.Assemble(query, Int("budget", 12_000), Int("seeds", 3), Int("max-sources", 12));

        Console.WriteLine(JsonSerializer.Serialize(ctx, Json.Pretty));
        Log($"est tokens: {ctx.EstTokens}, slices: {ctx.Slices.Count}, sources: {ctx.Sources.Count}");
        return 0;
    }

    default:
        Console.Error.WriteLine($"unknown command '{command}'");
        return 1;
}

static async Task WriteJsonl<T>(string path, IEnumerable<T> items)
{
    await using var w = new StreamWriter(path);
    foreach (var i in items) await w.WriteLineAsync(Json.Line(i));
}

static IEnumerable<string> EnumerateFiles(string root, string pattern)
{
    if (!Directory.Exists(root)) return Enumerable.Empty<string>();
    return Directory.EnumerateFiles(root, pattern, SearchOption.AllDirectories)
        .Where(f =>
        {
            var p = f.Replace('\\', '/');
            return !p.Contains("/bin/") && !p.Contains("/obj/") &&
                   !p.Contains("/node_modules/") && !p.Contains("/.git/");
        });
}

static Dictionary<string, string> ParseFlags(IEnumerable<string> rest)
{
    var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    string? key = null;
    foreach (var a in rest)
    {
        if (a.StartsWith("--", StringComparison.Ordinal))
        {
            if (key is not null) d[key] = "true";
            key = a[2..];
        }
        else if (key is not null) { d[key] = a; key = null; }
    }
    if (key is not null) d[key] = "true";
    return d;
}
