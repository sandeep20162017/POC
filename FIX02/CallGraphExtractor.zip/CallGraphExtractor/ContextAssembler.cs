using System.Text.RegularExpressions;

namespace CallGraph;

public sealed record SourceSnippet(string Id, string File, int Line, int EndLine, string Code);

public sealed record AssembledContext
{
    public required string Query { get; init; }
    public required List<Slice> Slices { get; init; }
    public required List<CallPath> Paths { get; init; }
    public required Dictionary<string, string> Schema { get; init; }
    public required List<SourceSnippet> Sources { get; init; }
    public required int EstTokens { get; init; }
    public string[] Dropped { get; init; } = Array.Empty<string>();
}

/// Lexical seed selection + graph expansion + budgeted source attachment.
/// Swap Score() for an embedding lookup once you have vectors; the expansion
/// and budgeting below stay the same.
public sealed class ContextAssembler
{
    private readonly Graph _graph;
    private readonly SchemaIndex _schema;
    private readonly SliceBuilder _slices;
    private readonly string _repoRoot;

    public ContextAssembler(Graph graph, SchemaIndex schema, string repoRoot, SliceOptions? opt = null)
    {
        _graph = graph;
        _schema = schema;
        _repoRoot = repoRoot;
        _slices = new SliceBuilder(graph, schema, opt);
    }

    public AssembledContext Assemble(string query, int budget = 12_000, int seeds = 3, int maxSources = 12)
    {
        var terms = Regex.Matches(query.ToLowerInvariant(), @"[\w/{}]{3,}")
                         .Select(m => m.Value).ToArray();

        var ranked = _graph.Nodes.Values
            .Where(n => n.Kind == NodeKind.Method)
            .Select(n => (Node: n, Score: Score(n, query.ToLowerInvariant(), terms)))
            .Where(x => x.Score > 0)
            .OrderByDescending(x => x.Score)
            .ThenBy(x => x.Node.Id, StringComparer.Ordinal)
            .Take(seeds)
            .Select(x => x.Node)
            .ToList();

        if (ranked.Count == 0)
            return new AssembledContext
            {
                Query = query, Slices = new(), Paths = new(),
                Schema = new(), Sources = new(), EstTokens = 0
            };

        // Prefer the entry point above a seed rather than the seed itself: an
        // action-rooted slice gives the model request-to-database context.
        var roots = ranked.Select(NearestEntryPoint).Distinct(StringComparer.Ordinal).ToList();

        var builtSlices = new List<Slice>();
        foreach (var r in roots)
            builtSlices.AddRange(_slices.Build(r));

        var paths = builtSlices.SelectMany(s => s.Paths)
                               .GroupBy(p => string.Join(">", p.Steps.Select(s => s.Id)) + p.Terminal)
                               .Select(g => g.First())
                               .ToList();

        var tables = builtSlices.SelectMany(s => s.Tables).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var schema = _schema.For(tables);

        var spent = builtSlices.Sum(s => s.EstTokens) + TokenCounter.Estimate(schema);

        // Attach real source, seeds first, until the budget runs out.
        var order = ranked.Concat(builtSlices.SelectMany(s => s.Nodes))
                          .Where(n => n.Kind == NodeKind.Method && n.File is not null && n.EndLine is not null)
                          .GroupBy(n => n.Id).Select(g => g.First());

        var sources = new List<SourceSnippet>();
        var dropped = new List<string>();

        foreach (var n in order)
        {
            if (sources.Count >= maxSources) { dropped.Add(n.Id); continue; }
            var path = Path.Combine(_repoRoot, n.File!);
            if (!File.Exists(path)) continue;

            var lines = File.ReadAllLines(path);
            var from = Math.Max(0, n.Line!.Value - 1);
            var to = Math.Min(lines.Length, n.EndLine!.Value);
            if (to <= from) continue;

            var code = string.Join("\n", lines[from..to]);
            var cost = TokenCounter.Estimate(code);
            if (spent + cost > budget) { dropped.Add(n.Id); continue; }

            sources.Add(new SourceSnippet(n.Id, n.File!, n.Line.Value, n.EndLine.Value, code));
            spent += cost;
        }

        return new AssembledContext
        {
            Query = query,
            Slices = builtSlices,
            Paths = paths,
            Schema = schema,
            Sources = sources,
            EstTokens = spent,
            Dropped = dropped.Take(40).ToArray()
        };
    }

    private string NearestEntryPoint(Node seed)
    {
        if (seed.Tags.Contains("controller-action") || seed.Tags.Contains("minimal-api"))
            return seed.Id;

        var seen = new HashSet<string>(StringComparer.Ordinal) { seed.Id };
        var q = new Queue<(string Id, int D)>();
        q.Enqueue((seed.Id, 0));
        while (q.Count > 0)
        {
            var (cur, d) = q.Dequeue();
            if (d > 6) break;
            foreach (var e in _graph.In(cur))
            {
                if (e.Kind is not (EdgeKind.Call or EdgeKind.Ctor or EdgeKind.Implements)) continue;
                if (!seen.Add(e.From)) continue;
                var n = _graph.Get(e.From);
                if (n is not null && (n.Tags.Contains("controller-action") || n.Tags.Contains("minimal-api")))
                    return n.Id;
                q.Enqueue((e.From, d + 1));
            }
        }
        return seed.Id;
    }

    private static int Score(Node n, string query, string[] terms)
    {
        var score = 0;
        var route = (n.Route ?? "").ToLowerInvariant();
        var id = n.Id.ToLowerInvariant();
        var file = (n.File ?? "").ToLowerInvariant();

        if (route.Length > 0 && query.Contains(route)) score += 25;
        if (route.Length > 0 && RouteMatches(route, query)) score += 20;
        if (query.Contains(id)) score += 15;

        foreach (var t in terms)
        {
            if (route.Contains(t)) score += 6;
            if (id.Contains(t)) score += 4;
            if (file.Contains(t)) score += 2;
            if ((n.Name ?? "").ToLowerInvariant() == t) score += 8;
        }

        if (n.Tags.Contains("controller-action")) score += 3;
        if (n.Tags.Contains("accessor")) score -= 4;
        return score;
    }

    private static bool RouteMatches(string route, string query)
    {
        // "/orders/42" should match "GET /orders/{id}"
        var pattern = "^" + Regex.Escape(route.Split(' ').Last()).Replace(@"\{", "{") + "$";
        pattern = Regex.Replace(pattern, @"\{[^}]+\}", @"[^/]+");
        return Regex.Matches(query, @"/[\w/{}.-]+")
                    .Any(m => Regex.IsMatch(m.Value, pattern, RegexOptions.IgnoreCase));
    }
}
