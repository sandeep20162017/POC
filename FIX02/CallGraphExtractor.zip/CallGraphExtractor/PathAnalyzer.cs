namespace CallGraph;

public sealed class PathOptions
{
    public int MaxDepth { get; init; } = 12;
    public int MaxPathsPerEntry { get; init; } = 60;
    public int MaxTotalPaths { get; init; } = 20_000;
    /// When true, only paths that end at a table/proc are kept.
    public bool SqlTerminalsOnly { get; init; } = true;
    /// Follow interface -> implementation hops. Turning this off keeps the graph
    /// small but stops every path at the interface boundary.
    public bool FollowImplementations { get; init; } = true;

    /// Start paths at DOM event handlers as well as controller actions, so a
    /// path reads button click -> ajax -> action -> service -> repo -> table.
    public bool IncludeClientPaths { get; init; } = true;
}

/// Enumerates entry point -> ... -> terminal paths.
///
/// Path counts explode combinatorially on real codebases, so every traversal is
/// capped and paths that revisit a node on the current stack are cut (recursion
/// is recorded as Truncated rather than followed).
public sealed class PathAnalyzer
{
    private readonly Graph _graph;
    private readonly PathOptions _opt;
    private int _counter;

    public PathAnalyzer(Graph graph, PathOptions? options = null)
    {
        _graph = graph;
        _opt = options ?? new PathOptions();
    }

    public List<CallPath> Analyze(Action<string>? log = null)
    {
        var all = new List<CallPath>();

        var roots = _graph.EntryPoints().AsEnumerable();
        if (_opt.IncludeClientPaths) roots = roots.Concat(_graph.ClientEntryPoints());

        foreach (var entry in roots.OrderBy(n => n.Id, StringComparer.Ordinal))
        {
            var found = new List<CallPath>();
            var stack = new List<PathStep>
            {
                new() { Id = entry.Id, Display = Short(entry), File = entry.File, Line = entry.Line }
            };
            Walk(entry.Id, stack, new HashSet<string>(StringComparer.Ordinal) { entry.Id }, entry, found);
            all.AddRange(found);

            if (all.Count >= _opt.MaxTotalPaths)
            {
                _graph.Warnings.Add($"path-cap\ttotal cap {_opt.MaxTotalPaths} reached");
                break;
            }
        }
        log?.Invoke($"paths: {all.Count}");
        return all;
    }

    /// Paths for a single root, used by the query-time context assembler.
    public List<CallPath> From(string rootId)
    {
        var node = _graph.Get(rootId);
        if (node is null) return new List<CallPath>();
        var found = new List<CallPath>();
        var stack = new List<PathStep>
        {
            new() { Id = node.Id, Display = Short(node), File = node.File, Line = node.Line }
        };
        Walk(rootId, stack, new HashSet<string>(StringComparer.Ordinal) { rootId }, node, found);
        return found;
    }

    private void Walk(string current, List<PathStep> stack, HashSet<string> onStack,
                      Node entry, List<CallPath> found)
    {
        if (found.Count >= _opt.MaxPathsPerEntry) return;

        var outgoing = _graph.Out(current);
        var branched = false;

        // SQL terminals first — these are the paths worth keeping.
        foreach (var e in outgoing.Where(e => e.Kind is EdgeKind.SqlRead or EdgeKind.SqlWrite or EdgeKind.SqlProc))
        {
            branched = true;
            var table = _graph.Get(e.To);
            found.Add(new CallPath
            {
                Id = $"p{Interlocked.Increment(ref _counter):D5}",
                Entry = entry.Id,
                Route = entry.Route,
                Steps = new List<PathStep>(stack),
                TerminalKind = e.Kind switch
                {
                    EdgeKind.SqlRead => "sql-read",
                    EdgeKind.SqlWrite => "sql-write",
                    _ => "sql-proc"
                },
                Terminal = table?.Name ?? e.To,
                Sql = e.Sql
            });
            if (found.Count >= _opt.MaxPathsPerEntry) return;
        }

        if (stack.Count >= _opt.MaxDepth)
        {
            if (outgoing.Any(IsTraversable))
                found.Add(Leaf(entry, stack, truncated: true));
            return;
        }

        foreach (var e in outgoing.Where(IsTraversable))
        {
            if (onStack.Contains(e.To))
            {
                // recursion / cycle: record and stop
                found.Add(Leaf(entry, stack, truncated: true));
                continue;
            }

            var next = _graph.Get(e.To);
            if (next is null) continue;

            var via = e.Kind switch
            {
                EdgeKind.Implements => "interface",
                EdgeKind.HttpCall => $"http:{e.Resolution}",
                EdgeKind.FormPost => "form",
                _ => null
            };

            branched = true;
            stack.Add(new PathStep
            {
                Id = next.Id,
                Display = Short(next),
                File = next.File,
                Line = next.Line,
                CallSite = e.Line,
                Via = via
            });
            onStack.Add(next.Id);

            Walk(next.Id, stack, onStack, entry, found);

            onStack.Remove(next.Id);
            stack.RemoveAt(stack.Count - 1);

            if (found.Count >= _opt.MaxPathsPerEntry) return;
        }

        if (!branched && !_opt.SqlTerminalsOnly && stack.Count > 1)
            found.Add(Leaf(entry, stack, truncated: false));
    }

    private bool IsTraversable(Edge e) =>
        e.Kind == EdgeKind.Call ||
        e.Kind == EdgeKind.Ctor ||
        (e.Kind == EdgeKind.Implements && _opt.FollowImplementations) ||
        // Client hops. Renders/Includes/ScriptRef are deliberately NOT traversed:
        // action -> view -> script -> ajax -> action would make every path cyclic.
        (_opt.IncludeClientPaths &&
            e.Kind is EdgeKind.JsCall or EdgeKind.HttpCall or EdgeKind.FormPost);

    private CallPath Leaf(Node entry, List<PathStep> stack, bool truncated) => new()
    {
        Id = $"p{Interlocked.Increment(ref _counter):D5}",
        Entry = entry.Id,
        Route = entry.Route,
        Steps = new List<PathStep>(stack),
        TerminalKind = "leaf",
        Truncated = truncated
    };

    private static string Short(Node n) =>
        n.DeclaringType is null
            ? n.Name ?? n.Id
            : $"{n.DeclaringType.Split('.').Last()}.{n.Name}";
}
