using System.Text.RegularExpressions;

namespace CallGraph;

/// The Razor and JS scanners emit edges pointing at *pending* targets, because
/// a URL or a (controller, action) pair is not a symbol id. This pass rewrites
/// those targets to real controller-action node ids and drops the ones that
/// cannot be matched (recorded as warnings so you can see the blind spots).
public static class EndpointResolver
{
    private const string PendingActionPrefix = "pending:action:";
    private const string PendingUrlPrefix = "pending:url:";

    public static string PendingId(string? controller, string action) =>
        $"{PendingActionPrefix}{controller ?? "*"}/{action}";

    public static string PendingUrl(string verb, string url) =>
        $"{PendingUrlPrefix}{verb} {url}";

    public static void Resolve(Graph graph, Action<string>? log = null)
    {
        var actions = graph.Nodes.Values
            .Where(n => n.Tags.Contains("controller-action") || n.Tags.Contains("minimal-api"))
            .ToList();

        // (controller, action) -> id
        var byName = new Dictionary<string, List<Node>>(StringComparer.OrdinalIgnoreCase);
        foreach (var a in actions)
        {
            if (a.DeclaringType is null || a.Name is null) continue;
            var typeName = a.DeclaringType.Split('.').Last();
            var controller = typeName.EndsWith("Controller", StringComparison.Ordinal)
                ? typeName[..^"Controller".Length] : typeName;
            Add(byName, $"{controller}/{a.Name}", a);
            Add(byName, $"*/{a.Name}", a);
        }

        // route template -> id
        var routes = actions
            .Where(a => a.Route is not null)
            .Select(a => (Node: a, Verb: Verb(a.Route!), Regex: TemplateRegex(a.Route!)))
            .ToList();

        var resolved = 0;
        var unresolved = new List<string>();

        for (var i = 0; i < graph.Edges.Count; i++)
        {
            var e = graph.Edges[i];
            if (!e.To.StartsWith("pending:", StringComparison.Ordinal)) continue;

            Node? target = null;

            if (e.To.StartsWith(PendingActionPrefix, StringComparison.Ordinal))
            {
                var key = e.To[PendingActionPrefix.Length..];
                if (byName.TryGetValue(key, out var list))
                    target = list.Count == 1 ? list[0] : Disambiguate(list, e, graph);
            }
            else
            {
                var spec = e.To[PendingUrlPrefix.Length..];
                var sp = spec.Split(' ', 2);
                var verb = sp[0];
                var url = Clean(sp.Length > 1 ? sp[1] : "");

                var hits = routes
                    .Where(r => (r.Verb == "*" || verb == "*" || r.Verb == verb) && r.Regex.IsMatch(url))
                    .ToList();

                // prefer the most specific (longest) template
                target = hits.OrderByDescending(h => h.Node.Route!.Length).FirstOrDefault().Node;
            }

            if (target is null)
            {
                unresolved.Add(e.To);
                graph.Edges[i] = e with { To = e.To, Resolution = (e.Resolution ?? "") + "|unresolved" };
                continue;
            }

            graph.Edges[i] = e with { To = target.Id };
            resolved++;
        }

        // Drop js -> js edges whose target was never declared (library calls).
        var known = new HashSet<string>(graph.Nodes.Keys, StringComparer.Ordinal);
        graph.Edges.RemoveAll(e =>
            (e.Kind == EdgeKind.JsCall && !known.Contains(e.To)) ||
            e.To.StartsWith("pending:", StringComparison.Ordinal));

        foreach (var u in unresolved.Distinct().Take(200))
            graph.Warnings.Add($"unresolved-endpoint\t{u}");

        graph.Invalidate();
        log?.Invoke($"endpoints resolved: {resolved}, unresolved: {unresolved.Distinct().Count()}");
    }

    private static Node? Disambiguate(List<Node> candidates, Edge edge, Graph graph)
    {
        // Same action name on several controllers: prefer the controller whose
        // view folder matches the file the call came from.
        var from = graph.Get(edge.From)?.File ?? "";
        foreach (var c in candidates)
        {
            var typeName = c.DeclaringType?.Split('.').Last() ?? "";
            var controller = typeName.EndsWith("Controller", StringComparison.Ordinal)
                ? typeName[..^"Controller".Length] : typeName;
            if (from.Contains($"/Views/{controller}/", StringComparison.OrdinalIgnoreCase) ||
                from.Contains($"/{controller.ToLowerInvariant()}", StringComparison.OrdinalIgnoreCase))
                return c;
        }
        return null;   // ambiguous: better to report than to guess
    }

    private static void Add(Dictionary<string, List<Node>> d, string key, Node n)
    {
        if (!d.TryGetValue(key, out var list)) d[key] = list = new List<Node>();
        list.Add(n);
    }

    private static string Verb(string route)
    {
        var sp = route.Split(' ', 2);
        return sp.Length > 1 ? sp[0] : "*";
    }

    private static Regex TemplateRegex(string route)
    {
        var template = route.Split(' ').Last().Trim('/');
        // {id} / {id:int} / {*slug} -> single segment wildcard, optional if {id?}
        var pattern = Regex.Escape(template)
            .Replace(@"\{", "{").Replace(@"\}", "}");
        pattern = Regex.Replace(pattern, @"\{\*?[^}]+\?\}", "(?:[^/]*)?");
        pattern = Regex.Replace(pattern, @"\{\*[^}]+\}", ".*");
        pattern = Regex.Replace(pattern, @"\{[^}]+\}", "[^/]+");
        return new Regex("^/?" + pattern + "/?$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    }

    private static string Clean(string url)
    {
        var u = url.Split('?')[0].Split('#')[0].Trim();
        if (u.StartsWith("~")) u = u[1..];
        // strip an origin if one is present
        var idx = u.IndexOf("://", StringComparison.Ordinal);
        if (idx > 0)
        {
            var slash = u.IndexOf('/', idx + 3);
            u = slash > 0 ? u[slash..] : "/";
        }
        // "/api/orders/" + id  -> "/api/orders/{...}" -> treat tail as a segment
        u = u.Replace("{...}", "1");
        return u.TrimEnd('/') is { Length: 0 } ? "/" : u;
    }
}
