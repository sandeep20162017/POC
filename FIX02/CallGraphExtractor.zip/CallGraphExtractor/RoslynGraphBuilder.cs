using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.MSBuild;

namespace CallGraph;

public sealed class RoslynGraphBuilder
{
    public static readonly SymbolDisplayFormat IdFormat = new(
        globalNamespaceStyle: SymbolDisplayGlobalNamespaceStyle.Omitted,
        typeQualificationStyle: SymbolDisplayTypeQualificationStyle.NameAndContainingTypesAndNamespaces,
        genericsOptions: SymbolDisplayGenericsOptions.IncludeTypeParameters,
        memberOptions: SymbolDisplayMemberOptions.IncludeContainingType |
                       SymbolDisplayMemberOptions.IncludeParameters,
        parameterOptions: SymbolDisplayParameterOptions.IncludeType,
        miscellaneousOptions: SymbolDisplayMiscellaneousOptions.UseSpecialTypes);

    private static readonly SymbolDisplayFormat ShortFormat = new(
        typeQualificationStyle: SymbolDisplayTypeQualificationStyle.NameAndContainingTypes,
        memberOptions: SymbolDisplayMemberOptions.IncludeContainingType,
        genericsOptions: SymbolDisplayGenericsOptions.IncludeTypeParameters);

    private static readonly string[] DiMethods =
    {
        "AddScoped", "AddTransient", "AddSingleton",
        "TryAddScoped", "TryAddTransient", "TryAddSingleton",
        "AddHostedService", "AddHttpClient"
    };

    private readonly Graph _graph = new();
    private readonly HashSet<string> _solutionAssemblies = new(StringComparer.Ordinal);
    private string _root = "";

    public static string Id(ISymbol s) => s.OriginalDefinition.ToDisplayString(IdFormat);
    private static string Display(ISymbol s) => s.ToDisplayString(ShortFormat);

    public async Task<Graph> BuildAsync(string solutionPath, Action<string>? log = null)
    {
        log ??= _ => { };
        _root = Path.GetDirectoryName(Path.GetFullPath(solutionPath))!;

        using var workspace = MSBuildWorkspace.Create();
        workspace.WorkspaceFailed += (_, e) =>
        {
            if (e.Diagnostic.Kind == WorkspaceDiagnosticKind.Failure)
                _graph.Warnings.Add("workspace\t" + e.Diagnostic.Message);
        };

        log($"opening {solutionPath}");
        var solution = await workspace.OpenSolutionAsync(solutionPath);

        var compilations = new List<(Project Project, Compilation Compilation)>();
        foreach (var project in solution.Projects)
        {
            var c = await project.GetCompilationAsync();
            if (c is null) { _graph.Warnings.Add($"no-compilation\t{project.Name}"); continue; }
            compilations.Add((project, c));
            _solutionAssemblies.Add(c.Assembly.Name);
        }
        log($"{compilations.Count} projects compiled");

        // Pass 1 — declarations, invocations, SQL, DI registrations.
        foreach (var (project, compilation) in compilations)
        {
            foreach (var document in project.Documents)
            {
                if (document.FilePath is null || document.FilePath.Contains("/obj/")) continue;
                var tree = await document.GetSyntaxTreeAsync();
                if (tree is null) continue;
                var model = compilation.GetSemanticModel(tree);
                var root = await tree.GetRootAsync();

                WalkDeclarations(root, model, document.FilePath, project.Name);
                WalkDiRegistrations(root, model);
                WalkMinimalApi(root, model, document.FilePath, project.Name);
            }
            log($"  scanned {project.Name}");
        }

        // Pass 2 — polymorphism: interface member -> impl, virtual -> override.
        foreach (var (_, compilation) in compilations)
            LinkImplementations(compilation);

        _graph.Invalidate();
        log($"graph: {_graph.Nodes.Count} nodes, {_graph.Edges.Count} edges");
        return _graph;
    }

    // ------------------------------------------------------------- pass 1

    private void WalkDeclarations(SyntaxNode root, SemanticModel model, string filePath, string project)
    {
        foreach (var decl in root.DescendantNodes().Where(IsDeclaration))
        {
            var symbol = DeclaredMethod(decl, model);
            if (symbol is null) continue;

            var id = Id(symbol);
            var span = decl.GetLocation().GetLineSpan();

            if (!_graph.Nodes.ContainsKey(id))
            {
                _graph.Nodes[id] = new Node
                {
                    Id = id,
                    Kind = NodeKind.Method,
                    Name = symbol.Name,
                    DeclaringType = symbol.ContainingType?.ToDisplayString(IdFormat),
                    Namespace = symbol.ContainingNamespace?.ToDisplayString(),
                    Project = project,
                    File = Relative(filePath),
                    Line = span.StartLinePosition.Line + 1,
                    EndLine = span.EndLinePosition.Line + 1,
                    Route = RouteResolver.Resolve(symbol),
                    Returns = symbol.ReturnType.ToDisplayString(IdFormat),
                    Parameters = symbol.Parameters
                        .Select(p => $"{p.Type.ToDisplayString(IdFormat)} {p.Name}").ToArray(),
                    Tags = Tags(symbol),
                    IsAsync = symbol.IsAsync,
                    IsAbstract = symbol.IsAbstract,
                    Loc = span.EndLinePosition.Line - span.StartLinePosition.Line + 1
                };
            }

            WalkBody(decl, model, id);
        }

        // interface members have no body but must exist as nodes to hang Implements edges on
        foreach (var iface in root.DescendantNodes().OfType<InterfaceDeclarationSyntax>())
        {
            if (model.GetDeclaredSymbol(iface) is not INamedTypeSymbol t) continue;
            foreach (var m in t.GetMembers().OfType<IMethodSymbol>())
            {
                var id = Id(m);
                if (_graph.Nodes.ContainsKey(id)) continue;
                var span = iface.GetLocation().GetLineSpan();
                _graph.Nodes[id] = new Node
                {
                    Id = id, Kind = NodeKind.Method, Name = m.Name,
                    DeclaringType = t.ToDisplayString(IdFormat),
                    Namespace = t.ContainingNamespace?.ToDisplayString(),
                    Project = project, File = Relative(filePath),
                    Line = span.StartLinePosition.Line + 1,
                    Returns = m.ReturnType.ToDisplayString(IdFormat),
                    Parameters = m.Parameters.Select(p => $"{p.Type.ToDisplayString(IdFormat)} {p.Name}").ToArray(),
                    Tags = new[] { "interface-member" },
                    IsAbstract = true
                };
            }
        }
    }

    private static bool IsDeclaration(SyntaxNode n) =>
        n is MethodDeclarationSyntax or ConstructorDeclarationSyntax
          or PropertyDeclarationSyntax or LocalFunctionStatementSyntax
          or AccessorDeclarationSyntax;

    private static IMethodSymbol? DeclaredMethod(SyntaxNode decl, SemanticModel model) =>
        model.GetDeclaredSymbol(decl) switch
        {
            IMethodSymbol m => m,
            IPropertySymbol p => p.GetMethod ?? p.SetMethod,
            _ => null
        };

    private void WalkBody(SyntaxNode decl, SemanticModel model, string fromId)
    {
        foreach (var inv in decl.DescendantNodes().OfType<InvocationExpressionSyntax>())
        {
            // don't double-count invocations owned by a nested local function
            if (inv.Ancestors().OfType<LocalFunctionStatementSyntax>().Any(a => a != decl && decl.Contains(a)))
                continue;

            var info = model.GetSymbolInfo(inv);
            var target = info.Symbol as IMethodSymbol
                         ?? info.CandidateSymbols.OfType<IMethodSymbol>().FirstOrDefault();
            if (target is null) continue;

            var line = inv.GetLocation().GetLineSpan().StartLinePosition.Line + 1;

            if (SqlExtractor.IsDataAccess(target))
                SqlExtractor.Emit(_graph, inv, model, fromId, line);

            if (IsInSolution(target))
                _graph.Edges.Add(new Edge
                {
                    From = fromId, To = Id(target), Kind = EdgeKind.Call, Line = line,
                    Resolution = target.ContainingType?.TypeKind == TypeKind.Interface ? "interface"
                               : target.IsVirtual || target.IsAbstract || target.IsOverride ? "virtual"
                               : "direct"
                });
        }

        foreach (var ctor in decl.DescendantNodes().OfType<BaseObjectCreationExpressionSyntax>())
        {
            if (model.GetSymbolInfo(ctor).Symbol is not IMethodSymbol target) continue;
            if (!IsInSolution(target)) continue;
            _graph.Edges.Add(new Edge
            {
                From = fromId, To = Id(target), Kind = EdgeKind.Ctor,
                Line = ctor.GetLocation().GetLineSpan().StartLinePosition.Line + 1
            });
        }
    }

    private bool IsInSolution(ISymbol s) =>
        s.ContainingAssembly is not null && _solutionAssemblies.Contains(s.ContainingAssembly.Name);

    private void WalkDiRegistrations(SyntaxNode root, SemanticModel model)
    {
        foreach (var inv in root.DescendantNodes().OfType<InvocationExpressionSyntax>())
        {
            if (inv.Expression is not MemberAccessExpressionSyntax { Name: GenericNameSyntax g }) continue;
            if (!DiMethods.Contains(g.Identifier.Text)) continue;

            var types = g.TypeArgumentList.Arguments
                .Select(t => model.GetSymbolInfo(t).Symbol as INamedTypeSymbol)
                .Where(t => t is not null)
                .Cast<INamedTypeSymbol>()
                .ToList();

            if (types.Count != 2) continue;
            var line = inv.GetLocation().GetLineSpan().StartLinePosition.Line + 1;
            _graph.Edges.Add(new Edge
            {
                From = Id(types[0]), To = Id(types[1]),
                Kind = EdgeKind.DiRegister, Line = line, Resolution = "di"
            });
        }
    }

    /// app.MapGet("/orders/{id}", handler) — captures the lambda as an entry point.
    private void WalkMinimalApi(SyntaxNode root, SemanticModel model, string filePath, string project)
    {
        foreach (var inv in root.DescendantNodes().OfType<InvocationExpressionSyntax>())
        {
            if (inv.Expression is not MemberAccessExpressionSyntax ma) continue;
            var name = ma.Name.Identifier.Text;
            if (!name.StartsWith("Map", StringComparison.Ordinal)) continue;
            if (name is not ("MapGet" or "MapPost" or "MapPut" or "MapDelete" or "MapPatch")) continue;

            var args = inv.ArgumentList.Arguments;
            if (args.Count < 2) continue;
            var template = SqlExtractor.Resolve(args[0].Expression, model) ?? "?";
            var verb = name[3..].ToUpperInvariant();

            // lambda handler
            if (args[1].Expression is AnonymousFunctionExpressionSyntax lambda &&
                model.GetSymbolInfo(lambda).Symbol is IMethodSymbol lm)
            {
                var id = Id(lm);
                var span = lambda.GetLocation().GetLineSpan();
                _graph.Nodes[id] = new Node
                {
                    Id = id, Kind = NodeKind.Method, Name = $"{verb} {template}",
                    Project = project, File = Relative(filePath),
                    Line = span.StartLinePosition.Line + 1,
                    EndLine = span.EndLinePosition.Line + 1,
                    Route = $"{verb} {template}",
                    Tags = new[] { "minimal-api" }
                };
                WalkBody(lambda, model, id);
            }
            // method group handler
            else if (model.GetSymbolInfo(args[1].Expression).Symbol is IMethodSymbol handler &&
                     IsInSolution(handler))
            {
                var id = Id(handler);
                if (_graph.Nodes.TryGetValue(id, out var existing))
                    _graph.Nodes[id] = existing with
                    {
                        Route = $"{verb} {template}",
                        Tags = existing.Tags.Append("minimal-api").Distinct().ToArray()
                    };
            }
        }
    }

    // ------------------------------------------------------------- pass 2

    private void LinkImplementations(Compilation compilation)
    {
        foreach (var type in AllTypes(compilation.GlobalNamespace))
        {
            if (type.TypeKind != TypeKind.Class && type.TypeKind != TypeKind.Struct) continue;
            if (type.IsAbstract) continue;

            foreach (var iface in type.AllInterfaces)
            foreach (var member in iface.GetMembers().OfType<IMethodSymbol>())
            {
                if (type.FindImplementationForInterfaceMember(member) is not IMethodSymbol impl) continue;
                if (!IsInSolution(impl)) continue;
                _graph.Edges.Add(new Edge
                {
                    From = Id(member), To = Id(impl),
                    Kind = EdgeKind.Implements, Resolution = "interface"
                });
            }

            foreach (var m in type.GetMembers().OfType<IMethodSymbol>())
                if (m.OverriddenMethod is { } ov && IsInSolution(ov))
                    _graph.Edges.Add(new Edge
                    {
                        From = Id(ov), To = Id(m),
                        Kind = EdgeKind.Implements, Resolution = "virtual"
                    });
        }
    }

    private static IEnumerable<INamedTypeSymbol> AllTypes(INamespaceSymbol ns)
    {
        foreach (var t in ns.GetTypeMembers())
        {
            yield return t;
            foreach (var nested in Nested(t)) yield return nested;
        }
        foreach (var child in ns.GetNamespaceMembers())
            foreach (var t in AllTypes(child)) yield return t;

        static IEnumerable<INamedTypeSymbol> Nested(INamedTypeSymbol t)
        {
            foreach (var n in t.GetTypeMembers())
            {
                yield return n;
                foreach (var d in Nested(n)) yield return d;
            }
        }
    }

    // ------------------------------------------------------------- helpers

    private static string[] Tags(IMethodSymbol s)
    {
        var tags = new List<string>();
        var t = s.ContainingType;
        if (t is null) return tags.ToArray();

        var ancestry = Ancestry(t).ToList();

        if (ancestry.Any(n => n is "Controller" or "ControllerBase"))
        {
            var isAction = s.DeclaredAccessibility == Accessibility.Public &&
                           !s.IsStatic &&
                           s.MethodKind == MethodKind.Ordinary &&
                           !s.GetAttributes().Any(a => a.AttributeClass?.Name == "NonActionAttribute");
            tags.Add(isAction ? "controller-action" : "controller-member");
        }

        if (ancestry.Contains("BackgroundService") ||
            t.AllInterfaces.Any(i => i.Name == "IHostedService"))
            tags.Add("background-service");

        if (t.AllInterfaces.Any(i => i.Name is "IRequestHandler" or "INotificationHandler" or "IConsumer"))
            tags.Add("message-handler");

        if (t.Name.EndsWith("Repository", StringComparison.Ordinal)) tags.Add("repository");
        else if (t.Name.EndsWith("Service", StringComparison.Ordinal)) tags.Add("service");
        if (t.TypeKind == TypeKind.Interface) tags.Add("interface-member");
        if (s.MethodKind == MethodKind.Constructor) tags.Add("ctor");
        if (s.MethodKind is MethodKind.PropertyGet or MethodKind.PropertySet) tags.Add("accessor");

        return tags.ToArray();
    }

    private static IEnumerable<string> Ancestry(INamedTypeSymbol t)
    {
        for (var b = t; b is not null; b = b.BaseType) yield return b.Name;
    }

    private string Relative(string p) =>
        Path.GetRelativePath(_root, p).Replace('\\', '/');
}
