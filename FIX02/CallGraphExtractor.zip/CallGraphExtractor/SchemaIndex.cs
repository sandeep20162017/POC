using System.Text;
using System.Text.RegularExpressions;

namespace CallGraph;

/// Splits schema.sql into per-table DDL blocks so only the tables a slice
/// actually touches get sent to the model.
public sealed class SchemaIndex
{
    private readonly Dictionary<string, StringBuilder> _byTable = new(StringComparer.OrdinalIgnoreCase);

    private static readonly Regex CreateTable = new(
        @"CREATE\s+TABLE\s+(\[?\w+\]?(?:\s*\.\s*\[?\w+\]?)?)\s*\(",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex OnTable = new(
        @"\bON\s+(\[?\w+\]?(?:\s*\.\s*\[?\w+\]?)?)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex AlterTable = new(
        @"ALTER\s+TABLE\s+(\[?\w+\]?(?:\s*\.\s*\[?\w+\]?)?)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public static SchemaIndex Load(string? path)
    {
        var idx = new SchemaIndex();
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return idx;

        foreach (var batch in SplitBatches(File.ReadAllText(path)))
        {
            var trimmed = batch.Trim();
            if (trimmed.Length == 0) continue;

            string? table = null;
            if (CreateTable.Match(trimmed) is { Success: true } ct) table = ct.Groups[1].Value;
            else if (AlterTable.Match(trimmed) is { Success: true } at) table = at.Groups[1].Value;
            else if (trimmed.StartsWith("CREATE", StringComparison.OrdinalIgnoreCase) &&
                     OnTable.Match(trimmed) is { Success: true } on) table = on.Groups[1].Value;

            if (table is null) continue;

            var key = Key(table);
            if (!idx._byTable.TryGetValue(key, out var sb))
                idx._byTable[key] = sb = new StringBuilder();
            sb.AppendLine(trimmed.TrimEnd(';'));
            sb.AppendLine("GO");
        }
        return idx;
    }

    private static IEnumerable<string> SplitBatches(string sql)
    {
        // Split on GO batch separators, falling back to statement terminators.
        var parts = Regex.Split(sql, @"^\s*GO\s*$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
        if (parts.Length > 1) return parts;
        return Regex.Split(sql, @";\s*(?=CREATE|ALTER|DROP)", RegexOptions.IgnoreCase);
    }

    private static string Key(string raw) =>
        SqlExtractor.Normalize(raw).Split('.').Last().ToLowerInvariant();

    public bool TryGet(string tableName, out string ddl)
    {
        if (_byTable.TryGetValue(Key(tableName), out var sb))
        {
            ddl = sb.ToString().TrimEnd();
            return true;
        }
        ddl = "";
        return false;
    }

    public Dictionary<string, string> For(IEnumerable<string> tables)
    {
        var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var t in tables)
            if (TryGet(t, out var ddl)) d[t] = ddl;
        return d;
    }

    public int Count => _byTable.Count;
}
