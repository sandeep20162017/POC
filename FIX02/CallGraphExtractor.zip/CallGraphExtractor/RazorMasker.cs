using System.Text;
using System.Text.RegularExpressions;

namespace CallGraph;

/// A Razor expression found inside a script block, e.g. @Url.Action("Get", "Order").
public sealed record RazorExpression(
    string Placeholder,
    string Raw,
    int Line,
    string? Controller = null,
    string? Action = null,
    string? RouteName = null);

/// JavaScript embedded in .cshtml is not valid JavaScript: `@Url.Action(...)`,
/// `@Model.Id` and `@if (...) { }` are all syntax errors to a JS parser.
///
/// The masker replaces every Razor construct with a quoted placeholder of the
/// same shape ("__RZR_3__"), so the result parses as ordinary JS, and keeps a
/// map back to the original expression. When the JS analyzer finds a URL
/// argument that is a placeholder, it resolves it through that map to a real
/// controller action.
public static class RazorMasker
{
    // @Url.Action("Get", "Order", new { id = 1 })  /  @Url.RouteUrl("orders")
    private static readonly Regex UrlHelper = new(
        @"@Url\.(Action|RouteUrl|Content|Page)\s*\(([^()]*(?:\([^()]*\)[^()]*)*)\)",
        RegexOptions.Compiled);

    // @Html.ActionLink("text", "Action", "Controller")
    private static readonly Regex HtmlHelper = new(
        @"@Html\.\w+\s*\(([^()]*(?:\([^()]*\)[^()]*)*)\)",
        RegexOptions.Compiled);

    // @(expression) — explicit
    private static readonly Regex Explicit = new(
        @"@\((?:[^()]|\([^()]*\))*\)", RegexOptions.Compiled);

    // @Model.Foo.Bar, @ViewBag.X, @item.Id, @someLocal
    private static readonly Regex Implicit = new(
        @"@[A-Za-z_][\w]*(?:\.[A-Za-z_]\w*)*(?:\([^()]*\))?", RegexOptions.Compiled);

    // control flow blocks inside script: @if (...) { ... } / @foreach (...) { ... }
    private static readonly Regex ControlFlow = new(
        @"@(if|foreach|for|while|switch)\s*\([^)]*\)\s*", RegexOptions.Compiled);

    private static readonly Regex StringArgs = new(
        "\"([^\"]*)\"|'([^']*)'", RegexOptions.Compiled);

    public static (string Masked, Dictionary<string, RazorExpression> Map) Mask(string script, int lineOffset = 0)
    {
        var map = new Dictionary<string, RazorExpression>(StringComparer.Ordinal);
        var counter = 0;
        var working = script;

        string Replace(Regex re, string input, bool quote)
        {
            return re.Replace(input, m =>
            {
                var placeholder = $"__RZR_{counter++}__";
                var line = lineOffset + CountLines(input, m.Index);
                map[placeholder] = Parse(placeholder, m.Value, line);
                return quote ? $"\"{placeholder}\"" : $"/*{placeholder}*/";
            });
        }

        // Order matters: most specific first.
        working = Replace(UrlHelper, working, quote: true);
        working = Replace(HtmlHelper, working, quote: true);
        working = Replace(Explicit, working, quote: true);
        working = Replace(ControlFlow, working, quote: false);
        working = Replace(Implicit, working, quote: true);

        // `@@` escapes and stray `@` left over
        working = working.Replace("@@", "@");

        return (working, map);
    }

    /// Pulls controller/action out of a Url.Action or Html.ActionLink call.
    private static RazorExpression Parse(string placeholder, string raw, int line)
    {
        var args = StringArgs.Matches(raw)
            .Select(m => m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value)
            .Where(s => s.Length > 0)
            .ToList();

        if (raw.Contains("Url.Action", StringComparison.Ordinal))
        {
            // Url.Action(action) | Url.Action(action, controller)
            var action = args.ElementAtOrDefault(0);
            var controller = args.ElementAtOrDefault(1);
            return new RazorExpression(placeholder, raw.Trim(), line, controller, action);
        }

        if (raw.Contains("Url.RouteUrl", StringComparison.Ordinal))
            return new RazorExpression(placeholder, raw.Trim(), line, RouteName: args.ElementAtOrDefault(0));

        if (raw.Contains("Html.ActionLink", StringComparison.Ordinal))
        {
            // ActionLink(linkText, action, controller)
            var action = args.ElementAtOrDefault(1);
            var controller = args.ElementAtOrDefault(2);
            return new RazorExpression(placeholder, raw.Trim(), line, controller, action);
        }

        return new RazorExpression(placeholder, raw.Trim(), line);
    }

    private static int CountLines(string text, int index)
    {
        var n = 0;
        for (var i = 0; i < index && i < text.Length; i++)
            if (text[i] == '\n') n++;
        return n;
    }

    /// True when a resolved string is (or contains) a placeholder.
    public static bool IsPlaceholder(string? s) =>
        s is not null && s.Contains("__RZR_", StringComparison.Ordinal);

    public static IEnumerable<string> Placeholders(string s)
    {
        foreach (Match m in Regex.Matches(s, @"__RZR_\d+__"))
            yield return m.Value;
    }

    public static string Unmask(string s, Dictionary<string, RazorExpression> map)
    {
        var sb = new StringBuilder(s);
        foreach (var (k, v) in map) sb.Replace(k, v.Raw);
        return sb.ToString();
    }
}
