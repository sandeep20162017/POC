using System.Text.RegularExpressions;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace CallGraph;

/// Recognises Dapper / raw ADO calls and turns the command text into
/// method -> table / method -> proc edges.
public static class SqlExtractor
{
    public static readonly HashSet<string> DapperMethods = new(StringComparer.Ordinal)
    {
        "Query", "QueryAsync",
        "QueryFirst", "QueryFirstAsync",
        "QueryFirstOrDefault", "QueryFirstOrDefaultAsync",
        "QuerySingle", "QuerySingleAsync",
        "QuerySingleOrDefault", "QuerySingleOrDefaultAsync",
        "QueryMultiple", "QueryMultipleAsync",
        "Execute", "ExecuteAsync",
        "ExecuteScalar", "ExecuteScalarAsync",
        "ExecuteReader", "ExecuteReaderAsync",
        // Dapper.Contrib
        "Get", "GetAll", "Insert", "Update", "Delete", "DeleteAll",
    };

    private static readonly Regex TableRegex = new(
        @"\b(?:from|join|into|update|delete\s+from|merge(?:\s+into)?)\s+(?!\()(\[?\w+\]?(?:\s*\.\s*\[?\w+\]?){0,2})",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex CteRegex = new(
        @"\bwith\s+(\w+)\s+as\s*\(", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex WriteRegex = new(
        @"\b(insert\s+into|update\s+\w|delete\s+from|merge\s+into|truncate\s+table)\b",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex ProcNameRegex = new(
        @"^\s*(?:exec(?:ute)?\s+)?(\[?\w+\]?(?:\s*\.\s*\[?\w+\]?){0,2})\s*(?:@\w+.*)?$",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex SqlKeywords = new(
        @"\b(select|insert|update|delete|merge|exec|execute|truncate)\b",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public static bool IsDataAccess(IMethodSymbol m)
    {
        if (!DapperMethods.Contains(m.Name)) return false;
        var owner = m.ContainingType?.Name ?? "";
        if (owner is "SqlMapper" or "SqlMapperExtensions") return true;
        if (m.ContainingNamespace?.ToDisplayString().StartsWith("Dapper", StringComparison.Ordinal) == true)
            return true;
        return m.IsExtensionMethod &&
               m.Parameters.FirstOrDefault()?.Type is { } t &&
               (t.Name is "IDbConnection" or "DbConnection" or "SqlConnection" ||
                t.AllInterfaces.Any(i => i.Name == "IDbConnection"));
    }

    public static void Emit(
        Graph graph,
        InvocationExpressionSyntax inv,
        SemanticModel model,
        string fromId,
        int line)
    {
        var sql = FindCommandText(inv, model);
        if (sql is null)
        {
            graph.Warnings.Add($"unresolved-sql\t{fromId}\tline {line}");
            return;
        }

        if (IsStoredProcedure(inv) && ProcNameRegex.Match(sql) is { Success: true } pm)
        {
            var proc = Normalize(pm.Groups[1].Value);
            AddNode(graph, $"sql:proc:{proc}", NodeKind.Proc, proc);
            graph.Edges.Add(new Edge
            {
                From = fromId, To = $"sql:proc:{proc}",
                Kind = EdgeKind.SqlProc, Line = line, Sql = Truncate(sql, 400)
            });
            return;
        }

        var ctes = CteRegex.Matches(sql).Select(m => m.Groups[1].Value.ToLowerInvariant()).ToHashSet();
        var write = WriteRegex.IsMatch(sql);
        var any = false;

        foreach (Match m in TableRegex.Matches(sql))
        {
            var table = Normalize(m.Groups[1].Value);
            if (table.Length == 0) continue;
            var shortName = table.Split('.').Last().ToLowerInvariant();
            if (ctes.Contains(shortName)) continue;          // CTE, not a real table
            if (shortName.StartsWith("#")) continue;         // temp table

            any = true;
            AddNode(graph, $"sql:table:{table}", NodeKind.Table, table);
            graph.Edges.Add(new Edge
            {
                From = fromId,
                To = $"sql:table:{table}",
                Kind = write ? EdgeKind.SqlWrite : EdgeKind.SqlRead,
                Line = line,
                Sql = Truncate(sql, 600)
            });
        }

        if (!any) graph.Warnings.Add($"sql-no-tables\t{fromId}\tline {line}\t{Truncate(sql, 120)}");
    }

    private static void AddNode(Graph g, string id, NodeKind kind, string name)
    {
        if (!g.Nodes.ContainsKey(id))
            g.Nodes[id] = new Node { Id = id, Kind = kind, Name = name };
    }

    private static bool IsStoredProcedure(InvocationExpressionSyntax inv) =>
        inv.ArgumentList.Arguments.Any(a =>
            a.Expression.ToString().Contains("CommandType.StoredProcedure", StringComparison.Ordinal));

    private static string? FindCommandText(InvocationExpressionSyntax inv, SemanticModel model)
    {
        var args = inv.ArgumentList.Arguments;

        foreach (var a in args)
            if (a.NameColon?.Name.Identifier.Text is "sql" or "commandText")
                return Resolve(a.Expression, model);

        // Dapper's CommandDefinition overload
        foreach (var a in args)
            if (a.Expression is ObjectCreationExpressionSyntax oc &&
                oc.Type.ToString().Contains("CommandDefinition", StringComparison.Ordinal))
            {
                var first = oc.ArgumentList?.Arguments.FirstOrDefault()?.Expression;
                if (first is not null) return Resolve(first, model);
            }

        foreach (var a in args)
        {
            var s = Resolve(a.Expression, model);
            if (s is not null && SqlKeywords.IsMatch(s)) return s;
        }
        return null;
    }

    /// Best-effort constant folding: literals, consts, static readonly fields,
    /// string concatenation, interpolation, verbatim strings and raw literals.
    public static string? Resolve(ExpressionSyntax expr, SemanticModel model, int depth = 0)
    {
        if (depth > 8) return null;

        var constant = model.GetConstantValue(expr);
        if (constant is { HasValue: true, Value: string cs }) return cs;

        switch (expr)
        {
            case LiteralExpressionSyntax lit when lit.Token.Value is string s:
                return s;

            case ParenthesizedExpressionSyntax p:
                return Resolve(p.Expression, model, depth + 1);

            case BinaryExpressionSyntax bin when bin.IsKind(SyntaxKind.AddExpression):
            {
                var l = Resolve(bin.Left, model, depth + 1);
                var r = Resolve(bin.Right, model, depth + 1);
                if (l is null && r is null) return null;
                return (l ?? " /*dynamic*/ ") + (r ?? " /*dynamic*/ ");
            }

            case InterpolatedStringExpressionSyntax interp:
                return string.Concat(interp.Contents.Select(c => c switch
                {
                    InterpolatedStringTextSyntax t => t.TextToken.ValueText,
                    InterpolationSyntax i => Resolve(i.Expression, model, depth + 1) ?? " /*dynamic*/ ",
                    _ => ""
                }));

            case InvocationExpressionSyntax call
                when call.Expression is MemberAccessExpressionSyntax { Name.Identifier.Text: "ToString" } ma:
                return Resolve(ma.Expression, model, depth + 1);

            case IdentifierNameSyntax:
            case MemberAccessExpressionSyntax:
            {
                var sym = model.GetSymbolInfo(expr).Symbol;
                foreach (var reference in sym?.DeclaringSyntaxReferences ?? default)
                {
                    switch (reference.GetSyntax())
                    {
                        case VariableDeclaratorSyntax { Initializer.Value: { } v }:
                            return Resolve(v, model, depth + 1);
                        case PropertyDeclarationSyntax { ExpressionBody.Expression: { } pe }:
                            return Resolve(pe, model, depth + 1);
                    }
                }
                return null;
            }
        }
        return null;
    }

    public static string Normalize(string raw) =>
        raw.Replace("[", "").Replace("]", "").Replace(" ", "").Replace("\"", "").Trim();

    public static string Truncate(string s, int n)
    {
        s = Regex.Replace(s.Trim(), @"\s+", " ");
        return s.Length <= n ? s : s[..n] + " /*…*/";
    }
}
