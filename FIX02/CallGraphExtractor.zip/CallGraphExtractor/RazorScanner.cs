using System.Text.RegularExpressions;

namespace CallGraph;

public sealed record ScriptBlock(
    string ViewId,
    string File,
    int StartLine,
    string Code,
    Dictionary<string, RazorExpression> RazorMap,
    bool Inline);

/// Walks the Views tree (and any wwwroot JS) building View / ScriptFile nodes,
/// view -> partial, view -> script and view -> action edges.
public sealed class RazorScanner
{
    private static readonly Regex ScriptTag = new(
        @"<script\b(?<attrs>[^>]*)>(?<body>.*?)</script\s*>",
        RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);

    private static readonly Regex SelfClosingScript = new(
        @"<script\b(?<attrs>[^>]*?)/?>(?=\s*(?:<|$))",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex Attr = new(
        @"(?<name>[\w-]+)\s*=\s*(?:""(?<v>[^""]*)""|'(?<v>[^']*)')",
        RegexOptions.Compiled);

    private static readonly Regex TagWithAspAction = new(
        @"<(?<tag>form|a|button|input)\b(?<attrs>[^>]*\basp-action\b[^>]*)>",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex PartialCall = new(
        @"@(?:await\s+)?Html\.(?:Partial|PartialAsync|RenderPartial|RenderPartialAsync)\s*\(\s*""(?<name>[^""]+)""",
        RegexOptions.Compiled);

    private static readonly Regex PartialTagHelper = new(
        @"<partial\b[^>]*\bname\s*=\s*""(?<name>[^""]+)""", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex LayoutAssign = new(
        @"Layout\s*=\s*""(?<name>[^""]+)""", RegexOptions.Compiled);

    private static readonly Regex ModelDirective = new(
        @"^@model\s+(?<type>[\w.<>\[\], ]+)\s*$",
        RegexOptions.Multiline | RegexOptions.Compiled);

    private readonly Graph _graph;
    private readonly string _root;
    public List<ScriptBlock> Scripts { get; } = new();

    public RazorScanner(Graph graph, string repoRoot)
    {
        _graph = graph;
        _root = repoRoot;
    }

    public void ScanViews(IEnumerable<string> cshtmlFiles, Action<string>? log = null)
    {
        var count = 0;
        foreach (var file in cshtmlFiles)
        {
            try { ScanView(file); count++; }
            catch (Exception ex) { _graph.Warnings.Add($"razor-scan\t{Rel(file)}\t{ex.Message}"); }
        }
        log?.Invoke($"views: {count}");
    }

    private void ScanView(string file)
    {
        var text = File.ReadAllText(file);
        var rel = Rel(file);
        var viewId = $"view:{rel}";

        var model = ModelDirective.Match(text) is { Success: true } mm
            ? mm.Groups["type"].Value.Trim() : null;

        _graph.Nodes[viewId] = new Node
        {
            Id = viewId,
            Kind = NodeKind.View,
            Name = Path.GetFileNameWithoutExtension(file),
            File = rel,
            Line = 1,
            Language = "razor",
            Returns = model,
            Tags = Path.GetFileName(file).StartsWith("_", StringComparison.Ordinal)
                ? new[] { "partial" } : new[] { "view" },
            Loc = text.Count(c => c == '\n') + 1
        };

        // view -> layout / partials
        foreach (var name in PartialCall.Matches(text).Select(m => m.Groups["name"].Value)
                     .Concat(PartialTagHelper.Matches(text).Select(m => m.Groups["name"].Value))
                     .Concat(LayoutAssign.Matches(text).Select(m => m.Groups["name"].Value)))
        {
            var target = ResolvePartial(file, name);
            if (target is null) { _graph.Warnings.Add($"unresolved-partial\t{rel}\t{name}"); continue; }
            _graph.Edges.Add(new Edge { From = viewId, To = $"view:{target}", Kind = EdgeKind.Includes });
        }

        // <form asp-controller="Order" asp-action="Save">
        foreach (Match m in TagWithAspAction.Matches(text))
        {
            var attrs = ParseAttrs(m.Groups["attrs"].Value);
            attrs.TryGetValue("asp-action", out var action);
            attrs.TryGetValue("asp-controller", out var controller);
            if (action is null) continue;

            var line = LineAt(text, m.Index);
            _graph.Edges.Add(new Edge
            {
                From = viewId,
                To = EndpointResolver.PendingId(controller, action),
                Kind = EdgeKind.FormPost,
                Line = line,
                Resolution = "asp-tag-helper"
            });
        }

        // @Url.Action / @Html.ActionLink outside script blocks are links too
        foreach (var expr in RazorMasker.Mask(text).Map.Values)
        {
            if (expr.Action is null) continue;
            _graph.Edges.Add(new Edge
            {
                From = viewId,
                To = EndpointResolver.PendingId(expr.Controller, expr.Action),
                Kind = EdgeKind.FormPost,
                Line = expr.Line + 1,
                Resolution = "url-helper"
            });
        }

        ExtractScripts(text, rel, viewId);
        TelerikExtractor.Scan(_graph, viewId, rel, text);
    }

    private void ExtractScripts(string text, string rel, string viewId)
    {
        // <script src="~/js/order.js"></script>
        foreach (Match m in SelfClosingScript.Matches(text))
        {
            var attrs = ParseAttrs(m.Groups["attrs"].Value);
            if (!attrs.TryGetValue("src", out var src)) continue;
            LinkScriptFile(viewId, src, LineAt(text, m.Index));
        }

        foreach (Match m in ScriptTag.Matches(text))
        {
            var attrs = ParseAttrs(m.Groups["attrs"].Value);

            if (attrs.TryGetValue("src", out var src))
            {
                LinkScriptFile(viewId, src, LineAt(text, m.Index));
                continue;
            }

            // skip templating engines masquerading as scripts
            if (attrs.TryGetValue("type", out var type) &&
                !type.Contains("javascript", StringComparison.OrdinalIgnoreCase) &&
                type != "module" && type != "text/babel")
                continue;

            var body = m.Groups["body"].Value;
            if (body.Trim().Length == 0) continue;

            var startLine = LineAt(text, m.Groups["body"].Index);
            var (masked, map) = RazorMasker.Mask(body, startLine);

            var blockId = $"script:{rel}#{startLine}";
            _graph.Nodes[blockId] = new Node
            {
                Id = blockId,
                Kind = NodeKind.ScriptFile,
                Name = $"{Path.GetFileName(rel)}:{startLine}",
                File = rel,
                Line = startLine,
                EndLine = startLine + body.Count(c => c == '\n'),
                Language = "js",
                Tags = new[] { "inline-script" }
            };
            _graph.Edges.Add(new Edge
            {
                From = viewId, To = blockId, Kind = EdgeKind.ScriptRef, Line = startLine
            });

            Scripts.Add(new ScriptBlock(blockId, rel, startLine, masked, map, Inline: true));
        }
    }

    private void LinkScriptFile(string viewId, string src, int line)
    {
        if (src.StartsWith("http", StringComparison.OrdinalIgnoreCase)) return;   // CDN
        var normalized = NormalizeSrc(src);
        var id = $"script:{normalized}";
        if (!_graph.Nodes.ContainsKey(id))
            _graph.Nodes[id] = new Node
            {
                Id = id, Kind = NodeKind.ScriptFile,
                Name = Path.GetFileName(normalized), File = normalized,
                Language = "js", Tags = new[] { "external-script" }
            };
        _graph.Edges.Add(new Edge { From = viewId, To = id, Kind = EdgeKind.ScriptRef, Line = line });
    }

    /// Adds standalone .js files (wwwroot/js/**) as ScriptFile nodes.
    public List<ScriptBlock> ScanJsFiles(IEnumerable<string> jsFiles, Action<string>? log = null)
    {
        var blocks = new List<ScriptBlock>();
        var n = 0;
        foreach (var file in jsFiles)
        {
            var rel = Rel(file);
            if (rel.Contains("/lib/") || rel.EndsWith(".min.js", StringComparison.OrdinalIgnoreCase))
                continue;

            var id = $"script:{rel}";
            var code = File.ReadAllText(file);
            _graph.Nodes[id] = new Node
            {
                Id = id, Kind = NodeKind.ScriptFile, Name = Path.GetFileName(file),
                File = rel, Line = 1, EndLine = code.Count(c => c == '\n') + 1,
                Language = "js", Tags = new[] { "script-file" }
            };
            blocks.Add(new ScriptBlock(id, rel, 1, code,
                new Dictionary<string, RazorExpression>(StringComparer.Ordinal), Inline: false));
            n++;
        }
        log?.Invoke($"js files: {n}");
        Scripts.AddRange(blocks);
        return blocks;
    }

    /// Links controller actions to the views they render, by MVC convention and
    /// by explicit View("Name") calls recorded during the Roslyn pass.
    public void LinkActionsToViews()
    {
        var views = _graph.Nodes.Values.Where(n => n.Kind == NodeKind.View).ToList();

        foreach (var action in _graph.Nodes.Values
                     .Where(n => n.Tags.Contains("controller-action") && n.DeclaringType is not null))
        {
            var typeName = action.DeclaringType!.Split('.').Last();
            var controller = typeName.EndsWith("Controller", StringComparison.Ordinal)
                ? typeName[..^"Controller".Length] : typeName;

            var match = views.FirstOrDefault(v =>
                v.File is not null &&
                v.File.Replace('\\', '/')
                 .EndsWith($"/Views/{controller}/{action.Name}.cshtml", StringComparison.OrdinalIgnoreCase));

            match ??= views.FirstOrDefault(v =>
                v.File is not null &&
                v.File.Replace('\\', '/')
                 .EndsWith($"/Pages/{controller}/{action.Name}.cshtml", StringComparison.OrdinalIgnoreCase));

            if (match is null) continue;
            _graph.Edges.Add(new Edge
            {
                From = action.Id, To = match.Id, Kind = EdgeKind.Renders, Resolution = "convention"
            });
        }
    }

    // ---------------------------------------------------------------- helpers

    private string? ResolvePartial(string fromFile, string name)
    {
        if (name.EndsWith(".cshtml", StringComparison.OrdinalIgnoreCase) || name.StartsWith("~/"))
        {
            var direct = NormalizeSrc(name);
            return _graph.Nodes.ContainsKey($"view:{direct}") ? direct : null;
        }

        var candidates = _graph.Nodes.Values
            .Where(n => n.Kind == NodeKind.View && n.File is not null &&
                        Path.GetFileNameWithoutExtension(n.File).Equals(name, StringComparison.OrdinalIgnoreCase))
            .Select(n => n.File!)
            .ToList();

        if (candidates.Count == 0) return null;
        if (candidates.Count == 1) return candidates[0];

        // prefer same folder, then Shared
        var dir = Path.GetDirectoryName(Rel(fromFile))?.Replace('\\', '/') ?? "";
        return candidates.FirstOrDefault(c => c.StartsWith(dir, StringComparison.OrdinalIgnoreCase))
               ?? candidates.FirstOrDefault(c => c.Contains("/Shared/", StringComparison.OrdinalIgnoreCase))
               ?? candidates[0];
    }

    private static string NormalizeSrc(string src)
    {
        var s = src.Split('?')[0].Trim();
        if (s.StartsWith("~/")) s = s[2..];
        if (s.StartsWith("/")) s = s[1..];
        if (!s.StartsWith("wwwroot/", StringComparison.OrdinalIgnoreCase) &&
            !s.Contains("/Views/", StringComparison.OrdinalIgnoreCase))
            s = "wwwroot/" + s;
        return s;
    }

    private static Dictionary<string, string> ParseAttrs(string raw)
    {
        var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (Match m in Attr.Matches(raw))
            d[m.Groups["name"].Value] = m.Groups["v"].Value;
        return d;
    }

    private static int LineAt(string text, int index)
    {
        var n = 1;
        for (var i = 0; i < index && i < text.Length; i++)
            if (text[i] == '\n') n++;
        return n;
    }

    private string Rel(string p) => Path.GetRelativePath(_root, p).Replace('\\', '/');
}
