using Microsoft.CodeAnalysis;

namespace CallGraph;

public static class RouteResolver
{
    public static string? Resolve(IMethodSymbol method)
    {
        var type = method.ContainingType;
        if (type is null) return null;

        var isController = Ancestry(type).Any(n => n is "Controller" or "ControllerBase");
        if (!isController) return null;

        string? verb = null, methodTemplate = null, classTemplate = null, area = null;

        foreach (var a in method.GetAttributes())
        {
            var n = a.AttributeClass?.Name ?? "";
            if (n is "HttpGetAttribute" or "HttpPostAttribute" or "HttpPutAttribute"
                  or "HttpDeleteAttribute" or "HttpPatchAttribute" or "HttpHeadAttribute"
                  or "HttpOptionsAttribute")
            {
                verb = n[4..^9].ToUpperInvariant();
                methodTemplate ??= Template(a);
            }
            else if (n == "RouteAttribute")
            {
                methodTemplate ??= Template(a);
            }
        }

        foreach (var a in type.GetAttributes())
        {
            var n = a.AttributeClass?.Name ?? "";
            if (n == "RouteAttribute") classTemplate ??= Template(a);
            else if (n == "AreaAttribute") area = Template(a);
        }

        var controller = type.Name.EndsWith("Controller", StringComparison.Ordinal)
            ? type.Name[..^"Controller".Length]
            : type.Name;

        string template;
        if (classTemplate is null && methodTemplate is null)
        {
            // conventional routing
            template = area is null ? $"{controller}/{method.Name}" : $"{area}/{controller}/{method.Name}";
        }
        else
        {
            template = string.Join("/", new[] { classTemplate, methodTemplate }
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x!.Trim('/')));
        }

        template = template
            .Replace("[controller]", controller, StringComparison.OrdinalIgnoreCase)
            .Replace("[action]", method.Name, StringComparison.OrdinalIgnoreCase)
            .Replace("[area]", area ?? "", StringComparison.OrdinalIgnoreCase)
            .Trim('/');

        return $"{verb ?? "*"} /{template}";
    }

    private static string? Template(AttributeData a)
    {
        var positional = a.ConstructorArguments.FirstOrDefault();
        if (positional.Value is string s && s.Length > 0) return s;
        foreach (var named in a.NamedArguments)
            if (named.Key is "Template" or "Name" && named.Value.Value is string ns) return ns;
        return null;
    }

    private static IEnumerable<string> Ancestry(INamedTypeSymbol t)
    {
        for (var b = t; b is not null; b = b.BaseType) yield return b.Name;
    }
}
