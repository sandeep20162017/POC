# CallGraphExtractor

Roslyn-based call graph generator for ASP.NET Core MVC apps using Dapper,
Razor views, embedded/standalone JavaScript, and Telerik/Kendo UI widgets.
Outputs a method-level graph plus token-budgeted slices meant to be fed to
an LLM (GPT-4o-mini or similar) as developer-assistant context.

**This has not been compiled or run against a real solution.** The sandbox
this was written in has no .NET SDK and no network access, so treat it as a
solid first draft, not a tested tool. Build it locally, fix whatever the
compiler flags (Roslyn API surface shifts a little between 4.9.x patch
versions), and check `warnings.txt` after the first real run.

---

## 1. Prerequisites

- **.NET 8 SDK** — `dotnet --version` should print `8.x`.
- The **MSBuild toolset for your project type**. If `YourApp.sln` is a normal
  ASP.NET Core web app this is already part of the SDK. If it references
  older .NET Framework projects, install the corresponding Visual Studio
  Build Tools workload — `MSBuildLocator` needs a real MSBuild to resolve
  against.
- **NuGet packages must be restorable** for the target solution (`dotnet
  restore` should succeed on it) — Roslyn needs to resolve types, including
  Dapper's and Telerik's, to do anything beyond guesswork.

## 2. Build the tool

```bash
cd CallGraphExtractor
dotnet restore
dotnet build -c Release
```

If restore fails on `Microsoft.CodeAnalysis.Workspaces.MSBuild` or
`Acornima`, your environment likely has no internet access to nuget.org —
point `NuGet.Config` at an internal feed/mirror, or `dotnet nuget add
source` first.

## 3. Run it against your app

```bash
dotnet run --project CallGraphExtractor -- build \
  /path/to/YourApp.sln \
  --out ./graph \
  --repo /path/to/YourApp \
  --schema /path/to/schema.sql \
  --js-root /path/to/YourApp/src/Web/wwwroot/js \
  --budget 6000 \
  --depth 6
```

| Flag | Meaning | Default |
|---|---|---|
| `--out` | output directory | `./graph` |
| `--repo` | repo root, used to resolve `.cshtml`/`.js` and to make relative paths | the `.sln`'s folder |
| `--schema` | path to `schema.sql`, attaches table DDL to slices | none — tables still extracted, just without column detail |
| `--js-root` | explicit JS folder | any `*.js` under a `wwwroot/` folder |
| `--budget` | target tokens per slice file | `6000` |
| `--depth` | how many call hops deep a slice's closure goes | `6` |
| `--callers` | how many hops of *callers* to include | `1` |
| `--no-client` | skip Razor/JS/Telerik scanning entirely (C# graph only, faster) | off |

This produces, under `./graph/`:

```
nodes.jsonl        one JSON object per line — every method, table, proc, view, script, JS function, widget
edges.jsonl        one JSON object per line — every relationship between two nodes
paths.jsonl        entry point → … → SQL table/proc, and browser event → … → SQL
manifest.json      counts: nodes, edges by kind, entry points, slices, estimated tokens
warnings.txt       everything the tool couldn't resolve — READ THIS FIRST
slices/
  index.json       one row per slice: id, route, tables touched, token estimate, retrieval text
  <EntryPoint>.json          one slice per controller action / entry point
  <EntryPoint>.p2.json       continuation part if the slice exceeded --budget
```

### Also useful: full path dump without slicing

```bash
dotnet run --project CallGraphExtractor -- paths \
  /path/to/YourApp.sln \
  --out ./graph \
  --max-depth 12 \
  --max-paths 60
```

Writes `nodes.jsonl` / `edges.jsonl` / `paths.jsonl` / `warnings.txt` only —
skips slice generation, useful when you just want to inspect the graph
shape or feed `paths.jsonl` into something else.

## 4. Query-time context assembly (what your assistant actually calls)

Once `./graph` exists, this is the piece you'd wire up as a tool behind
your OpenAI integration — given a bug report or a route, it returns a
budgeted JSON blob: relevant slices, call paths as text, matching
`schema.sql` DDL, and real source for the top N methods.

```bash
dotnet run --project CallGraphExtractor -- context \
  ./graph \
  --query "GET /orders/{id} returns wrong total" \
  --src /path/to/YourApp \
  --schema /path/to/schema.sql \
  --budget 12000 \
  --seeds 3 \
  --max-sources 12
```

Prints one JSON object to stdout — pipe it wherever your prompt-assembly
code reads from, e.g.:

```bash
dotnet run --project CallGraphExtractor -- context ./graph --query "$1" \
  --src /path/to/YourApp --schema /path/to/schema.sql > context.json
```

## 5. First-run checklist

1. Run `build` once, then open `manifest.json`. Sanity-check the counts —
   if `entryPoints` is 0, your controllers aren't matching the
   `Controller`/`ControllerBase` base-class detection (check for a custom
   base controller and extend `RoslynGraphBuilder.Tags`).
2. Open `warnings.txt`. The categories that matter most, roughly in order
   of how much they cost you:
   - `unresolved-sql` — Dapper calls where the SQL text couldn't be
     constant-folded (built in a loop, from a `StringBuilder`, etc). These
     are often exactly the spots worth debugging by hand anyway.
   - `unresolved-endpoint` — a JS/Telerik call whose target URL or
     `Url.Action` couldn't be matched to a controller action. If your app
     builds URLs through a shared JS helper (`api.get('orders')` instead of
     literal strings), extend `JsAnalyzer.DetectHttp` for that one helper —
     it's usually a 10–15 line addition and fixes most instances at once.
   - `telerik-partial-content` — a Kendo Window/Dialog whose popup body is
     an embedded partial rather than an AJAX-loaded action. Currently
     logged, not linked — see the note in `TelerikExtractor.cs`.
   - `no-compilation` — a project Roslyn couldn't compile at all (missing
     restore, unsupported project type). Fix restore for that project or
     accept it's excluded from the graph.
3. Pick one entry point you know well and read its slice in
   `slices/<Name>.json` end to end. Confirm the tables, the Razor view, and
   the JS/Telerik widgets it lists match what you'd expect. This catches
   more bugs than anything else — the graph is only as good as this manual
   spot check.

## 6. Regenerating

There's no incremental mode — every run rebuilds the whole graph. For a
mid-size app (few hundred controllers) expect the Roslyn pass to dominate
runtime; the Razor/JS pass is comparatively fast. Wire this into CI as a
nightly job or a post-merge step rather than running it per-commit.

## File map

| File | Responsibility |
|---|---|
| `Model.cs` | shared record types: `Node`, `Edge`, `Graph`, `CallPath`, `Slice` |
| `RoslynGraphBuilder.cs` | opens the solution, walks C# declarations/calls, links interface→impl and DI |
| `RouteResolver.cs` | resolves `[Route]`/`[Http*]` attributes and conventional routing to a route template |
| `SqlExtractor.cs` | recognizes Dapper calls, constant-folds SQL text, extracts table/proc names |
| `RazorMasker.cs` | rewrites Razor expressions (`@Url.Action(...)`) inside `<script>` blocks into parseable placeholders |
| `RazorScanner.cs` | walks `.cshtml` files: views, partials, layouts, `asp-action` tag helpers, script blocks |
| `TelerikExtractor.cs` | Telerik/Kendo server-side fluent widget config (`.Read(r => r.Action(...))`, `.LoadContentFrom(...)`) |
| `JsAnalyzer.cs` | parses masked JS with Acornima: function declarations, event handlers, `fetch`/`$.ajax`/`axios`/`.load()`, Kendo widget JS init |
| `EndpointResolver.cs` | resolves the "pending" targets the Razor/JS/Telerik scanners emit into real controller-action node ids |
| `SchemaIndex.cs` | parses `schema.sql` into per-table DDL blocks |
| `PathAnalyzer.cs` | enumerates entry-point → … → SQL-terminal paths, including browser-rooted paths |
| `SliceBuilder.cs` | builds the token-budgeted per-entry-point neighborhoods and splits oversized ones |
| `ContextAssembler.cs` | query-time: seed ranking, slice expansion, source attachment within a token budget |
| `Program.cs` | CLI: `build`, `paths`, `context` commands |
