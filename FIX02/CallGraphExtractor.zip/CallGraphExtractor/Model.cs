using System.Text.Json;
using System.Text.Json.Serialization;

namespace CallGraph;

public enum NodeKind
{
    Method,
    Table,
    Proc,
    External,
    View,          // .cshtml file
    ScriptFile,    // .js file under wwwroot (or an inline <script> block)
    JsFunction     // named function, arrow, class method or event handler
}

public enum EdgeKind
{
    Call,          // resolved method invocation inside the solution
    Ctor,          // object creation
    Implements,    // interface member -> concrete impl, or virtual -> override
    DiRegister,    // services.AddScoped<IFoo, Foo>()
    SqlRead,
    SqlWrite,
    SqlProc,

    // ---- client side ----
    Renders,       // controller action -> view
    Includes,      // view -> partial view / layout
    ScriptRef,     // view -> .js file or inline script block
    Defines,       // script file -> js function
    JsCall,        // js function -> js function
    HttpCall,      // js function -> controller action (fetch/$.ajax/axios)
    FormPost       // view form or link -> controller action (asp-action, Url.Action)
}

public sealed record Node
{
    public required string Id { get; init; }
    public required NodeKind Kind { get; init; }
    public string? Name { get; init; }
    public string? DeclaringType { get; init; }
    public string? Namespace { get; init; }
    public string? Project { get; init; }
    public string? File { get; init; }
    public int? Line { get; init; }
    public int? EndLine { get; init; }
    public string? Route { get; init; }
    public string? Returns { get; init; }
    public string[]? Parameters { get; init; }
    public string[] Tags { get; init; } = Array.Empty<string>();
    public bool IsAsync { get; init; }
    public bool IsAbstract { get; init; }
    public int? Loc { get; init; }

    /// csharp | js | razor
    public string? Language { get; init; }
    /// For event handlers: the binding that produced them, e.g. "#saveBtn.click".
    public string? Selector { get; init; }
    /// For HTTP calls that could not be resolved to an action: the raw URL expression.
    public string? Url { get; init; }

    /// Optional: one-line summary produced by an LLM in a later pass.
    public string? Summary { get; set; }

    [JsonIgnore] public bool IsSql => Kind is NodeKind.Table or NodeKind.Proc;
    [JsonIgnore] public bool IsClient =>
        Kind is NodeKind.View or NodeKind.ScriptFile or NodeKind.JsFunction;
}

public sealed record Edge
{
    public required string From { get; init; }
    public required string To { get; init; }
    public required EdgeKind Kind { get; init; }
    public int? Line { get; init; }
    public string? Sql { get; init; }

    /// direct | interface | virtual | di
    public string? Resolution { get; init; }

    public string Key => $"{From}|{To}|{Kind}|{Line}";
}

public sealed class Graph
{
    public Dictionary<string, Node> Nodes { get; } = new(StringComparer.Ordinal);
    public List<Edge> Edges { get; } = new();
    public List<string> Warnings { get; } = new();

    private Dictionary<string, List<Edge>>? _out, _in;

    public IReadOnlyList<Edge> Out(string id) =>
        (_out ??= Index(e => e.From)).TryGetValue(id, out var v) ? v : Array.Empty<Edge>();

    public IReadOnlyList<Edge> In(string id) =>
        (_in ??= Index(e => e.To)).TryGetValue(id, out var v) ? v : Array.Empty<Edge>();

    public void Invalidate() { _out = null; _in = null; }

    private Dictionary<string, List<Edge>> Index(Func<Edge, string> key)
    {
        var d = new Dictionary<string, List<Edge>>(StringComparer.Ordinal);
        foreach (var e in Edges)
        {
            if (!d.TryGetValue(key(e), out var list)) d[key(e)] = list = new List<Edge>();
            list.Add(e);
        }
        return d;
    }

    public Node? Get(string id) => Nodes.TryGetValue(id, out var n) ? n : null;

    public IEnumerable<Node> EntryPoints() => Nodes.Values.Where(n =>
        n.Tags.Contains("controller-action") ||
        n.Tags.Contains("background-service") ||
        n.Tags.Contains("minimal-api") ||
        n.Tags.Contains("message-handler"));

    /// Browser-side roots: DOM event handlers and document-ready blocks.
    public IEnumerable<Node> ClientEntryPoints() => Nodes.Values.Where(n =>
        n.Kind == NodeKind.JsFunction &&
        (n.Tags.Contains("js-event-handler") || n.Tags.Contains("js-ready")));
}

// ------------------------------------------------------------------ paths

public sealed record PathStep
{
    public required string Id { get; init; }
    public string? Display { get; init; }
    public string? File { get; init; }
    public int? Line { get; init; }
    /// Line inside the *caller* where this step is invoked.
    public int? CallSite { get; init; }
    public string? Via { get; init; }   // "interface" when the hop went through DI
}

public sealed record CallPath
{
    public required string Id { get; init; }
    public required string Entry { get; init; }
    public string? Route { get; init; }
    public required List<PathStep> Steps { get; init; }
    public string? TerminalKind { get; init; }   // sql-read | sql-write | sql-proc | leaf
    public string? Terminal { get; init; }       // table / proc name
    public string? Sql { get; init; }
    public int Depth => Steps.Count;
    public bool Truncated { get; init; }
}

// ------------------------------------------------------------------ slices

public sealed record Slice
{
    public required string Id { get; init; }
    public required string Entry { get; init; }
    public string? Route { get; init; }
    public int Part { get; init; } = 1;
    public int PartsTotal { get; init; } = 1;
    public required List<Node> Nodes { get; init; }
    public required List<Edge> Edges { get; init; }
    public List<CallPath> Paths { get; init; } = new();
    public List<string> Tables { get; init; } = new();
    public Dictionary<string, string> Schema { get; init; } = new();
    public string[]? OmittedBranches { get; init; }
    public int EstTokens { get; set; }
}

public sealed record SliceIndexEntry
{
    public required string Id { get; init; }
    public required string File { get; init; }
    public required string Entry { get; init; }
    public string? Route { get; init; }
    public int Part { get; init; }
    public int PartsTotal { get; init; }
    public int NodeCount { get; init; }
    public int PathCount { get; init; }
    public string[] Tables { get; init; } = Array.Empty<string>();
    public string[] Files { get; init; } = Array.Empty<string>();
    public int EstTokens { get; init; }
    /// Text to embed / BM25 over for retrieval.
    public required string Text { get; init; }
}

public static class Json
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        Converters = { new JsonStringEnumConverter(JsonNamingPolicy.KebabCaseLower) },
        WriteIndented = false
    };

    public static readonly JsonSerializerOptions Pretty = new(Options) { WriteIndented = true };

    public static string Line<T>(T value) => JsonSerializer.Serialize(value, Options);
}

public static class TokenCounter
{
    public const double CharsPerToken = 3.6;

    public static int Estimate(string s) => (int)(s.Length / CharsPerToken) + 1;
    public static int Estimate<T>(T obj) => Estimate(Json.Line(obj));
}
