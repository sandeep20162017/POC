using Acornima;
using Acornima.Ast;

namespace CallGraph;

/// Parses JavaScript (already Razor-masked) into function nodes, js -> js call
/// edges, and js -> controller-action edges for fetch / jQuery / axios calls.
public sealed class JsAnalyzer
{
    private readonly Graph _graph;
    private readonly Parser _parser;

    private static readonly HashSet<string> EventBinders = new(StringComparer.Ordinal)
    {
        "on", "click", "change", "submit", "blur", "focus", "keyup", "keydown",
        "addEventListener", "ready", "live", "delegate", "one"
    };

    private static readonly HashSet<string> JQueryHttp = new(StringComparer.Ordinal)
    {
        "ajax", "get", "post", "getJSON", "getScript", "load"
    };

    // $('#modal').load('/Order/Edit/5') — classic Bootstrap/jQuery popup pattern.
    // Distinguished from other JQueryHttp members because its target is the
    // *caller's* selector, not a data payload.
    private static readonly HashSet<string> JQueryLoadInto = new(StringComparer.Ordinal) { "load" };

    // Kendo widget constructor names whose config object may carry a DataSource
    // with transport.read/update/create/destroy URLs, or a bare content/url.
    private static readonly HashSet<string> KendoWidgetInit = new(StringComparer.Ordinal)
    {
        "kendoGrid", "kendoWindow", "kendoDialog", "kendoListView",
        "kendoTreeList", "kendoScheduler", "kendoUpload", "kendoAutoComplete",
        "kendoComboBox", "kendoDropDownList", "kendoDataSource"
    };

    private static readonly HashSet<string> AxiosVerbs = new(StringComparer.Ordinal)
    {
        "get", "post", "put", "patch", "delete", "request", "head"
    };

    public JsAnalyzer(Graph graph)
    {
        _graph = graph;
        // Tolerant so one bad block doesn't kill the run; Razor masking should
        // already have made the source syntactically valid.
        _parser = new Parser(new ParserOptions { Tolerant = true });
    }

    public void Analyze(ScriptBlock block, Action<string>? log = null)
    {
        Program ast;
        try
        {
            ast = _parser.ParseScript(block.Code);
        }
        catch (Exception ex)
        {
            _graph.Warnings.Add($"js-parse\t{block.File}:{block.StartLine}\t{ex.Message}");
            FallbackScan(block);
            return;
        }

        var ctx = new Ctx(block, block.ViewId);
        Walk(ast, ctx);
    }

    private sealed class Ctx
    {
        public readonly ScriptBlock Block;
        public readonly Stack<string> Scope = new();
        public int Anonymous;

        public Ctx(ScriptBlock block, string rootId)
        {
            Block = block;
            Scope.Push(rootId);
        }

        public string Current => Scope.Peek();
        public int Line(Node n) => Block.Inline
            ? Block.StartLine + n.Location.Start.Line - 1
            : n.Location.Start.Line;
    }

    // ------------------------------------------------------------------ walk

    private void Walk(Node node, Ctx ctx)
    {
        switch (node)
        {
            case FunctionDeclaration { Id: { } id } fd:
                DeclareAndDescend(fd, ctx, id.Name, Array.Empty<string>());
                return;

            case VariableDeclarator { Id: Identifier vid, Init: { } init }
                when init is FunctionExpression or ArrowFunctionExpression:
                DeclareAndDescend(init, ctx, vid.Name, Array.Empty<string>());
                return;

            case MethodDefinition { Key: Identifier mk } md:
            {
                var cls = FindEnclosingClassName(md);
                DeclareAndDescend(md.Value, ctx, cls is null ? mk.Name : $"{cls}.{mk.Name}",
                    Array.Empty<string>());
                return;
            }

            case ObjectProperty { Key: Identifier pk, Value: { } pv }
                when pv is FunctionExpression or ArrowFunctionExpression:
                DeclareAndDescend(pv, ctx, pk.Name, Array.Empty<string>());
                return;

            case CallExpression call:
                HandleCall(call, ctx);
                break;   // fall through to children as well
        }

        foreach (var child in node.ChildNodes)
            if (child is not null) Walk(child, ctx);
    }

    private void DeclareAndDescend(Node fn, Ctx ctx, string name, string[] extraTags)
    {
        var id = FunctionId(ctx.Block, name);
        var line = ctx.Line(fn);

        if (!_graph.Nodes.ContainsKey(id))
            _graph.Nodes[id] = new Node
            {
                Id = id,
                Kind = NodeKind.JsFunction,
                Name = name,
                File = ctx.Block.File,
                Line = line,
                EndLine = ctx.Block.Inline
                    ? ctx.Block.StartLine + fn.Location.End.Line - 1
                    : fn.Location.End.Line,
                Language = "js",
                Tags = extraTags,
                Parameters = Parameters(fn)
            };

        _graph.Edges.Add(new Edge
        {
            From = ctx.Block.ViewId, To = id, Kind = EdgeKind.Defines, Line = line
        });

        ctx.Scope.Push(id);
        foreach (var child in fn.ChildNodes)
            if (child is not null) Walk(child, ctx);
        ctx.Scope.Pop();
    }

    // ------------------------------------------------------------ call sites

    private void HandleCall(CallExpression call, Ctx ctx)
    {
        var line = ctx.Line(call);

        // --- event binding: $('#save').on('click', fn) / el.addEventListener('click', fn)
        if (call.Callee is MemberExpression { Property: Identifier bind } bm &&
            EventBinders.Contains(bind.Name))
        {
            var handler = call.Arguments.LastOrDefault();
            if (handler is FunctionExpression or ArrowFunctionExpression)
            {
                var selector = SelectorOf(bm.Object);
                var evt = bind.Name switch
                {
                    "on" or "one" or "addEventListener" or "live" or "delegate" =>
                        StringOf(call.Arguments.FirstOrDefault()) ?? "event",
                    "ready" => "ready",
                    _ => bind.Name
                };
                var name = $"{selector}.{evt}";
                var tags = evt == "ready"
                    ? new[] { "js-ready", "js-event-handler" }
                    : new[] { "js-event-handler" };

                var id = FunctionId(ctx.Block, name);
                var hl = ctx.Line(handler!);
                if (!_graph.Nodes.ContainsKey(id))
                    _graph.Nodes[id] = new Node
                    {
                        Id = id, Kind = NodeKind.JsFunction, Name = name,
                        File = ctx.Block.File, Line = hl,
                        EndLine = ctx.Block.Inline
                            ? ctx.Block.StartLine + handler!.Location.End.Line - 1
                            : handler!.Location.End.Line,
                        Language = "js", Selector = selector, Tags = tags
                    };
                _graph.Edges.Add(new Edge
                {
                    From = ctx.Block.ViewId, To = id, Kind = EdgeKind.Defines, Line = hl
                });

                ctx.Scope.Push(id);
                foreach (var child in handler!.ChildNodes)
                    if (child is not null) Walk(child, ctx);
                ctx.Scope.Pop();
                return;
            }
        }

        // --- HTTP calls
        var http = DetectHttp(call);
        if (http is not null)
        {
            var (url, verb, raw) = http.Value;
            EmitHttp(ctx, url, verb, raw, line);
        }

        // --- $('#modal').load('/Order/Edit/5') — the target selector is the
        // popup container, not a data argument, so it's worth its own tag.
        if (call.Callee is MemberExpression { Property: Identifier { Name: "load" } } lm &&
            call.Arguments.FirstOrDefault() is { } loadArg)
        {
            var url = StringOf(loadArg);
            if (url is not null)
            {
                var selector = SelectorOf(lm.Object);
                EmitHttp(ctx, url, "GET", $"jQuery.load->{selector}", line);
            }
        }

        // --- Kendo/Telerik widget initialized in JS: $('#grid').kendoGrid({...})
        if (call.Callee is MemberExpression { Property: Identifier wname } wm &&
            KendoWidgetInit.Contains(wname.Name) &&
            call.Arguments.FirstOrDefault() is ObjectExpression config)
        {
            var selector = SelectorOf(wm.Object);
            var widgetId = $"js:{ctx.Block.File}:{selector}.{wname.Name}";
            if (!_graph.Nodes.ContainsKey(widgetId))
                _graph.Nodes[widgetId] = new Node
                {
                    Id = widgetId, Kind = NodeKind.JsFunction, Name = $"{selector}.{wname.Name}",
                    File = ctx.Block.File, Line = line, Language = "js",
                    Selector = selector, Tags = new[] { "telerik-widget", wname.Name }
                };
            _graph.Edges.Add(new Edge { From = ctx.Current, To = widgetId, Kind = EdgeKind.Defines, Line = line });

            foreach (var (verb, urlExpr) in FindKendoUrls(config))
            {
                var url = StringOf(urlExpr);
                if (url is null) continue;
                var to = RazorMasker.IsPlaceholder(url) && TryResolvePlaceholder(ctx, url, out var pendingId)
                    ? pendingId!
                    : EndpointResolver.PendingUrl(verb == "content" ? "GET" : verb.ToUpperInvariant(),
                        RazorMasker.Unmask(url, ctx.Block.RazorMap));
                _graph.Edges.Add(new Edge
                {
                    From = widgetId, To = to, Kind = EdgeKind.HttpCall, Line = line,
                    Resolution = $"kendo-{wname.Name}-{verb}"
                });
            }
        }

        // --- plain js -> js call
        var calleeName = call.Callee switch
        {
            Identifier i => i.Name,
            MemberExpression { Property: Identifier p, Object: Identifier o } => $"{o.Name}.{p.Name}",
            MemberExpression { Property: Identifier p } => p.Name,
            _ => null
        };

        if (calleeName is not null)
        {
            var targetId = FunctionId(ctx.Block, calleeName);
            // Only emit if the target is (or will be) a known function in this
            // script set; unresolved calls would swamp the graph with library noise.
            _graph.Edges.Add(new Edge
            {
                From = ctx.Current, To = targetId, Kind = EdgeKind.JsCall,
                Line = line, Resolution = "name"
            });
        }
    }

    private (string Url, string Verb, string Raw)? DetectHttp(CallExpression call)
    {
        switch (call.Callee)
        {
            // fetch('/orders/1', { method: 'POST' })
            case Identifier { Name: "fetch" }:
            {
                var url = StringOf(call.Arguments.FirstOrDefault());
                if (url is null) return null;
                var verb = OptionsVerb(call.Arguments.ElementAtOrDefault(1)) ?? "GET";
                return (url, verb, "fetch");
            }

            // $.ajax({ url: ..., type: 'POST' }) / $.get(url) / $.post(url, data)
            case MemberExpression { Object: Identifier { Name: "$" or "jQuery" }, Property: Identifier jp }
                when JQueryHttp.Contains(jp.Name):
            {
                if (jp.Name == "ajax")
                {
                    var opts = call.Arguments.FirstOrDefault();
                    var url = ObjectProp(opts, "url") ?? StringOf(opts);
                    if (url is null) return null;
                    var verb = ObjectProp(opts, "type") ?? ObjectProp(opts, "method") ?? "GET";
                    return (url, verb.ToUpperInvariant(), "$.ajax");
                }
                var u = StringOf(call.Arguments.FirstOrDefault());
                if (u is null) return null;
                var v = jp.Name switch { "post" => "POST", _ => "GET" };
                return (u, v, "$." + jp.Name);
            }

            // axios.post(url, body) / axios({url, method})
            case MemberExpression { Object: Identifier { Name: "axios" }, Property: Identifier ap }
                when AxiosVerbs.Contains(ap.Name):
            {
                var url = StringOf(call.Arguments.FirstOrDefault())
                          ?? ObjectProp(call.Arguments.FirstOrDefault(), "url");
                if (url is null) return null;
                return (url, ap.Name.ToUpperInvariant(), "axios." + ap.Name);
            }

            // xhr.open('POST', url)
            case MemberExpression { Property: Identifier { Name: "open" } }:
            {
                var verb = StringOf(call.Arguments.FirstOrDefault());
                var url = StringOf(call.Arguments.ElementAtOrDefault(1));
                if (url is null || verb is null) return null;
                return (url, verb.ToUpperInvariant(), "XMLHttpRequest");
            }
        }
        return null;
    }

    private void EmitHttp(Ctx ctx, string url, string verb, string raw, int line)
    {
        // The URL may be a Razor placeholder standing in for @Url.Action(...).
        string to;
        if (RazorMasker.IsPlaceholder(url) && TryResolvePlaceholder(ctx, url, out var resolvedId))
        {
            to = resolvedId!;
        }
        else
        {
            var unmasked = RazorMasker.IsPlaceholder(url) ? RazorMasker.Unmask(url, ctx.Block.RazorMap) : url;
            to = EndpointResolver.PendingUrl(verb, unmasked);
        }

        _graph.Edges.Add(new Edge
        {
            From = ctx.Current, To = to, Kind = EdgeKind.HttpCall,
            Line = line, Resolution = raw
        });
    }

    private static bool TryResolvePlaceholder(Ctx ctx, string url, out string? pendingId)
    {
        foreach (var ph in RazorMasker.Placeholders(url))
        {
            if (!ctx.Block.RazorMap.TryGetValue(ph, out var expr)) continue;
            if (expr.Action is null) continue;
            pendingId = EndpointResolver.PendingId(expr.Controller, expr.Action);
            return true;
        }
        pendingId = null;
        return false;
    }

    /// Walks a Kendo/Telerik widget config object looking for DataSource
    /// transport URLs (read/update/create/destroy) and top-level content/url
    /// properties (Window, Dialog). Returns (verbLabel, urlExpression) pairs.
    private static IEnumerable<(string Verb, Node Url)> FindKendoUrls(ObjectExpression obj, string context = "")
    {
        foreach (var prop in obj.Properties)
        {
            if (prop is not ObjectProperty { Key: Identifier key } op) continue;
            var name = key.Name;

            switch (name)
            {
                case "read" or "update" or "create" or "destroy":
                    if (op.Value is StringLiteral or Literal { Value: string })
                        yield return (name, op.Value);
                    else if (op.Value is ObjectExpression nested)
                        foreach (var r in FindKendoUrls(nested, name)) yield return r;
                    break;

                case "url" when context.Length > 0:
                    yield return (context, op.Value);
                    break;

                case "content" when op.Value is StringLiteral or Literal { Value: string }:
                    yield return ("content", op.Value);
                    break;
                case "content" when op.Value is ObjectExpression nestedContent:
                    foreach (var r in FindKendoUrls(nestedContent, "content")) yield return r;
                    break;

                case "transport" or "dataSource" when op.Value is ObjectExpression nestedDs:
                    foreach (var r in FindKendoUrls(nestedDs, context)) yield return r;
                    break;
            }
        }
    }

    // ------------------------------------------------------------ fallbacks

    /// Regex sweep for blocks the parser rejected, so a broken file still
    /// contributes endpoint edges instead of disappearing entirely.
    private void FallbackScan(ScriptBlock block)
    {
        foreach (System.Text.RegularExpressions.Match m in
                 System.Text.RegularExpressions.Regex.Matches(
                     block.Code,
                     @"(?:fetch|\$\.(?:get|post|ajax|getJSON)|axios\.\w+)\s*\(\s*[""']([^""']+)[""']"))
        {
            var url = m.Groups[1].Value;
            _graph.Edges.Add(new Edge
            {
                From = block.ViewId,
                To = RazorMasker.IsPlaceholder(url) &&
                     block.RazorMap.TryGetValue(RazorMasker.Placeholders(url).First(), out var e) &&
                     e.Action is not null
                    ? EndpointResolver.PendingId(e.Controller, e.Action)
                    : EndpointResolver.PendingUrl("GET", url),
                Kind = EdgeKind.HttpCall,
                Resolution = "regex-fallback"
            });
        }
    }

    // ------------------------------------------------------------ utilities

    private static string FunctionId(ScriptBlock block, string name) =>
        $"js:{block.File}:{name}";

    private static string? StringOf(Node? n) => n switch
    {
        StringLiteral s => s.Value,
        Literal l when l.Value is string sv => sv,
        TemplateLiteral t => string.Concat(t.Quasis.Select(q => q.Value.Cooked ?? "")) + "{...}",
        BinaryExpression { Operator: Operator.Addition } b =>
            (StringOf(b.Left) ?? "") + (StringOf(b.Right) ?? "{...}"),
        Identifier => null,
        _ => null
    };

    private static string? ObjectProp(Node? n, string prop)
    {
        if (n is not ObjectExpression obj) return null;
        foreach (var p in obj.Properties)
            if (p is ObjectProperty { Key: Identifier k } op && k.Name == prop)
                return StringOf(op.Value);
            else if (p is ObjectProperty { Key: StringLiteral sk } sp && sk.Value == prop)
                return StringOf(sp.Value);
        return null;
    }

    private static string? OptionsVerb(Node? options) =>
        ObjectProp(options, "method")?.ToUpperInvariant();

    private static string SelectorOf(Node target) => target switch
    {
        CallExpression { Callee: Identifier { Name: "$" or "jQuery" } } c =>
            StringOf(c.Arguments.FirstOrDefault()) ?? "$",
        Identifier i => i.Name,
        MemberExpression { Property: Identifier p } => p.Name,
        _ => "el"
    };

    private static string[] Parameters(Node fn) => fn switch
    {
        IFunction f => f.Params.Select(p => p switch
        {
            Identifier i => i.Name,
            _ => "_"
        }).ToArray(),
        _ => Array.Empty<string>()
    };

    private static string? FindEnclosingClassName(Node node)
    {
        // Acornima does not expose parents; class name is resolved by the caller
        // when it walks ClassDeclaration. Returns null for standalone methods.
        return null;
    }
}
