/* Vehicle Cost Reports - Kendo/jQuery compatible, no PNG export */
(function(window,$){
    "use strict";
    var VCR = {};
    var state = { data:null, current:"vehicle", busy:false };

    function root(){ return $("#vehicleCostReports"); }
    function num(v){ var n=parseFloat(v); return isFinite(n)?n:0; }
    function money(v){ return "$"+num(v).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}); }
    function integer(v){ var n=parseInt(v,10); return isFinite(n)?n.toLocaleString():"-"; }
    function decimal(v){ return num(v).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}); }
    function safe(v){ return $("<div>").text(v==null?"":String(v)).html(); }
    function dateTime(v){
        if(!v) return "-";
        var d=new Date(v);
        return isNaN(d.getTime())?String(v):d.toLocaleString(undefined,{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"});
    }
    function setAll(selector, value){ $(selector).text(value); }
    function eachReport(fn){ root().find(".vcr-report").each(function(){fn($(this));}); }

    function setReportData(report,data){
        var r=$(report);
        var map={
            estimateNumber: data.EstimateNumber || root().data("part-num") || "-",
            vehicleDescription:data.VehicleDescription, vehicleSeries:data.VehicleSeries,
            vehicleMake:data.Make, vehicleModel:data.Model, vehicleYear:integer(data.Year),
            numberOfVehicles:integer(data.NumOfVehicles), vehicleEngine:data.Engine,
            vehicleTransmission:data.Transmission, vehicleDifferential:data.Differential,
            modifiedLastBy:data.ModifiedLastBy, modifiedLastDate:dateTime(data.ModifiedLastDate),
            totalHours:decimal(data.TotalLabourHours), totalEffectiveHours:decimal(data.TotalEffectiveHours),
            totalAdjustedHours:decimal(data.TotalAdjustedHours),
            stockPartsCount:integer(data.TotalStockPartsCount),
            nonStockPartsCount:integer(data.TotalNonStockPartsCount),
            rebuiltPartsCount:integer(data.TotalRebuiltPartsCount)
        };
        Object.keys(map).forEach(function(k){ r.find('[data-vcr="'+k+'"]').text(map[k]==null||map[k]===""?"-":map[k]); });
        r.find("[data-vcr-money]").each(function(){
            var key=$(this).attr("data-vcr-money");
            $(this).text(money(data[key]));
        });
        var total=num(data.MaterialTotalWithTax)+num(data.FinalLabourCost);
        r.find('[data-vcr="grandTotal"]').text(money(total));
        var parts=num(data.TotalStockPartsCount)+num(data.TotalNonStockPartsCount)+num(data.TotalRebuiltPartsCount);
        r.find('[data-vcr="materialCount"]').text(integer(parts)+" parts");
        var ml=data.MaterialLines||[], lt=data.LabourTasks||[];
        r.find('[data-vcr="materialLinesCount"]').text(integer(ml.length)+" items");
        r.find('[data-vcr="taskCount"]').text(integer(lt.length)+" tasks");
        buildMaterials(r,ml); buildLabour(r,lt);
    }

    function buildMaterials(r,lines){
        var body=r.find('[data-vcr-table="materials"]'); if(!body.length) return;
        if(!lines.length){body.html('<tr><td colspan="8" class="c">No material items found</td></tr>');return;}
        var totals={Stock:0,Rebuilt:0,"Non-Stock":0}, grand=0, html="";
        lines.forEach(function(x){
            var type=x.Type||"Stock", cost=num(x.TotalCost), cls=type.toLowerCase().replace(/-/g,"");
            totals[type]=(totals[type]||0)+cost; grand+=cost;
            var badge=cls==="nonstock"?"nonstock":cls;
            html+='<tr><td><span class="vcr-type vcr-type-'+badge+'">'+safe(type)+'</span></td>'+
                '<td>'+safe(x.StockCode||"-")+'</td><td>'+safe(x.CC||"-")+'</td><td>'+safe(x.Description||"N/A")+'</td>'+
                '<td class="r">'+decimal(x.Quantity)+'</td><td class="r">'+money(x.UnitCost)+'</td>'+
                '<td class="r">'+num(x.PercentUsage).toFixed(1)+'%</td><td class="r"><strong>'+money(cost)+'</strong></td></tr>';
        });
        ["Stock","Rebuilt","Non-Stock"].forEach(function(t){if(totals[t]>0)html+='<tr class="vcr-subtotal"><td colspan="7" class="r">Subtotal - '+t+'</td><td class="r">'+money(totals[t])+'</td></tr>';});
        html+='<tr class="vcr-grand-row"><td colspan="7" class="r">GRAND TOTAL</td><td class="r">'+money(grand)+'</td></tr>';
        body.html(html);
    }

    function buildLabour(r,tasks){
        var body=r.find('[data-vcr-table="labour"]'); if(!body.length) return;
        if(!tasks.length){body.html('<tr><td colspan="9" class="c">No labour tasks found</td></tr>');return;}
        var h=0,e=0,a=0,c=0,html="";
        tasks.forEach(function(x){
            h+=num(x.Hours);e+=num(x.EffectiveHours);a+=num(x.AdjustedHours);c+=num(x.TotalCost);
            html+='<tr><td>'+safe(x.Task||"Unnamed")+'</td><td>'+safe(x.LabourDefinition||"N/A")+'</td><td>'+safe(x.CC||"-")+'</td>'+
                '<td class="r">'+decimal(x.Hours)+'</td><td class="r">'+decimal(x.EffectiveHours)+'</td><td class="r">'+decimal(x.AdjustedHours)+'</td>'+
                '<td class="r">'+money(x.RatePerHour)+'</td><td class="r"><strong>'+money(x.TotalCost)+'</strong></td><td class="c">'+integer(x.Count)+'</td></tr>';
        });
        html+='<tr class="vcr-grand-row"><td colspan="3">TOTAL</td><td class="r">'+decimal(h)+'</td><td class="r">'+decimal(e)+'</td><td class="r">'+decimal(a)+'</td><td></td><td class="r">'+money(c)+'</td><td class="c">'+integer(tasks.length)+'</td></tr>';
        body.html(html);
    }

    function populate(data){
        state.data=data;
        eachReport(function(r){setReportData(r,data);});
        root().find("#vcrLoading").hide(); root().find("#vcrNoData").hide(); root().find("#vcrReportsHost").show();
        show(state.current,false);
    }

    function fetchData(){
        var el=root(), url=el.data("url"), id=el.data("part-num"), gt=el.data("grid-type");
        el.find("#vcrLoading").show(); el.find("#vcrNoData").hide(); el.find("#vcrReportsHost").hide();
        $.ajax({url:url,type:"GET",dataType:"json",timeout:30000,data:{id:id,gridType:gt}})
        .done(function(resp){
            if(resp && resp.Data && resp.Data.length){ console.log("Vehicle Cost Reports data loaded",resp.Data[0]); populate(resp.Data[0]); }
            else {el.find("#vcrLoading").hide();el.find("#vcrNoData").show();}
        })
        .fail(function(xhr,status,error){
            console.error("Vehicle Cost Reports load failed",status,error,xhr);
            el.find("#vcrLoading").hide();el.find("#vcrNoData").show();
        });
    }

    function show(type,announce){
        state.current=type;
        var r=root().find('.vcr-report[data-report-type="'+type+'"]');
        root().find(".vcr-report").removeClass("vcr-active").hide();
        r.addClass("vcr-active").show();
        if(announce) console.log("Vehicle Cost Report switched to",type);
    }

    function reportTitle(type){
        return {vehicle:"Vehicle_Estimate_Report",labour:"Labour_Details_Report",materials:"Materials_Estimate_Report",full:"Full_Vehicle_Estimate_Report"}[type]||"Vehicle_Report";
    }
    function ensureReady(){
        if(!state.data){ if(window.kendo&&kendo.alert)kendo.alert("Please wait until the estimate has finished loading."); return false; }
        return true;
    }

    function copy(type){
        if(!ensureReady())return;
        var r=root().find('.vcr-report[data-report-type="'+type+'"]')[0];
        if(!r)return;
        var html=r.outerHTML, text=r.innerText||r.textContent||"";
        if(navigator.clipboard && window.ClipboardItem){
            navigator.clipboard.write([new ClipboardItem({"text/html":new Blob([html],{type:"text/html"}),"text/plain":new Blob([text],{type:"text/plain"})})])
            .then(function(){alertMsg("Report copied to clipboard.");})
            .catch(function(){fallbackCopy(r,text);});
        }else fallbackCopy(r,text);
    }
    function fallbackCopy(r,text){
        var ta=document.createElement("textarea");ta.value=text;ta.style.position="fixed";ta.style.left="-10000px";document.body.appendChild(ta);ta.select();
        try{document.execCommand("copy");alertMsg("Report copied to clipboard.");}catch(e){alertMsg("Clipboard copy is not available in this browser.");}
        document.body.removeChild(ta);
    }
    function alertMsg(msg){ if(window.kendo&&kendo.alert)kendo.alert(msg); else window.alert(msg); }

    function pdf(type){
        if(!ensureReady()||state.busy)return;
        var r=root().find('.vcr-report[data-report-type="'+type+'"]')[0];
        if(!r)return;
        if(!window.kendo||!kendo.drawing||!kendo.drawing.drawDOM||!kendo.drawing.exportPDF||!kendo.saveAs){
            alertMsg("Kendo PDF export is not available on this page."); return;
        }
        state.busy=true;
        var clone=r.cloneNode(true);
        $(clone).find(".no-print,button,.k-button").remove();
        clone.style.display="block"; clone.style.width="1180px"; clone.style.maxWidth="1180px"; clone.style.background="#fff"; clone.style.boxShadow="none";
        var host=document.createElement("div");
        host.style.position="absolute";host.style.left="-20000px";host.style.top="0";host.style.width="1180px";host.style.background="#fff";host.style.visibility="visible";host.style.opacity="1";
        host.appendChild(clone);document.body.appendChild(host);
        try{
            void clone.offsetWidth;void clone.offsetHeight;
            if(clone.offsetWidth<=0||clone.offsetHeight<=0)throw new Error("PDF target has zero dimensions.");
            var req=kendo.drawing.drawDOM(clone,{paperSize:"Letter",landscape:true,margin:{top:".35in",bottom:".35in",left:".35in",right:".35in"},scale:.78,multiPage:true,avoidLinks:true,keepTogether:".vcr-section,.vcr-grand-total,.vcr-audit"});
            req.done(function(group){
                var p=kendo.drawing.exportPDF(group,{paperSize:"Letter",landscape:true,margin:{top:".35in",bottom:".35in",left:".35in",right:".35in"}});
                p.done(function(uri){
                    var id=String(state.data.EstimateNumber||root().data("part-num")||"Estimate").replace(/[^a-z0-9_.-]/gi,"_");
                    kendo.saveAs({dataURI:uri,fileName:reportTitle(type)+"_"+id+".pdf"});
                    cleanup();
                }).fail(function(e){cleanup();console.error(e);alertMsg("Error generating PDF.");});
            }).fail(function(e){cleanup();console.error(e);alertMsg("Error preparing PDF.");});
        }catch(e){cleanup();console.error(e);alertMsg("Error generating PDF: "+e.message);}
        function cleanup(){if(host.parentNode)host.parentNode.removeChild(host);state.busy=false;}
    }

    $(function(){
        var el=root(); if(!el.length)return;
        $("#vcrReportMenu").kendoContextMenu({
            target:"#vcrReportActions",showOn:"click",alignToAnchor:true,
            select:function(e){
                var item=$(e.item), action=item.data("vcr-action"), type=item.data("report");
                if(!action)return;
                if(action==="view")show(type,true);
                if(action==="copy")copy(type);
                if(action==="pdf")pdf(type);
            }
        });
        $("#vcrRetry").on("click",fetchData);
        fetchData();
    });

    VCR.show=show; VCR.copy=copy; VCR.pdf=pdf; VCR.reload=fetchData;
    window.VehicleCostReports=VCR;
})(window,jQuery);
