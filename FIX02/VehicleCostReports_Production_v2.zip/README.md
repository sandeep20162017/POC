# Vehicle Cost Reports - Production Package

## Files
Place the four report partials in `Views/Shared/`:
- `_Vehicle_Estimate_Report.cshtml`
- `_Labour_Details_Report.cshtml`
- `_MaterialsEstimate_Report.cshtml`
- `_Full_Vehicle_Estimate_Report.cshtml`

Also replace/update:
- `Views/Shared/_VehicleTotalCost.cshtml`
- `wwwroot/css/vehicle-cost-reports.css`
- `wwwroot/js/vehicle-cost-reports.js`

## User experience
The Vehicle Cost Estimate tab opens with **Vehicle Estimate Report** by default.

The vertical 3-dot button provides:
1. View Vehicle Estimate Report
2. View Labour Details Report
3. View Materials Estimate Report
4. View Full Vehicle Estimate Report
5-12. Copy/PDF actions for each report

The three additional reports are rendered in the same page and switched client-side. This avoids requiring new controller actions or additional HTTP requests.

## API
The existing endpoint is retained:
`/TotalCost/GetTotalCostInEstimates?id={id}&gridType={gridType}`

Expected response shape:
`{ Data: [ { ... } ] }`

Existing fields used by the original report are preserved, including:
VehicleSeries, VehicleDescription, Make, Model, Year, NumOfVehicles,
Engine, Transmission, Differential, ModifiedLastBy, ModifiedLastDate,
TotalStockPartsCount, TotalNonStockPartsCount, TotalRebuiltPartsCount,
SCPartsMaterialCost, NSCSCPartsMaterialCost, RBPartsMaterialCost,
MaterialTotalCostNoTax, MaterialTotalTaxAmount, MaterialTotalWithTax,
LabourFringe, LabourBenefits, BlendedFringeBenefitCost, LabourOverhead,
FinalLabourCost, TotalLabourHours, TotalEffectiveHours, TotalAdjustedHours,
MaterialLines and LabourTasks.

## Dependencies
- ASP.NET Core Razor
- jQuery
- Telerik/Kendo UI
- Kendo Drawing/PDF support

No PNG export is included.

## PDF design
PDFs use Letter landscape, printer-friendly spacing, multi-page Kendo drawing, and a real off-screen layout host with non-zero dimensions. The report itself is never hidden while Kendo measures it, avoiding the zero-width/height and blank-page failure mode encountered previously.

## CSS
The UI retains the original dark-blue/light-gray visual language. Print/PDF output is designed to remain readable on black-and-white printers.
