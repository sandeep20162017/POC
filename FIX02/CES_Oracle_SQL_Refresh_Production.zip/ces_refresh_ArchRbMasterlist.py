# ============================================================
# ces_refresh_ArchRbMasterlist.py
# Oracle CES -> SQL Server CES / SBCES
# Production refresh script generated from supplied DDL
# ============================================================

import sys
import logging
from datetime import datetime
import pyodbc
import oracledb

ORACLE_DSN = "//ocipr-wersc-scan.ttcociclientsub.ttcocivcn.oraclevcn.com:1521/ces_prd_svc.int.ttc.ca"
ORACLE_USER = "CES"
ORACLE_PASSWORD = "cesprd1210"

SQL_CONN_STR = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=SQL2022UAT;"
    "DATABASE=CES;"
    "UID=cesuser;"
    "PWD=CESUser#UAT;"
    "TrustServerCertificate=Yes;"
)

SQL_SCHEMA = "SBCES"
ORACLE_TABLE = "ARCH_RB_MASTERLIST"
SQL_TABLE = "ArchRbMasterlist"

LOG_FILE = f"{SQL_TABLE}_refresh.log"

logger = logging.getLogger(SQL_TABLE)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
    console = logging.StreamHandler(sys.stdout)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
    handler.setFormatter(fmt)
    console.setFormatter(fmt)
    logger.addHandler(handler)
    logger.addHandler(console)

def get_oracle_conn():
    return oracledb.connect(
        user=ORACLE_USER,
        password=ORACLE_PASSWORD,
        dsn=ORACLE_DSN
    )

def get_sql_conn():
    conn = pyodbc.connect(SQL_CONN_STR, timeout=30)
    cur = conn.cursor()
    cur.execute("SET ANSI_WARNINGS OFF;")
    cur.close()
    return conn

def get_oracle_count(conn):
    cur = conn.cursor()
    try:
        cur.execute(f"SELECT COUNT(*) FROM {ORACLE_TABLE}")
        return int(cur.fetchone()[0])
    finally:
        cur.close()

def get_sql_count(conn):
    cur = conn.cursor()
    try:
        cur.execute(f"SELECT COUNT(*) FROM {SQL_SCHEMA}.{SQL_TABLE}")
        return int(cur.fetchone()[0])
    finally:
        cur.close()

def delete_sql_table(conn):
    sql = f"DELETE FROM {SQL_SCHEMA}.{SQL_TABLE}"
    cur = conn.cursor()
    try:
        cur.execute(sql)
        deleted = cur.rowcount
        conn.commit()
        logger.info("Deleted existing SQL rows: %s", deleted)
    except Exception:
        conn.rollback()
        logger.exception("DELETE failed for %s", SQL_TABLE)
        raise
    finally:
        cur.close()

def fetch_oracle_rows(conn):
    sql = f"""
        SELECT
            ARCH_RB_MASTERLIST_ID,
            MMS_STOCK_CODE,
            ITEM_REF_NUMBER,
            DETAILED_DESC,
            KEYWORD,
            CORE_PART_NUM,
            REBUILT_STOCK_NUM,
            CORE_CHARGE,
            JOB_NUMBER,
            DATE_ARCHIVED,
            ARCHIVED_BY,
            ESTIMATED_COST,
            SOP_NUMBER,
            LABOUR_COST,
            LABOUR_OVERHEAD_AMOUNT,
            LABOUR_TOTAL,
            MATERIALS_TOTAL,
            TOTAL_REBUILT_PART_COST,
            TAX_TOTAL,
            TOTAL_COST_TAX
        FROM {ORACLE_TABLE}
    """
    cur = conn.cursor()
    try:
        cur.execute(sql)
        return cur.fetchall()
    finally:
        cur.close()

def insert_rows(conn, rows):
    sql = f"""
        INSERT INTO {SQL_SCHEMA}.{SQL_TABLE} (
            ArchRbMasterlistId,
            MmsStockCode,
            ItemRefNumber,
            DetailedDesc,
            Keyword,
            CorePartNum,
            RebuiltStockNum,
            CoreCharge,
            JobNumber,
            DateEntered,
            EnteredBy,
            EstimatedCost,
            SopNumber,
            LabourCost,
            LabourOverheadAmount,
            LabourTotal,
            MaterialsTotal,
            TotalRebuiltPartCost,
            TaxTotal,
            TotalCostTax
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    success = 0
    failed = 0
    cur = conn.cursor()

    try:
        # Fast path.
        cur.fast_executemany = True
        try:
            cur.executemany(sql, rows)
            success = len(rows)
            conn.commit()
            logger.info("Bulk insert succeeded: %s rows", success)
            return success, failed
        except Exception as bulk_error:
            conn.rollback()
            logger.warning("Bulk insert failed; retrying row-by-row. Error: %s", bulk_error)

        # Row-by-row fallback gives exact rejected-row diagnostics.
        cur.fast_executemany = False
        for idx, row in enumerate(rows, start=1):
            try:
                cur.execute(sql, row)
                success += 1
            except Exception as exc:
                failed += 1
                logger.error(
                    "ROW FAILED | row=%s | error=%s | data=%r",
                    idx, exc, row
                )
        conn.commit()
        return success, failed
    except Exception:
        conn.rollback()
        logger.exception("Insert transaction failed")
        raise
    finally:
        cur.close()

def main():
    mode = __import__("os").environ.get("CES_REFRESH_MODE", "FULL").upper()
    started = datetime.now()
    oracle_conn = None
    sql_conn = None

    logger.info("=" * 90)
    logger.info("START REFRESH | Oracle=%s | SQL=%s.%s | MODE=%s",
                ORACLE_TABLE, SQL_SCHEMA, SQL_TABLE, mode)

    try:
        oracle_conn = get_oracle_conn()
        sql_conn = get_sql_conn()

        oracle_count = get_oracle_count(oracle_conn)
        logger.info("ORACLE COUNT | %s = %s", ORACLE_TABLE, oracle_count)

        if mode == "DELETE":
            delete_sql_table(sql_conn)
            sql_count = get_sql_count(sql_conn)
            logger.info("SQL COUNT AFTER DELETE | %s.%s = %s",
                        SQL_SCHEMA, SQL_TABLE, sql_count)
            return 0

        if mode == "INSERT":
            rows = fetch_oracle_rows(oracle_conn)
            logger.info("FETCHED FROM ORACLE | %s rows", len(rows))
            if len(rows) != oracle_count:
                raise RuntimeError(
                    f"Oracle row count changed during fetch: COUNT={oracle_count}, FETCHED={len(rows)}"
                )
            success, failed = insert_rows(sql_conn, rows)
            sql_count = get_sql_count(sql_conn)
            logger.info("SQL COUNT | %s.%s = %s", SQL_SCHEMA, SQL_TABLE, sql_count)
            logger.info("RESULT | Oracle=%s | Inserted=%s | Failed=%s | SQL=%s",
                        oracle_count, success, failed, sql_count)
            if failed == 0 and sql_count == oracle_count:
                logger.info("STATUS | SUCCESS | COUNTS MATCH")
                return 0
            logger.error("STATUS | FAILED/REVIEW")
            return 2

        if mode != "FULL":
            raise ValueError("CES_REFRESH_MODE must be FULL, DELETE, or INSERT")

        delete_sql_table(sql_conn)
        rows = fetch_oracle_rows(oracle_conn)
        logger.info("FETCHED FROM ORACLE | %s rows", len(rows))
        success, failed = insert_rows(sql_conn, rows)
        sql_count = get_sql_count(sql_conn)
        logger.info("RESULT | Oracle=%s | Inserted=%s | Failed=%s | SQL=%s",
                    oracle_count, success, failed, sql_count)
        return 0 if failed == 0 and sql_count == oracle_count else 2

    except Exception as exc:
        logger.exception("FATAL ERROR | %s", exc)
        return 1
    finally:
        if oracle_conn is not None:
            try: oracle_conn.close()
            except Exception: pass
        if sql_conn is not None:
            try: sql_conn.close()
            except Exception: pass
        logger.info("END REFRESH | elapsed=%s", datetime.now() - started)
        logger.info("=" * 90)

if __name__ == "__main__":
    sys.exit(main())

    started = datetime.now()
    oracle_conn = None
    sql_conn = None

    logger.info("=" * 90)
    logger.info("START REFRESH | Oracle=%s | SQL=%s.%s", ORACLE_TABLE, SQL_SCHEMA, SQL_TABLE)

    try:
        oracle_conn = get_oracle_conn()
        sql_conn = get_sql_conn()

        oracle_count = get_oracle_count(oracle_conn)
        logger.info("ORACLE COUNT | %s = %s", ORACLE_TABLE, oracle_count)

        # IMPORTANT: the BAT file controls FK-safe execution order.
        # This script only refreshes its own target table.
        delete_sql_table(sql_conn)

        rows = fetch_oracle_rows(oracle_conn)
        logger.info("FETCHED FROM ORACLE | %s rows", len(rows))

        if len(rows) != oracle_count:
            logger.error(
                "ORACLE FETCH COUNT MISMATCH | COUNT(*)=%s | FETCHED=%s",
                oracle_count, len(rows)
            )
            raise RuntimeError("Oracle row count changed during fetch; refresh aborted.")

        success, failed = insert_rows(sql_conn, rows)

        sql_count = get_sql_count(sql_conn)
        logger.info("SQL COUNT | %s.%s = %s", SQL_SCHEMA, SQL_TABLE, sql_count)
        logger.info(
            "RESULT | Oracle=%s | Inserted=%s | Failed=%s | SQL=%s",
            oracle_count, success, failed, sql_count
        )

        if failed == 0 and sql_count == oracle_count:
            logger.info("STATUS | SUCCESS | COUNTS MATCH")
            return 0

        logger.error("STATUS | FAILED/REVIEW | COUNTS DO NOT MATCH OR ROWS FAILED")
        return 2

    except Exception as exc:
        logger.exception("FATAL ERROR | %s", exc)
        return 1
    finally:
        if oracle_conn is not None:
            try:
                oracle_conn.close()
            except Exception:
                pass
        if sql_conn is not None:
            try:
                sql_conn.close()
            except Exception:
                pass

        logger.info("END REFRESH | elapsed=%s", datetime.now() - started)
        logger.info("=" * 90)

if __name__ == "__main__":
    sys.exit(main())
