@echo off
setlocal EnableExtensions EnableDelayedExpansion
title CES Oracle to SQL Server Refresh

echo ================================================================
echo CES ORACLE -> SQL SERVER REFRESH
echo ================================================================
echo.
if not exist logs mkdir logs
set MASTER_LOG=logs\ces_refresh_all.log
echo [%date% %time%] START > "%MASTER_LOG%"

echo [PHASE 1] DELETE CHILD TABLES FIRST
set CES_REFRESH_MODE=DELETE
echo Deleting ArchMbEmployeeLabour...
python ces_refresh_ArchMbEmployeeLabour.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchMbListBuses...
python ces_refresh_ArchMbListBuses.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchMbmaterielsCcTotal...
python ces_refresh_ArchMbmaterielsCcTotal.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchMbNscPartsUsed...
python ces_refresh_ArchMbNscPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchMbScPartsUsed...
python ces_refresh_ArchMbScPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchRbEmployeeLabour...
python ces_refresh_ArchRbEmployeeLabour.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchRbLabourCcTotal...
python ces_refresh_ArchRbLabourCcTotal.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchRbListBuses...
python ces_refresh_ArchRbListBuses.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchRbMaterialsCcTotal...
python ces_refresh_ArchRbMaterialsCcTotal.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchRbNscPartsUsed...
python ces_refresh_ArchRbNscPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchRbScPartsUsed...
python ces_refresh_ArchRbScPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchVehEmployeeLabour...
python ces_refresh_ArchVehEmployeeLabour.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchVehKits...
python ces_refresh_ArchVehKits.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchVehLabourCcTotal...
python ces_refresh_ArchVehLabourCcTotal.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchVehMaterialsCcTotal...
python ces_refresh_ArchVehMaterialsCcTotal.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchVehNscPartsUsed...
python ces_refresh_ArchVehNscPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchVehScPartsUsed...
python ces_refresh_ArchVehScPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED

echo [PHASE 1B] DELETE PARENT TABLES
echo Deleting ArchMbMasterlist...
python ces_refresh_ArchMbMasterlist.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchRbMasterlist...
python ces_refresh_ArchRbMasterlist.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Deleting ArchVehicleList...
python ces_refresh_ArchVehicleList.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED

echo [PHASE 2] INSERT PARENT TABLES FIRST
set CES_REFRESH_MODE=INSERT
echo Inserting ArchMbMasterlist...
python ces_refresh_ArchMbMasterlist.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchRbMasterlist...
python ces_refresh_ArchRbMasterlist.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchVehicleList...
python ces_refresh_ArchVehicleList.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED

echo [PHASE 2B] INSERT CHILD TABLES
echo Inserting ArchMbEmployeeLabour...
python ces_refresh_ArchMbEmployeeLabour.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchMbListBuses...
python ces_refresh_ArchMbListBuses.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchMbmaterielsCcTotal...
python ces_refresh_ArchMbmaterielsCcTotal.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchMbNscPartsUsed...
python ces_refresh_ArchMbNscPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchMbScPartsUsed...
python ces_refresh_ArchMbScPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchRbEmployeeLabour...
python ces_refresh_ArchRbEmployeeLabour.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchRbLabourCcTotal...
python ces_refresh_ArchRbLabourCcTotal.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchRbListBuses...
python ces_refresh_ArchRbListBuses.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchRbMaterialsCcTotal...
python ces_refresh_ArchRbMaterialsCcTotal.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchRbNscPartsUsed...
python ces_refresh_ArchRbNscPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchRbScPartsUsed...
python ces_refresh_ArchRbScPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchVehEmployeeLabour...
python ces_refresh_ArchVehEmployeeLabour.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchVehKits...
python ces_refresh_ArchVehKits.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchVehLabourCcTotal...
python ces_refresh_ArchVehLabourCcTotal.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchVehMaterialsCcTotal...
python ces_refresh_ArchVehMaterialsCcTotal.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchVehNscPartsUsed...
python ces_refresh_ArchVehNscPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED
echo Inserting ArchVehScPartsUsed...
python ces_refresh_ArchVehScPartsUsed.py >> "%MASTER_LOG%" 2>&1
if errorlevel 1 goto :FAILED

set CES_REFRESH_MODE=
echo.
echo ================================================================
echo REFRESH COMPLETE - REVIEW logs\ces_refresh_all.log
echo ================================================================
echo [%date% %time%] SUCCESS >> "%MASTER_LOG%"
exit /b 0

:FAILED
set RC=%ERRORLEVEL%
set CES_REFRESH_MODE=
echo.
echo ================================================================
echo REFRESH FAILED - RETURN CODE %RC%
echo Review logs\ces_refresh_all.log and individual *_refresh.log files.
echo ================================================================
echo [%date% %time%] FAILED RC=%RC% >> "%MASTER_LOG%"
exit /b %RC%
