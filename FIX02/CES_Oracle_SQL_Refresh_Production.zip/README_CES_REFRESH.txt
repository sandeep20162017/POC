CES Oracle -> SQL Server Refresh Package
==========================================

Files:
- One ces_refresh_<SQLTableName>.py per supplied table.
- ces_refresh_all.bat performs a two-phase FK-safe refresh:
  1) delete children, then parents
  2) insert parents, then children
- logs\ces_refresh_all.log is the consolidated BAT log.
- Each Python script writes <SQLTable>_refresh.log.

Important schema observations from the supplied DDL:
1. Identity-only SQL columns are intentionally NOT inserted:
   - ArchMbEmployeeLabour.Id
   - ArchRbEmployeeLabour.Id
   - ArchVehEmployeeLabour.ID
2. ArchMbMasterlist:
   Oracle DATE_ARCHIVED maps to SQL DateEntered.
   Oracle ARCHIVED_BY is not present in the SQL DDL as a matching field, so it is NOT inserted.
3. ArchRbMasterlist:
   Oracle DATE_ARCHIVED -> SQL DateEntered
   Oracle ARCHIVED_BY -> SQL EnteredBy
4. ArchVehicleList:
   Oracle DATE_ARCHIVED -> SQL DateEntered
   Oracle ARCHIVED_BY -> SQL EnteredBy
5. The supplied text contains an apparent duplicate/mismatch:
   ARCH_RB_LABOUR_CC_TOTAL is shown against SQL ArchMblabourCcTotal in one section,
   while a later section also supplies SQL ArchRbLabourCcTotal for the same Oracle
   ARCH_RB_LABOUR_CC_TOTAL structure.
   No second Oracle source table was supplied. Both SQL targets therefore cannot be
   independently populated from the same Oracle table without a business rule.
   The generated package retains the supplied mappings and should be reviewed before
   production execution.
6. ArchRbMasterlist has an FK to SBCES.RbMasterlist(RebuiltStockNum), which is outside
   the supplied table set. The target RbMasterlist data must already exist.
7. The SQL foreign keys shown in the supplied DDL are sometimes NOCHECK/disabled.
   The BAT nevertheless uses parent-first insertion so it is safe if constraints are
   later enabled.
8. Scripts report Oracle COUNT(*), fetched count, inserted count, failed count, and
   final SQL COUNT. A row-by-row fallback logs rejected rows after bulk insert failure.

Dependencies represented by the supplied FK definitions:
- ArchMbMasterlist
  -> ArchMbEmployeeLabour
  -> ArchMbListBuses
  -> ArchMbmaterielsCcTotal
  -> ArchMbNscPartsUsed
  -> ArchMbScPartsUsed

- ArchRbMasterlist
  -> ArchRbEmployeeLabour
  -> ArchRbLabourCcTotal
  -> ArchRbListBuses
  -> ArchRbMaterialsCcTotal
  -> ArchRbNscPartsUsed
  -> ArchRbScPartsUsed

- ArchVehicleList
  -> ArchVehEmployeeLabour
  -> ArchVehKits
  -> ArchVehLabourCcTotal
  -> ArchVehMaterialsCcTotal
  -> ArchVehNscPartsUsed
  -> ArchVehScPartsUsed
